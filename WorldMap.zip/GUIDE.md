# 세계 관광지 아틀라스 — 수정 가이드

> **보기 전에:** `start.bat`을 더블클릭해 서버를 켜고 `http://localhost:8765` 로 확인하세요.

---

## 파일 구조 한눈에 보기

```
WorldMap/
├── data/
│   ├── countries.json          ← 나라 목록 (지도 마커 + 카드)
│   ├── cities/
│   │   └── kr.json             ← 국가별 도시 목록 (kr = 한국)
│   └── spots/
│       └── seoul.json          ← 도시별 관광지 목록
├── content/
│   ├── countries/
│   │   └── kr.md               ← 국가 블로그 본문
│   └── cities/
│       └── seoul.md            ← 도시 블로그 본문
└── images/
    └── city-illustrations/     ← 도시 배경 이미지 (선택)
```

---

## 1. 나라·도시 아이콘(썸네일) 바꾸기

### 파일: `data/countries.json` 또는 `data/cities/[국가코드].json`

각 항목의 `"thumbnail"` 값을 원하는 이미지 URL로 바꾸면 됩니다.

```json
{
  "id": "kr",
  "name": "대한민국",
  "thumbnail": "https://picsum.photos/seed/korea/120/120",  ← 이 부분
  ...
}
```

**옵션 A — 로컬 이미지 사용 (권장)**
1. `images/` 폴더에 이미지 파일을 넣습니다 (WebP 또는 JPG, 120×120px 권장)
2. `"thumbnail": "images/korea.webp"` 로 수정

**옵션 B — 다른 웹 이미지 URL 사용**
- `"thumbnail": "https://example.com/my-image.jpg"` 로 수정
- CORS를 허용하는 이미지 URL이어야 합니다

**옵션 C — picsum.photos 시드 변경 (가장 간단)**
- `seed/korea` 부분만 바꾸면 다른 랜덤 이미지가 나옵니다
- 예: `"thumbnail": "https://picsum.photos/seed/korea2/120/120"`

---

## 2. 나라 추가하기

### 필요한 작업: 파일 2개 수정/생성

#### ① `data/countries.json` 에 항목 추가

마지막 `}` 뒤에 `,` 를 붙이고 아래 형식으로 추가합니다.

```json
{
  "id": "vn",                                          ← 국가 코드 (소문자 2자리 ISO)
  "name": "베트남",                                    ← 한국어 이름
  "nameEn": "Vietnam",                                 ← 영어 이름
  "numericId": 704,                                    ← ISO 숫자 코드 (아래 표 참고)
  "coord": [108.0, 16.0],                              ← [경도, 위도] (지도 마커 위치)
  "thumbnail": "https://picsum.photos/seed/vietnam/120/120",
  "summary": "하롱베이와 쌀국수의 나라"               ← 카드 아래 짧은 소개 (50자 이내)
}
```

**주요 국가 numericId 참고표**

| 국가 | 코드 | numericId |
|------|------|-----------|
| 베트남 | vn | 704 |
| 태국 | th | 764 |
| 인도네시아 | id | 360 |
| 싱가포르 | sg | 702 |
| 말레이시아 | my | 458 |
| 포르투갈 | pt | 620 |
| 스웨덴 | se | 752 |
| 캐나다 | ca | 124 |
| 브라질 | br | 76 |
| 아르헨티나 | ar | 32 |
| 이집트 | eg | 818 |
| 케냐 | ke | 404 |
| 멕시코 | mx | 484 |
| 체코 | cz | 203 |

> 국가 코드와 numericId 전체 목록: https://ko.wikipedia.org/wiki/ISO_3166-1

#### ② `data/cities/[국가코드].json` 생성

도시가 없어도 빈 파일이 있어야 클릭했을 때 오류가 안 납니다.

```json
[]
```

도시가 있다면 아래 **3번 도시 추가하기** 참고.

---

## 3. 도시 추가하기

### 파일: `data/cities/[국가코드].json`

파일이 없으면 새로 만들고, 있으면 배열에 항목을 추가합니다.

```json
[
  {
    "id": "hanoi",                                     ← 도시 고유 ID (영문 소문자)
    "countryId": "vn",                                 ← 국가 코드 (countries.json의 id)
    "name": "하노이",                                  ← 한국어 이름
    "nameEn": "Hanoi",                                 ← 영어 이름
    "coord": [105.8412, 21.0278],                      ← [경도, 위도]
    "thumbnail": "https://picsum.photos/seed/hanoi/120/120",
    "summary": "베트남의 수도, 천년 역사의 도시"
  }
]
```

> **좌표 찾는 법:** Google Maps에서 원하는 도시를 클릭하면 하단에 `위도, 경도` 표시됨.
> JSON에 넣을 때는 `[경도, 위도]` 순서 (반대임에 주의).

---

## 4. 관광지(스팟) 추가하기

### 파일: `data/spots/[도시ID].json`

파일이 없으면 새로 만들고, 있으면 배열에 항목을 추가합니다.

```json
[
  {
    "id": "hoan-kiem",                                 ← 관광지 고유 ID (영문 소문자, 하이픈)
    "name": "호안끼엠 호수",                           ← 한국어 이름
    "category": "자연·역사",                           ← 아래 카테고리 목록 참고
    "rating": 4.7,                                     ← 평점 (0.0 ~ 5.0)
    "coord": [105.8527, 21.0285],                      ← [경도, 위도]
    "x": 50,                                           ← 도시 배경 이미지 위 핀 위치 (가로 %)
    "y": 40,                                           ← 도시 배경 이미지 위 핀 위치 (세로 %)
    "image": "https://picsum.photos/seed/hoankiem/400/300",
    "description": "하노이 중심부에 위치한 호수. 거북 탑과 옥산 사당이 있는 하노이의 상징."
  }
]
```

**사용 가능한 카테고리 (배지 색상이 자동으로 결정됨)**

| 카테고리 | 색상 |
|----------|------|
| 역사 | 파란색 |
| 자연 | 초록색 |
| 문화 | 주황색 |
| 예술 | 보라색 |
| 쇼핑 | 빨간색 |
| 현대 | 파란색 |
| 체험 | 초록색 |
| 관광 | 청록색 |
| 미식 | 노란색 |
| 종교 | 올리브색 |

> `"category"` 에 위 단어 중 하나가 포함되어 있으면 해당 색상이 적용됩니다.
> 예: `"역사·문화"`, `"자연·체험"` 도 가능합니다.

---

## 5. 국가 블로그 작성/수정하기

### 파일: `content/countries/[국가코드].md`

마크다운 형식으로 자유롭게 작성합니다.

```markdown
# 베트남 — 하롱베이와 쌀국수의 나라

![베트남](https://picsum.photos/seed/vietnam-banner/1200/400)

첫 번째 단락을 여기에 씁니다. 이 단락의 앞 200자가 국가 카드 미리보기로 자동 표시됩니다.

## 섹션 제목

본문 내용...

## 또 다른 섹션

내용...
```

**규칙**
- 파일명: 국가 코드 소문자 + `.md` (예: `vn.md`)
- 맨 위 `# 제목` 은 블로그 제목
- `![설명](URL)` 로 이미지 삽입
- `##` 소제목으로 섹션 구분

---

## 6. 도시 블로그 작성/수정하기

### 파일: `content/cities/[도시ID].md`

국가 블로그와 동일한 마크다운 형식입니다.

```markdown
# 하노이 — 천년 역사의 베트남 수도

![하노이](https://picsum.photos/seed/hanoi-banner/1200/400)

첫 단락 내용 (도시 화면 상단 미리보기로 자동 표시됩니다)...

## 올드 쿼터

내용...

## 먹거리

내용...
```

**규칙**
- 파일명: 도시 ID + `.md` (예: `hanoi.md`)
- 파일이 없어도 오류는 나지 않습니다 (블로그 섹션만 안 나옴)

---

## 7. 새 나라를 처음부터 추가하는 전체 순서

아래 순서대로 하면 됩니다. **①~③만 해도 지도에 나라가 표시됩니다.**

```
① data/countries.json     → 나라 항목 추가
② data/cities/vn.json     → 생성 (최소 [])
③ 브라우저에서 확인       → 지도에 마커 표시
④ data/cities/vn.json     → 도시 추가
⑤ data/spots/hanoi.json   → 관광지 추가
⑥ content/countries/vn.md → 국가 블로그 작성
⑦ content/cities/hanoi.md → 도시 블로그 작성
```

---

## 8. 자주 쓰는 이미지 URL 패턴

이미지 URL이 없을 때 임시로 쓸 수 있는 무료 서비스입니다.

```
썸네일 (120×120):  https://picsum.photos/seed/[키워드]/120/120
관광지 (400×300):  https://picsum.photos/seed/[키워드]/400/300
배너 (1200×400):   https://picsum.photos/seed/[키워드]/1200/400
```

`[키워드]` 는 아무 영문 단어나 가능합니다. 같은 키워드는 항상 같은 이미지가 나옵니다.

---

## 빠른 체크리스트

나라 추가 후 지도에 안 나올 때:
- [ ] `numericId` 가 올바른 ISO 숫자 코드인가?
- [ ] `coord` 가 `[경도, 위도]` 순서인가? (위도·경도 반대 아닌지)
- [ ] JSON 문법 오류 없는가? (마지막 항목 뒤에 `,` 없어야 함)

클릭했을 때 오류가 날 때:
- [ ] `data/cities/[국가코드].json` 파일이 존재하는가?
- [ ] 파일 내용이 최소 `[]` 인가?

블로그가 안 나올 때:
- [ ] `content/countries/[코드].md` 파일이 존재하는가?
- [ ] 파일이 UTF-8 인코딩으로 저장되어 있는가?

---

## 9. GitHub Pages에 배포하기

빌드 과정 없이 폴더 그대로 올리면 됩니다.

#### ① GitHub 저장소 만들기

1. [github.com](https://github.com) → New repository
2. 저장소 이름 입력 (예: `worldmap`)
3. Public 선택 → Create repository

#### ② 파일 올리기

터미널(명령 프롬프트)에서 WorldMap 폴더 안에서 실행:

```bash
git init
git add .
git commit -m "첫 배포"
git branch -M main
git remote add origin https://github.com/[내아이디]/worldmap.git
git push -u origin main
```

#### ③ GitHub Pages 활성화

1. 저장소 → Settings → Pages
2. Source: `Deploy from a branch`
3. Branch: `main` / `/ (root)` 선택 → Save
4. 약 1~2분 후 `https://[내아이디].github.io/worldmap/` 에서 접속 가능

> **주의:** GitHub Pages는 HTTPS이므로 외부 이미지(picsum.photos 등)도 HTTPS여야 합니다. 현재 프로젝트는 모두 HTTPS 또는 로컬 파일이므로 문제없습니다.

---

## 10. Hugo 사이트에 통합하기

Hugo 사이트에 이 지도를 페이지로 추가하는 방법입니다.

#### 방법 A — static 폴더에 복사 (가장 간단)

Hugo 프로젝트의 `static/` 폴더에 WorldMap 폴더 전체를 복사합니다.

```
hugo-site/
└── static/
    └── worldmap/          ← WorldMap 폴더 전체 복사
        ├── index.html
        ├── app.js
        └── ...
```

빌드 후 `https://[사이트주소]/worldmap/` 으로 접속 가능.

#### 방법 B — Hugo 페이지에 iframe으로 삽입

Hugo 마크다운 파일에 아래 코드 추가:

```html
<iframe src="/worldmap/" width="100%" height="800px" frameborder="0"></iframe>
```

#### 방법 C — Hugo 페이지에 직접 embed

Hugo 레이아웃 파일(`layouts/_default/single.html`)에서 직접 D3 지도를 불러올 수도 있습니다. 이 경우 `app.js`를 Hugo 테마 `assets/`에 넣고 Hugo의 파이프라인으로 관리합니다 (고급).

---

## 파일 구조 전체 보기

```
WorldMap/
├── index.html              ← 진입점 (건드리지 않아도 됨)
├── app.js                  ← 지도·라우팅·렌더링 전체 로직
├── style.css               ← 전체 스타일
├── start.bat               ← 로컬 서버 실행 (더블클릭)
├── .nojekyll               ← GitHub Pages Jekyll 비활성화
├── GUIDE.md                ← 이 파일
├── favicon.ico
├── vendor/
│   ├── d3.min.js
│   ├── topojson-client.min.js
│   ├── marked.min.js
│   ├── osmtogeojson.min.js
│   ├── world-110m.json     ← 세계 지도 데이터
│   └── flags/              ← 국기 SVG (101개, 로컬)
│       ├── kr.svg
│       ├── jp.svg
│       └── ...
├── data/
│   ├── countries.json      ← 나라 목록
│   ├── stats.json          ← 통계 (개국·도시·관광지 수)
│   ├── districts-config.json
│   ├── cities/             ← 국가별 도시 목록
│   │   └── kr.json
│   └── spots/              ← 도시별 관광지 목록
│       └── seoul.json
├── content/
│   ├── countries/          ← 국가 블로그 (마크다운)
│   │   └── kr.md
│   └── cities/             ← 도시 블로그 (마크다운)
│       └── seoul.md
└── images/
    └── city-illustrations/ ← 도시 배경 이미지 (선택)
