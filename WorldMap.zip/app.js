'use strict';

/* ── 캐시 & 데이터 로더 ─────────────────────────────────────── */
const _cache = {};

async function fetchJSON(url) {
  if (_cache[url]) return _cache[url];
  const r = await fetch(url, { cache: 'no-store' });
  if (!r.ok) throw new Error(`fetch 실패: ${url}`);
  return (_cache[url] = await r.json());
}

async function fetchText(url) {
  if (_cache[url] !== undefined) return _cache[url];
  const r = await fetch(url, { cache: 'no-store' });
  return (_cache[url] = r.ok ? await r.text() : null);
}

/* ── 공통 헬퍼 ─────────────────────────────────────────────── */

// 즐겨찾기 유틸 (localStorage)
function _getFavs() { try { return JSON.parse(localStorage.getItem('wm_favs') || '[]'); } catch { return []; } }
function _toggleFav(cityId) {
  const favs = _getFavs();
  const idx = favs.indexOf(cityId);
  if (idx >= 0) favs.splice(idx, 1); else favs.push(cityId);
  localStorage.setItem('wm_favs', JSON.stringify(favs));
  return idx < 0; // true = 새로 추가됨
}

// 국가 ID → 지역 매핑
const _REGION_MAP = {
  kr:'아시아', jp:'아시아', cn:'아시아', in:'아시아', th:'아시아', vn:'아시아', tr:'아시아',
  fr:'유럽', it:'유럽', es:'유럽', de:'유럽', gb:'유럽', gr:'유럽', pt:'유럽', nl:'유럽',
  us:'아메리카', br:'아메리카', mx:'아메리카',
  eg:'아프리카', ke:'아프리카', ma:'아프리카', za:'아프리카',
  ru:'유럽', se:'유럽', cz:'유럽', hu:'유럽', pl:'유럽', no:'유럽', ch:'유럽', dk:'유럽', at:'유럽', fi:'유럽', be:'유럽',
  sg:'아시아', id:'아시아', il:'아시아', ae:'아시아', kh:'아시아', jo:'아시아', np:'아시아', lk:'아시아', ph:'아시아', mm:'아시아',
  tz:'아프리카', et:'아프리카',
  is:'유럽',
  ca:'아메리카', ar:'아메리카', cl:'아메리카', co:'아메리카', pe:'아메리카', cu:'아메리카', pa:'아메리카',
  gh:'아프리카',
  nz:'오세아니아', au:'오세아니아'
};
function _countryRegion(id) { return _REGION_MAP[id] || '기타'; }

// 평점을 ★☆ 시각화 (0.7 이상이면 올림, 미만이면 내림)
function ratingStars(rating) {
  const full = (rating % 1) >= 0.7 ? Math.ceil(rating) : Math.floor(rating);
  const clamped = Math.min(5, Math.max(0, full));
  return '★'.repeat(clamped) + '☆'.repeat(5 - clamped);
}

// 카테고리별 배지 색상
const CAT_PALETTE = {
  '역사': '#2c6e8a', '자연': '#6a994e', '문화': '#e8723a',
  '예술': '#8338ec', '쇼핑': '#9b2226', '현대': '#2980b9',
  '체험': '#27ae60', '관광': '#16a085', '미식': '#f39c12', '종교': '#7d6608'
};
function catColor(category) {
  const key = Object.keys(CAT_PALETTE).find(k => category.includes(k));
  return key ? CAT_PALETTE[key] : '#6b7280';
}

// 마크다운에서 순수 텍스트 미리보기 추출 (헤더·이미지 제외)
function mdPreview(text, maxLen = 200) {
  if (!text) return '';
  const lines = text.split('\n').filter(l => l.trim() && !l.startsWith('#') && !l.startsWith('!'));
  return lines.join(' ').slice(0, maxLen) + '…';
}

function setApp(html) {
  const el = document.getElementById('app');
  el.innerHTML = html;
  el.classList.remove('page-enter');
  void el.offsetWidth; // reflow 강제로 애니메이션 재시작
  el.classList.add('page-enter');
}

// 화면별 로딩 메시지
const makeLoading = (msg = '로딩 중…') =>
  `<div class="loading"><div class="spinner"></div><p>${msg}</p></div>`;

function setBreadcrumb(items) {
  document.getElementById('breadcrumb').innerHTML = items.map((it, i) =>
    i < items.length - 1
      ? `<a href="${it.href}">${it.label}</a><span class="bc-sep">›</span>`
      : `<span class="bc-current">${it.label}</span>`
  ).join('');
}

const LOADING = `<div class="loading"><div class="spinner"></div><p>로딩 중…</p></div>`;

// DOM 레이아웃이 완전히 계산될 때까지 대기
const raf = () => new Promise(r => requestAnimationFrame(r));

// Overpass API 미러 서버 목록 (rate limit 우회)
const OVERPASS_URLS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://maps.mail.ru/osm/tools/overpass/api/interpreter'
];
let _overpassIdx = 0; // 현재 사용 중인 서버 인덱스

async function _overpassFetch(q) {
  // 최대 2번 시도, 서버당 12초 타임아웃 → 최악 ~26초 후 throw
  const MAX = 2;
  for (let attempt = 0; attempt < MAX; attempt++) {
    const url = OVERPASS_URLS[_overpassIdx % OVERPASS_URLS.length];
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(new DOMException('timeout', 'AbortError')), 12000);
    try {
      const r = await fetch(url, {
        method: 'POST', body: `data=${encodeURIComponent(q)}`, signal: ctrl.signal
      });
      clearTimeout(timer);
      if (r.status === 429 || r.status === 504) {
        _overpassIdx++;
        await new Promise(res => setTimeout(res, r.status === 429 ? 3000 : 1000));
        continue;
      }
      if (!r.ok) throw new Error(`Overpass ${r.status}`);
      return await r.json();
    } catch (e) {
      clearTimeout(timer);
      if (attempt < MAX - 1) { _overpassIdx++; await new Promise(res => setTimeout(res, 1000)); }
      else throw e;
    }
  }
}

// Overpass API로 행정구역 경계 fetch (OSM ODbL — 상업적 이용 가능, 출처 표시 필요)
async function fetchDistricts(cityId, cfg) {
  const key = `dist:${cityId}`;
  if (_cache[key]) return _cache[key];
  const [south, west, north, east] = cfg.bbox;
  // areaName이 있으면 도시 행정구역 안에서만 검색 (bbox보다 정확하고 빠름)
  const q = cfg.areaName
    ? `[out:json][timeout:60];area["name"="${cfg.areaName}"]->.a;(relation["boundary"="administrative"]["admin_level"="${cfg.adminLevel}"](area.a););out geom;`
    : `[out:json][timeout:60];(relation["boundary"="administrative"]["admin_level"="${cfg.adminLevel}"](${south},${west},${north},${east}););out geom;`;
  const raw = await _overpassFetch(q);
  return (_cache[key] = osmtogeojson(raw));
}

// Overpass API로 수계+공원+녹지 통합 fetch (OSM ODbL — 수계·공원 한 번에 가져옴)
async function fetchMapLayers(cityId, cfg) {
  const key = `layers:${cityId}`;
  if (_cache[key]) return _cache[key];
  const [south, west, north, east] = cfg.bbox;
  // way만 쿼리 (relation 제외 — 데이터 크기 최소화로 타임아웃 방지)
  const q = cfg.areaName
    ? `[out:json][timeout:25];area["name"="${cfg.areaName}"]->.a;(way["waterway"~"^(river|canal)$"](area.a);way["natural"="water"](area.a);way["leisure"="park"](area.a););out geom;`
    : `[out:json][timeout:25];(way["waterway"~"^(river|canal)$"](${south},${west},${north},${east});way["natural"="water"](${south},${west},${north},${east});way["leisure"="park"](${south},${west},${north},${east}););out geom;`;
  const raw = await _overpassFetch(q);
  return (_cache[key] = osmtogeojson(raw));
}

// graticule 배경 그리드 (.graticule-bg 클래스 — 행정구역 로딩 완료 후 제거)
function _drawGraticule(container, path) {
  const gr = d3.geoGraticule().step([0.05, 0.05]);
  container.append('path').attr('class', 'graticule-bg').datum(gr())
    .attr('d', path).attr('fill', 'none')
    .attr('stroke', '#c8ddc8').attr('stroke-width', 0.5).attr('opacity', 0.6);
}

/* ── World 화면 ────────────────────────────────────────────── */
async function renderWorld() {
  document.title = '세계 관광지 아틀라스';
  setApp(makeLoading('🌍 세계 지도 불러오는 중…'));
  setBreadcrumb([{ label: '세계', href: '#/world' }]);

  const [world, countries, stats] = await Promise.all([
    fetchJSON('vendor/world-110m.json'),
    fetchJSON('data/countries.json'),
    fetchJSON('data/stats.json').catch(() => null)
  ]);
  const totalCities = stats?.cities ?? countries.length * 2;
  const totalSpots  = stats?.spots  ?? countries.length * 10;

  setApp(`
    <div class="world-view">
      <div class="world-banner">
        <div style="flex:1">
          <h1>🌏 세계 관광지 아틀라스</h1>
          <p>국가를 클릭해 도시와 관광지를 탐색하세요</p>
        </div>
        <div class="stats">
          <div class="stat"><div class="stat-num">${countries.length}</div><div class="stat-label">개국</div></div>
          <div class="stat"><div class="stat-num">${totalCities}</div><div class="stat-label">개 도시</div></div>
          <div class="stat"><div class="stat-num">${totalSpots}</div><div class="stat-label">개 관광지</div></div>
        </div>
      </div>
      <div class="world-map-section">
        <div class="map-container" id="world-map"></div>
      </div>
      <div class="country-grid-section">
        <div class="country-grid-header">
          <span>🗺 탐색 가능한 국가</span>
          <div class="region-filter" id="region-filter">
            <button class="rf-btn active" data-region="">전체 ${countries.length}</button>
            <button class="rf-btn" data-region="아시아">아시아</button>
            <button class="rf-btn" data-region="유럽">유럽</button>
            <button class="rf-btn" data-region="아메리카">아메리카</button>
            <button class="rf-btn" data-region="아프리카">아프리카</button>
            <button class="rf-btn" data-region="오세아니아">오세아니아</button>
          </div>
        </div>
        <div class="country-grid">
          ${countries.map(c => `
            <a href="#/country/${c.id}" class="country-grid-card" data-region="${_countryRegion(c.id)}">
              <img src="${c.thumbnail}" alt="${c.name}" loading="lazy">
              <div class="country-grid-info">
                <strong>${c.name}</strong>
                <small>${(c.summary || '').slice(0, 36)}…</small>
              </div>
            </a>
          `).join('')}
        </div>
      </div>
    </div>`);

  await raf();

  const el = document.getElementById('world-map');
  const W = el.clientWidth || window.innerWidth;
  const H = el.clientHeight || window.innerHeight - 100;

  const proj = d3.geoNaturalEarth1()
    .scale(W / 6.4)
    .translate([W / 2, H / 2]);
  const path = d3.geoPath().projection(proj);

  const svg = d3.select('#world-map')
    .append('svg').attr('width', W).attr('height', H)
    .style('cursor', 'grab');

  svg.append('rect').attr('width', W).attr('height', H).attr('fill', '#c2dff0');

  // container: 지도 경로 (zoom transform 그대로 적용)
  const container = svg.append('g');
  // overlay: 마커 (위치만 줌 따라가고 크기·글자는 고정)
  const overlay = svg.append('g');

  const PALETTE = [
    '#b9d4a0', '#a8c8d8', '#d4c49a', '#c4b2d4',
    '#d4b8a8', '#a8d4c4', '#d8d0a0', '#b8c4d4',
    '#c8d4b0', '#d4a8b8'
  ];
  // id가 null이거나 숫자가 아닌 경우 fallback 색상 사용
  const countryColor = id => { const n = +id; return isNaN(n) ? '#ccd8c0' : PALETTE[n % PALETTE.length]; };

  const land = topojson.feature(world, world.objects.countries);
  const highlighted = new Set(countries.map(c => c.numericId));

  container.append('g').selectAll('path')
    .data(land.features).join('path')
    .attr('d', path)
    .attr('fill', d => highlighted.has(+d.id) ? '#4a9ece' : countryColor(d.id))
    .attr('stroke', 'none')
    .style('cursor', d => highlighted.has(+d.id) ? 'pointer' : 'default')
    .on('click', (e, d) => {
      const c = countries.find(x => x.numericId === +d.id);
      if (c) location.hash = `#/country/${c.id}`;
    });

  // 경계선·해안선 — 변수로 보관해 zoom에서 두께 역보정
  const bordersPath = container.append('path')
    .datum(topojson.mesh(world, world.objects.countries, (a, b) => a !== b))
    .attr('d', path).attr('fill', 'none')
    .attr('stroke', '#88a8bc').attr('stroke-width', 0.9);

  const outlinePath = container.append('path')
    .datum(topojson.mesh(world, world.objects.countries, (a, b) => a === b))
    .attr('d', path).attr('fill', 'none')
    .attr('stroke', '#6a9ab0').attr('stroke-width', 0.6);

  // defs는 svg에 (transform 무관)
  const defs = svg.append('defs');

  countries.filter(c => proj(c.coord)).forEach(c => {
    const [cx, cy] = proj(c.coord);

    defs.append('pattern').attr('id', `pat-${c.id}`)
      .attr('width', 1).attr('height', 1).attr('patternUnits', 'objectBoundingBox')
      .append('image').attr('href', `vendor/flags/${c.id}.svg`)
      .attr('width', 36).attr('height', 36)
      .attr('preserveAspectRatio', 'xMidYMid slice');

    // 마커를 overlay에 — datum으로 원래 좌표 보관
    const g = overlay.append('g')
      .attr('class', 'country-marker')
      .datum({ coord: c.coord })
      .attr('transform', `translate(${cx},${cy})`)
      .style('cursor', 'pointer')
      .on('click', () => location.hash = `#/country/${c.id}`);

    g.append('circle').attr('class', 'ring').attr('r', 10)
      .attr('fill', '#fff').attr('stroke', '#e8723a').attr('stroke-width', 2);
    g.append('circle').attr('r', 8).attr('fill', `url(#pat-${c.id})`);

    const tt = g.append('g').attr('class', 'tt').attr('transform', 'translate(0,14)').style('opacity', 0);
    tt.append('rect').attr('x', -30).attr('y', 0).attr('width', 60).attr('height', 16)
      .attr('rx', 3).attr('fill', 'rgba(0,0,0,.72)');
    tt.append('text').attr('text-anchor', 'middle').attr('y', 11)
      .attr('fill', '#fff').attr('font-size', 10).text(c.name);

    g.on('mouseover', function() {
      d3.select(this).select('.tt').style('opacity', 1);
      d3.select(this).select('.ring').attr('r', 13).attr('stroke-width', 2.5);
    }).on('mouseout', function() {
      d3.select(this).select('.tt').style('opacity', 0);
      d3.select(this).select('.ring').attr('r', 10).attr('stroke-width', 2);
    });
  });

  const zoom = d3.zoom()
    .scaleExtent([0.5, 10])
    .on('zoom', e => {
      const t = e.transform;
      container.attr('transform', t);
      // 경계선 두께를 줌 배율 역비례로 유지 → 항상 같은 픽셀 두께
      bordersPath.attr('stroke-width', 0.9 / t.k);
      outlinePath.attr('stroke-width', 0.6 / t.k);
      // 마커: 위치만 줌에 맞게 재계산, 크기는 고정
      overlay.selectAll('.country-marker').attr('transform', function(d) {
        const [nx, ny] = t.apply(proj(d.coord));
        return `translate(${nx},${ny})`;
      });
    });

  svg.call(zoom);
  svg.on('dblclick.zoom', () =>
    svg.transition().duration(350).call(zoom.transform, d3.zoomIdentity));
}

/* ── Country 화면 ──────────────────────────────────────────── */
async function renderCountry(cid) {
  setApp(makeLoading('🗺 국가 정보 불러오는 중…'));

  const [world, countries, cities, md] = await Promise.all([
    fetchJSON('vendor/world-110m.json'),
    fetchJSON('data/countries.json'),
    fetchJSON(`data/cities/${cid}.json`).catch(() => []),
    fetchText(`content/countries/${cid}.md`)
  ]);

  const country = countries.find(c => c.id === cid);
  if (!country) { location.hash = '#/world'; return; }

  document.title = `${country.name} — 세계 관광지 아틀라스`;
  setBreadcrumb([
    { label: '세계', href: '#/world' },
    { label: country.name, href: `#/country/${cid}` }
  ]);

  setApp(`
    <div class="country-view">
      <div class="country-map-wrap">
        <a href="#/world" class="btn-back map-back">◀ 세계지도로</a>
        <div class="map-container" id="country-map"></div>
      </div>
      <div class="country-sidebar">
        <div class="sidebar-header">
          <h2>${country.name}</h2>
          <p class="sidebar-preview">${mdPreview(md, 120)}</p>
          <a href="#/blog/country/${cid}" class="btn-blog sidebar-blog-btn">✍️ 전체 여행 가이드</a>
        </div>
        <div class="city-list">
          ${cities.map(city => `
            <a href="#/city/${city.id}" class="city-card">
              <img src="${city.thumbnail}" alt="${city.name}" loading="lazy">
              <div class="city-card-info">
                <h3>${city.name}</h3>
                <p>${city.summary || ''}</p>
                <span class="city-explore">관광지 5곳 탐색 →</span>
              </div>
            </a>
          `).join('')}
        </div>
      </div>
    </div>`);

  await raf();

  const el = document.getElementById('country-map');
  const W = el.clientWidth || window.innerWidth;
  const H = el.clientHeight || window.innerHeight - 150;

  const allFeatures = topojson.feature(world, world.objects.countries).features;
  const feat = allFeatures.find(f => +f.id === country.numericId);
  if (!feat) {
    // 소규모 국가(싱가포르 등): 지도 데이터 없음 → 안내 표시
    const el2 = document.getElementById('country-map');
    if (el2) {
      const W2 = el2.clientWidth || window.innerWidth;
      const H2 = el2.clientHeight || window.innerHeight - 150;
      const svg2 = d3.select('#country-map').append('svg').attr('width', W2).attr('height', H2);
      svg2.append('rect').attr('width', W2).attr('height', H2).attr('fill', '#d4e8f4');
      svg2.append('text').attr('x', W2/2).attr('y', H2/2 - 16)
        .attr('text-anchor','middle').attr('font-size',18).attr('fill','#4a9ece').text('🗺');
      svg2.append('text').attr('x', W2/2).attr('y', H2/2 + 10)
        .attr('text-anchor','middle').attr('font-size',13).attr('fill','#6b7280')
        .text('소규모 국가 — 세계 지도에 표시 불가');
    }
    return;
  }

  // 해당 국가가 화면에 꽉 차도록 투영 (팬·줌 없음)
  const proj = d3.geoMercator().fitExtent([[40, 60], [W - 40, H - 60]], feat);
  const path = d3.geoPath().projection(proj);

  const svg = d3.select('#country-map')
    .append('svg').attr('width', W).attr('height', H)
    .style('cursor', 'grab');

  svg.append('rect').attr('width', W).attr('height', H).attr('fill', '#c8e6f4');

  const container = svg.append('g');
  const overlay = svg.append('g');  // 도시 마커 전용 — 크기 고정

  const PALETTE = [
    '#b9d4a0', '#a8c8d8', '#d4c49a', '#c4b2d4',
    '#d4b8a8', '#a8d4c4', '#d8d0a0', '#b8c4d4',
    '#c8d4b0', '#d4a8b8'
  ];
  container.append('g').selectAll('path')
    .data(allFeatures.filter(f => +f.id !== country.numericId)).join('path')
    .attr('d', path).attr('fill', f => { const n = +f.id; return isNaN(n) ? '#ccd8c0' : PALETTE[n % PALETTE.length]; }).attr('stroke', 'none');

  // 경계선들 — 변수로 보관해 zoom에서 두께 역보정
  const bgBordersPath = container.append('path')
    .datum(topojson.mesh(world, world.objects.countries,
      (a, b) => a !== b && +a.id !== country.numericId && +b.id !== country.numericId))
    .attr('d', path).attr('fill', 'none')
    .attr('stroke', '#8aacbc').attr('stroke-width', 0.8);

  const countryFillPath = container.append('path').datum(feat)
    .attr('d', path).attr('fill', '#4a9ece').attr('stroke', '#1e5a7a').attr('stroke-width', 2.5);

  const countryBorderPath = container.append('path')
    .datum(topojson.mesh(world, world.objects.countries,
      (a, b) => (a !== b) && (+a.id === country.numericId || +b.id === country.numericId)))
    .attr('d', path).attr('fill', 'none')
    .attr('stroke', '#1e5a7a').attr('stroke-width', 2);

  // 도시 마커를 overlay에 — datum으로 원래 좌표 보관
  const CITY_COLORS = ['#e8723a', '#2c6e8a', '#6a994e', '#9b2226', '#8338ec'];

  cities.forEach((city, idx) => {
    const pos = proj(city.coord);
    if (!pos) return;
    const [cx, cy] = pos;
    const color = CITY_COLORS[idx % CITY_COLORS.length];

    const g = overlay.append('g')
      .attr('class', 'city-marker')
      .datum({ coord: city.coord })
      .attr('transform', `translate(${cx},${cy})`)
      .style('cursor', 'pointer')
      .on('click', () => {
        // 사이드 패널 해당 도시 카드 하이라이트 후 이동
        document.querySelectorAll('.city-card').forEach(c => c.classList.remove('active'));
        const card = document.querySelector(`.city-card[href="#/city/${city.id}"]`);
        if (card) { card.classList.add('active'); card.scrollIntoView({ behavior:'smooth', block:'nearest' }); }
        setTimeout(() => { location.hash = `#/city/${city.id}`; }, 600);
      });

    g.append('circle').attr('r', 14).attr('fill', '#fff').attr('stroke', color).attr('stroke-width', 3);
    g.append('circle').attr('r', 10).attr('fill', color).attr('stroke', '#fff').attr('stroke-width', 2);
    g.append('text').attr('text-anchor', 'middle').attr('y', 4)
      .attr('fill', '#fff').attr('font-size', 11).attr('font-weight', 'bold').text(idx + 1);
    g.append('text')
      .attr('text-anchor', 'middle').attr('y', -18)
      .attr('font-size', 14).attr('font-weight', 'bold').attr('fill', '#1a2a3a')
      .attr('stroke', '#fff').attr('stroke-width', 3).attr('paint-order', 'stroke')
      .text(city.name);

    g.on('mouseover', function() {
      d3.select(this).select('circle').attr('r', 15);
    }).on('mouseout', function() {
      d3.select(this).select('circle').attr('r', 12);
    });
  });

  const zoom = d3.zoom()
    .scaleExtent([0.5, 15])
    .on('zoom', e => {
      const t = e.transform;
      container.attr('transform', t);
      // 경계선 두께 역보정
      bgBordersPath.attr('stroke-width', 0.8 / t.k);
      countryFillPath.attr('stroke-width', 2.5 / t.k);
      countryBorderPath.attr('stroke-width', 2 / t.k);
      // 마커: 위치만 줌에 맞게, 크기는 고정
      overlay.selectAll('.city-marker').attr('transform', function(d) {
        const [nx, ny] = t.apply(proj(d.coord));
        return `translate(${nx},${ny})`;
      });
    });

  svg.call(zoom);
  svg.on('dblclick.zoom', () =>
    svg.transition().duration(350).call(zoom.transform, d3.zoomIdentity));
}

/* ── City 화면 — 관광지 소개 페이지 ──────────────────────────── */
async function renderCity(cityId) {
  setApp(makeLoading('🏙 도시 정보 불러오는 중…'));

  const countries = await fetchJSON('data/countries.json');

  const allCities = await Promise.all(countries.map(c => fetchJSON(`data/cities/${c.id}.json`).catch(() => [])));
  let city = null, country = null;
  for (let i = 0; i < countries.length; i++) {
    const found = allCities[i].find(ci => ci.id === cityId);
    if (found) { city = found; country = countries[i]; break; }
  }
  if (!city) { location.hash = '#/world'; return; }

  document.title = `${city.name} | 관광지 5곳 — 세계 관광지 아틀라스`;
  const [spots, md] = await Promise.all([
    fetchJSON(`data/spots/${cityId}.json`),
    fetchText(`content/cities/${cityId}.md`)
  ]);

  setBreadcrumb([
    { label: '세계', href: '#/world' },
    { label: country.name, href: `#/country/${country.id}` },
    { label: city.name, href: `#/city/${cityId}` }
  ]);

  const SPOT_COLORS = ['#e8723a', '#2c6e8a', '#6a994e', '#9b2226', '#8338ec'];

  setApp(`
    <div class="city-page">
      <div class="city-hero" style="background-image:url('https://picsum.photos/seed/${cityId}-hero/1400/420')">
        <div class="city-hero-overlay">
          <h1>${city.name}</h1>
          <p>${city.summary || ''}</p>
          <div class="city-hero-actions">
            <a href="#/country/${country.id}" class="btn-back">◀ ${country.name}으로</a>
            <a href="#/blog/city/${cityId}" class="btn-blog">✍️ 여행 가이드 전체 보기</a>
          </div>
          <button class="fav-btn${_getFavs().includes(cityId) ? ' active' : ''}" id="fav-btn" data-city="${cityId}" aria-label="즐겨찾기">
            ${_getFavs().includes(cityId) ? '♥' : '♡'}
          </button>
        </div>
      </div>
      <div class="spots-toolbar">
        <span class="spots-section-title">✈️ 추천 관광지 ${spots.length}곳</span>
        <div class="filter-btns" id="filter-btns">
          <button class="filter-btn active" data-cat="">전체</button>
          ${[...new Set(spots.map(s => s.category.split('·')[0].trim()))].map(cat =>
            `<button class="filter-btn" data-cat="${cat}">${cat}</button>`
          ).join('')}
          <button class="sort-btn" id="sort-rating">★ 평점순</button>
        </div>
      </div>
      <div class="spots-grid" id="spots-grid">
        ${spots.map((spot, i) => `
          <div class="spot-card-full" data-cat="${spot.category}" data-rating="${spot.rating}" data-order="${i}">
            <div class="img-wrap"><img src="${spot.image}" alt="${spot.name}" loading="lazy"></div>
            <div class="spot-card-body">
              <div class="spot-meta">
                <span class="spot-num" style="background:${catColor(spot.category)}">${i + 1}</span>
                <span class="spot-cat" style="background:${catColor(spot.category)}">${spot.category.split('·')[0]}</span>
                <span class="spot-rating" title="${spot.rating}점">${ratingStars(spot.rating)} <small>${spot.rating}</small></span>
              </div>
              <h3>${spot.name}</h3>
              <p>${spot.description}</p>
            </div>
          </div>
        `).join('')}
      </div>
    </div>`);

  // 카테고리 필터 + 평점 정렬 이벤트
  document.getElementById('filter-btns')?.addEventListener('click', e => {
    const filterBtn = e.target.closest('.filter-btn');
    if (filterBtn) {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      filterBtn.classList.add('active');
      const cat = filterBtn.dataset.cat;
      document.querySelectorAll('.spot-card-full').forEach(card => {
        card.style.display = (!cat || card.dataset.cat.includes(cat)) ? '' : 'none';
      });
      return;
    }
    const sortBtn = e.target.closest('#sort-rating');
    if (sortBtn) {
      sortBtn.classList.toggle('active');
      const rated = sortBtn.classList.contains('active');
      const grid = document.getElementById('spots-grid');
      [...grid.querySelectorAll('.spot-card-full')]
        .sort((a, b) => rated ? +b.dataset.rating - +a.dataset.rating : +a.dataset.order - +b.dataset.order)
        .forEach(c => grid.appendChild(c));
    }
  });

  // 즐겨찾기 버튼 이벤트
  document.getElementById('fav-btn')?.addEventListener('click', () => {
    const btn = document.getElementById('fav-btn');
    const isNowFav = _toggleFav(cityId);
    btn.textContent = isNowFav ? '♥' : '♡';
    btn.classList.toggle('active', isNowFav);
    showToast(isNowFav ? '♥ 즐겨찾기에 추가됨' : '즐겨찾기에서 제거됨');
  });
}
/* ── Blog 화면 ─────────────────────────────────────────────── */
async function renderBlog(type, id) {
  setApp(makeLoading('📖 블로그 불러오는 중…'));
  const countries = await fetchJSON('data/countries.json');

  let label, backHref, mdUrl, relatedHtml = '';

  if (type === 'country') {
    const c = countries.find(x => x.id === id);
    label = c ? `${c.name} 여행 가이드` : id;
    backHref = `#/country/${id}`;
    mdUrl = `content/countries/${id}.md`;
    setBreadcrumb([
      { label: '세계', href: '#/world' },
      { label: c?.name || id, href: `#/country/${id}` },
      { label: '블로그', href: `#/blog/country/${id}` }
    ]);
    // 해당 국가 도시 카드 (하단 연관)
    const cities = await fetchJSON(`data/cities/${id}.json`).catch(() => []);
    if (cities.length) {
      relatedHtml = `
        <div class="blog-related">
          <h3>✈️ ${c?.name || ''} 도시 탐색하기</h3>
          <div class="related-cards">
            ${cities.map(city => `
              <a href="#/city/${city.id}" class="related-card">
                <img src="${city.thumbnail}" alt="${city.name}" loading="lazy">
                <div class="related-info">
                  <strong>${city.name}</strong>
                  <small>${(city.summary || '').slice(0, 55)}…</small>
                  <span class="related-cta">관광지 5곳 보기 →</span>
                </div>
              </a>
            `).join('')}
          </div>
        </div>`;
    }
  } else {
    const allCities = await Promise.all(countries.map(c => fetchJSON(`data/cities/${c.id}.json`).catch(() => [])));
    let city = null, country = null;
    for (let i = 0; i < countries.length; i++) {
      const f = allCities[i].find(ci => ci.id === id);
      if (f) { city = f; country = countries[i]; break; }
    }
    label = city ? `${city.name} 여행 가이드` : id;
    backHref = `#/city/${id}`;
    mdUrl = `content/cities/${id}.md`;
    setBreadcrumb([
      { label: '세계', href: '#/world' },
      { label: country?.name || '', href: `#/country/${country?.id}` },
      { label: city?.name || id, href: `#/city/${id}` },
      { label: '블로그', href: `#/blog/city/${id}` }
    ]);
    // 도시 블로그 하단: 관광지·국가 가이드 링크
    relatedHtml = `
      <div class="blog-related">
        <h3>🗺 더 탐색하기</h3>
        <div class="related-btns">
          <a href="#/city/${id}" class="btn-blog">🏙 ${city?.name || ''} 관광지 보기</a>
          ${country ? `<a href="#/blog/country/${country.id}" class="btn-readmore">📖 ${country.name} 전체 여행 가이드 →</a>` : ''}
        </div>
      </div>`;
  }

  document.title = `${label} | 블로그 — 세계 관광지 아틀라스`;
  const md = await fetchText(mdUrl);
  const cleanMd = md ? md.replace(/^!\[.*?\]\(.*?\)\n?/m, '') : null;
  const html = cleanMd ? marked.parse(cleanMd) : '<p>콘텐츠를 불러올 수 없습니다.</p>';

  setApp(`
    <div class="blog-view">
      <div class="blog-hero" style="background-image:url('https://picsum.photos/seed/${id}-hero/1200/400')">
        <h1>${label}</h1>
      </div>
      <div class="blog-body">
        <a href="${backHref}" class="btn-back">◀ 지도로 돌아가기</a>
        <article class="blog-article">${html}</article>
        ${relatedHtml}
        <a href="${backHref}" class="btn-back blog-back-bottom">◀ 지도로 돌아가기</a>
      </div>
    </div>`);
}

/* ── 즐겨찾기 화면 ─────────────────────────────────────────── */
async function renderFavorites() {
  document.title = '즐겨찾기 — 세계 관광지 아틀라스';
  setApp(makeLoading('♥ 즐겨찾기 불러오는 중…'));
  setBreadcrumb([
    { label: '세계', href: '#/world' },
    { label: '♥ 즐겨찾기', href: '#/favorites' }
  ]);

  const favIds = _getFavs();

  if (favIds.length === 0) {
    setApp(`
      <div class="fav-page">
        <div class="fav-empty">
          <div class="fav-empty-icon">♡</div>
          <h2>아직 즐겨찾기한 도시가 없어요</h2>
          <p>도시 화면의 ♥ 버튼을 눌러 즐겨찾기를 추가해보세요</p>
          <a href="#/world" class="btn-blog">🌍 세계 지도 탐색하기</a>
        </div>
      </div>`);
    return;
  }

  const countries = await fetchJSON('data/countries.json');
  const allCities = await Promise.all(countries.map(c => fetchJSON(`data/cities/${c.id}.json`).catch(() => [])));
  const cityFlat = allCities.flat();

  const favCities = favIds.map(id => {
    const city = cityFlat.find(c => c.id === id);
    const country = city ? countries.find(co => co.id === city.countryId) : null;
    return { city, country };
  }).filter(f => f.city);

  setApp(`
    <div class="fav-page">
      <div class="fav-header">
        <h1>♥ 즐겨찾기 도시</h1>
        <p class="fav-count">${favCities.length}개 도시 저장됨</p>
      </div>
      <div class="fav-grid">
        ${favCities.map(({ city, country }) => `
          <div class="fav-city-card" data-city="${city.id}">
            <a href="#/city/${city.id}" class="fav-city-link">
              <img src="${city.thumbnail}" alt="${city.name}" loading="lazy">
              <div class="fav-city-info">
                <strong>${city.name}</strong>
                <span class="fav-country">${country?.name || ''}</span>
                <small>${(city.summary || '').slice(0, 55)}…</small>
              </div>
            </a>
            <button class="fav-remove-btn" title="즐겨찾기 제거">×</button>
          </div>
        `).join('')}
      </div>
    </div>`);

  // 제거 버튼 이벤트
  document.querySelector('.fav-grid')?.addEventListener('click', e => {
    const btn = e.target.closest('.fav-remove-btn');
    if (!btn) return;
    const card = btn.closest('.fav-city-card');
    const cityId = card?.dataset.city;
    if (cityId) { _toggleFav(cityId); card.remove(); }
    const remaining = document.querySelectorAll('.fav-city-card').length;
    const countEl = document.querySelector('.fav-count');
    if (countEl) countEl.textContent = `${remaining}개 도시 저장됨`;
    if (remaining === 0) renderFavorites();
  });
}

/* ── 해시 라우터 ────────────────────────────────────────────── */
function route() {
  // '#/country/kr' → ['country', 'kr']
  const parts = (location.hash || '#/world').replace(/^#\/?/, '').split('/');
  const [p0, p1, p2] = parts;

  if (!p0 || p0 === 'world') renderWorld();
  else if (p0 === 'country' && p1)    renderCountry(p1);
  else if (p0 === 'city' && p1)       renderCity(p1);
  else if (p0 === 'blog' && p1 && p2) renderBlog(p1, p2);
  else if (p0 === 'favorites')        renderFavorites();
  else renderWorld();
}

/* ── 헤더 검색 ─────────────────────────────────────────────── */
async function initSearch() {
  const countries = await fetchJSON('data/countries.json').catch(() => []);
  const allCities = await Promise.all(
    countries.map(c => fetchJSON(`data/cities/${c.id}.json`).catch(() => []))
  );
  const cityFlat = allCities.flat();

  // 관광지 인덱스 (도시 ID 포함)
  const allSpots = await Promise.all(
    cityFlat.map(ci => fetchJSON(`data/spots/${ci.id}.json`).catch(() => [])
      .then(spots => spots.map(s => ({ type: '관광지', name: s.name, sub: ci.name, href: `#/city/${ci.id}` })))
    )
  );

  const index = [
    ...countries.map(c => ({ type: '국가', name: c.name, href: `#/country/${c.id}` })),
    ...cityFlat.map(ci => ({ type: '도시', name: ci.name, href: `#/city/${ci.id}` })),
    ...allSpots.flat()
  ];

  const iconBtn = document.getElementById('search-icon-btn');
  const box = document.getElementById('search-box');
  const input = document.getElementById('search-input');
  const results = document.getElementById('search-results');
  let activeIdx = -1;

  function close() { box.hidden = true; input.value = ''; results.innerHTML = ''; activeIdx = -1; }
  function renderHits(q) {
    if (q.length < 2) { results.innerHTML = ''; return; }
    const hits = index.filter(d => d.name.includes(q)).slice(0, 8);
    results.innerHTML = hits.length
      ? hits.map(d => `<a class="sr-item" href="${d.href}">
          <span class="sr-type">${d.type}</span>
          <span class="sr-name">${d.name}</span>
          ${d.sub ? `<span class="sr-sub">${d.sub}</span>` : ''}
        </a>`).join('')
      : '<div class="sr-empty">결과 없음</div>';
    activeIdx = -1;
  }

  iconBtn.addEventListener('click', e => {
    e.stopPropagation();
    box.hidden = !box.hidden;
    if (!box.hidden) input.focus();
  });

  input.addEventListener('input', () => renderHits(input.value.trim()));

  // 키보드 탐색 (↑↓Enter)
  input.addEventListener('keydown', e => {
    const items = [...results.querySelectorAll('.sr-item')];
    if (!items.length) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      activeIdx = Math.min(activeIdx + 1, items.length - 1);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      activeIdx = Math.max(activeIdx - 1, -1);
    } else if (e.key === 'Enter' && activeIdx >= 0) {
      const a = items[activeIdx];
      if (a) { location.hash = a.getAttribute('href').slice(1); close(); return; }
    }
    items.forEach((el, i) => el.classList.toggle('kbd-active', i === activeIdx));
  });

  results.addEventListener('click', e => {
    const a = e.target.closest('.sr-item');
    if (a) { location.hash = a.getAttribute('href').slice(1); close(); }
  });

  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  document.addEventListener('click', e => { if (!e.target.closest('#search-wrap')) close(); });
  window.addEventListener('hashchange', close);
}

/* ── 토스트 메시지 ──────────────────────────────────────────── */
function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 2000);
}

/* ── 스크롤-to-top ──────────────────────────────────────────── */
function initScrollTop() {
  const btn = document.getElementById('scroll-top');
  if (!btn) return;
  // capture 모드로 .city-page/.blog-view 등 내부 스크롤 모두 감지
  document.addEventListener('scroll', e => {
    const el = e.target;
    btn.classList.toggle('visible', (el.scrollTop || 0) > 300);
  }, { capture: true, passive: true });
  btn.addEventListener('click', () => {
    const scrollable = document.querySelector('.city-page, .blog-view, .world-view, #app');
    if (scrollable) scrollable.scrollTo({ top: 0, behavior: 'smooth' });
    else window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/* ── 공유 버튼 ──────────────────────────────────────────────── */
function initShare() {
  document.getElementById('share-btn')?.addEventListener('click', () => {
    const url = location.href;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(() => showToast('🔗 링크 복사됨!')).catch(() => showToast(url));
    } else {
      showToast(url);
    }
  });
}

/* ── 다크 모드 ──────────────────────────────────────────────── */
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem('theme', theme);
  const btn = document.getElementById('theme-btn');
  if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
}

function initTheme() {
  applyTheme(localStorage.getItem('theme') || 'light');
  document.getElementById('theme-btn')?.addEventListener('click', () => {
    applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  });
}

/* ── 국가 지역 필터 (이벤트 위임) ──────────────────────────── */
function initRegionFilter() {
  document.addEventListener('click', e => {
    const btn = e.target.closest('.rf-btn');
    if (!btn) return;
    document.querySelectorAll('.rf-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const region = btn.dataset.region;
    document.querySelectorAll('.country-grid-card').forEach(card => {
      card.style.display = (!region || card.dataset.region === region) ? '' : 'none';
    });
  });
}

window.addEventListener('hashchange', route);
document.addEventListener('DOMContentLoaded', () => { initTheme(); route(); initSearch(); initScrollTop(); initShare(); initRegionFilter(); });
