# 세계 관광지 아틀라스

D3.js + Natural Earth 데이터로 만든 순수 정적 웹 여행 탐색 서비스.  
100% 무료 · 상업적 이용 가능 · 빌드 도구 없음.

## 실행 방법

```bash
cd WorldMap
python -m http.server 8787
# 브라우저에서 http://localhost:8787 접속
```

Node.js를 선호하면:
```bash
npx serve . -p 8787
```

> `file://` 프로토콜로 직접 열면 fetch가 차단되므로 반드시 로컬 서버를 사용하세요.

## 화면 구조

| URL 해시 | 화면 |
|---|---|
| `#/world` | SVG 세계지도 + 국가 마커 |
| `#/country/{id}` | 해당 국가 확대 지도 + 도시 마커 |
| `#/city/{id}` | 도시 일러스트 배경 + 관광지 핀/카드 |
| `#/blog/country/{id}` | 국가 블로그 (마크다운 렌더링) |
| `#/blog/city/{id}` | 도시 블로그 (마크다운 렌더링) |

## 현재 데이터

| 국가 ID | 도시 IDs |
|---|---|
| `kr` (대한민국) | `seoul`, `busan` |
| `jp` (일본) | `tokyo`, `kyoto` |
| `fr` (프랑스) | `paris`, `nice` |

## 새 국가 추가 방법

1. **`data/countries.json`** — 국가 항목 추가  
   - `numericId`: ISO 3166-1 숫자 코드 (예: 미국=840, 독일=276)
   - `coord`: 대표 좌표 `[경도, 위도]`

2. **`data/cities/{id}.json`** — 도시 목록 작성 (배열)  
   - `coord`: `[경도, 위도]`

3. **`data/spots/{cityId}.json`** — 관광지 목록 작성  
   - `x`, `y`: 배경 이미지 위 핀 위치 (퍼센트, 0~100)

4. **`content/countries/{id}.md`** — 국가 소개 블로그 글

5. **`content/cities/{cityId}.md`** — 도시 소개 블로그 글

6. (선택) **`images/city-illustrations/{cityId}.jpg`** — 실제 도시 배경 이미지  
   없으면 `https://picsum.photos/seed/{cityId}/1200/800` placeholder 자동 사용

## 파일 구조

```
WorldMap/
├── index.html          # 진입점
├── style.css           # 전체 스타일
├── app.js              # SPA 라우터 + 화면 렌더링 로직
├── vendor/
│   ├── d3.min.js
│   ├── topojson-client.min.js
│   ├── marked.min.js
│   └── world-110m.json # Natural Earth 110m (Public Domain)
├── data/
│   ├── countries.json
│   ├── cities/         # {countryId}.json
│   └── spots/          # {cityId}.json
└── content/
    ├── countries/      # {id}.md
    └── cities/         # {id}.md
```

## 라이선스

사용 라이브러리 전부 ISC / MIT / Public Domain — 상업적 이용 무제한.
