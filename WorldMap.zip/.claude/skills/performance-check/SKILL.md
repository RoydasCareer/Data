---
name: performance-check
description: 사이트의 로딩 속도와 파일 용량을 점검하고 초경량 기준을 만족하는지 검증할 때 사용. "성능 체크해줘", "가벼운지 확인해줘" 같은 요청에 자동 실행.
allowed-tools: [Bash, Read, chrome-devtools]
user-invocable: true
---

# 성능 검증 프로토콜

1. chrome-devtools MCP로 로컬 서버(index.html)를 열고 Network 탭 기록을 확인한다.
2. 다음 항목을 측정하고 표로 보고한다:
   - 전체 페이지 로딩 시간
   - 총 다운로드 용량 (목표: 1MB 이하)
   - 이미지 파일 중 200KB 초과하는 것이 있는지
   - 콘솔 에러/경고 유무
3. /vendor 폴더 내 라이브러리들이 실제로 로컬에서 로드되는지(외부 CDN 요청이 없는지) 확인한다.
4. 기준 미달 항목이 있으면 구체적인 개선 방법(이미지 압축, 불필요한 fetch 제거 등)을 제안하고 
   사용자 승인 없이 바로 수정까지 진행한다.
