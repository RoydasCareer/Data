---
name: add-content
description: 새로운 국가, 도시, 관광지, 블로그 글을 추가할 때 사용. "이탈리아 추가해줘", "새 도시 넣어줘" 같은 요청에 자동 실행.
allowed-tools: [Read, Write, Edit]
user-invocable: true
---

# 콘텐츠 추가 프로토콜

사용자가 국가/도시/관광지를 추가해달라고 하면 다음을 순서대로 수행한다:

1. data/countries.json (또는 해당 cities/spots json)에 기존 스키마와 동일한 형식으로 항목을 추가한다.
2. content/countries/{id}.md 또는 content/cities/{id}.md에 
   TasteAtlas 스타일의 여행 정보성 소개글(3~5문단)을 새로 작성한다.
3. 이미지가 없으면 placeholder(picsum.photos) URL을 사용하고, 
   "실제 이미지로 교체가 필요하다"고 사용자에게 안내한다.
4. 기존 코드(app.js, index.html)는 절대 수정하지 않는다 (데이터만 추가해도 자동 반영되는 구조이므로).
5. 로컬 서버로 열어서 새 항목이 정상적으로 지도에 표시되는지 확인 후 결과를 보고한다.
