---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/telematics
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "DrivY"
size: "스타트업"
fit: "★"
business: "운전 행동 분석·UBI 텔레매틱스 앱 (⚠️ 공개 정보 제한적)"
hq: "Australia (정확한 위치 미확인)"
founded: "—"
employees: "—"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# DrivY

> 운전 행동 분석·UBI 텔레매틱스 앱 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Australia (정확한 위치 미확인) |
| 설립 연도 | 미확인 |
| 임직원 수 | 미확인 |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 스마트폰 기반 운전 행동 분석·UBI (Usage-Based Insurance) 텔레매틱스 서비스 |
| 공식 홈페이지 | 미확인 |

> ⚠️ **공개 정보 제한적.** 상세 데이터 미확인.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- UBI 보험 텔레매틱스 수요 증가.
- 소규모 스타트업 — 시장 경쟁 치열.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 스타트업 — 공개 정보 부족. |
| 추천 직무 | 미확인 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | 미확인 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: 공개 정보 부족 (2026.05 기준 미확인)*
