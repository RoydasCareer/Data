---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/software
  - automotive/retail
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Infomedia"
size: "중견기업"
fit: "★"
business: "자동차 OEM 딜러 부품 카탈로그·서비스 SaaS"
hq: "North Sydney, New South Wales, Australia"
founded: "1992"
employees: "~450명 (2024)"
revenue: "~$135M AUD (FY2024)"
ipo_status: "상장 (ASX: IFM)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Infomedia

> 자동차 OEM 딜러 부품 카탈로그 SaaS | 중견기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | North Sydney, New South Wales, Australia |
| 설립 연도 | 1992년 |
| 임직원 수 | ~450명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | ASX: IFM |
| 주력 사업 | Microcat EPC (전자 부품 카탈로그) + Superservice SaaS — Ford, Toyota, GM, Stellantis 등 글로벌 OEM 딜러망 적용 |
| 공식 홈페이지 | https://www.infomedia.com.au |

**주요 고객:** Ford, Toyota, GM, Stellantis 등 글로벌 OEM 딜러십 (180개국 이상).

---

## 🇰🇷 한국 관련

한국 사무소 없음. 글로벌 OEM 딜러 서비스 제공이나 한국 직영 법인 미확인.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 글로벌 딜러십 디지털화 수요 꾸준.
- 자동차 임베디드 SW와 직접 연관 없음.
- ASX 상장 중형주 — 안정적 매출.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. OEM 부품 카탈로그 SaaS — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | SW Engineer (SaaS 플랫폼) / Product Engineer — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 중견기업, TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [infomedia.com.au](https://www.infomedia.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: infomedia.com.au 공식 (2026.05 기준)*
