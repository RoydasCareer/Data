---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/testing
  - automotive/safety
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "Australian Road Research Board (ARRB)"
size: "중견기업"
fit: "★★"
business: "도로·교통 연구·자율주행 테스팅 (ARRB Group 구 명칭)"
hq: "Vermont South, Victoria, Australia"
founded: "1960"
employees: "~350명 (2024)"
revenue: "~$100M AUD"
ipo_status: "비상장 (정부 소유 연구기관)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Australian Road Research Board (ARRB)

> 도로·교통 연구·자율주행 테스팅 | 중견기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Vermont South, Victoria, Australia |
| 설립 연도 | 1960년 |
| 임직원 수 | ~350명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 (호주 정부 교통부 소유) |
| 주력 사업 | 도로 안전·교통 연구 + 자율주행 차량 테스팅 인프라 — 현재 "ARRB Group"으로 운영 |
| 공식 홈페이지 | https://www.arrb.com.au |

> ℹ️ **ARRB Group과 동일 기관.** ARRB_Group.md 참조.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

→ ARRB_Group.md 참조.

---

## ⭐ 지원 추천 정보 #Recommand

→ ARRB_Group.md 참조.

---

## 🔗 관련 정보

- 홈페이지: [arrb.com.au](https://www.arrb.com.au)
- 관련 파일: [[ARRB_Group|ARRB Group]]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: arrb.com.au 공식 (2026.05 기준)*
