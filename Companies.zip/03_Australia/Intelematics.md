---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/connectivity
  - automotive/telematics
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Intelematics"
size: "중소기업"
fit: "★"
business: "호주 자동차클럽 커넥티드카·긴급구조 서비스 SW"
hq: "Melbourne, Victoria, Australia"
founded: "1999"
employees: "~150명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (NRMA·RACV·RACT 합작)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Intelematics

> 호주 커넥티드카·긴급구조 SaaS | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 1999년 |
| 임직원 수 | ~150명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 (NRMA·RACV·RACT 호주 자동차클럽 합작법인) |
| 주력 사업 | eCall·사고 자동 감지·긴급구조·커넥티드카 서비스 플랫폼 — BMW, Audi, Kia, Honda 호주 딜러 적용 |
| 공식 홈페이지 | https://www.intelematics.com |

**자동차 관련:** 차량 사고 감지·eCall·긴급구조 연계 커넥티드카 SW — 임베디드 직접 연관 낮음.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 호주 전용 자동차클럽 합작 서비스.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 호주 커넥티드카 eCall 서비스 안정적 점유.
- 글로벌 확장 제한 — 호주 자동차클럽 합작 구조.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 호주 전용 커넥티드카 서비스 — 자동차 임베디드 SW 직접 연관 낮음. |
| 추천 직무 | Platform Engineer (커넥티드카 서비스) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [intelematics.com](https://www.intelematics.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: intelematics.com 공식 (2026.05 기준)*
