---
tags:
  - company
  - automotive
  - country/australia
  - size/large
  - automotive/autonomous
  - automotive/testing
  - fit/★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Transdev Australasia"
size: "대기업"
fit: "★★"
business: "자율주행 대중교통·전기버스·스마트 모빌리티 운영 호주/뉴질랜드 최대 민간 대중교통사"
hq: "Sydney, NSW, Australia (글로벌 HQ: Paris, France)"
founded: "2000 (호주 법인)"
employees: "~7,000명 (호주/뉴질랜드)"
ipo_status: "비상장 (Rethmann SE 자회사)"
korea_office: "없음"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Transdev Australasia

> 자율주행 대중교통·전기버스·스마트 모빌리티 | 대기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, NSW, Australia |
| 설립 연도 | 2000 (호주 법인) |
| 임직원 수 | ~7,000명 (호주/뉴질랜드) |
| 상장 여부 | 비상장 (Rethmann SE 자회사) |
| 주력 사업 | 버스·전철 운영, 자율주행 셔틀 파일럿, EV 플릿 전환, 스마트 모빌리티 플랫폼 |
| 공식 홈페이지 | https://www.transdev.com.au |

## 🎯 주요 제품 & 서비스

호주 최대 민간 대중교통 운영사. EasyMile·Navya 자율주행 셔틀 파일럿 운영 경험. OBD/텔레매틱스 기반 차량 상태 모니터링, 전기버스(Yutong·BYD) 도입 가속, 수소버스 파일럿.

## 🚗 자동차/모빌리티 관련성

자율주행 셔틀 실증 + 전기버스 OBD 진단 모니터링 → Technical PM으로 AV·EV 플릿 프로젝트 관리. 호주 13개월 거주 경험으로 현지 적응력 입증.

## 📈 성장성 & 전망

**성장성 평가: ★★★**

호주 정부 전기버스 의무화 로드맵(2030+), AV 대중교통 파일럿 확대. 탄소 중립 교통 전환 가속.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | Technical PM + AV/EV 플릿 운영 도메인. 호주 13개월 거주 경험으로 TSS 482 비자 케이스 강화. |
| 추천 직무 | Technical PM, AV Integration Engineer, Fleet Technology Manager |
| 지원 방법 | transdev.com.au/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★★ (호주 대형 운영사, TSS 482 지원 경험 풍부) |

## ⚠️ 리스크 / 고려사항

- 순수 SW 개발보다 운영·관리 역할 위주
- 자동차 기술 전문성보다 교통 운영 경험 중시할 수 있음

## 🔗 관련 정보

- 홈페이지: [transdev.com.au](https://www.transdev.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Transdev Australasia 공식 홈페이지 (2026.07 기준)*
