---
tags:
  - company
  - automotive
  - country/australia
  - size/public
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Transport Certification Australia (TCA)"
size: "공기업"
fit: "★"
business: "호주 중대형 화물차 텔레매틱스 인증·규정 준수 관리 기관"
hq: "Melbourne, Victoria, Australia"
founded: "2004"
employees: "~50명 (2024)"
revenue: "정부 기금 (비상업)"
ipo_status: "비상장 (연방·주 교통부 공동 설립)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Transport Certification Australia (TCA)

> 화물차 텔레매틱스 인증 기관 | 공기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 2004년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 공기업 |
| 상장 여부 | 비상장 (정부 기관) |
| 주력 사업 | IAP (Intelligent Access Program) — 중대형 화물차 GPS 텔레매틱스 장치 인증·규정 준수 관리 |
| 공식 홈페이지 | https://www.tca.gov.au |

> ⚠️ **상업 기업이 아닌 정부 인증 기관.** 외국인 취업 경로 매우 제한적.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★**

- 정부 인증 기관 — 상업 성장 해당 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 정부 인증 기관 — 외국인 취업 경로 매우 제한적. 한국 사무소 없음. |
| 추천 직무 | 해당없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 정부 기관, 시민권자 우선 |
| 고졸 채용 가능성 | 학위 필수 |

---

## 🔗 관련 정보

- 홈페이지: [tca.gov.au](https://www.tca.gov.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: tca.gov.au 공식 (2026.05 기준)*
