---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Teletrac Navman"
size: "중견기업"
fit: "★"
business: "상용 차량 플릿 GPS·ELD 텔레매틱스 SaaS (Fortive Corporation 자회사)"
hq: "Chicago, IL, USA (글로벌 HQ) — 호주·뉴질랜드·영국 운영"
founded: "1990년대 (Navman + Teletrac 합병)"
employees: "~600명 글로벌 (2024)"
revenue: "비공개 (Fortive 자회사)"
ipo_status: "비상장 (Fortive Corp. NYSE: FTV 자회사)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Teletrac Navman

> 상용 차량 플릿 GPS·ELD 텔레매틱스 | 중견기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Chicago, IL, USA (글로벌 HQ) — 호주·뉴질랜드·영국 주요 운영 |
| 설립 연도 | 1990년대 (Navman Wireless + Teletrac 합병) |
| 임직원 수 | ~600명 글로벌 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 (Fortive Corp. NYSE: FTV 자회사) |
| 주력 사업 | Director 플릿 관리 SaaS — 상용 트럭·버스·자산 GPS 추적·ELD·운전자 행동·연료 관리 |
| 공식 홈페이지 | https://www.teletracnavman.com.au |

**자동차 관련:** 상용 차량 플릿 텔레매틱스 — 자동차 임베디드 SW와 직접 연관 낮음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 상용 차량 플릿 SaaS 안정적 시장.
- Fortive 자회사 — 독립 성장 제한.
- 자동차 임베디드 SW와 직접 연관 낮음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 상용 차량 플릿 텔레매틱스 — 자동차 임베디드 SW 직접 연관 낮음. |
| 추천 직무 | Platform SW Engineer (플릿 SaaS) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 중견기업, TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [teletracnavman.com.au](https://www.teletracnavman.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: teletracnavman.com.au 공식 (2026.05 기준)*
