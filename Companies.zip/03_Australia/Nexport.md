---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/ev
  - automotive/powertrain
  - fit/★★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Nexport"
size: "중소기업"
fit: "★★★★"
business: "전기버스·전기트럭 EV 파워트레인 통합 (호주 상용 EV 전동화)"
hq: "Sydney, New South Wales, Australia"
founded: "2018"
employees: "~80명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Nexport

> 전기버스·전기트럭 상용 EV 전동화 | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2018년 |
| 임직원 수 | ~80명 (2024) |
| 상장 여부 | 비상장 |
| 주력 사업 | EV 버스·트럭 파워트레인 통합 — Yutong EV 버스 호주 공급 및 현지 SW 통합 |
| 공식 홈페이지 | https://www.nexport.com.au |

---

## 🎯 주요 제품 & 서비스

Nexport는 중국 Yutong의 EV 버스를 호주 시장에 공급하고, 호주 규제·환경에 맞는 파워트레인 SW 커스터마이징과 현지 통합을 담당합니다. BMS 소프트웨어, VCU 로직, 충전 시스템 통합, 원격 차량 진단(Telematics) 플랫폼을 자체 개발합니다. 공공 버스 운영사(Transit Systems, ComfortDelGro 등)에 EV 버스를 납품합니다.

---

## 🚗 자동차/모빌리티 관련성

EV 버스·트럭의 VCU·BMS SW 개발, 파워트레인 통합, 충전 시스템 인터페이스, 원격 진단 텔레매틱스 등 자동차 임베디드 SW 엔지니어가 직접 기여할 수 있는 상용 EV 분야입니다.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

- 호주 주정부 전기버스 전환 정책 (NSW·VIC·QLD 전기버스 도입 가속)
- 상용 EV 파워트레인 SW 개발 희소 스킬 분야
- Yutong 글로벌 EV 버스 공급망과 연계된 기술력

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | EV 버스·트럭 BMS/VCU 임베디드 SW, 파워트레인 통합 — 상용 EV 핵심 기술. 호주 전기버스 전환 수혜 기업. |
| 추천 직무 | Embedded SW Engineer (VCU/BMS), EV Systems Integration Engineer, Telematics SW Developer |
| 지원 방법 | nexport.com.au/careers, LinkedIn |
| 한국 채용 | 없음 — 시드니 포지션 |
| 비자 스폰 가능성 | ★★★ — 성장 중인 중소기업, TSS 482 가능 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [nexport.com.au](https://www.nexport.com.au)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Nexport 공식 홈페이지 (2026.06 기준)*
