---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/adas
  - automotive/autonomous
  - automotive/sensing
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Emesent"
size: "스타트업"
fit: "★★★"
business: "LiDAR SLAM 자율 비행 드론·로봇 SW 플랫폼 (GPS 불가 환경 자율 탐색)"
hq: "Brisbane, Queensland, Australia"
founded: "2018"
employees: "~100명 (2024)"
revenue: "비공개 ($30M+ 투자 유치)"
ipo_status: "비상장 (Droneshield 투자 유치)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Emesent

> LiDAR SLAM 자율 로봇 SW 플랫폼 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Brisbane, Queensland, Australia |
| 설립 연도 | 2018년 (QUT 퀸즐랜드공대 스핀아웃) |
| 임직원 수 | ~100명 (2024) |
| 상장 여부 | 비상장 ($30M+ 시리즈 A/B 투자 유치) |
| 주력 사업 | Hovermap — LiDAR SLAM 기반 GPS 불가 환경 자율 드론·로봇 탐색 SW |
| 공식 홈페이지 | https://www.emesent.com |

---

## 🎯 주요 제품 & 서비스

Emesent의 **Hovermap**은 LiDAR 센서 + 실시간 SLAM 알고리즘으로 GPS 신호가 없는 지하 광산·터널·산업 시설에서 드론이 자율 비행하며 3D 매핑을 수행하는 SW 플랫폼입니다. 동시적 지도화 및 위치 추정(SLAM), 장애물 회피 경로 계획, 포인트 클라우드 처리 알고리즘을 개발합니다. 광업(BHP, Rio Tinto), 건설, 국방 분야에 납품합니다.

---

## 🚗 자동차/모빌리티 관련성

ADAS와 동일한 기술 스택: LiDAR 포인트 클라우드 처리, 실시간 SLAM(NDT·ICP), 센서 퓨전(LiDAR+IMU), 경로 계획 알고리즘(ROS 기반). 자율주행 ADAS 센서 퓨전 경험을 자율 로봇으로 직접 전환 가능합니다.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

- 광업·건설·국방 분야 자율 로봇 수요 급증
- BHP·Rio Tinto 등 대형 광산사와 파트너십
- QUT 연구 인프라 기반 기술 경쟁력 + 글로벌 확장 중

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | LiDAR SLAM·센서 퓨전·자율 경로 계획 — ADAS 기술을 자율 로봇에 적용. 브리즈번 성장 스타트업. |
| 추천 직무 | Robotics SW Engineer (SLAM/LiDAR), Perception Engineer, Autonomous Systems Developer |
| 지원 방법 | emesent.com/careers, LinkedIn |
| 한국 채용 | 없음 — 브리즈번 포지션 |
| 비자 스폰 가능성 | ★★★ — 기술 스타트업, TSS 482 가능 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [emesent.com](https://www.emesent.com)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Emesent 공식 홈페이지 (2026.06 기준)*
