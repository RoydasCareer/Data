---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/iot
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Fleet Space Technologies"
size: "스타트업"
fit: "★"
business: "나노위성 기반 IoT 연결 네트워크 (광업·농업·스마트시티)"
hq: "Adelaide, South Australia, Australia"
founded: "2015"
employees: "~100명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (~$65M AUD 투자 유치)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Fleet Space Technologies

> 나노위성 IoT 연결 네트워크 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Adelaide, South Australia, Australia |
| 설립 연도 | 2015년 |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 (~$65M AUD 투자 유치) |
| 주력 사업 | 큐브위성(나노위성) 군집 네트워크 + Centauri IoT — 오지 광업·농업 자산 원격 모니터링 |
| 공식 홈페이지 | https://www.fleetspace.com |

> ⚠️ **자동차 임베디드 SW와 직접 연관 없음.** 위성 IoT 통신 인프라 전문 기업 (광업·농업 자산 추적 중심).

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 오지 위성 IoT 틈새 시장.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 위성 IoT 인프라 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Embedded SW / RF Engineer (위성 IoT) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [fleetspace.com](https://www.fleetspace.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: fleetspace.com 공식 (2026.05 기준)*
