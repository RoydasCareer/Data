---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/adas
  - automotive/sensing
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "Baraja"
size: "중소기업"
fit: "★★"
business: "Spectrum-Scan™ LiDAR 센서 기술 (자율주행용)"
hq: "Sydney, New South Wales, Australia"
founded: "2016"
employees: "~80명 (2024)"
revenue: "비공개"
ipo_status: "비상장 ($32M+ 투자 유치)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Baraja

> Spectrum-Scan™ LiDAR 기술 | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2016년 |
| 임직원 수 | ~80명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 ($32M+ 투자 유치) |
| 주력 사업 | Spectrum-Scan™ 파장 조향 LiDAR — 기계적 회전부 없는 고신뢰성 자율주행용 LiDAR 센서 |
| 공식 홈페이지 | https://www.baraja.com |

**자동차 관련:** 자율주행·ADAS용 LiDAR 센서 + 센서 퓨전 SW — Trident 제품 시리즈.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 자율주행 LiDAR 시장 성장.
- 독자적 Spectrum-Scan 기술로 차별화.
- 소규모 — 자금·상용화 경쟁 치열.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | LiDAR 센서·자율주행 인식 SW — ADAS 경험 직접 활용. 한국 사무소 없음. |
| 추천 직무 | Sensor SW / Perception Engineer — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [baraja.com](https://www.baraja.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: baraja.com 공식 (2026.05 기준)*
