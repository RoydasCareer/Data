---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/ev
  - automotive/charging
  - fit/★★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Tritium"
size: "중견기업"
fit: "★★★★"
business: "DC 급속 EV 충전기 설계·제조·SW 플랫폼 (NASDAQ: DCFC)"
hq: "Brisbane, Queensland, Australia"
founded: "2001"
employees: "~600명 (2024)"
revenue: "~US$236M (FY2023)"
ipo_status: "NASDAQ 상장 (DCFC) — 2022년 SPAC 합병"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Tritium

> DC 급속 EV 충전기 전문기업 | 중견기업 | 호주 🇦🇺 | NASDAQ: DCFC

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Brisbane, Queensland, Australia (미국 테네시주 제조공장) |
| 설립 연도 | 2001년 (퀸즐랜드대학교 스핀아웃) |
| 임직원 수 | ~600명 (2024) |
| 연매출 | ~US$236M (FY2023) |
| 상장 | NASDAQ: DCFC (2022년 SPAC 상장) |
| 주력 사업 | PKM·RTM 시리즈 DC 급속 충전기 + VEEFIL 플랫폼 SW |
| 공식 홈페이지 | https://www.tritiumcharging.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2001 | 퀸즐랜드대학교 스핀아웃 창업 |
| 2015 | 유럽 EV 충전 시장 진출 |
| 2022 | NASDAQ SPAC 상장 (DCFC) |
| 2023 | 미국 테네시주 제조공장 가동 |

---

## 🎯 주요 제품 & 서비스

PKM 시리즈(50/75kW)와 RTM 시리즈(300/475kW) DC 급속 충전기를 설계·제조합니다. 독자 개발한 VEEFIL 충전 플랫폼 SW로 충전기 네트워크 원격 관리, 결제, 진단 기능을 제공합니다. CCS/CHAdeMO/GB-T 멀티 프로토콜 지원.

---

## 🚗 자동차/모빌리티 관련성

EV 충전 인프라의 핵심 HW·SW를 모두 자체 개발합니다. 임베디드 펌웨어, 전력 전자 제어 SW, 클라우드 충전 관리 플랫폼, CCS/OCPP 프로토콜 스택 등 자동차 SW 엔지니어가 직접 기여할 수 있는 분야가 광범위합니다.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

- 글로벌 EV 충전 인프라 투자 급증 (미국 IRA, 유럽 AFIR 규제)
- 미국 테네시 공장으로 현지 생산 — Buy American 조건 충족
- 재무적으로 적자 지속 중 → 수익성 개선이 핵심 과제

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | EV 충전기 임베디드 SW·전력 제어·충전 프로토콜(OCPP/CCS) 전 분야 채용. 호주 창업 NASDAQ 상장사로 글로벌 기회. |
| 추천 직무 | Embedded SW Engineer (충전기 펌웨어), Cloud Platform Engineer (VEEFIL), Power Electronics SW Engineer |
| 지원 방법 | tritiumcharging.com/careers, LinkedIn |
| 한국 채용 | 없음 — 브리즈번/테네시 포지션 |
| 비자 스폰 가능성 | ★★★ — 상장사, TSS 482 비자 가능 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [tritiumcharging.com](https://www.tritiumcharging.com)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Tritium 공식 홈페이지, NASDAQ 공시 (2026.06 기준)*
