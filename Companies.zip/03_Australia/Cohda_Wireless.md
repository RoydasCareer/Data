---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/v2x
  - automotive/connectivity
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "Cohda Wireless"
size: "중소기업"
fit: "★★"
business: "V2X·커넥티드카 통신 SW (DSRC/C-V2X)"
hq: "Adelaide, South Australia, Australia"
founded: "2007"
employees: "~120명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (DENSO 등 전략적 투자)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Cohda Wireless

> V2X 커넥티드카 통신 SW | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Adelaide, South Australia, Australia |
| 설립 연도 | 2007년 (University of Adelaide 스핀아웃) |
| 임직원 수 | ~120명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 (DENSO·Tier1 전략적 투자) |
| 주력 사업 | MK5/MK6 V2X OBU·RSU 플랫폼 — DSRC/C-V2X (ETSI ITS-G5 / SAE J2735) 표준 SW 스택 |
| 공식 홈페이지 | https://www.cohdawireless.com |

**자동차 관련:** V2X 통신 SW 스택 — 교차로 안전, 자율주행 인프라 연계, 협력형 ADAS(C-ADAS) 핵심 기술.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 유럽·미국·호주 V2X 파일럿 중심.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 글로벌 V2X 의무화 진행 — 유럽 eCall, 미국 C-V2X 표준화.
- DENSO 등 대형 Tier1 전략적 파트너.
- 소규모 — 대형 통신·반도체 기업과 경쟁.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | V2X·커넥티드카 통신 SW — CAN/DoIP 통신 경험 확장 가능. 한국 사무소 없음. |
| 추천 직무 | Embedded SW Engineer (V2X 스택) / Protocol Engineer — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [cohdawireless.com](https://www.cohdawireless.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: cohdawireless.com 공식 (2026.05 기준)*
