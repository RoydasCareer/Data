---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/ev
  - automotive/charging
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Evie Networks"
size: "중소기업"
fit: "★★★"
business: "호주 EV 급속 충전 네트워크 (NRMA·RAA·RACQ 컨소시엄 + 정부 투자)"
hq: "Sydney, New South Wales, Australia"
founded: "2018"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (NRMA·RAA·RACQ·RAC 공동 투자)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Evie Networks

> 호주 EV 급속 충전 네트워크 | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2018년 |
| 임직원 수 | ~50명 (2024) |
| 상장 여부 | 비상장 (NRMA·RAA·RACQ·RAC 호주 자동차 클럽 컨소시엄) |
| 주력 사업 | 호주 전국 DC 급속 EV 충전 네트워크 구축·운영 + 충전 플랫폼 SW |
| 공식 홈페이지 | https://www.evienetworks.com.au |

---

## 🎯 주요 제품 & 서비스

호주 주요 고속도로(Pacific Hwy, Hume Hwy 등)와 목적지 충전 거점에 50~350kW DC 급속 충전기를 구축합니다. 자체 개발 충전 관리 플랫폼으로 OCPP 1.6/2.0 기반 충전기 원격 모니터링, 결제 처리, 에너지 관리, 고장 진단을 제공합니다. 정부 ARENA·NRMA 투자로 전국 네트워크를 확장 중입니다.

---

## 🚗 자동차/모빌리티 관련성

OCPP 프로토콜 스택 구현, 충전기 백엔드 플랫폼 SW, DC 충전기 통신 인터페이스(ISO 15118·DIN 70121), 에너지 관리 알고리즘. EV 충전 인프라 SW 생태계 핵심 분야.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

- 호주 정부 ARENA 충전 인프라 펀딩 수혜 (AUD $87.7M+)
- 호주 자동차 클럽 4개의 안정적 자금 지원
- Chargefox와 함께 호주 양대 DC 급속 충전 네트워크

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | OCPP·ISO 15118 충전 프로토콜 + 충전 네트워크 플랫폼 SW — EV 충전 인프라 핵심 기술. 안정적 컨소시엄 투자 기반. |
| 추천 직무 | Backend/Platform Engineer (충전 관리), Embedded Engineer (충전기 펌웨어), EV Charging Systems Engineer |
| 지원 방법 | evienetworks.com.au/careers, LinkedIn |
| 한국 채용 | 없음 — 시드니 포지션 |
| 비자 스폰 가능성 | ★★★ — 중견 규모, TSS 482 가능 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [evienetworks.com.au](https://www.evienetworks.com.au)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Evie Networks 공식 홈페이지 (2026.06 기준)*
