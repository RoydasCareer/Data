---
tags:
  - company
  - automotive
  - country/australia
  - size/large
  - automotive/aspice
  - automotive/functional-safety
  - automotive/cybersecurity
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "DNV Australia"
size: "대기업"
fit: "★★★"
business: "자동차 A-SPICE·ISO26262·기능안전 컨설팅·평가·훈련 (DNV 글로벌 Business Assurance)"
hq: "Melbourne & Sydney, Australia (호주 주요 거점); 글로벌 HQ: Høvik, Norway"
founded: "1864 (DNV 창립); 호주 법인 [확인필요]"
employees: "15,000명+ (DNV 글로벌); 호주 규모 미공개"
revenue: "NOK 33.8B (DNV 글로벌, 2024)"
ipo_status: "비상장 (재단 소유 — Det Norske Veritas Stiftelse)"
korea_office: "DNV Korea — 부산 (글로벌 법인)"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# DNV Australia

> A-SPICE·ISO26262·기능안전 컨설팅·평가 | 대기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 멜버른 오피스 | 350 Queen Street, Level 12, Melbourne |
| 시드니 오피스 | 124 Walker Street, Level 7, North Sydney |
| 설립 연도 | 1864년 (DNV 창립, 노르웨이); 호주 법인 [확인필요] |
| 임직원 수 | 15,000명+ (DNV 글로벌); 호주 규모 미공개 |
| 규모 분류 | 대기업 (글로벌 기준) |
| 상장 여부 | 비상장 (Det Norske Veritas 재단 소유) |
| 주력 사업 | 자동차 A-SPICE 프로세스 컨설팅·평가·훈련 / ISO 26262 기능안전 평가·갭 분석·검증 지원 |
| 공식 홈페이지 | https://www.dnv.com.au |

글로벌 리스크 관리·품질보증(Business Assurance) 기관 DNV의 호주 법인. **A-SPICE 프로세스 개발·최적화·평가** 및 **ISO 26262 기능안전 평가·갭 분석·안전 개념 개발** 서비스 제공. ISO/SAE 21434(자동차 사이버보안) 대응 서비스도 포함. 멜버른·시드니 2개 오피스 운영.

---

## 🇰🇷 한국 관련

**DNV Korea** — 부산 소재 (선급·해양 중심). 자동차 기능안전 분야 채용은 호주 오피스 중심 — 직접 지원 필요.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- 호주 자동차 산업 내 A-SPICE·ISO26262 전문 컨설팅 수요 증가
- ISO/SAE 21434(사이버보안) 신규 서비스 수요 구조적 성장
- DNV 글로벌 브랜드 — 자동차 안전 분야 세계적 공신력

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | A-SPICE 프로세스 컨설팅·ISO26262 기능안전 평가 직접 수행 — 사용자 핵심 역량 100% 직결. 호주 멜버른·시드니 2개 거점. DNV 글로벌 브랜드 경력 가치 높음. |
| 추천 직무 | A-SPICE Assessor, Functional Safety Engineer, Automotive Cybersecurity Consultant |
| 한국 지원 경로 | 없음 (호주 본사 직접 지원 — dnv.com.au/careers) |
| 비자 스폰 가능성 | ★★★ — TSS 482 비자 (대기업 스폰서 가능) |
| 고졸 채용 가능성 | 기술 자격·경험 중시 (ASIL·A-SPICE 자격 보유 시 유리) |

---

## ⚠️ 리스크 / 고려사항

- **재단 소유 비상장**: 재무 공개 의무 없음 — 경영 안정성 외부 파악 제한
- **호주 오피스 팀 규모 미공개**: 자동차 전담 인원 확인 필요 — LinkedIn 탐색 권장
- **컨설팅 특성**: 프로젝트 기반 — 계약직 위주일 수 있음
- **한국 법인 연결 제한**: DNV Korea는 선급/해양 중심 — 자동차 분야 지원은 호주 직접 지원 필요

## 🔗 관련 정보

- 홈페이지: [dnv.com.au](https://www.dnv.com.au)
- 자동차 서비스: [dnv.com.au/assurance/automotive-aerospace](https://www.dnv.com.au/assurance/automotive-aerospace/)
- LinkedIn: [linkedin.com/company/dnv](https://www.linkedin.com/company/dnv/)
- 채용: [dnv.com/careers](https://www.dnv.com/careers)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: dnv.com.au 공식, DNV A-SPICE·ISO26262 서비스 페이지 (2026.06 기준)*
