---
tags:
  - company
  - automotive
  - country/australia
  - size/public
  - automotive/v2x
  - automotive/safety
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Austroads"
size: "공기업"
fit: "★"
business: "호주·뉴질랜드 도로 교통 표준화 기관 — AV 가이드라인·V2X 표준 주도"
hq: "Sydney, New South Wales, Australia"
founded: "1989"
employees: "~80명 (2024)"
revenue: "정부 기금 (비상업)"
ipo_status: "비상장 (호주·뉴질랜드 주 교통부 공동 설립)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Austroads

> 호주·뉴질랜드 도로 교통 표준화 기관 | 공기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 1989년 |
| 임직원 수 | ~80명 (2024) |
| 규모 분류 | 공기업 (정부 간 기구) |
| 상장 여부 | 비상장 |
| 주력 사업 | 도로 설계·안전 기준 표준화 + AV 가이드라인·V2X 표준 개발 — 정책 연구 기관 |
| 공식 홈페이지 | https://www.austroads.com.au |

> ⚠️ **상업 기업이 아닌 정부 표준화 기관.** 직접 채용보다 정책 연구 역할.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- AV·V2X 표준화 역할 중요.
- 정부 기관 — 상업적 성장 개념 해당 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 정부 표준화 기관 — 상업 취업 경로 매우 제한적. 한국 사무소 없음. |
| 추천 직무 | Transport Policy Researcher / Standards Engineer — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 정부 기관, 외국인 채용 제한 |
| 고졸 채용 가능성 | 학위 필수 |

---

## 🔗 관련 정보

- 홈페이지: [austroads.com.au](https://www.austroads.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: austroads.com.au 공식 (2026.05 기준)*
