---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Connexion Technologies"
size: "스타트업"
fit: "★"
business: "커넥티드카·애프터마켓 텔레매틱스 서비스"
hq: "Perth, Western Australia, Australia"
founded: "2015"
employees: "~20명 (2024)"
revenue: "소규모 (ASX 상장)"
ipo_status: "상장 (ASX: CXZ)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Connexion Technologies

> 커넥티드카 텔레매틱스 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Perth, Western Australia, Australia |
| 설립 연도 | 2015년 |
| 임직원 수 | ~20명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | ASX: CXZ (소형 상장사) |
| 주력 사업 | 애프터마켓 커넥티드카 텔레매틱스 서비스 — 운전 데이터·위치 추적·원격 진단 |
| 공식 홈페이지 | https://www.connexiontechnologies.com.au |

**자동차 관련:** 차량 커넥티비티·텔레매틱스 — 자동차 임베디드 SW와 직접 연관 낮음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 소규모 ASX 상장 스타트업 — 자금 제한적.
- 커넥티드카 애프터마켓 시장 경쟁 치열.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 스타트업 — 자동차 임베디드 SW 직접 연관 낮음. |
| 추천 직무 | SW Engineer (IoT 텔레매틱스) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [connexiontechnologies.com.au](https://www.connexiontechnologies.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: connexiontechnologies.com.au 공식 (2026.05 기준)*
