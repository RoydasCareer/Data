---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/mobility
  - automotive/parking
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Divvy Parking"
size: "스타트업"
fit: "★"
business: "기업·상업용 스마트 주차 관리 SaaS"
hq: "Sydney, New South Wales, Australia"
founded: "2015"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Divvy Parking

> 기업·상업용 스마트 주차 관리 SaaS | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2015년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 기업·상업용 빌딩 주차공간 예약·관리 SaaS — 직원 주차 배정 자동화 |
| 공식 홈페이지 | https://www.divvyparking.com.au |

**자동차 관련:** 주차 관리 플랫폼 — 자동차 임베디드 SW와 직접 연관 없음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 기업 주차 관리 SaaS 수요.
- 소규모 — 확장성 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 주차 관리 SaaS — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Full-Stack Engineer (SaaS) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [divvyparking.com.au](https://www.divvyparking.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: divvyparking.com.au 공식 (2026.05 기준)*
