---
tags:
  - company
  - automotive
  - country/australia
  - size/public
  - automotive/autonomous
  - automotive/safety
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Department of Transport and Planning (Victoria)"
size: "공기업"
fit: "★"
business: "빅토리아주 교통·자율주행 정책·규제 기관"
hq: "Melbourne, Victoria, Australia"
founded: "—"
employees: "~5,000명 (2024)"
revenue: "정부 (비상업)"
ipo_status: "비상장 (빅토리아주 정부 기관)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Department of Transport and Planning (Victoria)

> 빅토리아주 교통·자율주행 정책 기관 | 공기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 임직원 수 | ~5,000명 (2024) |
| 규모 분류 | 공기업 (정부 기관) |
| 상장 여부 | 비상장 |
| 주력 사업 | 빅토리아주 도로·교통 인프라 관리 + 자율주행 차량 규제·테스팅 정책 수립 |
| 공식 홈페이지 | https://www.transport.vic.gov.au |

> ⚠️ **상업 기업이 아닌 정부 부처.** 외국인 취업 경로 매우 제한적.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★**

- 정부 기관 — 상업 성장 해당 없음.
- 외국인 비자 스폰서 거의 불가.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 정부 부처 — 외국인 취업 경로 매우 제한적. 한국 사무소 없음. |
| 추천 직무 | 해당없음 (정부 공무원직) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 정부 기관, 시민권자 우선 |
| 고졸 채용 가능성 | 학위 필수 |

---

## 🔗 관련 정보

- 홈페이지: [transport.vic.gov.au](https://www.transport.vic.gov.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: transport.vic.gov.au 공식 (2026.05 기준)*
