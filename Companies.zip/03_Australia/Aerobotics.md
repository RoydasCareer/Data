---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/testing
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Aerobotics"
size: "스타트업"
fit: "★"
business: "드론·AI 기반 농작물 분석 SaaS (자동차 무관 — 남아공 창업)"
hq: "Cape Town, South Africa (창업) — 호주 운영 미확인"
founded: "2014"
employees: "~100명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Aerobotics

> 드론·AI 농작물 분석 SaaS | 스타트업 | 남아공(호주) 🇿🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Cape Town, South Africa (창업, 호주 운영 미확인) |
| 설립 연도 | 2014년 |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 드론 촬영 + AI 기반 과수원·농작물 병해충 분석 SaaS — 남아공·미국·호주 농업 시장 |
| 공식 홈페이지 | https://www.aerobotics.com |

> ⚠️ **자동차 임베디드 SW와 직접 연관 없음.** 농업용 드론 영상분석 전문 기업. 호주 배치 여부 미확인.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 농업 드론 AI 분석 틈새 시장.
- 자동차 임베디드 SW와 무관.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 농업 드론 AI — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | ML/CV Engineer (드론 영상 분석) — 남아공/원격 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | 미확인 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [aerobotics.com](https://www.aerobotics.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: aerobotics.com 공식 (2026.05 기준)*
