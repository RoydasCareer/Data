---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/fleet
  - automotive/telematics
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Geotab Australia"
size: "중견기업"
fit: "★★★"
business: "OBD-II·CAN 버스 기반 상용 플릿 텔레매틱스 플랫폼 (세계 최대 플릿 텔레매틱스)"
hq: "Sydney, New South Wales, Australia"
founded: "2012"
employees: "~100명 (호주, 2024)"
revenue: "비공개 (Geotab Inc. 글로벌 연매출 $1B+)"
ipo_status: "비상장 (캐나다 Geotab Inc. 자회사)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Geotab Australia

> 세계 최대 플릿 텔레매틱스 | 중견기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2012년 (호주 법인) |
| 임직원 수 | ~100명 (호주, 2024) |
| 상장 여부 | 비상장 (캐나다 Geotab Inc. 자회사) |
| 주력 사업 | OBD-II·CAN J1939 기반 플릿 텔레매틱스 HW(GO 디바이스) + MyGeotab 클라우드 플랫폼 |
| 공식 홈페이지 | https://www.geotab.com/au |

---

## 🎯 주요 제품 & 서비스

**GO 디바이스**: OBD-II·SAE J1939 CAN 버스를 통해 차량 엔진 데이터(RPM, 연료 소모, 고장 코드 DTC), 운전 거동, GPS를 실시간 수집하는 텔레매틱스 HW입니다. **MyGeotab**: 350,000+ 기업 고객에게 플릿 최적화, 운전자 코칭, EV 충전 관리, 차량 상태 모니터링을 제공하는 클라우드 플랫폼. **IOX 확장 포트**: 개방형 HW 인터페이스로 냉동차·특수장비 센서를 통합합니다.

---

## 🚗 자동차/모빌리티 관련성

OBD-II/CAN J1939 프로토콜 파싱, DTC 진단 코드 처리, 차량 CAN 데이터 수집 펌웨어, EV 배터리 상태(SoC·SoH) 모니터링 알고리즘. 차량 통신 프로토콜(CAN·J1939·OBD-II) 경험이 핵심 역량입니다.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

- 전 세계 400만+ 연결 차량 — 세계 최대 규모 플릿 텔레매틱스
- EV 플릿 전환으로 EV 텔레매틱스 수요 급증
- 호주·뉴질랜드 시장 성장 중

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | OBD-II·CAN J1939·DTC 진단 — 차량 통신 프로토콜 전문 기술 활용. 세계 최대 플릿 텔레매틱스 기업의 호주 법인. |
| 추천 직무 | Embedded SW Engineer (GO Device/CAN), Fleet Software Engineer, EV Telematics Developer |
| 지원 방법 | geotab.com/au/careers, LinkedIn |
| 한국 채용 | 없음 — 시드니 포지션 |
| 비자 스폰 가능성 | ★★★ — 글로벌 기업 호주 법인, TSS 482 가능 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [geotab.com/au](https://www.geotab.com/au)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Geotab Australia 공식 홈페이지 (2026.06 기준)*
