---
tags:
  - company
  - automotive
  - country/australia
  - size/large
  - automotive/connectivity
  - automotive/iot
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Telstra (IoT/Automotive)"
size: "대기업"
fit: "★"
business: "호주 최대 통신사 — 커넥티드카·차량 IoT 사업부"
hq: "Melbourne, Victoria, Australia"
founded: "1975"
employees: "~22,000명 (2024)"
revenue: "~$23B AUD (FY2024)"
ipo_status: "상장 (ASX: TLS)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Telstra (IoT/Automotive)

> 호주 최대 통신사·커넥티드카 IoT | 대기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 1975년 |
| 임직원 수 | ~22,000명 (2024) |
| 규모 분류 | 대기업 |
| 상장 여부 | ASX: TLS |
| 주력 사업 | 4G/5G 통신 + 기업 IoT — C-V2X 커넥티드카 시범 사업·차량 원격 진단 서비스 제공 |
| 공식 홈페이지 | https://www.telstra.com.au |

**자동차 관련:** 호주 C-V2X·스마트교통 파일럿 통신 파트너 — 핵심 사업은 통신, 자동차 임베디드 SW와 직접 연관 낮음.

---

## 🇰🇷 한국 관련

한국 사무소 없음 (호주 전용 통신사).

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 호주 5G 최대 사업자.
- 자동차 임베디드 SW 직접 연관 낮음 — 통신 인프라 사업자.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 통신사 — 자동차 임베디드 SW 전문성과 연관 낮음. |
| 추천 직무 | IoT Platform Engineer / 네트워크 엔지니어 — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 대기업, TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [telstra.com.au](https://www.telstra.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: telstra.com.au 공식 (2026.05 기준)*
