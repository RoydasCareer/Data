---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/autonomous
  - automotive/ev
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "Applied EV"
size: "중소기업"
fit: "★★"
business: "모듈형 자율주행 EV 샤시 플랫폼 (BLADE)"
hq: "Melbourne, Victoria, Australia"
founded: "2016"
employees: "~100명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Applied EV

> 모듈형 자율주행 EV 샤시 플랫폼 | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 2016년 |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | BLADE 모듈형 자율주행 EV 샤시 + Koios 자율주행 컴퓨팅 플랫폼 — 물류·공항·광산 자율 이동체 |
| 공식 홈페이지 | https://www.appliedev.com.au |

**자동차 관련:** 자율주행 EV 플랫폼 — 임베디드 SW·전력 전자·자율주행 스택 개발 포함.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 물류·공항·광산 자율 이동 플랫폼 수요 증가.
- 소규모 — 상용화 단계 초기.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자율주행 EV 임베디드 플랫폼 — ADAS/자율주행 SW 경험 직접 활용 가능. 한국 사무소 없음. |
| 추천 직무 | Embedded SW Engineer (자율주행 플랫폼) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 (고용주 스폰서) 가능 |
| 고졸 채용 가능성 | 관련 직무 경험으로 대체 가능 |

---

## 🔗 관련 정보

- 홈페이지: [appliedev.com.au](https://www.appliedev.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: appliedev.com.au 공식 (2026.05 기준)*
