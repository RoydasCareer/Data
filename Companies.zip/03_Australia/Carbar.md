---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/mobility
  - automotive/ev
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Carbar"
size: "스타트업"
fit: "★"
business: "호주 자동차 구독 서비스 플랫폼"
hq: "Sydney, New South Wales, Australia"
founded: "2016"
employees: "~100명 (2024)"
revenue: "비공개 (~$43M AUD 투자)"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Carbar

> 자동차 구독 서비스 플랫폼 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2016년 |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 (~$43M AUD 투자 유치) |
| 주력 사업 | 월정액 자동차 구독 서비스 — 보험·유지보수·등록세 포함 호주 소비자 대상 EV/ICE 구독 |
| 공식 홈페이지 | https://www.carbar.com.au |

**자동차 관련:** 자동차 구독 플랫폼 — 자동차 임베디드 SW와 직접 연관 없음.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 호주 전용 소비자 서비스.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 호주 EV 구독 수요 증가.
- 소규모 스타트업 — 수익성 확보 과제.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소비자 자동차 구독 플랫폼 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Full-Stack Engineer (구독 플랫폼) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [carbar.com.au](https://www.carbar.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: carbar.com.au 공식 (2026.05 기준)*
