---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/testing
  - automotive/qa
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "Laserbird"
size: "스타트업"
fit: "★★"
business: "AI 기반 자동차 차체 손상·품질 검사 자동화 SW"
hq: "Melbourne, Victoria, Australia"
founded: "~2018"
employees: "~20명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Laserbird

> AI 자동차 차체 손상·품질 검사 자동화 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | ~2018년 |
| 임직원 수 | ~20명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 컴퓨터 비전 기반 자동차 차체 손상 자동 감지·품질 검사 — 렌터카·중고차·딜러십 대상 |
| 공식 홈페이지 | https://www.laserbird.io |

**자동차 관련:** 자동차 차체 AI 손상 감지 — ADAS 카메라·CV 기술 자동차 품질 검사 적용.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- AI 차량 손상 감지 시장 성장.
- 소규모 스타트업 — 자금·고객 기반 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | AI 차량 손상 감지 — 컴퓨터 비전·ADAS 경험 활용 가능. 소규모 스타트업. 한국 사무소 없음. |
| 추천 직무 | CV/ML Engineer (자동차 품질 검사) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [laserbird.io](https://www.laserbird.io)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: laserbird.io 공식 (2026.05 기준)*
