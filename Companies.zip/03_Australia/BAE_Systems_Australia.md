---
tags:
  - company
  - automotive
  - country/australia
  - size/large
  - automotive/embedded
  - automotive/defense
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "BAE Systems Australia"
size: "대기업"
fit: "★★★"
business: "방산 전투차량 전자·임베디드 SW (Redback IFV·LAND 400 Phase 3 주계약사)"
hq: "Melbourne, Victoria, Australia"
founded: "1985"
employees: "~5,000명 (호주, 2024)"
revenue: "비공개 (BAE Systems plc 글로벌 연매출 £25B+)"
ipo_status: "비상장 (BAE Systems plc 자회사 — London: BA.)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# BAE Systems Australia

> 방산 전투차량 전자·임베디드 SW | 대기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia (브리즈번·캔버라·애들레이드 거점) |
| 설립 연도 | 1985년 (호주 법인) |
| 임직원 수 | ~5,000명 (호주, 2024) |
| 상장 여부 | 비상장 (BAE Systems plc 자회사, London: BA.) |
| 주력 사업 | Redback IFV(보병전투차) 전자 시스템, 함정 전투 관리, 사이버 보안 |
| 공식 홈페이지 | https://www.baesystems.com/en-au |

---

## 🎯 주요 제품 & 서비스

BAE Systems Australia는 LAND 400 Phase 3(Redback IFV 129대, AUD $27B 규모)의 주계약사입니다. Redback 전투차량의 전자 아키텍처: CAN/MIL-STD-1553 기반 차량 관리 시스템, 전투 관리 SW(BMS), 원격 무장 시스템 제어, 드라이버 열화상·카메라 시스템, 차량 전력 분배 제어 임베디드 SW를 개발합니다.

---

## 🚗 자동차/모빌리티 관련성

방산이지만 기술 스택은 자동차 임베디드 SW와 동일: 실시간 RTOS(QNX·VxWorks) 임베디드 C/C++, CAN 버스·MIL-STD-1553 통신, 센서 퓨전(열화상·LiDAR·카메라), 차량 전력 관리 제어. DO-178C/ISO 26262 수준의 안전 무결성 SW 개발 경험 가능.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

- AUD $27B LAND 400 Phase 3 Redback IFV 계약 (10년+ 프로그램)
- 호주 국방 예산 확대 기조 — 차량 전자화 추가 프로그램 예정
- 안정적 장기 계약 기반의 대기업 고용

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | Redback IFV 전투차량 임베디드 SW — RTOS·CAN·센서 퓨전. 자동차 임베디드 기술 방산에 적용. 대형 장기 계약 안정성. |
| 추천 직무 | Embedded SW Engineer (Vehicle Systems), Combat Vehicle SW Developer, Systems Integration Engineer |
| 지원 방법 | baesystems.com/en-au/careers, LinkedIn |
| 한국 채용 | 없음 — 멜버른/브리즈번 포지션 (보안 클리어런스 요구) |
| 비자 스폰 가능성 | ★★★ — 대기업이나 보안 클리어런스로 외국인 채용 제한적 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [baesystems.com/en-au](https://www.baesystems.com/en-au)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: BAE Systems Australia 공식 홈페이지 (2026.06 기준)*
