---
tags:
  - company
  - automotive
  - country/australia
  - size/public
  - automotive/v2x
  - automotive/connectivity
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Transport for NSW"
size: "공기업"
fit: "★"
business: "NSW주 교통 인프라·스마트교통·V2X 파일럿 운영 기관"
hq: "Sydney, New South Wales, Australia"
founded: "2011"
employees: "~30,000명 (2024)"
revenue: "정부 (비상업)"
ipo_status: "비상장 (NSW주 정부 기관)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Transport for NSW

> NSW주 교통 인프라·스마트교통 기관 | 공기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2011년 |
| 임직원 수 | ~30,000명 (2024) |
| 규모 분류 | 공기업 (NSW주 교통부) |
| 상장 여부 | 비상장 |
| 주력 사업 | NSW주 전체 교통 인프라 관리 — 도로·철도·버스·페리 + 스마트교통·V2X·AV 파일럿 프로젝트 |
| 공식 홈페이지 | https://www.transport.nsw.gov.au |

> ⚠️ **상업 기업이 아닌 정부 기관.** 외국인 취업 경로 제한적이나 IT/SW 직군 채용 있음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★**

- 정부 기관 — 상업 성장 해당 없음.
- 스마트교통 IT 인력 채용 있으나 외국인 비자 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 정부 교통 기관 — 외국인 취업 경로 매우 제한적. 한국 사무소 없음. |
| 추천 직무 | IT/Platform Engineer (스마트교통) — 호주 영주권·시민권자 우선 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 정부 기관, 시민권자 우선 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [transport.nsw.gov.au](https://www.transport.nsw.gov.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: transport.nsw.gov.au 공식 (2026.05 기준)*
