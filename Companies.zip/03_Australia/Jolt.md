---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/ev
  - automotive/charging
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Jolt"
size: "중소기업"
fit: "★★★"
business: "무료 EV 충전 + 디지털 광고 통합 스타트업 (충전기 임베디드 SW·네트워크 플랫폼)"
hq: "Adelaide, South Australia, Australia"
founded: "2018"
employees: "~80명 (2024)"
revenue: "비공개 ($40M+ 투자 유치)"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Jolt

> 무료 EV 충전·디지털 광고 통합 스타트업 | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Adelaide, South Australia, Australia |
| 설립 연도 | 2018년 |
| 임직원 수 | ~80명 (2024) |
| 상장 여부 | 비상장 ($40M+ 투자 유치) |
| 주력 사업 | AC 무료 EV 충전기 + 대형 디지털 광고 스크린 통합 — 광고 수익으로 충전 무료화 |
| 공식 홈페이지 | https://www.jolt.com.au |

---

## 🎯 주요 제품 & 서비스

Jolt는 쇼핑몰·주유소 등 고통행량 장소에 22kW AC 충전기와 55인치 디지털 광고 스크린을 통합한 충전 스테이션을 설치합니다. **충전 SW 플랫폼**: OCPP 기반 충전 관리, 광고 콘텐츠 관리 시스템(CMS)과 충전기 제어 시스템 통합, 모바일 앱(충전 인증·세션 관리), 에너지 최적화. 호주 + 영국·UAE 확장 중.

---

## 🚗 자동차/모빌리티 관련성

충전기 임베디드 펌웨어(OCPP·IEC 61851), 충전 세션 관리 플랫폼, 광고-충전 통합 IoT 시스템. 독특한 비즈니스 모델의 EV 충전 SW 스타트업.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★**

- 독자적 무료 충전 모델로 EV 충전 시장 차별화
- 호주·영국·UAE 글로벌 확장 중
- 미디어 + EV 충전 결합 새로운 수익 모델

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | EV 충전기 임베디드 펌웨어·OCPP 플랫폼·IoT 통합 — 독자적 비즈니스 모델의 충전 스타트업. |
| 추천 직무 | Embedded SW Engineer (EV Charger Firmware), IoT Platform Engineer, Backend Developer |
| 지원 방법 | jolt.com.au/careers, LinkedIn |
| 한국 채용 | 없음 — 애들레이드(SA) 포지션 |
| 비자 스폰 가능성 | ★★★ — 성장 스타트업, TSS 482 가능 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [jolt.com.au](https://www.jolt.com.au)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Jolt 공식 홈페이지 (2026.06 기준)*
