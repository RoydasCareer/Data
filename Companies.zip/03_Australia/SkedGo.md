---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/mobility
  - automotive/maas
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "SkedGo"
size: "스타트업"
fit: "★"
business: "MaaS 통합 경로 탐색 API/SDK (TripGo 플랫폼)"
hq: "Sydney, New South Wales, Australia"
founded: "2007"
employees: "~20명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# SkedGo

> MaaS 통합 경로 탐색 API/SDK | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2007년 (TripGo로 시작) |
| 임직원 수 | ~20명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | TripGo MaaS 플랫폼 API/SDK — 버스·기차·자전거·차량 통합 멀티모달 경로 탐색 |
| 공식 홈페이지 | https://skedgo.com |

**자동차 관련:** 자동차·대중교통 통합 MaaS 경로 탐색 — 자동차 임베디드 SW와 직접 연관 없음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- MaaS 플랫폼 SDK 수요 증가.
- 소규모 — 확장 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 MaaS SDK — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Backend Engineer (경로 탐색 API) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [skedgo.com](https://skedgo.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: skedgo.com 공식 (2026.05 기준)*
