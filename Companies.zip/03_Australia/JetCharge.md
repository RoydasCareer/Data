---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/ev
  - automotive/charging
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "JetCharge"
size: "스타트업"
fit: "★★★"
business: "EV 충전 솔루션 (HW 공급·설치 + SW 관리 플랫폼)"
hq: "Melbourne, Victoria, Australia"
founded: "2018"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# JetCharge

> EV 충전 솔루션 스타트업 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 2018년 |
| 임직원 수 | ~50명 (2024) |
| 상장 여부 | 비상장 |
| 주력 사업 | 가정·상업용 EV 충전기 설치 + 충전 관리 SW 플랫폼(JetCharge Cloud) |
| 공식 홈페이지 | https://www.jetcharge.com.au |

---

## 🎯 주요 제품 & 서비스

주거·상업용 EV 충전기(Level 2 AC)를 설치·공급하고, 자체 개발한 JetCharge Cloud 플랫폼으로 충전 세션 관리, 에너지 모니터링, 스마트 스케줄링, OCPP 통신을 제공합니다. Tesla, Schneider, Wallbox 등 주요 충전기 브랜드의 공인 파트너입니다.

---

## 🚗 자동차/모빌리티 관련성

OCPP 기반 충전 관리 플랫폼 SW, 에너지 관리 알고리즘, IoT 디바이스 연동 등 EV 충전 인프라 SW 분야입니다. 소규모 팀에서 폭넓은 기술 스택 경험 가능.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★**

- 호주 EV 보급 확대에 따른 가정·상업용 충전기 수요 증가
- 스타트업 성장 단계 — 빠른 책임 확대 가능
- 규모 성장에 따른 엔지니어링 팀 확대 중

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | EV 충전 관리 플랫폼 SW(OCPP/IoT/에너지 관리) — EV 충전 SW 생태계 입문. 멜버른 스타트업. |
| 추천 직무 | Software Engineer (충전 플랫폼), IoT/Firmware Engineer, Backend Developer |
| 지원 방법 | jetcharge.com.au/careers, LinkedIn |
| 한국 채용 | 없음 — 멜버른 포지션 |
| 비자 스폰 가능성 | ★★ — 소규모 스타트업, TSS 482 제한적 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [jetcharge.com.au](https://www.jetcharge.com.au)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: JetCharge 공식 홈페이지 (2026.06 기준)*
