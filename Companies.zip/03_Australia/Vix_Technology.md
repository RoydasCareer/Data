---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/mobility
  - automotive/maas
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Vix Technology"
size: "중견기업"
fit: "★"
business: "스마트 대중교통 발권·요금 징수 시스템"
hq: "Melbourne, Victoria, Australia"
founded: "1994"
employees: "~800명 (2024)"
revenue: "~$250M AUD (추정)"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Vix Technology

> 스마트 대중교통 발권·요금 징수 시스템 | 중견기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 1994년 |
| 임직원 수 | ~800명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 버스·철도·트램 대중교통 NFC·비접촉 발권 시스템 — AFC (Automatic Fare Collection) 플랫폼 글로벌 공급 |
| 공식 홈페이지 | https://www.vixtechnology.com |

**자동차 관련:** 버스·트램 대중교통 발권 시스템 — 자동차 임베디드 SW와 직접 연관 없음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 글로벌 대중교통 발권 시스템 안정적 수요.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 대중교통 발권 시스템 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Embedded SW Engineer (AFC 시스템) / Platform Engineer — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [vixtechnology.com](https://www.vixtechnology.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: vixtechnology.com 공식 (2026.05 기준)*
