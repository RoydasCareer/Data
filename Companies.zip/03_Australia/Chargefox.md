---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/ev
  - automotive/charging
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Chargefox"
size: "중소기업"
fit: "★★★"
business: "호주 최대 EV 급속 충전 네트워크 — 충전 플랫폼 SW·네트워크 운영"
hq: "Fitzroy, Victoria, Australia"
founded: "2017"
employees: "~80명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (NRMA 등 주요 자동차 클럽 컨소시엄 투자)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Chargefox

> 호주 최대 EV 충전 네트워크 | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Fitzroy, Victoria, Australia |
| 설립 연도 | 2017년 |
| 임직원 수 | ~80명 (2024) |
| 상장 여부 | 비상장 (NRMA, RAA, RACQ, RAC 컨소시엄 투자) |
| 주력 사업 | 호주 전역 EV 급속 충전 네트워크 운영 + 충전 플랫폼 SW |
| 공식 홈페이지 | https://www.chargefox.com |

---

## 🎯 주요 제품 & 서비스

호주 전역 700개 이상 충전 스테이션을 운영하는 EV 충전 네트워크입니다. 자체 개발한 충전 관리 플랫폼(앱 + 백엔드)으로 결제, 원격 모니터링, OCPP 프로토콜 통신, 에너지 관리를 제공합니다. 호주 자동차 클럽(NRMA, RAA 등)과 파트너십으로 전국 커버리지를 확장 중입니다.

---

## 🚗 자동차/모빌리티 관련성

EV 충전 인프라 SW 플랫폼(OCPP/백엔드), 충전기 펌웨어 통신, 에너지 관리 알고리즘, 모바일 앱 개발 등 EV 생태계 SW 전반을 개발합니다.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

- 호주 EV 보급 가속화 — 충전 인프라 수요 급증
- 호주 주요 자동차 클럽 컨소시엄의 안정적 자금 지원
- 정부의 EV 충전 인프라 보조금 정책 수혜

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 호주 최대 EV 충전 네트워크. OCPP 충전 프로토콜·백엔드·에너지 관리 SW — EV 충전 인프라 SW 경험 가능. |
| 추천 직무 | Backend Software Engineer (충전 플랫폼), Embedded/Firmware Engineer (충전기 통신), Platform Engineer |
| 지원 방법 | chargefox.com/careers, LinkedIn |
| 한국 채용 | 없음 — 멜버른 포지션 |
| 비자 스폰 가능성 | ★★ — 스타트업, TSS 482 가능하나 제한적 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [chargefox.com](https://www.chargefox.com)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Chargefox 공식 홈페이지 (2026.06 기준)*
