---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/mobility
  - automotive/maas
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Liftango"
size: "스타트업"
fit: "★"
business: "기업 직원 카풀·공유 통근 플랫폼"
hq: "Sydney, New South Wales, Australia"
founded: "2016"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Liftango

> 기업 직원 카풀·공유 통근 플랫폼 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2016년 |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 기업·캠퍼스 대상 직원 카풀·공유 통근 매칭 플랫폼 — 탄소 배출 감소 통근 솔루션 |
| 공식 홈페이지 | https://www.liftango.com |

**자동차 관련:** 공유 통근 매칭 SW — 자동차 임베디드 SW와 직접 연관 없음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 기업 ESG 탄소 감소 수요로 카풀 플랫폼 주목.
- 소규모 — 확장성 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 카풀 플랫폼 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Full-Stack / Mobile Developer — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [liftango.com](https://www.liftango.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: liftango.com 공식 (2026.05 기준)*
