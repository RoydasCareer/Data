---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/ev
  - automotive/battery
  - fit/★★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Relectrify"
size: "스타트업"
fit: "★★★★"
business: "EV 폐배터리 2차 수명 BMS 소프트웨어 플랫폼"
hq: "Melbourne, Victoria, Australia"
founded: "2016"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장 ($8M+ 투자 유치)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Relectrify

> EV 배터리 2차 수명 BMS 소프트웨어 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 2016년 |
| 임직원 수 | ~50명 (2024) |
| 상장 여부 | 비상장 |
| 주력 사업 | 퇴역 EV 배터리팩의 2차 수명(ESS) 활용을 위한 BMS SW 플랫폼 |
| 공식 홈페이지 | https://www.relectrify.com |

---

## 🎯 주요 제품 & 서비스

Relectrify는 닛산 리프, GM Volt 등 퇴역 EV 배터리팩을 에너지 저장 시스템(ESS)으로 재활용하는 독자 BMS 소프트웨어를 개발합니다. 기존 배터리 셀을 교체하지 않고 SW만으로 성능을 최적화하는 기술이 핵심 차별점입니다.

---

## 🚗 자동차/모빌리티 관련성

EV 배터리 수명 관리 소프트웨어, 셀 밸런싱 알고리즘, 배터리 상태 추정(SoC/SoH) 등 BMS 핵심 기술을 개발합니다. 자동차 배터리 SW 경험을 직접 활용할 수 있습니다.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

- EV 폐배터리 재활용 시장 급성장 (2030년 수백조 규모)
- 배터리 순환 경제 규제 강화로 수요 증가
- Nissan, GM 등 OEM과의 파트너십 가능성

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | BMS SW, 배터리 알고리즘, 임베디드 펌웨어 — EV 배터리 SW 엔지니어링 핵심. 희소 기술 분야 스타트업. |
| 추천 직무 | BMS Software Engineer, Battery Algorithm Engineer, Embedded Systems Engineer |
| 지원 방법 | relectrify.com, LinkedIn |
| 한국 채용 | 없음 — 멜버른 포지션 |
| 비자 스폰 가능성 | ★★ — 스타트업, TSS 482 가능하나 규모 제한 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [relectrify.com](https://www.relectrify.com)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Relectrify 공식 홈페이지 (2026.06 기준)*
