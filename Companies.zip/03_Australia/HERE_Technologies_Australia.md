---
tags:
  - company
  - automotive
  - country/australia
  - size/large
  - automotive/v2x
  - automotive/autonomous
  - fit/★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "HERE Technologies Australia"
size: "대기업"
fit: "★★"
business: "HD 맵·위치 인텔리전스·SDV 데이터 플랫폼 호주 거점"
hq: "Sydney, NSW, Australia (글로벌 HQ: Eindhoven, Netherlands)"
founded: "1985"
employees: "~10,000명 글로벌"
ipo_status: "비상장 (BMW·Mercedes·Audi 컨소시엄 투자)"
korea_office: "있음 (HERE Korea, 서울 종로)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# HERE Technologies Australia

> HD 맵·위치 인텔리전스·SDV 플랫폼 | 대기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, NSW, Australia |
| 설립 연도 | 1985 |
| 임직원 수 | ~10,000명 글로벌 |
| 상장 여부 | 비상장 |
| 주력 사업 | HD Live Map, 실시간 교통 데이터, ADAS 지도, V2X 위치 서비스 |
| 공식 홈페이지 | https://www.here.com |

## 🎯 주요 제품 & 서비스

HERE HD Live Map(자율주행 고정밀 지도), Lanes(차선 내비게이션), OTA 맵 업데이트. 호주 정부 CAV 실증사업 파트너. 호주 HERE Korea 통해 내부 이동 경로 가능.

## 🚗 자동차/모빌리티 관련성

SDV·ADAS 핵심 기반 HD 맵 → SDV 101 과정 + Technical PM 경험 직결.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

SDV·자율주행 전환으로 HD 맵 수요 급증.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | SDV/ADAS 지식 + Technical PM. HERE Korea 통해 호주 포지션 내부 이동 경로. |
| 추천 직무 | Technical PM, Automotive Solutions Engineer |
| 지원 방법 | here.com/company/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★ (글로벌 대기업, TSS 482 지원 가능) |

## ⚠️ 리스크 / 고려사항

- 호주 오피스 규모 불확실 — 채용 공고 확인 필요
- 맵 도메인 전문 지식 필요

## 🔗 관련 정보

- 홈페이지: [here.com](https://www.here.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: HERE Technologies 공식 홈페이지 (2026.07 기준)*
