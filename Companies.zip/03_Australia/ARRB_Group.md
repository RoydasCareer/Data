---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/testing
  - automotive/safety
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "ARRB Group"
size: "중견기업"
fit: "★★"
business: "도로·교통 연구·컨설팅·자율주행 테스팅 (Australian Road Research Board)"
hq: "Vermont South, Victoria, Australia"
founded: "1960"
employees: "~350명 (2024)"
revenue: "~$100M AUD"
ipo_status: "비상장 (정부 소유 연구기관)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# ARRB Group

> 도로·교통 연구·자율주행 테스팅 | 중견기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Vermont South, Victoria, Australia |
| 설립 연도 | 1960년 (Australian Road Research Board) |
| 임직원 수 | ~350명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 (호주 연방·주 정부 교통부 소유) |
| 주력 사업 | 도로 안전·교통 연구·컨설팅 + 자율주행 차량 테스팅 인프라 — NCAP 충돌시험·V2X 파일럿 |
| 공식 홈페이지 | https://www.arrb.com.au |

**자동차 관련:** 자율주행·ADAS 차량 테스팅·검증 서비스 — 도로 안전 연구 기관.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 호주·뉴질랜드 교통 연구 기관.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 자율주행 차량 테스팅 수요 증가.
- 정부 소유 연구기관 — 외국인 비자 스폰 제한 가능.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자율주행·도로 안전 테스팅 — ADAS 경험 활용 가능. 정부 기관으로 비자 스폰 제한 가능. 한국 사무소 없음. |
| 추천 직무 | Transport Research Engineer / AV Test Engineer — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 가능하나 정부 기관 특성상 제한 |
| 고졸 채용 가능성 | 학위 필수 |

---

## 🔗 관련 정보

- 홈페이지: [arrb.com.au](https://www.arrb.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: arrb.com.au 공식 (2026.05 기준)*
