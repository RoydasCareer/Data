---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/security
  - automotive/cybersecurity
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Bugcrowd"
size: "중견기업"
fit: "★"
business: "크라우드소싱 버그 바운티·보안 테스팅 플랫폼 (본사: 미국)"
hq: "San Francisco, CA, USA (호주 창업, 미국 이전)"
founded: "2011"
employees: "~400명 (2024)"
revenue: "비공개 ($80M+ USD 투자)"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Bugcrowd

> 크라우드소싱 버그 바운티 플랫폼 | 중견기업 | 호주(창업)·미국 🇦🇺🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | San Francisco, CA, USA (호주에서 창업 후 미국으로 이전) |
| 설립 연도 | 2011년 |
| 임직원 수 | ~400명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 ($80M+ USD 투자 유치) |
| 주력 사업 | 버그 바운티·크라우드소싱 보안 테스팅·취약점 공개 플랫폼 — 자동차 OEM·tier1 VDP 파트너 |
| 공식 홈페이지 | https://www.bugcrowd.com |

**자동차 관련:** 자동차 OEM 차량 보안 취약점 발견 버그 바운티 — 직접 임베디드 SW 개발은 아님.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 미국 본사 플랫폼 서비스.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 버그 바운티 시장 성장.
- 자동차 임베디드 SW 직접 연관 낮음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 보안 테스팅 플랫폼 — 자동차 임베디드 SW 직접 개발과 연관 낮음. |
| 추천 직무 | Security Engineer / Platform Engineer — 미국 또는 원격 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — 미국 H1B (호주 쪽 없음) |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [bugcrowd.com](https://www.bugcrowd.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: bugcrowd.com 공식 (2026.05 기준)*
