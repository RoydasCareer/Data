---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Verilink"
size: "중소기업"
fit: "★"
business: "UBI·플릿 텔레매틱스 IoT 솔루션 (보험사·대리점 채널)"
hq: "Melbourne, Victoria, Australia"
founded: "2009"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Verilink

> UBI·플릿 텔레매틱스 IoT | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 2009년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | OBD 텔레매틱스 장치 + UBI (Usage-Based Insurance) 플랫폼 — 보험사·딜러 채널 공급 |
| 공식 홈페이지 | https://www.verilink.com.au |

**자동차 관련:** 차량 OBD 텔레매틱스·보험 데이터 — 자동차 임베디드 SW와 직접 연관 낮음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- UBI 텔레매틱스 시장 성장.
- 소규모 — 확장성 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 UBI 텔레매틱스 — 자동차 임베디드 SW 직접 연관 낮음. |
| 추천 직무 | Embedded SW / IoT Engineer (OBD 장치) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [verilink.com.au](https://www.verilink.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: verilink.com.au 공식 (2026.05 기준)*
