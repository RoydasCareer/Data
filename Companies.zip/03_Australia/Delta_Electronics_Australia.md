---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/ev
  - automotive/charging
  - automotive/powertrain
  - fit/★★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Delta Electronics Australia"
size: "중견기업"
fit: "★★★★"
business: "파워 일렉트로닉스·EV 충전 시스템 HW/SW (OBC·DC-DC 컨버터·AC/DC 충전기)"
hq: "Sydney, New South Wales, Australia"
founded: "1998"
employees: "~150명 (호주, 2024)"
revenue: "비공개 (Delta Electronics 글로벌 연매출 NT$300B+)"
ipo_status: "비상장 (Delta Electronics, Inc. 자회사 — Taiwan: 2308)"
korea_office: "있음 (Delta Electronics Korea)"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Delta Electronics Australia

> 파워 일렉트로닉스·EV 충전 시스템 HW/SW | 중견기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 1998년 (호주 법인) |
| 임직원 수 | ~150명 (호주, 2024) |
| 상장 여부 | 비상장 (Delta Electronics, Inc. 자회사, Taiwan: 2308) |
| 주력 사업 | AC/DC EV 충전기, 차량용 OBC(온보드 충전기), DC-DC 컨버터, 산업용 전력 변환 시스템 |
| 공식 홈페이지 | https://www.delta.com.au |

---

## 🎯 주요 제품 & 서비스

Delta는 글로벌 자동차 OEM에 차량용 OBC(On-Board Charger), 400V/800V DC-DC 컨버터, EV 파워트레인용 인버터를 공급하는 글로벌 자동차 Tier-1입니다. 호주 법인은 AC 충전기(7~22kW), DC 급속 충전기(25~200kW)를 Chargefox·Evie Networks 등 충전 네트워크에 공급하며, 충전 시스템 제어 SW와 OCPP 통합을 담당합니다.

---

## 🚗 자동차/모빌리티 관련성

차량용 OBC/DC-DC 컨버터의 전력 제어 SW(PWM 제어·게이트 드라이버 알고리즘), EV 충전기 임베디드 펌웨어, OCPP/ISO 15118(PLC 통신) 프로토콜 스택 개발. 파워 일렉트로닉스 SW 엔지니어링 핵심 분야.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

- 호주 EV 충전 인프라 투자 확대 — Delta 충전기 수요 급증
- 글로벌 자동차 OEM EV 파워트레인 부품 공급 확대
- 대만 본사의 강력한 R&D 지원 + 호주 로컬 엔지니어링

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | EV OBC·DC-DC 컨버터 전력 제어 SW + 충전기 임베디드 펌웨어 — 파워트레인 SW와 충전 SW 동시 경험 가능. 글로벌 자동차 Tier-1. |
| 추천 직무 | Embedded SW Engineer (EV Charger/OBC), Power Electronics SW Engineer, EV Systems Engineer |
| 지원 방법 | delta.com.au/careers, LinkedIn |
| 한국 채용 | 없음 — 시드니 포지션 |
| 비자 스폰 가능성 | ★★★★ — 대기업 글로벌 Tier-1, TSS 482 비자 지원 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [delta.com.au](https://www.delta.com.au)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Delta Electronics Australia 공식 홈페이지 (2026.06 기준)*
