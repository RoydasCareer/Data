---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/fleet
  - automotive/ev
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Zoomo"
size: "중소기업"
fit: "★★★"
business: "배달용 전동 자전거(e-bike) 플릿 관리 SW·하드웨어 플랫폼"
hq: "Sydney, New South Wales, Australia"
founded: "2017"
employees: "~150명 (2024)"
revenue: "비공개 ($27M+ 투자 유치)"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Zoomo

> 배달 e-bike 플릿 관리 플랫폼 | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2017년 |
| 임직원 수 | ~150명 (2024) |
| 상장 여부 | 비상장 ($27M+ 시리즈 B 투자 유치) |
| 주력 사업 | 배달 라이더 전용 e-bike 구독·플릿 관리 (Uber Eats, DoorDash 등 파트너) |
| 공식 홈페이지 | https://www.ridezoomo.com |

---

## 🎯 주요 제품 & 서비스

Zoomo는 배달 플랫폼(Uber Eats, DoorDash, Menulog) 라이더를 위한 e-bike 구독 서비스를 운영합니다. 자체 개발한 e-bike 하드웨어(배터리·모터 통합)와 차량 IoT 플랫폼(실시간 위치·배터리 상태 모니터링, 원격 진단)을 보유합니다. 호주, 영국, 미국, 스페인 등에서 운영 중.

---

## 🚗 자동차/모빌리티 관련성

e-bike 임베디드 제어 SW, 배터리 관리 시스템(BMS), IoT 플릿 관리 플랫폼, 원격 진단 등 경량 전동 모빌리티 SW 분야입니다. 자동차 BMS·임베디드 경험을 마이크로 모빌리티로 확장 적용 가능.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★**

- 배달 경제 성장에 따른 e-bike 플릿 수요 증가
- 호주·영국·유럽·미국 글로벌 확장 중
- 탄소 규제 강화로 e-bike 대체 수요 확대

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | e-bike BMS·임베디드 IoT·플릿 SW — 마이크로 EV 분야 경험. 글로벌 성장 스타트업. |
| 추천 직무 | Embedded SW Engineer (e-bike/BMS), IoT Platform Engineer, Fleet Software Engineer |
| 지원 방법 | ridezoomo.com/careers, LinkedIn |
| 한국 채용 | 없음 — 시드니 포지션 |
| 비자 스폰 가능성 | ★★★ — 글로벌 스타트업, TSS 482 가능 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [ridezoomo.com](https://www.ridezoomo.com)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Zoomo 공식 홈페이지 (2026.06 기준)*
