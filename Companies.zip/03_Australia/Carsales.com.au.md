---
tags:
  - company
  - automotive
  - country/australia
  - size/large
  - automotive/data
  - automotive/retail
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "Carsales.com"
size: "대기업"
fit: "★★"
business: "호주 최대 온라인 자동차 마켓플레이스·데이터 플랫폼 (한국 SK Encar 인수)"
hq: "Melbourne, Victoria, Australia"
founded: "1997"
employees: "~1,600명 (2024)"
revenue: "~$700M AUD (FY2024)"
ipo_status: "상장 (ASX: CAR)"
korea_office: "있음 ★★★"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Carsales.com

> 호주 최대 자동차 온라인 마켓플레이스 | 대기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 1997년 |
| 임직원 수 | ~1,600명 (2024) |
| 규모 분류 | 대기업 |
| 상장 여부 | ASX: CAR |
| 주력 사업 | 자동차·트럭·이륜차 온라인 마켓플레이스 + 자동차 데이터·금융·보험 서비스 |
| 공식 홈페이지 | https://www.carsales.com.au |

**자동차 관련:** 자동차 마켓플레이스 + AI 기반 자동차 가격 평가·데이터 플랫폼.

---

## 🇰🇷 한국 관련

**한국 사업 있음 — SK Encar 인수 (한국 최대 중고차 온라인 플랫폼).**

| 항목 | 내용 |
| :--- | :--- |
| 한국 법인 | SK Encar (한국 최대 중고차 마켓플레이스) — Carsales가 지분 인수 후 완전 인수 |
| 관련 직무 | 한국 SW 개발 직무 (Encar 플랫폼 개발) |
| 비고 | Carsales→SK Encar 경로 — 한국 법인 직접 지원 가능 |

> ⚠️ **Carsales 본사 호주 기업이나 한국 Encar 법인을 통한 한국 취업 경로 존재.** Encar.com 직접 지원 권장.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 호주·한국·미국·동남아 다국적 자동차 마켓플레이스 확장.
- 한국 Encar 통해 한국 시장 직접 존재감.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 한국 Encar 법인 통한 한국 지원 경로 존재. 자동차 마켓플레이스 SW 개발. 임베디드 SW와는 연관 낮음. |
| 추천 직무 | SW/Platform Engineer — 한국 Encar 직접 지원 권장 |
| 한국 지원 경로 | Encar.com (한국 최대 중고차 플랫폼) 채용 페이지 직접 지원 |
| 비자 스폰 가능성 | 해당없음 (한국 법인 직접 고용) |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [carsales.com.au](https://www.carsales.com.au)
- 한국 Encar: [encar.com](https://www.encar.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: carsales.com.au 공식 + Encar.com (2026.05 기준)*
