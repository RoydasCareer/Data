---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/fleet
  - automotive/ev
  - fit/★★★
  - recommend
country: "호주"
country_folder: "03_Australia"
company_name: "Splend"
size: "중소기업"
fit: "★★★"
business: "우버·리들쉐어 라이더 전용 EV 구독 플릿 — 차량 IoT·배터리 상태 모니터링 SW"
hq: "Sydney, New South Wales, Australia"
founded: "2015"
employees: "~150명 (2024)"
revenue: "비공개 ($50M+ 투자 유치)"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Splend

> 라이드셰어 EV 구독 플릿 | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2015년 |
| 임직원 수 | ~150명 (2024) |
| 상장 여부 | 비상장 ($50M+ 투자 유치) |
| 주력 사업 | Uber·DiDi 라이더 전용 EV 차량 구독(주별 요금) + 플릿 관리 SW 플랫폼 |
| 공식 홈페이지 | https://www.splend.com.au |

---

## 🎯 주요 제품 & 서비스

Splend는 차량을 소유하지 않고 라이드셰어 업무를 하고 싶은 드라이버에게 EV(Tesla Model 3, BYD Atto 3 등)를 주별 구독으로 제공합니다. **플릿 관리 SW**: 차량별 배터리 SoC 모니터링, 원격 진단(OBD/API), 라이더 운전 거동 분석, 충전 일정 최적화, 차량 IoT 데이터 대시보드를 자체 개발합니다. 호주·영국·남아공 운영 중.

---

## 🚗 자동차/모빌리티 관련성

EV 플릿 IoT SW, 배터리 SoC·SoH 원격 모니터링, 차량 API 통합(Tesla API·OBD), 플릿 충전 최적화 알고리즘. EV 배터리 상태 관리 SW 경험 활용 가능.

---

## 📈 성장성 & 전망

**성장성 평가: ★★★**

- 라이드셰어 플랫폼의 EV 전환 정책 강화 (Uber·DiDi EV 우선 매칭)
- 호주·영국·남아공 글로벌 확장 중
- EV 구독 플릿 시장 선점 기업

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | EV 플릿 IoT·배터리 SoC 모니터링·차량 API 통합 — EV 플릿 SW 관리 플랫폼 경험. 글로벌 EV 라이드셰어 플릿 스타트업. |
| 추천 직무 | Fleet Software Engineer (EV IoT), Backend Engineer (차량 데이터 플랫폼), Data Engineer |
| 지원 방법 | splend.com.au/careers, LinkedIn |
| 한국 채용 | 없음 — 시드니 포지션 |
| 비자 스폰 가능성 | ★★★ — 성장 중인 스타트업, TSS 482 가능 |

---


## ⚠️ 리스크 / 고려사항

- [확인필요] 재무 안정성 및 규모 개별 확인 필요
- [확인필요] 한국 사무소 유무 및 비자 스폰 최신 현황 확인 필요
- [확인필요] 관련 직군(SW검증/A-SPICE/ISO26262) 실제 채용 공고 확인 필요

## 🔗 관련 정보

- 홈페이지: [splend.com.au](https://www.splend.com.au)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Splend 공식 홈페이지 (2026.06 기준)*
