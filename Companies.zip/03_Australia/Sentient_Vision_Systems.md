---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/sensing
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Sentient Vision Systems"
size: "중소기업"
fit: "★"
business: "드론·UAV 컴퓨터 비전 인식 SW (방산 특화)"
hq: "Melbourne, Victoria, Australia"
founded: "2006"
employees: "~80명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Sentient Vision Systems

> 드론·UAV 컴퓨터 비전 SW | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 2006년 |
| 임직원 수 | ~80명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | ViDAR (Visual Detection and Ranging)·드론 대상 물체 추적 AI — 방산·해상 수색구조·UAV 탑재 |
| 공식 홈페이지 | https://www.sentientvision.com |

> ⚠️ **승용차 자동차 임베디드 SW와 직접 연관 없음.** 방산·드론·UAV 컴퓨터 비전 전문 기업.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 방산·UAV 컴퓨터 비전 틈새 시장.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 방산·드론 CV 특화 — 승용차 임베디드 SW와 연관 낮음. |
| 추천 직무 | CV/ML Engineer (UAV 인식) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [sentientvision.com](https://www.sentientvision.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: sentientvision.com 공식 (2026.05 기준)*
