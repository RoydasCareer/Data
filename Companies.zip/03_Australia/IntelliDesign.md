---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/software
  - automotive/adas
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "IntelliDesign"
size: "중소기업"
fit: "★★"
business: "자동차·항공·방산 임베디드 SW 엔지니어링 서비스"
hq: "Melbourne, Victoria, Australia"
founded: "~2000년대"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# IntelliDesign

> 자동차·항공·방산 임베디드 SW 엔지니어링 | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 2000년대 초 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자동차·항공우주·방산 임베디드 SW 설계·개발·검증 — CAN bus, AUTOSAR, 기능 안전(ISO 26262) 컨설팅 |
| 공식 홈페이지 | https://www.intellidesign.com.au |

**자동차 관련:** 자동차 임베디드 C, AUTOSAR, CAN/LIN/Ethernet 통신, 기능 안전(ISO 26262) 엔지니어링 서비스.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 자동차 임베디드 SW 엔지니어링 수요 꾸준.
- 소규모 엔지니어링 회사 — 성장 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 임베디드 SW·AUTOSAR·기능안전 엔지니어링 — 직무 경험 직접 활용. 한국 사무소 없음. |
| 추천 직무 | Embedded SW Engineer (AUTOSAR/CAN) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [intellidesign.com.au](https://www.intellidesign.com.au)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: intellidesign.com.au 공식 (2026.05 기준)*
