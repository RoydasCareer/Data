---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/adas
  - automotive/safety
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "Seeing Machines"
size: "중견기업"
fit: "★★"
business: "AI 드라이버 모니터링 시스템(DMS)·운전자 주시 분석 SW"
hq: "Canberra, Australian Capital Territory, Australia"
founded: "2000"
employees: "~350명 (2024)"
revenue: "~$80M AUD (FY2024)"
ipo_status: "상장 (AIM London: SEE)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Seeing Machines

> AI 드라이버 모니터링 시스템(DMS) | 중견기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Canberra, ACT, Australia |
| 설립 연도 | 2000년 (Australian National University 스핀아웃) |
| 임직원 수 | ~350명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | AIM London: SEE |
| 주력 사업 | FOVIO 드라이버 모니터링 IC + Guardian Fleet — AI 기반 눈 추적·졸음·주의분산 실시간 감지 DMS |
| 공식 홈페이지 | https://www.seeingmachines.com |

**자동차 관련:** OEM DMS (Caterpillar, CNH Industrial 채택) + 트럭·버스·기차 운전자 모니터링 (Guardian 시스템). UN ECE R159 DMS 의무화 수혜 기업.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캔버라·런던·미국·독일·일본 오피스.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- UN ECE R159 DMS 의무화 (2024~) 수혜 — OEM DMS 채택 급증.
- 트럭·버스 운전자 모니터링 글로벌 확장.
- AIM 소형주 — 수익성 개선 중.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | DMS·AI 눈 추적 ADAS SW — 자동차 안전 SW 경험 직접 활용. 한국 사무소 없음. |
| 추천 직무 | CV/ML Engineer (DMS) / Embedded SW Engineer — 호주 또는 글로벌 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 중견기업, TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [seeingmachines.com](https://www.seeingmachines.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: seeingmachines.com 공식 (2026.05 기준)*
