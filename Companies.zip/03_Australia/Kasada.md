---
tags:
  - company
  - automotive
  - country/australia
  - size/small
  - automotive/security
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Kasada"
size: "중소기업"
fit: "★"
business: "웹·API 봇 공격 방지 SaaS (자동차 포털 보호 포함)"
hq: "Sydney, New South Wales, Australia"
founded: "2015"
employees: "~100명 (2024)"
revenue: "비공개 (~$23M USD 투자)"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Kasada

> 웹·API 봇 방지 보안 SaaS | 중소기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2015년 |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 (~$23M USD 투자 유치) |
| 주력 사업 | 봇 공격·스크래핑·크리덴셜 스터핑 방지 SaaS — 자동차 OEM 웹포털·커머스 API 보호 적용 |
| 공식 홈페이지 | https://www.kasada.io |

> ⚠️ **자동차 임베디드 SW와 직접 연관 없음.** 웹/API 봇 방지 사이버보안 전문 기업.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 웹 봇 방지 시장 성장.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 웹 보안 SaaS — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Security Engineer / Backend Engineer — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [kasada.io](https://www.kasada.io)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: kasada.io 공식 (2026.05 기준)*
