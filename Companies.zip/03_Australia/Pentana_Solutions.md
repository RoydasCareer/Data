---
tags:
  - company
  - automotive
  - country/australia
  - size/mid
  - automotive/software
  - automotive/retail
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Pentana Solutions"
size: "중견기업"
fit: "★"
business: "호주·아태 자동차 딜러 관리 시스템(DMS) — Cox Automotive 자회사"
hq: "Melbourne, Victoria, Australia"
founded: "1999"
employees: "~400명 (2024)"
revenue: "비공개 (Cox Automotive 자회사)"
ipo_status: "비상장 (Cox Automotive — Cox Enterprises 자회사)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Pentana Solutions

> 호주·아태 딜러 관리 시스템(DMS) | 중견기업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Melbourne, Victoria, Australia |
| 설립 연도 | 1999년 |
| 임직원 수 | ~400명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 (Cox Automotive 자회사) |
| 주력 사업 | ERA-IGNITE DMS — 호주·뉴질랜드·아시아태평양 자동차 딜러십 통합 관리 (판매·서비스·부품·금융) |
| 공식 홈페이지 | https://www.pentanasolutions.com |

**주요 고객:** Toyota, Mazda, Subaru 등 호주·아태 딜러십.

---

## 🇰🇷 한국 관련

한국 사무소 없음. Cox Automotive 별도 한국 사업과는 구분됨.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 호주·아태 DMS 안정적 시장.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 딜러십 DMS — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | SW Engineer (DMS/ERP) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 중견기업, TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [pentanasolutions.com](https://www.pentanasolutions.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: pentanasolutions.com 공식 (2026.05 기준)*
