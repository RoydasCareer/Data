---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/software
  - automotive/retail
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Loopit"
size: "스타트업"
fit: "★"
business: "자동차 딜러 구독 관리 SaaS 플랫폼"
hq: "Sydney, New South Wales, Australia"
founded: "2020"
employees: "~20명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Loopit

> 자동차 딜러 구독 관리 SaaS | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2020년 |
| 임직원 수 | ~20명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자동차 딜러십 대상 차량 구독 서비스 관리 플랫폼 — 계약·결제·차량 교체 자동화 |
| 공식 홈페이지 | https://www.loopit.co |

**자동차 관련:** 딜러십 구독 관리 SW — 자동차 임베디드 SW와 직접 연관 없음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 자동차 구독 서비스 시장 성장.
- 소규모 스타트업 — 확장성 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 딜러 구독 관리 플랫폼 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Full-Stack Engineer (SaaS) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [loopit.co](https://www.loopit.co)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: loopit.co 공식 (2026.05 기준)*
