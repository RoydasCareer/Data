---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/iot
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "Myriota"
size: "스타트업"
fit: "★"
business: "저전력 직접위성 IoT 통신 네트워크"
hq: "Adelaide, South Australia, Australia"
founded: "2015"
employees: "~100명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (~$60M AUD 투자 유치)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Myriota

> 저전력 직접위성 IoT 통신 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Adelaide, South Australia, Australia |
| 설립 연도 | 2015년 (University of South Australia 스핀아웃) |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 (~$60M AUD 투자 유치) |
| 주력 사업 | 저전력 위성 직접 통신 모듈 — 오지 IoT 센서 위성 연결 (NB-IoT 대안) |
| 공식 홈페이지 | https://www.myriota.com |

> ⚠️ **자동차 임베디드 SW와 직접 연관 낮음.** 오지 IoT 자산 추적·환경 센서 분야 전문.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 저전력 위성 IoT 틈새 시장.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 위성 IoT 통신 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Embedded SW / RF Engineer (위성 IoT) — 호주 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSS 482 비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [myriota.com](https://www.myriota.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: myriota.com 공식 (2026.05 기준)*
