---
tags:
  - index
  - country/australia
country: "호주"
---

# 호주 🇦🇺 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 73개 |
| ★★★★ 최우선 추천 | 10개 |
| ★★★ 핵심 추천 | 14개 |
| ★★ 높은 적합성 | 15개 |
| ★ 보통 적합성 | 21개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | TSS 482 비자 (고용주 스폰서) |
| 취득 용이성 | ★★ |
| 학위 요건 | 관련 직무 2년+ 경험으로 대체 가능 |
| 참고사항 | 호주 현장 경험 있어 유리. 스폰서 고용주 필요. |

## ⭐ 추천 기업 #Recommand

### ★★★★ 최우선 추천 (임베디드 SW·EV 파워트레인·자동차 전장 핵심)
- [[Bosch_Australia|Robert Bosch Australia]] — 자동차 전장·ADAS·EV ECU SW 엔지니어링 센터 (Clayton, VIC)
- [[Denso_Australia|Denso Australia]] — Toyota 핵심 Tier-1, ECU·ADAS 센서·열관리 임베디드 SW (Clayton, VIC)
- [[Toyota_Australia|Toyota Australia (TMCA)]] — ECU 캘리브레이션·컴플라이언스 SW 엔지니어링 (Port Melbourne, VIC)
- [[Delta_Electronics_Australia|Delta Electronics Australia]] — EV OBC·DC-DC 컨버터 전력 제어 SW (Sydney, NSW)
- [[Continental_Australia|Continental Australia]] — 자동차 전장·ADAS 시스템 티어1 (North Ryde, NSW)
- [[Thales_Australia|Thales Australia]] — 방산 차량 VETRONICS 임베디드 SW·CAN 버스 (Melbourne/Sydney)
- [[Tritium|Tritium (NASDAQ: DCFC)]] — DC 급속 EV 충전기 임베디드 SW·전력 제어 (Brisbane)
- [[SEA_Electric|SEA Electric]] — 상용차 EV 파워트레인 VCU/BMS SW (Melbourne)
- [[Relectrify|Relectrify]] — EV 폐배터리 2차 수명 BMS SW 스타트업 (Melbourne)
- [[Nexport|Nexport]] — 전기버스·트럭 파워트레인 통합 SW (Sydney)

### ★★★ 핵심 추천
- [[AB_Dynamics_Australia|AB Dynamics Australia]] — 차량 동역학 테스팅·ADAS 검증 장비 (Melbourne, LSE: ABD) *(2026-07-31 신규)*
- [[BAE_Systems_Australia|BAE Systems Australia]] — Redback IFV 전투차량 임베디드 SW·RTOS (Melbourne)
- [[Emesent|Emesent]] — LiDAR SLAM 자율 로봇 SW — ADAS 기술 직접 활용 (Brisbane)
- [[Geotab_Australia|Geotab Australia]] — OBD-II·CAN J1939 플릿 텔레매틱스 SW (Sydney)
- [[Chargefox|Chargefox]] — 호주 최대 EV 충전 네트워크 플랫폼 SW (Melbourne)
- [[Evie_Networks|Evie Networks]] — NRMA 기반 EV 급속 충전 OCPP 플랫폼 (Sydney)
- [[JetCharge|JetCharge]] — EV 충전 관리 플랫폼·IoT SW (Melbourne)
- [[Jolt|Jolt]] — 무료 EV 충전·디지털 광고 통합 충전기 임베디드 SW (Adelaide)
- [[Zoomo|Zoomo]] — 배달 e-bike BMS·플릿 관리 SW (Sydney)
- [[Splend|Splend]] — 라이드셰어 EV 플릿 IoT·배터리 모니터링 SW (Sydney)
- [[Amber_Electric|Amber Electric]] — 스마트 EV 충전·V2G 에너지 최적화 SW (Melbourne)
- [[AutoGrab|AutoGrab]] — 자동차 시장 데이터 인텔리전스 SW 플랫폼 (Melbourne)
- [[AutoAi|AutoAi]] — 자동차 AI 진단·데이터
- [[Drive_QA|Drive QA (Sydney)]] — 자동차 QA·테스팅 서비스
- [[DNV_Australia|DNV Australia]] — A-SPICE·ISO26262 기능안전 컨설팅·평가 (멜버른·시드니)

### ★★ 높은 적합성
- [[Cohda_Wireless|Cohda Wireless]] — V2X·커넥티드 차량 SW (HQ: Adelaide)
- [[Seeing_Machines|Seeing Machines]] — 드라이버 모니터링·아이트래킹 SW
- [[Connexion_Telematics|Connexion Telematics]] — 커넥티드카·플릿 관리 SW
- [[Applied_EV|Applied EV]] — 자율주행 차량 프로그래머블 플랫폼 SW (HQ: Melbourne)
- [[SafetyCulture|SafetyCulture]] — 점검·QA SW (플릿 포함)
- [[Imotive|Imotive]] — 자율주행 SW·테스팅
- [[Teletrac_Navman|Teletrac Navman (HQ: NZ/AU)]] — 플릿 SW·통신
- [[IntelliDesign|IntelliDesign]] — 자동차 전장·SW 설계
- [[Bugcrowd|Bugcrowd]] — 자동차 크라우드소싱 보안 테스팅
- [[HAZID_Technologies|HAZID Technologies]] — 자동차 안전 위험 분석 SW
- [[Laserbird|Laserbird]] — 자동차 품질 검사 SW
- [[WATA|WATA (Western AV Testing)]] — AV 테스팅·인증 서비스
- [[Verilink|Verilink (AU)]] — 텔레매틱스·V2X 통신
- [[ARRB_Group|ARRB Group]] — 자동차 도로 연구·테스팅
- [[Australian_Road_Research_Board|Australian Road Research Board]] — AV 테스팅 인프라
- [[HERE_Technologies_Australia|HERE Technologies Australia]] — HD 맵·위치 인텔리전스·SDV 플랫폼 (Sydney) *(2026-07-31 신규)*
- [[Kapsch_TrafficCom_Australia|Kapsch TrafficCom Australia]] — ITS·V2X·스마트 톨링 솔루션 (Melbourne) *(2026-07-31 신규)*

## 📋 전체 기업 목록 (적합도 낮은 기업 포함)

### ★ 보통 적합성
- [[Telstra|Telstra (Automotive/IoT)]] — V2X·커넥티드 차량 통신
- [[Intelematics|Intelematics]] — 교통·모빌리티 데이터 SW
- [[Infomedia|Infomedia]] — 자동차 데이터·SW 솔루션
- [[Baraja|Baraja]] — LiDAR 인식 SW (HQ: Sydney)
- [[Sentient_Vision_Systems|Sentient Vision Systems]] — 컴퓨터 비전·인식 SW
- [[Fleet_Space_Technologies|Fleet Space Technologies]] — 위성 기반 차량 추적·통신
- [[Myriota|Myriota]] — 저비용 위성 IoT·자동차 통신
- [[DrivY|DrivY]] — 플릿 통신·추적 SW
- [[Netstar_Australia|Netstar Australia]] — 텔레매틱스·보안 SW
- [[Quiktrak|Quiktrak]] — 차량 추적·보안 SW
- [[Pinpoint_Communications|Pinpoint Communications]] — 플릿 관리·텔레매틱스
- [[Eroad_Australia|Eroad Australia]] — 텔레매틱스·규정 준수 SW
- [[Secure_Code_Warrior|Secure Code Warrior]] — 자동차 SW 보안 교육 플랫폼
- [[Kasada|Kasada]] — 자동차 앱 봇 방지·보안 SW
- [[UpGuard|UpGuard]] — 자동차 공급망 사이버 리스크 관리
- [[Vault_Cloud|Vault Cloud]] — 자동차 데이터 보안 클라우드
- [[Aerobotics|Aerobotics (automotive context)]] — AI 드론·자율 검사 SW
- [[Transport_Certification_Australia|Transport Certification Australia]] — 텔레매틱스·차량 규정 SW
- [[Austroads|Austroads]] — 스마트 도로·V2X 표준 SW
- [[Transport_for_NSW|Transport for NSW]] — 스마트 교통·V2X 이니셔티브
- [[Department_of_Transport_Victoria|Department of Transport Victoria]] — 자율주행 규제·테스팅 프레임워크

### 기타 기업
- [[Vix_Technology|Vix Technology]] — 스마트 대중교통·모빌리티 SW
- [[SkedGo|SkedGo]] — MaaS·모빌리티 SW
- [[Liftango|Liftango]] — 공유 모빌리티·플릿 SW
- [[Damstra_Technology|Damstra Technology]] — 자산 관리·플릿 SW
- [[Carbar|Carbar]] — 자동차 구독·플릿 SW
- [[Loopit|Loopit]] — 자동차 딜러 구독 SW
- [[Titan_DMS|Titan DMS]] — 딜러 관리 SW
- [[Pentana_Solutions|Pentana Solutions]] — 자동차 ERP·SW
- [[Carsales.com.au|Carsales.com.au]] — 자동차 마켓플레이스·데이터
- [[RedBook|RedBook]] — 자동차 데이터·가치 평가 SW
- [[UbiPark|UbiPark]] — 커넥티드 주차·통신 SW
- [[Divvy_Parking|Divvy Parking]] — 스마트 주차·모빌리티 SW
- [[Smarter_City_Solutions|Smarter City Solutions]] — 스마트 주차·모빌리티 SW
