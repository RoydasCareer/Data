---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/autonomous
  - automotive/adas
  - fit/★★
country: "호주"
country_folder: "03_Australia"
company_name: "iMOVE Australia"
size: "스타트업"
fit: "★★"
business: "자율주행·스마트교통 협력연구 기관 (호주 정부 지원 CRC)"
hq: "Sydney, New South Wales, Australia"
founded: "2017"
employees: "~50명 (2024)"
revenue: "정부 지원 (비상업)"
ipo_status: "비상장 (호주 정부 Cooperative Research Centre)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# iMOVE Australia

> 자율주행·스마트교통 협력연구 CRC | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sydney, New South Wales, Australia |
| 설립 연도 | 2017년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 소규모 연구기관 |
| 상장 여부 | 비상장 (호주 정부 CRC 프로그램 지원) |
| 주력 사업 | 자율주행·스마트교통 산학 협력연구 — 대학·정부·기업 공동 R&D 프로젝트 코디네이션 |
| 공식 홈페이지 | https://imoveaustralia.com |

> ⚠️ **상업 기업이 아닌 정부 지원 협력연구 기관(CRC).** 직접 채용보다 연구 파트너십·프로젝트 참여 구조.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 자율주행·스마트교통 R&D 연구 기관.
- 상업 기업이 아니어서 직접 취업 경로 제한적.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자율주행·ADAS 연구 기관 — ADAS 경험 활용 가능. 단, 상업 기업이 아닌 정부 CRC. |
| 추천 직무 | Research Engineer (자율주행 SW) — 호주 현지 (비자 스폰 여부 불확실) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 연구기관, 불확실 |
| 고졸 채용 가능성 | 학위 필수 |

---

## 🔗 관련 정보

- 홈페이지: [imoveaustralia.com](https://imoveaustralia.com)
- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: imoveaustralia.com 공식 (2026.05 기준)*
