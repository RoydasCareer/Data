---
tags:
  - company
  - automotive
  - country/australia
  - size/startup
  - automotive/testing
  - automotive/qa
  - fit/★
country: "호주"
country_folder: "03_Australia"
company_name: "WATA (Western Australian Testing Authority)"
size: "스타트업"
fit: "★"
business: "자율주행·AV 테스팅 인프라 서비스 (서호주)"
hq: "Perth, Western Australia, Australia"
founded: "—"
employees: "—"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# WATA (Western Australian Testing Authority)

> AV 테스팅 인프라 서비스 | 스타트업 | 호주 🇦🇺

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Perth, Western Australia, Australia |
| 설립 연도 | 미확인 |
| 임직원 수 | 미확인 |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 서호주 자율주행 차량 테스팅·인증 서비스 — AV 파일럿 도로 테스트 지원 |
| 공식 홈페이지 | 미확인 |

> ⚠️ **공개 정보 제한적.** 상세 데이터 미확인.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- AV 테스팅 수요 증가.
- 소규모 — 공개 정보 부족.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 공개 정보 제한적. 한국 사무소 없음. |
| 추천 직무 | 미확인 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | 미확인 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|호주 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: 공개 정보 부족 (2026.05 기준 미확인)*
