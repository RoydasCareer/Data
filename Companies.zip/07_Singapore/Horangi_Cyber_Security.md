---
tags:
  - company
  - automotive
  - country/singapore
  - size/startup
  - automotive/security
  - automotive/cybersecurity
  - fit/★★
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Horangi Cyber Security"
size: "스타트업"
fit: "★★"
business: "클라우드 보안·펜테스팅·DevSecOps SaaS (IT/OT 사이버보안)"
hq: "Singapore"
founded: "2016"
employees: "100~300명 (추정)"
revenue: "비공개 (스타트업)"
ipo_status: "비상장"
---

# Horangi Cyber Security

> 클라우드 보안·펜테스팅·DevSecOps SaaS | 스타트업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Horangi Pte. Ltd. |
| 본사 | Singapore |
| 설립 연도 | **2016년** |
| 공동창업자 | Paul Hadjy (CEO), Travis Wetherbee |
| CEO | **Paul Hadjy** |
| 임직원 수 | 100~300명 (추정) |
| 연매출 | 비공개 |
| 상장 여부 | 비상장 |
| 공식 홈페이지 | https://www.horangi.com |

---

## 🎯 주요 제품 & 서비스

Horangi는 **클라우드 보안·펜테스팅·DevSecOps** 전문 사이버보안 스타트업입니다.

| 제품/서비스 | 내용 |
| :--- | :--- |
| **Warden** | 클라우드 보안 구성 관리(CSPM) — AWS, GCP, Azure |
| **펜테스팅 서비스** | 네트워크·애플리케이션·인프라 취약점 테스트 |
| **Red Team** | 공격자 시뮬레이션 기반 보안 평가 |
| **DevSecOps** | CI/CD 파이프라인 보안 통합 |
| **컴플라이언스** | ISO 27001, SOC 2, PCI DSS 등 |

---

## 🚗 자동차 사이버보안 연관성

| 항목 | 내용 |
| :--- | :--- |
| **직접 연관성** | 낮음 — OT/임베디드 보안보다 IT/클라우드 중심 |
| **간접 연관** | 자동차 OEM의 클라우드 인프라 보안 서비스 제공 가능 |
| **UN R155/ISO 21434** | 해당 분야 직접 서비스 미확인 |

---

## 🌍 글로벌 사무소

| 지역 | 위치 |
| :--- | :--- |
| 본사 | **Singapore** |
| 기타 | Indonesia, Philippines, US (확인 필요) |

---

## 🇰🇷 한국 지사

**한국 법인 없음** (확인 필요)

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 클라우드 보안 시장 고성장 (연 15%+)
- 동남아 사이버보안 수요 증가
- 스타트업 단계 — 성장 경로 불확실

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | IT/클라우드 사이버보안 — 자동차 사이버보안(OT, CAN, UN R155)보다는 IT 인프라 보안 중심. CAN 분석·차량 네트워크 보안 경험을 IT 보안으로 전환하려는 경우에 적합. |
| 추천 직무 | Security Researcher, Penetration Tester, Cloud Security Engineer, Security Consultant |
| 지원 방법 | horangi.com/careers, LinkedIn |
| 비자 스폰 (싱가포르) | ★★★ — Employment Pass 지원 가능 |
| 참고 | 자동차 보안 직접 연관성보다 일반 IT 사이버보안 커리어 전환 시 적합 |

---

## 🔗 관련 정보

- 홈페이지: [horangi.com](https://www.horangi.com)
- Warden: [horangi.com/warden](https://www.horangi.com/warden)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Horangi 공식 홈페이지 — 작성 기준 2026.06.01*
