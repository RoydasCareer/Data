---
tags:
  - company
  - automotive
  - country/singapore
  - size/startup
  - automotive/software
  - fit/★★
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "TransferFi"
size: "스타트업"
fit: "★★"
business: "무선 전력·데이터 동시 전송 기술 (TiBE™) — IoT·자동차 센서 응용"
hq: "Singapore"
founded: "2019"
employees: "20~50명 (추정)"
revenue: "비공개 (초기 스타트업)"
ipo_status: "비상장"
---

# TransferFi

> 무선 전력·데이터 동시 전송 기술 | 스타트업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | TransferFi Pte. Ltd. |
| 본사 | Singapore |
| 설립 연도 | **2019년** |
| CEO | Thomas Lim |
| 임직원 수 | 20~50명 (추정) |
| 연매출 | 비공개 |
| 상장 여부 | 비상장 |
| 공식 홈페이지 | https://transferfi.com |

---

## 🎯 핵심 기술 — TiBE™

TransferFi는 **TiBE™ (Tunneled Broadband Energy)** 기술을 개발합니다. 단일 RF 신호로 **전력 공급과 데이터 통신을 동시에** 처리하는 혁신 무선 기술입니다.

| 기술 특징 | 내용 |
| :--- | :--- |
| **무선 전력 전송** | 최대 수 미터 거리에서 무선 충전 |
| **동시 데이터 통신** | 전력과 데이터 단일 RF 채널 |
| **배터리리스 IoT** | 센서에 배터리 불필요 → 유지보수 비용 절감 |
| **소형 폼팩터** | 초소형 안테나 모듈 |

---

## 🚗 자동차 분야 응용

| 분야 | 내용 |
| :--- | :--- |
| **차량 센서 배선 제거** | 와이어 없는 차량 내부 센서 네트워크 |
| **타이어 압력 모니터링 (TPMS)** | 배터리리스 무선 TPMS |
| **시트 센서** | 탑승객 감지·무선 센서 |
| **무선 충전 인프라** | 주차장 EV 무선 충전 (장기 응용) |

---

## 🌍 주요 파트너 & 투자자

| 파트너 | 내용 |
| :--- | :--- |
| **Enterprise Singapore** | 정부 지원 프로그램 |
| **NUS (싱가포르 국립대)** | 기술 파트너십 (추정) |

---

## 🇰🇷 한국 지사

**한국 법인 없음** — 싱가포르 중심 초기 스타트업

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 배터리리스 IoT 시장 — 유지보수 비용 절감 가치 큼
- 자동차·산업용 무선 센서 네트워크 잠재력
- 매우 초기 단계 스타트업 — 기술 검증·상용화 단계

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 차량 센서 무선 통신·전력 기술 — RF/무선 통신, 임베디드 HW/SW, 배터리리스 IoT 관심자에게 적합. 자동차 ADAS보다는 차량 통신·센서 HW/SW 분야. |
| 추천 직무 | RF/Wireless Engineer, Embedded SW Engineer, IoT Systems Engineer |
| 지원 방법 | transferfi.com 채용, LinkedIn |
| 비자 스폰 (싱가포르) | ★★ — 소규모 초기 스타트업, 제한적 |
| 참고 | 초기 스타트업 리스크 — 기술 검증 단계임을 감안 |

---

## 🔗 관련 정보

- 홈페이지: [transferfi.com](https://transferfi.com)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: TransferFi 공식 홈페이지 — 작성 기준 2026.06.01*
