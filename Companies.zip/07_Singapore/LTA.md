---
tags:
  - company
  - automotive
  - country/singapore
  - size/startup
  - automotive/v2x
  - automotive/connectivity
  - fit/★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "LTA (Land Transport Authority)"
size: "스타트업"
fit: "★★"
business: "스마트 도로·V2X SW"
hq: "(본사 위치 미확인) — 싱가포르"
---

# LTA (Land Transport Authority)

> 스마트 도로·V2X SW | 스타트업 | 싱가포르 🇸🇬

## 🏢 회사 개요

차량-사물 통신(V2X, DSRC/C-V2X) 기반 스마트 모빌리티 솔루션 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 싱가포르 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 스타트업 |
| 주력 사업 | 스마트 도로·V2X SW |

## 🎯 비전 & 미션

자율주행과 스마트 인프라 연계로 안전하고 효율적인 교통 생태계를 구현합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

5G-V2X 표준화 진행 중. 2027년부터 유럽·미국 신차 V2X 의무화 논의.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | DoIP/CAN 통신 분석 경험 V2X로 확장 가능 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★★★ |
| 고졸 채용 가능성 | 관련 경험 5년+ 시 EP 예외 가능 |
| 비자 정보 | Employment Pass (EP) |
| 비고 | 자동차 기술직 EP 취득 가능. 월급여 S$5,000+ 필요. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
