---
tags:
  - company
  - automotive
  - country/singapore
  - size/startup
  - automotive/autonomous
  - automotive/software
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Auro.ai"
size: "스타트업"
fit: "★★★"
business: "자율주행 셔틀·라스트마일 솔루션 (Level 4 AV)"
hq: "Singapore"
founded: "2016"
employees: "50~150명 (추정)"
revenue: "비공개 (스타트업)"
ipo_status: "비상장"
---

# Auro.ai

> 자율주행 셔틀·라스트마일 솔루션 | 스타트업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Auro Technologies Pte. Ltd. |
| 본사 | Singapore |
| 설립 연도 | **2016년** |
| 임직원 수 | 50~150명 (추정) |
| 연매출 | 비공개 |
| 상장 여부 | 비상장 |
| 공식 홈페이지 | https://www.auro.ai |

---

## 🎯 주요 제품 & 서비스

Auro.ai는 **싱가포르 스마트시티 인프라에 맞춘 Level 4 자율주행 셔틀** 솔루션 개발사입니다.

| 제품/서비스 | 내용 |
| :--- | :--- |
| **자율주행 셔틀** | 제한 구역 내 완전 자율운행 전기 셔틀 |
| **AV 소프트웨어 스택** | 인식·계획·제어 통합 자율주행 SW |
| **플릿 관리** | 자율주행 차량 원격 모니터링 및 운영 플랫폼 |
| **라스트마일 솔루션** | 버스 정류장~목적지 구간 자율 이동 서비스 |

**주요 운영**: 싱가포르 산업단지, 대학 캠퍼스, 리조트 내 자율주행 셔틀 운행

---

## 🌍 주요 파트너 & 고객

| 파트너 | 내용 |
| :--- | :--- |
| **LTA (싱가포르 육상교통청)** | 자율주행 규제 샌드박스 협력 |
| **JTC Corporation** | 산업단지 자율주행 파일럿 |

---

## 🇰🇷 한국 지사

**한국 법인 없음** — 싱가포르 중심 운영

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 싱가포르 정부의 스마트시티·자율주행 친화적 규제 환경 수혜
- 제한 구역 Level 4 AV → 실제 상용화 가장 빠른 세그먼트
- 스타트업 특성상 자금 조달·성장 경로 불확실
- 동남아 스마트시티 수출 가능성

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | Level 4 자율주행 SW 개발 스타트업 — ADAS/자율주행 SW 경험 직접 적용 가능. 싱가포르 스마트시티 생태계 내 성장성 있음. 소규모 팀이라 폭넓은 역할 수행 가능. |
| 추천 직무 | Autonomous Driving SW Engineer, Perception Engineer, Planning & Control Engineer, ROS Developer |
| 지원 방법 | auro.ai 채용 페이지, LinkedIn |
| 비자 스폰 (싱가포르) | ★★★ — Employment Pass 지원 가능 (기술직) |
| 참고 | 스타트업 리스크 감수 가능 시 추천 — 자율주행 커리어 빌딩에 유리 |

---

## 🔗 관련 정보

- 홈페이지: [auro.ai](https://www.auro.ai)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: auro.ai 공식 홈페이지, LTA 보도자료 — 작성 기준 2026.06.01*
