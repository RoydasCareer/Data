---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/ev
  - automotive/adas
  - automotive/testing
  - fit/★★★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "HMGICS (Hyundai Motor Group Innovation Center Singapore)"
size: "대기업"
fit: "★★★★★"
business: "현대차그룹 글로벌 혁신 허브 — IONIQ 5 EV 스마트 팩토리·자율주행 실증·로보틱스·AV 테스팅"
hq: "Jurong Innovation District, Singapore"
founded: "2022"
employees: "~700명"
ipo_status: "비상장 (Hyundai Motor Group 직영)"
korea_office: "있음 (Hyundai Motor Group 본사)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# HMGICS (Hyundai Motor Group Innovation Center Singapore)

> 현대차그룹 글로벌 혁신 허브·EV 스마트 팩토리·AV 테스팅 | 대기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Jurong Innovation District, Singapore |
| 설립 연도 | 2022 (개장) |
| 임직원 수 | ~700명 |
| 상장 여부 | 비상장 (Hyundai Motor Group 직영) |
| 주력 사업 | IONIQ 5 EV 주문 생산, 자율주행 실증, 로보틱스, 미래 모빌리티 R&D |
| 공식 홈페이지 | https://www.hyundai.com/worldwide/en/hmgics |

## 🎯 주요 제품 & 서비스

세계 최초 인간-로봇 협업 EV 제조 시설(유연 생산). IONIQ 5 주문형 소규모 생산, 자율주행 Level 4 실증(Jurong Island 루프), Boston Dynamics Spot/Atlas 로보틱스 통합, AV 테스팅 트랙 운영. 현대차그룹 SDV 전환의 글로벌 쇼케이스 거점.

## 🚗 자동차/모빌리티 관련성

EV(IONIQ 5) 실차 생산 품질 검증, 자율주행 AV 테스팅, IVI/소프트웨어 정의 차량 검증 — 전수환의 현재 역할(Hyundai EV/HEV IVI 검증, Hyundai R&D 파견)과 동일 그룹사. 현대차그룹 내부 인사 이동 경로 최단.

## 📈 성장성 & 전망

**성장성 평가: ★★★★★**

싱가포르 정부 스마트 모빌리티 국책사업 파트너, 현대차그룹 SDV/AV 전략 핵심 거점. IONIQ 생산 확대 및 AV 실증 범위 지속 확장.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★★ |
| 핵심 추천 이유 | **현재 고용주(Hyundai Motor Group)와 동일 그룹** — 내부 이동 경로 최단. Hyundai EV/HEV IVI 검증 경험 완전 직결. JLR DoIP 프로젝트 리드 → AV 검증 리드로 확장 가능. Technical PM/Validation Lead 포지션 최우선. |
| 추천 직무 | Validation Lead, Technical PM (AV/EV), Software Integration Engineer, Quality Engineer |
| 지원 방법 | 현재 Hyundai R&D 파견 → 사내 이동 요청, hmgics.com/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★★★ (현대차그룹 직영, Employment Pass 스폰서 적극적) |

## ⚠️ 리스크 / 고려사항

- 싱가포르 생활비 매우 높음 — 급여 대비 실질 소득 계산 필요
- 소규모 생산 시설 특성상 대규모 양산 QA 경험과 차이 있을 수 있음
- 내부 이동 시 현재 FPT-Hyundai 파견 계약 검토 필요

## 🔗 관련 정보

- 홈페이지: [hyundai.com/hmgics](https://www.hyundai.com/worldwide/en/hmgics)
- LinkedIn: Hyundai Motor Group Innovation Center Singapore
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: HMGICS 공식 홈페이지 (2026.07 기준)*
