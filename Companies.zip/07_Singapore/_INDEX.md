---
tags:
  - index
  - country/singapore
country: "싱가포르"
---

# 싱가포르 🇸🇬 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 35개 |
| ★★★ 핵심 추천 | 5개 |
| ★★ 높은 적합성 | 17개 |
| ★ 보통 적합성 | 11개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | Employment Pass (EP) |
| 취득 용이성 | ★★★ |
| 학위 요건 | 관련 경력 5년+ 시 EP 예외 가능 |
| 급여 요건 | 최저 S$5,000/월 (2025 기준) |
| 소득세 | 최고 24% (SG$1M+ 소득) — 실질 중간소득 세율 낮음 |
| 참고사항 | 영어 공용어. 자율주행·V2X·테스팅 분야 아시아 허브. One-North·Jurong 클러스터. |

## ⭐ 추천 기업 #Recommand

### ★★★★★ 최우선 추천 (2026-07-31 신규 — 현재 고용주 동일 그룹)
- [[HMGICS|HMGICS (Hyundai Motor Group Innovation Center Singapore)]] — 현대차그룹 EV 스마트팩토리·AV 테스팅·로보틱스 혁신 허브 (Jurong)

### ★★★★ 핵심 추천 (2026-07-31 신규)
- [[Bosch_Singapore|Robert Bosch Singapore]] — 자동차 진단·ADAS·EV·사이버보안 ASEAN R&D 허브 (Bishan/Jurong)

### ★★★ 핵심 추천
- [[CETRAN|CETRAN (NTU)]] — 자율주행 테스팅·인증 (Nanyang Tech University 부설, 국가 AV 테스트베드)
- [[Keysight_SG|Keysight SG]] — 자동차 통신·전자 테스팅 장비·SW
- [[Anritsu_SG|Anritsu SG]] — 자동차 통신 테스팅 장비·SW (5G V2X 포함)
- [[Spirent_SG|Spirent SG]] — 자동차 네트워크·GNSS 테스팅
- [[Autobotik|Autobotik]] — 자율주행 SW·테스팅 플랫폼
- [[ComfortDelGro_Technology|ComfortDelGro Technology]] — AV·플릿 관리·차량 진단 플랫폼 (싱가포르 최대 교통 그룹)
- [[Continental_Singapore|Continental Automotive Singapore]] — ADAS·IVI·사이버보안·EV 파워트레인 APAC R&D 허브
- [[Aptiv_Singapore|Aptiv Singapore]] — 차량 아키텍처·전기화·사이버보안 APAC 엔지니어링 센터
- [[NXP_Singapore|NXP Semiconductors Singapore]] — 자동차 반도체·V2X·보안 MCU 아시아 HQ (NASDAQ: NXPI)

### ★★ 높은 적합성
- [[ST_Engineering|ST Engineering (Land Systems)]] — 자율주행·스마트 모빌리티 SW (SGX 상장)
- [[Hope_Technik|Hope Technik]] — 특수 차량·자율 SW (방산·산업 자율화)
- [[Quantum_Inventions|Quantum Inventions]] — 커넥티드카·내비게이션 SW
- [[Overdrive_IoT|Overdrive IoT]] — 플릿 관리·센서 데이터 SW
- [[Whizpace|Whizpace]] — TVWS·V2X 통신 SW
- [[Ackcio|Ackcio]] — 무선 센서·플릿 통신 SW
- [[Group-IB|Group-IB (SG HQ)]] — 자동차 위협 인텔리전스·보안
- [[Ensign_InfoSecurity|Ensign InfoSecurity]] — 자동차 사이버보안 관리
- [[LTA|LTA (Land Transport Authority)]] — 스마트 도로·V2X 인프라 SW
- [[ASTAR|A*STAR (I2R)]] — 자율주행·V2X 국가 R&D
- [[JTC_Corporation|JTC Corporation (Smart Mobility)]] — AV 테스팅 구역 운영
- [[Aedge_Technologies|Aedge Technologies]] — 자동차 IoT·엣지 컴퓨팅 SW
- [[Speedir|Speedir]] — 운전 분석·안전 SW
- [[AutoFleet|AutoFleet]] — 플릿 최적화·스케줄링 SW
- [[NovAtel|NovAtel (SG R&D)]] — 정밀 GNSS·자율주행 포지셔닝
- [[u-blox_Asia_Pacific|u-blox Asia Pacific]] — GNSS·무선 통신 모듈
- [[Quectel|Quectel (SG office)]] — 자동차 IoT 모듈·통신

## 📋 전체 기업 목록

### ★ 보통 적합성
- [[Auro.ai|Auro.ai]] — 자율 셔틀 SW
- [[TransferFi|TransferFi]] — 자동차 센서 무선 데이터·전력
- [[Trakomatic|Trakomatic]] — 비전 애널리틱스·모빌리티
- [[Goldbell|Goldbell (Automotive Tech)]] — 플릿 관리·모빌리티 SW
- [[Horangi_Cyber_Security|Horangi Cyber Security]] — 클라우드 보안·자동차 앱
- [[V-Key|V-Key]] — 모바일 보안·자동차 인증
- [[Cyber_Security_Agency|Cyber Security Agency (CSA)]] — 자동차 사이버보안 표준
- [[Oneberry_Technologies|Oneberry Technologies]] — IoT·자산 추적 SW
- [[Telit|Telit (SG)]] — IoT·자동차 셀룰러 통신 모듈
- [[SECO|SECO (SG)]] — 임베디드 자동차 컴퓨팅 모듈
- [[Aisin_SG|Aisin SG]] — 자동차 SW·부품 솔루션 (Toyota 계열)

### 기타 기업
- [[Grab|Grab (HQ: Singapore)]] — 모빌리티 플랫폼·플릿 SW (NASDAQ: GRAB)
- [[Motional|Motional (SG 운영)]] — Hyundai-Aptiv JV 자율주행 (→ [[../01_USA/Motional|미국 등재]])
