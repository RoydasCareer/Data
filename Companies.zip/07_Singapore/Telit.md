---
tags:
  - company
  - automotive
  - country/singapore
  - size/mid
  - automotive/software
  - automotive/telematics
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Telit (SG)"
size: "중견기업"
fit: "★★★"
business: "IoT·자동차용 셀룰러 통신 모듈·플랫폼 (HQ: 영국)"
hq: "London, UK (글로벌 본사) / Singapore (APAC 거점)"
founded: "2000"
employees: "1,400명+ (글로벌)"
revenue: "£196M (FY2023)"
ipo_status: "LSE 상장 (티커: TCM)"
---

# Telit (SG)

> IoT·자동차용 셀룰러 통신 모듈 | 중견기업 | 싱가포르 🇸🇬 (HQ: 영국)

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Telit Communications Limited |
| 글로벌 본사 | London, UK |
| APAC 거점 | **Singapore** |
| 설립 연도 | **2000년** |
| CEO | Paolo Dal Pino |
| 글로벌 임직원 | **1,400명+** |
| 연매출 | **£196M (FY2023)** |
| 상장 | **LSE: TCM** (런던 증권거래소) |
| 공식 홈페이지 | https://www.telit.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2000 | 영국에서 창업 |
| 2010s | 글로벌 IoT 모듈 시장 주요 플레이어로 성장 |
| 2020 | Cinterion (Siemens/Gemalto 계열) IoT 사업 인수 |
| 2022 | Telit과 IRIDIUM 파트너십 |

---

## 🎯 주요 제품 & 서비스

| 제품/서비스 | 내용 |
| :--- | :--- |
| **셀룰러 모듈** | 4G LTE, 5G NR, Cat-M1/NB-IoT 통신 모듈 |
| **GNSS 모듈** | GPS/GLONASS/Galileo/BeiDou 위치 모듈 |
| **Wi-Fi·블루투스** | 단거리 무선 통신 모듈 |
| **자동차용 모듈** | Automotive-grade (AEC-Q100) 셀룰러·GNSS 모듈 |
| **IoT 플랫폼** | deviceWISE™ 클라우드 IoT 플랫폼 |
| **엣지 컴퓨팅** | HPTP (High-Performance Telematics Platform) |

---

## 🚗 자동차 분야 적용

| 분야 | 내용 |
| :--- | :--- |
| **V2X 통신** | C-V2X 모듈 — 차량↔인프라 통신 |
| **텔레매틱스** | TCU(Telematic Control Unit) 핵심 모듈 |
| **OTA 업데이트** | 차량 OTA 통신 인프라 |
| **커넥티드카** | eCall, 원격 진단, 플릿 관리 모듈 |
| **자율주행** | V2X 데이터 통신 지원 |

---

## 🌍 글로벌 사무소

| 지역 | 위치 |
| :--- | :--- |
| 글로벌 본사 | London, UK |
| APAC | **Singapore**, 중국, 일본 |
| 미주 | 미국 |
| 유럽 | 독일, 이탈리아, 이스라엘 |

---

## 🇰🇷 한국 지사

**한국 직영 법인 정보 없음** — 대리점/파트너 통해 유통 가능 (확인 필요)

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- IoT·자동차 연결성 시장 고성장 수혜
- 5G·V2X 모듈 수요 증가
- 자동차 OEM 커넥티드카 의무화로 TCU 모듈 수요 급증
- 경쟁사: Quectel, u-blox, Sierra Wireless 등

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 자동차용 셀룰러 모듈·V2X·텔레매틱스 — 차량 통신(V2X, TCU), 임베디드 드라이버, 펌웨어 개발 경험 직접 활용 가능. LSE 상장 중견기업으로 안정성 있음. |
| 추천 직무 | Embedded SW Engineer (모듈 펌웨어), V2X/C-V2X Engineer, Automotive IoT Engineer, Field Application Engineer |
| 지원 방법 | telit.com/careers, LinkedIn |
| 비자 스폰 (싱가포르) | ★★★ — LSE 상장 중견기업, Employment Pass 지원 가능 |
| 참고 | 싱가포르 APAC 팀 채용 규모 확인 필요 — UK 본사·독일·이탈리아 포지션도 검토 |

---

## 🔗 관련 정보

- 홈페이지: [telit.com](https://www.telit.com)
- Automotive 솔루션: [telit.com/automotive](https://www.telit.com/automotive)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Telit 공식 홈페이지, LSE 공시 (FY2023 Annual Report) — 작성 기준 2026.06.01*
