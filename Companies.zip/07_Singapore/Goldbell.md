---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/telematics
  - automotive/fleet
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Goldbell (Automotive Tech)"
size: "대기업"
fit: "★★★"
business: "상용차·플릿 관리·모빌리티 솔루션 (싱가포르 최대 상용차 그룹)"
hq: "Singapore"
founded: "1980"
employees: "2,000명+ (그룹 전체)"
revenue: "비공개 (그룹 연결, 수억 SGD 추정)"
ipo_status: "비상장 (가족 경영 민간 기업)"
---

# Goldbell (Automotive Tech)

> 상용차·플릿 관리·모빌리티 솔루션 | 대기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Goldbell Group Pte. Ltd. |
| 본사 | Singapore |
| 설립 연도 | **1980년** |
| CEO | (확인 필요) |
| 임직원 수 | **2,000명+** (그룹 전체) |
| 연매출 | 비공개 (수억 SGD 추정) |
| 상장 여부 | 비상장 (가족 경영 민간 기업) |
| 공식 홈페이지 | https://www.goldbell.com.sg |

### 주요 사업 부문

Goldbell은 싱가포르에서 **상용차(포크리프트, 트럭, 밴) 판매·렌털·서비스**를 핵심으로 하는 종합 모빌리티 그룹입니다.

---

## 🎯 주요 제품 & 서비스

| 사업부 | 내용 |
| :--- | :--- |
| **장비 렌털** | 포크리프트, 리치스태커, 산업용 장비 렌털 |
| **상용차** | 경상용차(LCV)·트럭·밴 판매·렌털·리스 |
| **Goldbell Engineering** | 상용차 정비·개조 서비스 |
| **Fleet Management** | 텔레매틱스 기반 플릿 모니터링, 유지보수 관리 |
| **EV 전환** | 상용차 EV 전환 솔루션, EV 충전 인프라 |
| **Goldbell Financial** | 상용차 금융·리스 서비스 |

---

## 🌍 글로벌 사무소

| 지역 | 위치 |
| :--- | :--- |
| 본사 | **Singapore** |
| 동남아 | Malaysia, Indonesia (확인 필요) |

---

## 🇰🇷 한국 지사

**한국 법인 없음** — 싱가포르 중심 운영

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 싱가포르 물류·건설·제조업 상용차 수요 안정적
- **EV 상용차 전환**: 싱가포르 정부 녹색교통 정책에 따른 EV 플릿 전환 수요 급증
- 텔레매틱스·플릿 관리 SW 내재화로 디지털 전환 중
- 가족 경영 민간기업 특성상 보수적 성장 기조

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 상용차 플릿 관리·텔레매틱스 SW 개발 — 차량 통신(CAN), IoT, OTA, 플릿 관리 경험 활용 가능. EV 상용차 전환 프로젝트에서 임베디드 SW 역할 가능. 대형 민간 기업으로 안정성 있음. |
| 추천 직무 | Fleet Management SW Engineer, Telematics Engineer, Embedded SW Engineer (EV 상용차), IoT Engineer |
| 지원 방법 | goldbell.com.sg 채용, LinkedIn |
| 비자 스폰 (싱가포르) | ★★★ — 대형 민간기업, Employment Pass 지원 가능 |
| 참고 | 상용차·물류 도메인 자동차 SW 역할 — 승용차 ADAS와는 다른 영역 |

---

## 🔗 관련 정보

- 홈페이지: [goldbell.com.sg](https://www.goldbell.com.sg)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Goldbell 공식 홈페이지 — 작성 기준 2026.06.01*
