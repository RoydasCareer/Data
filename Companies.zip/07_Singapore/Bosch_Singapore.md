---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/diagnostics
  - automotive/adas
  - automotive/ev
  - fit/★★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Robert Bosch Singapore"
size: "대기업"
fit: "★★★★"
business: "자동차 진단·ADAS·EV·사이버보안 ASEAN R&D 허브"
hq: "Bishan / Jurong, Singapore"
founded: "1979"
employees: "~2,000명 (싱가포르)"
ipo_status: "비상장 (Robert Bosch GmbH 자회사)"
korea_office: "있음 (Bosch Korea, 용인)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Robert Bosch Singapore

> 자동차 진단·ADAS·EV ASEAN R&D 허브 | 대기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Bishan / Jurong Innovation District, Singapore |
| 설립 연도 | 1979 |
| 임직원 수 | ~2,000명 (싱가포르) |
| 상장 여부 | 비상장 (Robert Bosch GmbH 자회사) |
| 주력 사업 | 자동차 ADAS SW R&D, 진단 솔루션, EV 충전 인프라, 사이버보안, 스마트 모빌리티 |
| 공식 홈페이지 | https://www.bosch.com.sg |

## 🎯 주요 제품 & 서비스

ADAS 시스템(레이더·카메라) R&D, 자동차 진단 솔루션(ESI[tronic]·KTS), EV 충전 인프라(ASEAN 허브), 사이버보안(ISO 21434), 스마트 교통 솔루션. ASEAN 지역 글로벌 Bosch R&D 센터 역할.

## 🚗 자동차/모빌리티 관련성

UDS/OBD 진단 + Bosch 진단 솔루션 도메인 → 전수환의 진단 통신 5년+ 직결. ADAS 검증 + EV 기술(2026 과정) + Automotive Cybersecurity 수료 → 싱가포르 Bosch R&D 멀티 역할. Bosch Korea 통해 내부 이동 최단 경로.

## 📈 성장성 & 전망

**성장성 평가: ★★★★★**

싱가포르 스마트 모빌리티 국책사업 파트너, ASEAN EV 시장 급성장. Bosch 글로벌 ADAS·EV·사이버보안 전략의 ASEAN 핵심 허브.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | UDS/OBD 진단 5년+ + JLR·Hyundai·VW 다중 OEM 경험 + Automotive Cybersecurity → 보쉬 ASEAN 허브 Diagnostics/ADAS Validation 역할. Bosch Korea(용인) 통해 내부 이동 경로 현실적. |
| 추천 직무 | Automotive Diagnostics Engineer, ADAS Validation Engineer, Cybersecurity Engineer |
| 지원 방법 | bosch.com.sg/careers, LinkedIn, Bosch Korea HR 통해 SG 포지션 문의 |
| 비자 스폰 가능성 | ★★★★★ (보쉬 직영, Employment Pass 적극 지원) |

## ⚠️ 리스크 / 고려사항

- 싱가포르 생활비 매우 높음
- 보쉬 내부 이동 시 FPT-Hyundai 파견 계약 검토 필요

## 🔗 관련 정보

- 홈페이지: [bosch.com.sg](https://www.bosch.com.sg)
- 관련: [[../16_Germany/Robert_Bosch|Bosch 독일 본사]]
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Robert Bosch Singapore 공식 홈페이지 (2026.07 기준)*
