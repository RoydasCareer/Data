---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/embedded
  - automotive/security
  - automotive/v2x
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "NXP Semiconductors Singapore"
size: "대기업"
fit: "★★★"
business: "자동차 반도체·V2X·보안 MCU·게이트웨이 프로세서 아시아 HQ"
hq: "Singapore"
founded: "1953 (Philips 분사)"
employees: "~3,000명 (싱가포르)"
ipo_status: "상장 (NASDAQ: NXPI)"
korea_office: "있음 (NXP Korea, 강남)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# NXP Semiconductors Singapore

> 자동차 반도체·V2X·보안 MCU 아시아 HQ | 대기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Singapore (아시아 HQ) |
| 설립 연도 | 1953 (Philips 분사) |
| 임직원 수 | ~3,000명 (싱가포르) |
| 상장 여부 | 상장 (NASDAQ: NXPI) |
| 주력 사업 | S32G 자동차 게이트웨이 MCU, V2X 통신 칩(RoadLINK), HSM 보안 솔루션, 이더넷 트랜시버 |
| 공식 홈페이지 | https://www.nxp.com |

## 🎯 주요 제품 & 서비스

S32G(차량 게이트웨이), S32K(제어 MCU), V2X 5.9GHz DSRC/C-V2X 칩, 자동차 이더넷 트랜시버(100BASE-T1, 1000BASE-T1), HSM(Hardware Security Module). CAN-FD·DoIP·진단이 구동되는 MCU 플랫폼 제조사.

## 🚗 자동차/모빌리티 관련성

CAN-FD·이더넷·V2X·진단 칩 → 전수환의 CANoe/CAN-FD/DoIP 경험 완전 연결. Field Application Engineer(FAE)로 고객 기술지원 역할. NXP Korea 통해 싱가포르 이동 경로.

## 📈 성장성 & 전망

**성장성 평가: ★★★★★**

SDV·EV·V2X 모두 NXP 핵심 성장 영역. 싱가포르 HMGICS(Hyundai) 등 EV OEM 확대로 현지 수요 급성장.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | CAN-FD/V2X/DoIP 칩 도메인 + CANoe 경험 → FAE (Automotive) 포지션. NXP Korea(강남) 통해 싱가포르 내부 이동. |
| 추천 직무 | Field Application Engineer (Automotive), Technical Sales Engineer, Validation Engineer |
| 지원 방법 | nxp.com/careers, LinkedIn, NXP Korea HR 문의 |
| 비자 스폰 가능성 | ★★★★★ (글로벌 반도체 대기업, Employment Pass 적극 지원) |

## ⚠️ 리스크 / 고려사항

- 반도체 칩 레벨 기술 이해 필요 (FAE 역할)
- 싱가포르 생활비 높음

## 🔗 관련 정보

- 홈페이지: [nxp.com](https://www.nxp.com)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: NXP Semiconductors 공식 홈페이지 (2026.07 기준)*
