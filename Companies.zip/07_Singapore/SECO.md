---
tags:
  - company
  - automotive
  - country/singapore
  - size/mid
  - automotive/embedded
  - automotive/autosar
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "SECO (SG)"
size: "중견기업"
fit: "★★★"
business: "임베디드 컴퓨팅 모듈·엣지 AI 플랫폼 (HQ: 이탈리아)"
hq: "Arezzo, Italy (글로벌 본사) / Singapore (APAC 거점)"
founded: "1979"
employees: "500명+ (글로벌)"
revenue: "비공개"
ipo_status: "비상장 (민간 기업)"
---

# SECO (SG)

> 임베디드 컴퓨팅 모듈·엣지 AI 플랫폼 | 중견기업 | 싱가포르 🇸🇬 (HQ: 이탈리아)

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | SECO S.p.A. (글로벌 본사) / SECO Singapore Pte. Ltd. |
| 글로벌 본사 | Arezzo, Italy |
| APAC 거점 | **Singapore** |
| 설립 연도 | **1979년** |
| CEO | Massimo Mauri |
| 글로벌 임직원 | **500명+** |
| 연매출 | 비공개 |
| 상장 여부 | 비상장 |
| 공식 홈페이지 | https://www.seco.com |

---

## 🎯 주요 제품 & 서비스

SECO는 **산업용·자동차용 임베디드 컴퓨팅 모듈(SoM), SBC, 엣지 AI 플랫폼** 전문 기업입니다.

| 제품/서비스 | 내용 |
| :--- | :--- |
| **System on Module (SoM)** | NXP i.MX, NVIDIA Jetson, Intel 기반 SoM |
| **Single Board Computer (SBC)** | 산업·차량용 고신뢰성 SBC |
| **EDGEKEY™ Platform** | 엣지 AI·IoT 통합 관리 플랫폼 |
| **자동차용 컴퓨팅** | ADAS·인포테인먼트용 임베디드 컴퓨팅 모듈 |
| **BSP/드라이버** | 리눅스·윈도우 임베디드 BSP 지원 |
| **맞춤 설계** | 고객 요구사항 기반 커스텀 모듈 설계 |

---

## 🚗 자동차 분야 적용

| 분야 | 내용 |
| :--- | :--- |
| **ADAS 컴퓨팅** | NVIDIA Jetson 기반 ADAS 처리 모듈 |
| **인포테인먼트 (IVI)** | 차량 인포테인먼트 시스템용 임베디드 보드 |
| **차량 게이트웨이** | V2X·텔레매틱스 게이트웨이 컴퓨팅 |
| **OTA 업데이트** | EDGEKEY 플랫폼 기반 OTA 관리 |

---

## 🌍 글로벌 사무소

| 지역 | 위치 |
| :--- | :--- |
| 글로벌 본사 | Arezzo, Italy |
| 미주 | USA |
| APAC | **Singapore** |
| 유럽 | 독일, 프랑스 등 |

---

## 🇰🇷 한국 지사

**한국 직영 법인 없음** — 대리점/파트너 통해 국내 유통 가능

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 산업용 임베디드 컴퓨팅 시장 꾸준한 수요
- NVIDIA Jetson 기반 엣지 AI 수요 증가로 성장
- 자동차 ADAS·인포테인먼트 임베디드 모듈 수요 확대
- 중소 규모 기업 특성

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 자동차용 임베디드 컴퓨팅 모듈(ADAS, IVI, 게이트웨이) — BSP 개발, 리눅스 임베디드, NVIDIA Jetson, 드라이버 개발 경험 직접 활용 가능. 자동차 SW 엔지니어 적합도 높음. |
| 추천 직무 | Embedded SW Engineer (BSP/Linux), ADAS Platform Engineer, Embedded Systems Engineer (Automotive) |
| 지원 방법 | seco.com/careers, LinkedIn |
| 비자 스폰 (싱가포르) | ★★★ — Employment Pass 지원 가능 |
| 참고 | 이탈리아 본사 기업 — 싱가포르 APAC 팀 채용 규모 확인 필요 |

---

## 🔗 관련 정보

- 홈페이지: [seco.com](https://www.seco.com)
- EDGEKEY: [seco.com/edgekey](https://www.seco.com/edgekey)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: SECO 공식 홈페이지 — 작성 기준 2026.06.01*
