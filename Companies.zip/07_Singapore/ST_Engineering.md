---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/autonomous
  - automotive/adas
  - fit/★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "ST Engineering (Land Systems)"
size: "대기업"
fit: "★★"
business: "자율주행·스마트 모빌리티 SW"
hq: "(본사 위치 미확인) — 싱가포르"
---

# ST Engineering (Land Systems)

> 자율주행·스마트 모빌리티 SW | 대기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

AI 기반 자율주행 소프트웨어 플랫폼을 개발하는 기업입니다. 인식·판단·제어 알고리즘과 자율주행 검증·시뮬레이션 솔루션을 제공합니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 싱가포르 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 대기업 |
| 주력 사업 | 자율주행·스마트 모빌리티 SW |

## 🎯 비전 & 미션

레벨 4~5 완전 자율주행 상용화로 교통사고 제로, 물류·이동 혁신을 목표로 합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

글로벌 자율주행 시장 2030년 $2조 이상 예상. 단기 규제 리스크 있으나 장기 성장은 확실.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | ADAS QA 경험 활용 가능 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★★★ |
| 고졸 채용 가능성 | 관련 경험 5년+ 시 EP 예외 가능 |
| 비자 정보 | Employment Pass (EP) |
| 비고 | 자동차 기술직 EP 취득 가능. 월급여 S$5,000+ 필요. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
