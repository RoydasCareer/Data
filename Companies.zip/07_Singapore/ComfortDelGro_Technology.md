---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/testing
  - automotive/autonomous
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "ComfortDelGro Technology"
size: "대기업"
fit: "★★★"
business: "싱가포르 최대 교통 그룹 테크 자회사 — AV·플릿 관리·차량 진단 플랫폼"
hq: "Singapore"
founded: "2000s"
employees: "~500명"
ipo_status: "비상장 (ComfortDelGro Corporation SGX: C52 자회사)"
korea_office: "없음"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# ComfortDelGro Technology

> AV·플릿 관리·차량 진단 플랫폼 | 대기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Singapore |
| 설립 연도 | 2000s |
| 임직원 수 | ~500명 |
| 상장 여부 | 비상장 (ComfortDelGro SGX: C52 자회사) |
| 주력 사업 | 자율주행 셔틀 운행, 플릿 관리 SW, 차량 OBD 진단 모니터링, 스마트 모빌리티 |
| 공식 홈페이지 | https://www.comfortdelgro.com |

## 🎯 주요 제품 & 서비스

자율주행 셔틀 파일럿 운영(Nanyang Technological University 등), 택시·버스 플릿 OBD 실시간 진단 플랫폼, 운전자 행동 분석, EV 플릿 전환 관리. 싱가포르 정부 스마트 모빌리티 파트너.

## 🚗 자동차/모빌리티 관련성

OBD/CAN 진단 데이터 기반 플릿 모니터링 → 전수환의 OBD/진단 통신 경험 직결. Technical PM으로 대규모 플릿 기술 전환 프로젝트 관리. AV 실증 테스팅 역할도 가능.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

싱가포르 2040 교통 마스터플랜, EV 플릿 의무화, AV 파일럿 확대. 스마트 모빌리티 국책 투자 지속.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | OBD/CAN 진단 + Technical PM + 영어 90% 업무 → Fleet Technology PM, AV Integration Engineer 포지션. 싱가포르 Employment Pass 자격(5년+ 기술 경력). |
| 추천 직무 | Fleet Technology PM, AV Integration Engineer, Diagnostics Solutions Engineer |
| 지원 방법 | comfortdelgro.com/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★★ (싱가포르 대형 상장사, Employment Pass 스폰서) |

## ⚠️ 리스크 / 고려사항

- 자동차 SW 개발보다 운영·관리 역할 위주
- 순수 임베디드/진단 개발 포지션은 제한적

## 🔗 관련 정보

- 홈페이지: [comfortdelgro.com](https://www.comfortdelgro.com)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: ComfortDelGro 공식 홈페이지 (2026.07 기준)*
