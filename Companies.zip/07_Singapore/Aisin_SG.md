---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/software
  - automotive/parts
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Aisin (Singapore)"
size: "대기업"
fit: "★★★"
business: "자동차 부품·SW 솔루션 (Toyota Group Tier-1)"
hq: "Kariya, Aichi, Japan (글로벌 본사) / Singapore (ASEAN 거점)"
founded: "1949 (일본 본사) / 2021년 Aisin으로 그룹 통합"
employees: "110,000명+ (글로벌, Aisin 그룹)"
revenue: "¥4.3조 (FY2024, 글로벌)"
ipo_status: "TYO 상장 (티커: 7259) — Toyota Group 계열"
---

# Aisin (Singapore)

> 자동차 부품·SW 솔루션 | 대기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Aisin Asia Pacific Pte. Ltd. |
| 글로벌 본사 | Kariya, Aichi, Japan |
| 싱가포르 | ASEAN 지역 거점 (R&D·영업) |
| 설립 (일본) | **1949년** (2021년 Aisin Seiki·AW 합병 → 현 Aisin) |
| 모그룹 | **Toyota Group** Tier-1 부품 계열사 |
| 글로벌 임직원 | **110,000명+** (그룹 전체) |
| 글로벌 연매출 | **¥4.3조** (FY2024, 약 USD 28B) |
| 상장 | **TYO: 7259** |
| 공식 홈페이지 | https://www.aisin.com |

---

## 🎯 주요 제품 & 서비스

| 제품/서비스 | 내용 |
| :--- | :--- |
| **파워트레인** | 자동변속기(AT), CVT, 8단 AT — 세계 최대 AT 공급사 |
| **차체·안전** | 도어 시스템, 시트, 브레이크 시스템 |
| **전동화** | e-Axle, 모터, 인버터 — EV/HEV용 |
| **ADAS·자율주행** | 주차 지원, AVM, 사각지대 감지 |
| **정보·통신** | 내비게이션, 카 오디오, 커넥티드 서비스 |
| **에너지 관리** | 연료전지 스택, 수소 관련 부품 |

---

## 🌍 글로벌 사무소

| 지역 | 주요 거점 |
| :--- | :--- |
| 일본 | Kariya, Aichi (본사) |
| 동남아 | **Singapore** (ASEAN HQ), 태국, 인도네시아, 말레이시아 |
| 북미 | 미국 (Aisin North America) |
| 유럽 | 독일, 벨기에 |
| 중국 | 상하이, 베이징 등 |
| 한국 | 서울 (아이신코리아) |

---

## 🇰🇷 한국 지사

**아이신코리아(주) — 한국 법인 있음**

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | 아이신코리아(주) |
| 주요 고객 | 현대자동차그룹, 기아 등 국내 OEM |
| 채용 | aisin.com 또는 LinkedIn에서 Korea 포지션 검색 |

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★★**

- **Toyota Group 계열**: 안정적 수주 기반, 글로벌 공급망 핵심
- **전동화 전환**: EV/HEV용 e-Axle 사업 고성장
- **SW 역량 강화**: ADAS, 커넥티드, SDV 관련 SW 내재화 추진
- **ASEAN 생산거점 확대**: 싱가포르 R&D, 태국·인도네시아 생산

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | Toyota Group Tier-1 대형 부품사 — 전동화(e-Axle), ADAS, 커넥티드 SW 분야에서 자동차 SW 엔지니어 수요 있음. 한국 법인 채용 가능성 + 싱가포르 R&D 포지션 양쪽 검토 가능. |
| 추천 직무 | Embedded SW Engineer, ADAS SW Engineer, e-Axle Control SW Engineer, Systems Integration Engineer |
| 지원 방법 | aisin.com 채용 페이지, LinkedIn |
| 비자 스폰 (싱가포르) | ★★★ — 대기업, Employment Pass 지원 가능 |
| 한국 지사 지원 | 아이신코리아 채용 공고 별도 확인 |

---

## 🔗 관련 정보

- 홈페이지: [aisin.com](https://www.aisin.com)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: aisin.com 공식 홈페이지, 연간보고서 — 작성 기준 2026.06.01*
