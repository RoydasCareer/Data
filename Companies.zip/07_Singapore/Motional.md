---
tags:
  - company
  - automotive
  - country/singapore
  - size/mid
  - automotive/autonomous
  - automotive/software
  - fit/★★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Motional (HQ: 미국, SG 운영)"
size: "중견기업"
fit: "★★★★"
business: "Level 4 완전자율주행 개발 (Aptiv·현대차그룹 50:50 JV)"
hq: "Boston, MA, USA (글로벌 본사) / Singapore (APAC 테스트·운영)"
founded: "2020"
employees: "1,500명+ (글로벌)"
revenue: "비공개 (전략적 JV, 공모 전)"
ipo_status: "비상장 (Aptiv·현대차그룹 JV)"
---

# Motional (HQ: 미국, SG 운영)

> Level 4 완전자율주행 개발 | 중견기업 | 싱가포르 🇸🇬 (HQ: 미국)

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Motional AD LLC |
| 글로벌 본사 | Boston, MA, USA |
| 싱가포르 | APAC 테스트·운영 거점 |
| 설립 연도 | **2020년** (Aptiv·현대차그룹 발표 2019.08 → 완료 2020.03) |
| 지분 구조 | **Aptiv 50%** + **현대자동차그룹 50%** |
| 기업가치 | **$4B** (설립 시 기준) |
| CEO | **Laura Major** (2025년 7월 취임) |
| 임직원 수 | **1,500명+** (글로벌) |
| 상장 여부 | 비상장 (JV) |
| 공식 홈페이지 | https://motional.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2019.08 | Aptiv·현대차그룹 JV 발표 ($4B 기업가치) |
| 2020.03 | Motional AD LLC 설립 완료 |
| 2020.08 | "Motional" 브랜드명 공개 |
| 2022~23 | 라스베이거스·피츠버그·싱가포르 테스트 운행 확대 |
| 2025.02 | 현대차 테스트 트랙(한국) 고속도로 자율주행 테스트 |
| **2026.03** | **라스베이거스 Uber 연계 로보택시 서비스 개시** (IONIQ 5 기반) |

---

## 🎯 주요 기술 & 서비스

| 기술/서비스 | 내용 |
| :--- | :--- |
| **Level 4 AV 소프트웨어 스택** | 인식·계획·제어 완전 자율주행 SW |
| **IONIQ 5 로보택시** | 현대 IONIQ 5 기반 자율주행 차량 |
| **자율주행 플릿 운영** | Uber 연계 라스베이거스 로보택시 서비스 |
| **Aptiv Wind River 연계** | SDV 플랫폼 기반 자율주행 OS 통합 |
| **싱가포르 테스트** | LTA 규제 샌드박스 내 자율주행 테스트 |

---

## 🌍 글로벌 운영 거점

| 지역 | 역할 |
| :--- | :--- |
| **Boston, MA, USA** | 글로벌 본사, SW 개발 핵심 |
| **Las Vegas, NV, USA** | 상업 로보택시 운영 (Uber 연계) |
| **Pittsburgh, PA, USA** | 기술 개발 거점 |
| **Singapore** | APAC 테스트·운영 거점, LTA 협력 |
| **Seoul, Korea** | 현대차 연계 테스트 |

---

## 🇰🇷 한국 연관성

- **현대자동차그룹이 50% 지분** 보유 — 현대차 한국 본사와 긴밀 협력
- 현대차 테스트 트랙(화성) 고속도로 자율주행 테스트 진행
- 한국 SW 엔지니어 채용 가능성 (원격 또는 미국·싱가포르 포지션)

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★★**

- **상용화 본격화**: 라스베이거스 Uber 로보택시 2026년 3월 개시
- **현대차그룹 지원**: IONIQ 5 차량 공급·테스트 인프라 지원
- **리스크**: 자율주행 상용화 타임라인 불확실, 대규모 투자 지속 필요
- Aptiv의 Versigent 분사(2026.04) 이후 → 자율주행 집중 전략

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | Level 4 완전자율주행 SW 개발 최전선 — ADAS·자율주행·임베디드 SW 경험 최고 수준 활용 가능. 현대차그룹 JV로 한국 연계 강함. 로보택시 상용화 단계 진입으로 커리어 임팩트 최대. |
| 추천 직무 | Autonomous Driving SW Engineer, Perception Engineer, Planning & Control Engineer, Safety Engineer, ROS2/SW Platform Engineer |
| 지원 방법 | motional.com/careers, LinkedIn |
| 비자 스폰 (미국·싱가포르) | ★★★★ — 양 거점 모두 비자 지원 (미국 H-1B, 싱가포르 EP) |
| 한국 연계 | 현대차그룹 내부 이동 or 현대차 채용 통한 Motional 협력 포지션 가능 |

---

## 🔗 관련 정보

- 홈페이지: [motional.com](https://motional.com)
- 뉴스룸: [motional.com/news](https://motional.com/news)
- 모회사: [[Aptiv|Aptiv PLC]] (아일랜드)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: motional.com 공식 홈페이지, Aptiv IR, 현대차그룹 보도자료 — 작성 기준 2026.06.01*
*[주요 업데이트] 라스베이거스 Uber 로보택시 서비스 개시(2026.03), Aptiv Versigent 분사(2026.04) 반영*
