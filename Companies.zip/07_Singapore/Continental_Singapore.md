---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/adas
  - automotive/ivi
  - automotive/security
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Continental Automotive Singapore"
size: "대기업"
fit: "★★★"
business: "ADAS·IVI·사이버보안·EV 파워트레인 전자 시스템 아시아태평양 R&D 허브"
hq: "Singapore"
founded: "2002"
employees: "~800명 (싱가포르)"
ipo_status: "상장 (XETRA: CON)"
korea_office: "있음 (AUMOVIO Korea, 구 Continental Korea)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Continental Automotive Singapore

> ADAS·IVI·사이버보안 아시아태평양 R&D 허브 | 대기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Singapore |
| 설립 연도 | 2002 |
| 임직원 수 | ~800명 (싱가포르) |
| 상장 여부 | 상장 (XETRA: CON) |
| 주력 사업 | ADAS 시스템, IVI/HMI, 자동차 사이버보안, EV 파워트레인 전자 시스템 |
| 공식 홈페이지 | https://www.continental-automotive.com |

## 🎯 주요 제품 & 서비스

ADAS 카메라·레이더, IVI 콕핏 시스템, 자동차 사이버보안(VicOne 포함), 고압 EV 인버터·컨버터, V2X 모듈. 싱가포르 R&D 센터는 ASEAN·동남아 OEM 대응 허브.

## 🚗 자동차/모빌리티 관련성

ADAS/IVI 검증 + Automotive Cybersecurity(ISO 21434) → 전수환의 현재 역할(IVI 검증) + 수료 역량 완전 매칭. AUMOVIO Korea(구 Continental Korea, 판교)를 통해 싱가포르 이동 경로 가능.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

SDV 전환(CARIAD 협력), ASEAN EV 시장 급성장, 자동차 사이버보안 법제화(UN R155) 시행.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | IVI 검증(현재) + ADAS QA + Automotive Cybersecurity 수료 → Continental SG 핵심 채용 프로필. AUMOVIO Korea 통해 싱가포르 이동 경로. |
| 추천 직무 | IVI Validation Engineer, ADAS Test Engineer, Cybersecurity Analyst |
| 지원 방법 | continental.com/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★★★ (글로벌 Tier-1, Employment Pass 적극 지원) |

## ⚠️ 리스크 / 고려사항

- Continental 구조조정(AUMOVIO 분리) 진행 중 — 조직 변화 모니터링
- 싱가포르 생활비 높음

## 🔗 관련 정보

- 홈페이지: [continental-automotive.com](https://www.continental-automotive.com)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Continental Automotive 공식 홈페이지 (2026.07 기준)*
