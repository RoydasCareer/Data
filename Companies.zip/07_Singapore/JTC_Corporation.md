---
tags:
  - company
  - automotive
  - country/singapore
  - size/public
  - automotive/testing
  - automotive/qa
  - fit/★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "JTC Corporation (Smart Mobility)"
size: "공기업"
fit: "★★"
business: "AV 테스팅 구역 운영"
hq: "(본사 위치 미확인) — 싱가포르"
---

# JTC Corporation (Smart Mobility)

> AV 테스팅 구역 운영 | 공기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

자동차 소프트웨어 품질 보증(QA), 테스팅 자동화, 인증·검증 서비스 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 싱가포르 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 공기업 |
| 주력 사업 | AV 테스팅 구역 운영 |

## 🎯 비전 & 미션

SDV 시대의 SW 복잡도에 대응하는 AI 기반 테스팅 자동화 및 CI/CD 통합 QA 생태계를 구축합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★★**

차량당 SW 코드 10억+ 라인 시대. 자동차 SW 테스팅 시장 2028년까지 연 15% 성장.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | 자동차 QA·회귀 테스트 경험 직접 활용 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★★★ |
| 고졸 채용 가능성 | 관련 경험 5년+ 시 EP 예외 가능 |
| 비자 정보 | Employment Pass (EP) |
| 비고 | 자동차 기술직 EP 취득 가능. 월급여 S$5,000+ 필요. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
