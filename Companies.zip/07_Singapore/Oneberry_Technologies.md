---
tags:
  - company
  - automotive
  - country/singapore
  - size/startup
  - automotive/telematics
  - automotive/fleet
  - fit/★★
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Oneberry Technologies"
size: "스타트업"
fit: "★★"
business: "IoT 자산 추적·영상 감시 솔루션 (차량·현장 관리)"
hq: "Singapore"
founded: "2013"
employees: "50~200명 (추정)"
revenue: "비공개"
ipo_status: "비상장"
---

# Oneberry Technologies

> IoT 자산 추적·영상 감시 솔루션 | 스타트업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Oneberry Technologies Pte. Ltd. |
| 본사 | Singapore |
| 설립 연도 | **2013년** |
| 임직원 수 | 50~200명 (추정) |
| 연매출 | 비공개 |
| 상장 여부 | 비상장 |
| 공식 홈페이지 | https://www.oneberry.com |

---

## 🎯 주요 제품 & 서비스

Oneberry는 **IoT 기반 자산 추적·영상 감시·현장 안전** 솔루션 기업입니다.

| 제품/서비스 | 내용 |
| :--- | :--- |
| **차량 GPS 추적** | 실시간 차량·자산 위치 추적 플릿 관리 |
| **CCTV·영상 감시** | AI 영상 분석, 스마트 CCTV 솔루션 |
| **안전 관리** | 현장 근로자 안전 모니터링 (건설·물류) |
| **IoT 센서** | 온도·충격·진동 등 자산 상태 모니터링 |
| **클라우드 플랫폼** | 통합 자산 관리 대시보드 |

---

## 🚗 자동차/모빌리티 관련성

| 영역 | 내용 |
| :--- | :--- |
| **차량 플릿 추적** | GPS 기반 상용차·특수차 실시간 추적 |
| **운전 행동 분석** | 급가속·급제동·과속 모니터링 |
| **차량 상태 모니터링** | OBD2 연동 차량 진단 데이터 수집 |

---

## 🌍 운영 지역

싱가포르 중심 / 동남아 확장

---

## 🇰🇷 한국 지사

**한국 법인 없음**

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★**

- IoT 자산 추적 시장 꾸준한 성장
- 싱가포르 건설·물류 산업 수요 안정적
- 소규모 스타트업, 시장 규모 제한적

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 차량 GPS·IoT 추적 솔루션 — 텔레매틱스, 임베디드 IoT, 클라우드 플랫폼 경험 활용 가능. 자동차 ADAS·임베디드 SW보다 IoT·플릿 관리 중심. |
| 추천 직무 | IoT/Embedded Engineer, Fleet Management SW Engineer, Backend Engineer |
| 지원 방법 | oneberry.com 채용, LinkedIn |
| 비자 스폰 (싱가포르) | ★★ — Employment Pass 가능 |
| 참고 | 소규모 스타트업 — 안정성 낮음 |

---

## 🔗 관련 정보

- 홈페이지: [oneberry.com](https://www.oneberry.com)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Oneberry 공식 홈페이지 — 작성 기준 2026.06.01*
