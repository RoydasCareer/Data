---
tags:
  - company
  - automotive
  - country/singapore
  - size/public
  - automotive/security
  - automotive/cybersecurity
  - fit/★★
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Cyber Security Agency (CSA)"
size: "공기업"
fit: "★★"
business: "싱가포르 국가 사이버보안 기관 (정부 산하)"
hq: "Singapore (Guoco Tower)"
founded: "2015"
employees: "300명+ (추정)"
revenue: "정부 기관 (예산 운영)"
ipo_status: "정부 기관 — 비상장"
---

# Cyber Security Agency (CSA)

> 싱가포르 국가 사이버보안 기관 | 공기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Cyber Security Agency of Singapore (CSA) |
| 본사 | 8 Shenton Way, #31-01, Guoco Tower, Singapore |
| 설립 연도 | **2015년** (정보통신미디어개발청 IMDA에서 분리) |
| 상위 기관 | **총리실(PMO)** 산하 |
| Commissioner | **David Koh** (초대 CSA 청장, 현 Commissioner) |
| 임직원 수 | 300명+ (추정) |
| 유형 | 싱가포르 정부 기관 |
| 공식 홈페이지 | https://www.csa.gov.sg |

---

## 🎯 주요 역할 & 기능

CSA는 싱가포르의 **국가 사이버보안 정책·규제·역량 개발**을 총괄하는 정부 기관입니다.

| 역할 | 내용 |
| :--- | :--- |
| **국가 사이버보안 전략** | 싱가포르 사이버보안법 집행, Critical Information Infrastructure(CII) 보호 |
| **사이버보안 규제** | 통신·에너지·교통·금융·의료 등 주요 인프라 사이버보안 감독 |
| **사이버위협 대응** | SingCERT(싱가포르 사이버비상대응팀) 운영 |
| **인재 양성** | 사이버보안 인재 개발 프로그램, 장학금, 국제 협력 |
| **자동차 사이버보안** | UN R155/R156, ISO/SAE 21434 관련 정책·가이드라인 수립 |

---

## 🚗 자동차 사이버보안 관련성

| 항목 | 내용 |
| :--- | :--- |
| **UN R155 (차량 사이버보안)** | 싱가포르 내 차량 형식 승인 연계 사이버보안 규제 |
| **V2X 보안** | 커넥티드카·스마트교통 인프라 보안 정책 수립 |
| **연구 파트너십** | NUS, NTU 등과 자율주행 사이버보안 연구 협력 |
| **LTA 협력** | 자율주행 규제 샌드박스 내 사이버보안 기준 수립 |

---

## 🇰🇷 한국 연관성

- 한국 KISA(한국인터넷진흥원)·NIS와 국제 사이버보안 협력
- 직접 고용 대상: 싱가포르 시민권자/PR 우선 — 외국인 채용 제한적

---

## 📈 성장성 & 조직 동향

**성장성 평가: ★★★★** (사이버보안 시장 기준)

- 싱가포르 정부의 디지털 전환 및 스마트시티 확장으로 사이버보안 중요성 급증
- 자율주행·커넥티드카 확산에 따른 차량 사이버보안 정책 강화
- 정부 기관 특성상 안정적이나 급여·처우는 민간 대비 보수적

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 사이버보안(UN R155, ISO/SAE 21434) 정책 관련 업무 가능. CAN 분석·차량 보안 경험 활용 여지 있음. 그러나 정부 기관 특성상 외국인 채용 제한 및 처우 한계. |
| 추천 직무 | Cybersecurity Specialist (Transportation/Automotive), Policy Analyst (V2X Security) |
| 지원 방법 | csa.gov.sg/careers |
| 비자 스폰 (싱가포르) | ★ — 정부 기관, 시민권자/PR 우선 |
| 참고 | 정부 기관 특성상 외국인 지원 어려움 — 사이버보안 민간 기업(Ensign InfoSecurity 등)이 더 현실적 |

---

## 🔗 관련 정보

- 홈페이지: [csa.gov.sg](https://www.csa.gov.sg)
- SingCERT: [csa.gov.sg/singcert](https://www.csa.gov.sg/singcert)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: CSA 공식 홈페이지, 싱가포르 총리실 — 작성 기준 2026.06.01*
