---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/mobility
  - automotive/maas
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Grab"
size: "대기업"
fit: "★★★"
business: "동남아 최대 슈퍼앱 — 라이드헤일·음식배달·금융·모빌리티 플랫폼 (NASDAQ:GRAB)"
hq: "Singapore (One-North)"
founded: "2012"
employees: "8,000명+ (글로벌)"
revenue: "US$2.8B (FY2024)"
ipo_status: "NASDAQ 상장 (티커: GRAB) — 2021년 SPAC 상장"
---

# Grab

> 동남아 최대 슈퍼앱 | 대기업 | 싱가포르 🇸🇬 | NASDAQ:GRAB

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Grab Holdings Limited |
| 본사 | Singapore (One-North) |
| 설립 연도 | **2012년** (말레이시아에서 MyTeksi로 창업) |
| 공동창업자 | **Anthony Tan** (CEO), Tan Hooi Ling |
| CEO | **Anthony Tan** |
| 임직원 수 | **8,000명+** (글로벌) |
| 연매출 | **US$2.8B (FY2024)** |
| 상장 | **NASDAQ: GRAB** (2021년 Altimeter Capital SPAC 합병 상장) |
| 공식 홈페이지 | https://www.grab.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2012 | 말레이시아에서 택시 앱 MyTeksi로 창업 |
| 2013 | GrabTaxi로 개명, 싱가포르 진출 |
| 2018 | **Uber 동남아 사업 인수** (Uber 27.5% 지분 취득) |
| 2021 | **NASDAQ SPAC 상장** — $39.6B 기업가치 |
| 2023~24 | 수익성 개선 집중, 비핵심 사업 정리 |

---

## 🎯 주요 사업 세그먼트

| 사업 | 내용 |
| :--- | :--- |
| **Mobility** | 라이드헤일 (싱가포르·말레이시아·인도네시아·베트남·필리핀 등 8개국) |
| **Deliveries** | 음식배달(GrabFood), 택배(GrabExpress) |
| **Financial Services** | GrabPay, 디지털 은행(GXS Bank), 보험, 투자 |
| **Enterprise** | B2B 플릿 관리, 기업 이동 서비스 |

---

## 🚗 자동차/모빌리티 기술

| 영역 | 내용 |
| :--- | :--- |
| **플릿 최적화** | 수백만 대 차량 실시간 매칭·경로 최적화 AI |
| **운전자 안전 기술** | GrabDefence (사기 탐지), 피로 감지, 안전 운전 모니터링 |
| **지도·내비** | Grab Maps (동남아 특화 자체 지도 플랫폼) |
| **EV 도입** | 드라이버 EV 전환 지원 프로그램 |
| **자율주행 연구** | 과거 nuTonomy 등과 협력 (현재 연구 단계) |

---

## 🌍 운영 국가

싱가포르, 말레이시아, 인도네시아, 태국, 베트남, 필리핀, 캄보디아, 미얀마 (8개국)

---

## 🇰🇷 한국 지사

**한국 직영 법인 없음** — 동남아 중심

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★★**

- **동남아 슈퍼앱 독보적 1위**: 라이드헤일·음식배달 시장점유율 압도적
- **수익성 전환**: 2024년 처음으로 Adj. EBITDA 흑자 달성
- **금융 서비스 성장**: GXS Bank, 보험 → 고마진 핀테크 확장
- **경쟁**: Gojek/GoTo와 치열한 경쟁 지속

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 동남아 최대 모빌리티 플랫폼 — 대규모 플릿 최적화 AI, 지도·내비 SW, 안전 기술 등 자동차 SW와 연계된 엔지니어링 역할 다수. 글로벌 기술 기업 수준의 엔지니어링 환경. NASDAQ 상장사로 스톡옵션 보상 체계. |
| 추천 직무 | Maps & Navigation Engineer, Safety Systems Engineer, Fleet Optimization Engineer, ML Engineer (라이드 매칭) |
| 지원 방법 | grab.com/sg/careers, LinkedIn |
| 비자 스폰 (싱가포르) | ★★★★ — 대형 상장사, Employment Pass 적극 지원 |
| 한국 채용 | 한국 법인 없음 — 싱가포르 본사 포지션 지원 |

---

## 🔗 관련 정보

- 홈페이지: [grab.com](https://www.grab.com)
- Investor Relations: [investor.grab.com](https://investor.grab.com)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Grab 공식 홈페이지, SEC 10-K (FY2024), NASDAQ 공시 — 작성 기준 2026.06.01*
