---
tags:
  - company
  - automotive
  - country/singapore
  - size/large
  - automotive/embedded
  - automotive/security
  - automotive/adas
  - fit/★★★
  - recommend
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Aptiv Singapore"
size: "대기업"
fit: "★★★"
business: "차량 아키텍처·전기화·사이버보안 아시아태평양 엔지니어링 센터"
hq: "Singapore"
founded: "2012 (Delphi 분사)"
employees: "~500명 (싱가포르)"
ipo_status: "상장 (NYSE: APTV)"
korea_office: "있음 (Aptiv Korea)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Aptiv Singapore

> 차량 아키텍처·전기화·사이버보안 AP 엔지니어링 | 대기업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Singapore |
| 설립 연도 | 2012 (Delphi Technologies 분사) |
| 임직원 수 | ~500명 (싱가포르) |
| 상장 여부 | 상장 (NYSE: APTV) |
| 주력 사업 | 차량 전기/전자 아키텍처, 고압 하네스, ADAS 안전 시스템, 사이버보안(GUARDKNOX 협력) |
| 공식 홈페이지 | https://www.aptiv.com |

## 🎯 주요 제품 & 서비스

차량 중앙 게이트웨이 ECU, 고압 하네스(EV용), ADAS 안전 도메인 컨트롤러, 자동차 사이버보안 플랫폼(SVA). Hyundai·Toyota·BMW 등 글로벌 OEM 공급.

## 🚗 자동차/모빌리티 관련성

차량 네트워크 아키텍처 + CAN/이더넷 게이트웨이 ECU + 사이버보안 → 전수환의 CAN/진단 + Automotive Cybersecurity 수료 직결. Hyundai 납품사로 현재 고용주 연결. Aptiv Korea 통해 SG 이동 경로.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

SDV 전환으로 차량 아키텍처 재설계 수요 급증. ASEAN EV 시장 성장으로 고압 하네스 수요 폭발.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | CAN 네트워크/게이트웨이 ECU + Automotive Cybersecurity → Validation Engineer, Systems Engineer 포지션. Aptiv Korea 통해 SG 내부 이동 가능. |
| 추천 직무 | Vehicle Architecture Validation Engineer, Cybersecurity Engineer, Systems Integration Engineer |
| 지원 방법 | aptiv.com/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★★★ (글로벌 Tier-1, Employment Pass 적극 지원) |

## ⚠️ 리스크 / 고려사항

- 싱가포르 생활비 높음
- 하드웨어(하네스) 중심 사업부와 SW 사업부 역할 구분 필요

## 🔗 관련 정보

- 홈페이지: [aptiv.com](https://www.aptiv.com)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Aptiv 공식 홈페이지 (2026.07 기준)*
