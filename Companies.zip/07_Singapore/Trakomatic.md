---
tags:
  - company
  - automotive
  - country/singapore
  - size/startup
  - automotive/adas
  - automotive/sensing
  - fit/★★
country: "싱가포르"
country_folder: "07_Singapore"
company_name: "Trakomatic"
size: "스타트업"
fit: "★★"
business: "AI 비전 애널리틱스 — 리테일·스마트 공간·교통 (컴퓨터 비전)"
hq: "Singapore"
founded: "2012"
employees: "50~100명 (추정)"
revenue: "비공개"
ipo_status: "비상장"
---

# Trakomatic

> AI 비전 애널리틱스 | 스타트업 | 싱가포르 🇸🇬

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Trakomatic Pte. Ltd. |
| 본사 | Singapore |
| 설립 연도 | **2012년** |
| CEO | Jay Lim |
| 임직원 수 | 50~100명 (추정) |
| 연매출 | 비공개 |
| 상장 여부 | 비상장 |
| 공식 홈페이지 | https://www.trakomatic.com |

---

## 🎯 주요 제품 & 서비스

Trakomatic은 **AI 컴퓨터 비전 기반 인원·객체 분석** 플랫폼 기업입니다. 주력은 리테일·스마트빌딩이나 교통·모빌리티 분야로도 확장 중입니다.

| 제품/서비스 | 내용 |
| :--- | :--- |
| **People Counting** | AI 카메라 기반 인원 카운팅·동선 분석 |
| **얼굴 인식** | 입출입 관리, 신원 확인 |
| **차량 번호판 인식 (ANPR)** | 주차장·톨게이트 자동 차량 번호판 인식 |
| **교통 분석** | 교통량 카운팅, 차량 속도 측정 |
| **리테일 애널리틱스** | 매장 방문자 동선·체류시간 분석 |
| **클라우드 대시보드** | 실시간 데이터 모니터링 플랫폼 |

---

## 🚗 자동차/교통 관련성

| 분야 | 내용 |
| :--- | :--- |
| **ANPR** | 자동 번호판 인식 — 주차장·톨게이트 적용 |
| **교통 모니터링** | 차량 카운팅, 속도 감지, 혼잡도 분석 |
| **스마트 주차** | 주차장 AI 영상 분석 |

---

## 🌍 운영 지역

싱가포르 중심 / 동남아 확장 (말레이시아 등)

---

## 🇰🇷 한국 지사

**한국 법인 없음**

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 스마트시티·스마트빌딩 AI 비전 수요 증가
- 교통 분야 AI 모니터링 확장
- 소규모 스타트업 특성상 성장 불확실

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 컴퓨터 비전 기반 교통·차량 번호판 인식 — ADAS 비전 알고리즘 경험 일부 연계 가능. 주력은 리테일·빌딩이나 교통 모니터링 분야에서 자동차 비전 경험 활용 가능성. |
| 추천 직무 | Computer Vision Engineer, ML Engineer (객체 인식·추적), Backend Engineer |
| 지원 방법 | trakomatic.com 채용, LinkedIn |
| 비자 스폰 (싱가포르) | ★★ — Employment Pass 가능 |
| 참고 | 자동차 ADAS보다는 교통 모니터링·스마트시티 비전 분야 — 방향 확인 필요 |

---

## 🔗 관련 정보

- 홈페이지: [trakomatic.com](https://www.trakomatic.com)
- 국가 인덱스: [[_INDEX|싱가포르 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Trakomatic 공식 홈페이지 — 작성 기준 2026.06.01*
