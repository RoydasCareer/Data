---
tags:
  - company
  - automotive
  - country/netherlands
  - size/스타트업
  - automotive/ev
  - automotive/charging
  - fit/★★★★
  - recommend
country: "네덜란드"
country_folder: "10_Netherlands"
company_name: "Chargetrip"
size: "스타트업"
fit: "★★★★"
business: "EV 경로·충전 최적화 API 플랫폼"
hq: "Amsterdam, Netherlands"
founded: "2018"
employees: "~50명"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Chargetrip

> EV 경로·충전 최적화 API 플랫폼 | 스타트업 | 네덜란드 🇳🇱

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Amsterdam, Netherlands |
| 설립 연도 | 2018 |
| 임직원 수 | ~50명 |
| 주력 사업 | EV 주행거리·충전소 기반 경로 계획 API 서비스 |

## 🎯 주요 제품 & 서비스

Chargetrip은 전기차의 배터리 상태, 충전소 위치·가용성, 차량 에너지 소비 모델을 통합한 EV 전용 경로 계획 API를 제공하는 B2B 스타트업이다. 자동차 OEM, 충전 네트워크 사업자, 플릿 관리 업체들이 Chargetrip API를 통합하여 EV 최적 경로 및 충전 정류 계획 기능을 제품에 내재화한다. GraphQL 기반 API와 실시간 데이터 처리가 핵심 기술이다.

## 🚗 자동차/모빌리티 관련성

EV 차량 에너지 소비 모델링, 배터리 상태(SoC/SoH) 데이터 처리, 충전 인프라 연동, OEM API 통합 등 전기차 SW의 핵심 영역과 깊이 연관되어 있다. 자동차 OEM·Tier1의 커넥티드카 서비스와 직접 통합되는 B2B API 사업으로, 임베디드~클라우드를 연결하는 EV 소프트웨어 스택 전반에 걸쳐 있다.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

유럽 EV 보급 가속과 함께 EV 경로 계획 솔루션 수요가 폭발적으로 증가하고 있다. OEM·충전 네트워크·플릿 운영사 모두가 EV 경로 기능을 자사 서비스에 통합해야 하므로 시장 성장이 보장된다. 2023년 시리즈 A 투자 유치로 성장 기반을 확보했다.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | EV 에너지 모델링·충전 API·OEM 통합 등 자동차 SW 핵심 역량 직접 활용 가능 |
| 추천 직무 | EV 소프트웨어 엔지니어, 백엔드 엔지니어(EV API), 차량 에너지 모델 엔지니어 |
| 지원 방법 | chargetrip.com/careers, LinkedIn |
| 한국 채용 | 없음 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|네덜란드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
