---
tags:
  - company
  - automotive
  - country/netherlands
  - size/startup
  - automotive/telematics
  - automotive/fleet
  - fit/★★
  - recommend
country: "네덜란드"
country_folder: "10_Netherlands"
company_name: "ViriCiti (ChargePoint)"
size: "스타트업"
fit: "★★"
business: "전기버스·플릿 텔레매틱스"
hq: "(본사 위치 미확인) — 네덜란드"
---

# ViriCiti (ChargePoint)

> 전기버스·플릿 텔레매틱스 | 스타트업 | 네덜란드 🇳🇱

## 🏢 회사 개요

차량 원격 데이터 수집·분석·플릿 관리 소프트웨어 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 네덜란드 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 스타트업 |
| 주력 사업 | 전기버스·플릿 텔레매틱스 |

## 🎯 비전 & 미션

빅데이터 기반의 예측 정비, 보험, 물류 최적화로 자동차 생태계 전반을 혁신합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

커넥티드카 시장 2030년까지 연 20% 성장. 보험·물류·정비 등 다양한 수익 모델.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | 차량 데이터·통신 분야 경험 활용 가능 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★★ |
| 고졸 채용 가능성 | 급여 기준(€3,909+/월) 충족 시 학위 요건 완화 |
| 비자 정보 | Highly Skilled Migrant Visa |
| 비고 | HERE, RDW 등 비자 스폰 경험 다수. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|네덜란드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
