---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/simulation
  - automotive/testing
  - automotive/adas
  - fit/★★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Applied Intuition"
size: "중견기업"
fit: "★★★"
business: "AV·ADAS 시뮬레이션 및 SW 개발 도구"
hq: "Mountain View, California, USA"
founded: "2017"
employees: "1,300~1,500명 (2025)"
revenue: "비공개 (비상장, 기업가치 $150억)"
ipo_status: "비상장 — Series F 완료 ($6억, 2025.06), 기업가치 $150억"
korea_office: "서울 오피스 운영 중 (한국 도로교통법 특화 시나리오 제공)"
---

# Applied Intuition

> AV·ADAS 시뮬레이션 및 SW 개발 도구 | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 303 Bryant St, Mountain View, California, USA (Silicon Valley) |
| 설립 연도 | 2017 |
| 창업자 | Qasar Younis (前 YC COO), Peter Ludwig |
| 임직원 수 | 1,300~1,500명 (2025) |
| 기업가치 | **$150억 (2025.06 Series F 기준)** |
| 주요 투자자 | BlackRock, Kleiner Perkins, Andreessen Horowitz |
| 상장 여부 | **비상장** — Series F $6억 조달 완료 (2025.06) |
| 공식 홈페이지 | https://www.appliedintuition.com |
| 한국 홈페이지 | https://www.appliedintuition.com/kr |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2017 | Mountain View 창업 |
| 2021 | 글로벌 완성차 Top 20 중 18개사 고객사 확보 |
| 2023 | ISO 26262 기능안전 인증 취득 |
| 2024.03 | Series E $2.5억 조달 |
| 2024.07 | 세컨더리 라운드 $3억+ 추가 조달 |
| 2025.06 | **Series F $6억, 기업가치 $150억 달성** |
| 2026.04 | LG이노텍과 Physical AI 파트너십 체결 |

---

## 🛠️ 주력 제품 상세

| 제품명 | 설명 |
| :--- | :--- |
| **Simian** | AV·ADAS 가상 시뮬레이션 플랫폼. 한국 도로교통법 기반 시나리오 생성 포함. ISO 26262 인증. |
| **Spectral** | 센서 현실적 시뮬레이션 (카메라·LiDAR·레이더 디지털 트윈). |
| **Basis** | 시나리오 관리·분석·요구사항 추적 플랫폼. 한국경찰과학기술원 도입 사례. |
| **Vehicle OS** | SDV(소프트웨어 정의 차량)용 운영체제 및 자율주행 스택. |
| **Autonomy Stack** | 인식·판단·제어 전체 AD 소프트웨어 스택. |

---

## 🎯 전략 방향 (2024~2026)

| 분야 | 내용 |
| :--- | :--- |
| **방위·정부** | 미 국방부, 항공우주·로봇 분야로 시장 확장. "모든 움직이는 것에 자율주행"을 비전으로 제시. |
| **Physical AI** | LG이노텍 등과 로보틱스·드론까지 플랫폼 확장. |
| **한국 시장** | 서울 오피스 운영, 한국 도로 환경 맞춤 시뮬레이션, Supernal(현대차 AAM 자회사)·LG이노텍·한국경찰과학기술원 협력. |
| **일본 시장** | 2025년 일본 진출 발표. |
| **OpenAI 협력** | OpenAI와 AV용 AI 통합 파트너십. |

---

## 📈 성장성

**성장성 평가: ★★★★★**

- 2024~2025년 펀딩 $11억 이상 조달, 기업가치 2배 이상 성장.
- 글로벌 Top 20 완성차 중 18개사가 고객. 사실상 ADAS 시뮬레이션 업계 표준.
- 방위·로봇 시장까지 확장 중 — 장기 성장 다변화.
- 한국 오피스 설립 + LG이노텍·현대 계열사 협력으로 한국 시장 입지 강화 중.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | **서울 오피스 존재**. FPT Korea IVI QA 경력 + CANoe/PCAN 5년 경험이 Simian 플랫폼 검증 역할로 연결 가능. 한국 도로 기반 시뮬레이션 시나리오 QA·고객지원 업무 연결성 높음. |
| 추천 직무 | Application Engineer (Korea), Technical Solutions Engineer, AV Simulation QA |
| 한국 지사 지원 | appliedintuition.com/kr 채용 페이지 |
| 비자 스폰 가능성 | ★ (미국 본사 직접 지원 시 H-1B 추첨 필요, 학위 필수) |
| 현실적 경로 | **한국 서울 오피스 직접 지원이 현실적** |
| 고졸 채용 가능성 | 한국 지사: 경력·실무 중심이므로 가능성 있음 |

---

## 🇺🇸 USA 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| H-1B | 학위 필수 + 추첨제 (연간 쿼터 65,000개) — 고졸은 해당 없음 |
| O-1A | 탁월한 능력 입증 시 학위 불필요 — 진입 장벽 높음 |
| 비자 스폰 가능성 | ★ (저) |
| **현실적 경로** | **서울 오피스 국내 지원 강력 권장** |

---

## 🔗 관련 정보

- 홈페이지: [appliedintuition.com](https://www.appliedintuition.com)
- 한국 페이지: [appliedintuition.com/kr](https://www.appliedintuition.com/kr)
- 채용: [appliedintuition.com/careers](https://www.appliedintuition.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: appliedintuition.com, Korea Times, Forbes, FinSMEs, S&P Global, Built In SF (2026.06 기준 직접 확인)*
