---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Perrone Robotics"
size: "스타트업"
fit: "★"
business: "자율주행 SW 플랫폼 (TONY — 레거시 차량 자율화)"
hq: "Charlottesville, Virginia, USA"
founded: "2004"
employees: "~50명 미만"
revenue: "비공개 (소규모)"
ipo_status: "비상장"
korea_office: "없음"
---

# Perrone Robotics

> 자율주행 SW 플랫폼 (레거시 차량 자율화) | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Charlottesville, VA, USA |
| 설립 연도 | 2004년 |
| 창업자 | Paul Perrone |
| 임직원 수 | ~50명 미만 |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | TONY(기존 차량에 자율주행 기능 추가) SW 플랫폼, 자율주행 셔틀 |
| 공식 홈페이지 | https://www.perronerobotics.com |

**차별점:** 신규 차량 제작 없이 기존 차량(버스·골프카트·산업차)에 자율주행 소프트웨어 키트를 적용하는 레트로핏 방식.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 미국 남동부 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 틈새 시장 특화(레거시 차량 자율화). 대규모 성장은 어려움.
- 소규모 지역 운영 특화.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 매우 소규모 스타트업. 재정 불안정성 높음. |
| 추천 직무 | Robotics SW Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 경험 우선 가능성 있음 (소규모 특성) |

---

## 🔗 관련 정보

- 홈페이지: [perronerobotics.com](https://www.perronerobotics.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: perronerobotics.com 공식, LinkedIn (2026.05 기준)*
