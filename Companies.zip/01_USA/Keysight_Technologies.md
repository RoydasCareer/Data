---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/testing
  - automotive/qa
  - fit/★★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Keysight Technologies"
size: "대기업"
fit: "★★★"
business: "자동차 통신·전장 테스팅 솔루션"
hq: "Santa Rosa, California, USA"
---

# Keysight Technologies

> 자동차 통신·전장 테스팅 솔루션 | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

Keysight Technologies는 전자 측정 장비 및 소프트웨어의 세계적 선두 기업입니다. 자동차 분야에서 V2X 통신 테스팅, 자동차 이더넷 테스팅, ADAS 레이더/카메라 테스팅 솔루션을 제공합니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Santa Rosa, California, USA |
| 설립 연도 | 2014 |
| 임직원 수 | ~14,000명 |
| 규모 분류 | 대기업 |
| 주력 사업 | 자동차 통신·전장 테스팅 솔루션 |

## 🎯 비전 & 미션

"측정의 힘으로 기술 혁신을 가속화한다." 자동차 전장화·전기화·자율주행 전환의 핵심 테스팅 파트너.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★★**

- 5G-V2X 테스팅: 5G C-V2X 표준화에 따른 테스팅 장비 수요 급증
- 자동차 이더넷 테스팅: DoIP, 100BASE-T1 등 이더넷 기반 자동차 통신 검증 도구 성장
- ADAS 검증: 레이더·카메라 성능 테스팅 자동화 솔루션

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 추천 이유 | 자동차 통신 프로토콜(DoIP, CAN, V2X) 테스팅 경험 직결. 싱가포르 법인 포함 아태지역 채용도 활발. |
| 추천 직무 | Automotive Test Engineer, V2X Protocol Test Engineer, RF/Communication Test Engineer |
| 비자 스폰 가능성 | ★ |
| 고졸 채용 가능성 | 국가별 상이 |
| 비자 정보 | 취업 비자 (국가별 상이) |
| 비고 | 해당 국가 대사관 또는 채용 공고 확인 필요. |

---

## 🔗 관련 정보

- 홈페이지: [keysight.com](https://keysight.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
