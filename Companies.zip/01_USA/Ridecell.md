---
tags:
  - company
  - automotive
  - country/usa
  - size/small
  - automotive/fleet
  - automotive/software
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Ridecell"
size: "중소기업"
fit: "★"
business: "플릿 자동화·카셰어링 SW 플랫폼"
hq: "San Jose, California, USA"
founded: "2009"
employees: "~150명 (2024)"
revenue: "비공개 (시리즈 C $92M 조달)"
ipo_status: "비상장"
korea_office: "없음"
---

# Ridecell

> 플릿 자동화·카셰어링 SW 플랫폼 | 중소기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | San Jose, CA, USA |
| 설립 연도 | 2009년 |
| 창업자 | Aarjav Trivedi |
| 임직원 수 | ~150명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 (시리즈 C, $92M 조달) |
| 주력 사업 | 카셰어링·라이드헤일·플릿 운영 자동화 SaaS 플랫폼 (예약, 요금, 유지보수, 충전 통합) |
| 공식 홈페이지 | https://ridecell.com |

**주요 고객:** SIXT, 현대캐피탈, BMW Group (DriveNow 계열)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 유럽·북미 카셰어링 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 카셰어링 SW 플랫폼으로 OEM·렌터카 기업 고객 다수.
- 소규모 기업으로 재무 불확실성 있음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 스타트업. 자동차 SW보다 SaaS 플랫폼 개발 중심. |
| 추천 직무 | Backend SW Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [ridecell.com](https://ridecell.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: ridecell.com 공식, LinkedIn (2026.05 기준)*
