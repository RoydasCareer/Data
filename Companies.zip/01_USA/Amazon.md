---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Amazon (Zoox)"
size: "대기업"
fit: "★"
business: "자율주행 라이드헤일링 로보택시 (Zoox)"
hq: "Foster City, California, USA (Zoox)"
founded: "2014 (Zoox) / 1994 (Amazon)"
employees: "Zoox ~2,000명 / Amazon ~1,500,000명"
revenue: "$574.8B (Amazon 2023)"
ipo_status: "NASDAQ: AMZN"
korea_office: "아마존코리아(유) — 서울 강남구 (클라우드/이커머스, Zoox 무관)"
---

# Amazon (Zoox)

> 자율주행 라이드헬링 로보택시 | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| Zoox 본사 | 1400 Bridge Pkwy, Foster City, CA 94404, USA |
| Amazon 본사 | 410 Terry Ave N, Seattle, WA 98109, USA |
| 설립 연도 | Zoox 2014년 / Amazon 1994년 |
| 임직원 수 | Zoox ~2,000명 / Amazon 전체 ~1,525,000명 |
| 규모 분류 | 대기업 (Amazon 100% 자회사) |
| 연매출 | $574.8B (Amazon 2023) |
| 상장 여부 | **NASDAQ: AMZN** |
| 주력 사업 | 자율주행 로보택시(Zoox), 클라우드(AWS), 이커머스 |
| 공식 홈페이지 | https://zoox.com |

### Zoox 개요

Amazon이 2020년 $1.2B에 인수한 자율주행 로보택시 스타트업. 기존 차량 개조 없이 처음부터 로보택시 전용으로 설계된 양방향 주행 차량 개발 중. 라이다·레이더·카메라 기반 레벨 5 자율주행 목표.

---

## 🇰🇷 한국 관련

| 항목 | 내용 |
| :--- | :--- |
| Zoox 한국 사무소 | **없음** |
| 아마존코리아 | AWS Korea(클라우드), 이커머스 사업 위주 — Zoox와 무관 |
| 한국 풀리모트 | 불가 (Zoox는 Foster City 집중) |

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- **레벨 5 로보택시**: 규제 승인 후 라스베이거스 시범 운행 중.
- **Amazon 물류 시너지**: 마지막 마일 배송 자동화와의 연계 가능성.
- **단기 상용화 불확실**: 규제·안전 검증에 수년 소요 예상.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | Zoox는 Foster City 집중 운영, 한국 원격근무 불가. 자율주행 SW 엔지니어 포지션은 미국 현지 취업 비자 필요. Amazon Korea는 클라우드/이커머스 직군만. |
| 추천 직무 | Autonomy Software Engineer, Perception Engineer (Zoox 미국 한정) |
| 한국 지원 경로 | 없음 (Zoox) / Amazon Korea는 클라우드/비즈니스 직군 |
| 비자 스폰 가능성 | ★★ — Amazon 그룹 차원 H-1B 스폰 가능 |
| 고졸 채용 가능성 | Zoox: 학위 선호. Amazon Korea: 상황에 따라 다름. |

---

## 🔗 관련 정보

- Zoox: [zoox.com](https://zoox.com)
- 채용: [zoox.com/careers](https://zoox.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: zoox.com 공식, amazon.com (2026.05 기준)*
