---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/ivi
  - automotive/hmi
  - fit/★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Harman International (Samsung)"
size: "대기업"
fit: "★★"
business: "커넥티드카·인포테인먼트·자동차 SW"
hq: "(본사 위치 미확인) — 미국"
---

# Harman International (Samsung)

> 커넥티드카·인포테인먼트·자동차 SW | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

차내 인포테인먼트(IVI) 및 HMI 소프트웨어 플랫폼 개발 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 미국 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 대기업 |
| 주력 사업 | 커넥티드카·인포테인먼트·자동차 SW |

## 🎯 비전 & 미션

자동차를 '바퀴 달린 스마트폰'으로 전환하는 디지털 콕핏 혁신을 주도합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

OEM들의 SDV 전환으로 IVI SW 내재화 가속. Apple CarPlay·Android Auto 연계 서비스 확대.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | IVI SW 버전 검증·회귀 테스트 경험 직결 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★ |
| 고졸 채용 가능성 | 국가별 상이 |
| 비자 정보 | 취업 비자 (국가별 상이) |
| 비고 | 해당 국가 대사관 또는 채용 공고 확인 필요. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
