---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/autonomous
  - automotive/adas
  - automotive/software
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "General Motors (Cruise)"
size: "대기업"
fit: "★"
business: "자율주행 차량 SW (Cruise) / 전기차 (Ultium)"
hq: "Detroit, Michigan, USA"
founded: "1908"
employees: "~163,000명 (2023)"
revenue: "$171.8B (2023)"
ipo_status: "NYSE: GM"
korea_office: "한국GM(주) — 인천 부평구 (제조 법인) / SW 채용 없음"
---

# General Motors (Cruise)

> 자율주행 차량 SW (Cruise) / 전기차 (Ultium) | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 300 Renaissance Center, Detroit, MI 48243, USA |
| 설립 연도 | 1908년 9월 16일 |
| 임직원 수 | ~163,000명 (2023 기준) |
| 규모 분류 | 대기업 |
| 연매출 | **$171.8B (2023)** — 영업이익 $10.0B |
| 상장 여부 | **NYSE: GM** |
| 주력 사업 | Chevrolet·GMC·Cadillac·Buick 브랜드 차량, Ultium EV 플랫폼, Cruise 자율주행 |
| 공식 홈페이지 | https://www.gm.com |

### Cruise (자율주행 자회사)

| 항목 | 내용 |
| :--- | :--- |
| 인수 | 2016년 ($1B) |
| 본사 | 샌프란시스코, 캘리포니아 |
| 현황 | 2023년 10월 로보택시 사고 후 서비스 중단 → 2024년 대규모 구조조정 |
| 현재 | 자율주행 기술 GM 내재화 진행 중 |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 1908 | 창업 (디트로이트) |
| 1984 | 한국GM 전신 대우자동차와 합작 시작 |
| 2002 | **한국GM(주) 설립** (대우자동차 인수) — 인천 부평 |
| 2016 | Cruise 인수 ($1B) |
| 2021 | Honda, Microsoft 등 Cruise에 추가 투자 |
| 2023 | Cruise 로보택시 사고 → 서비스 중단, CEO 사임 |
| 2024 | Cruise 직원 1,000명+ 감원. GM이 자율주행 직접 내재화 |

---

## 🇰🇷 한국 법인 — 한국GM(주)

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | 한국GM(주) |
| 주소 | 인천광역시 부평구 (본공장) + 창원·군산 공장 |
| 주요 업무 | 차량 제조 (트레일블레이저, 스파크 등 수출 생산) |
| 임직원 수 | ~11,000명 (2023) |
| 비고 | **제조 법인** — 자율주행/SW 엔지니어링 포지션 없음 |

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- **Ultium EV 플랫폼**: 모든 GM 브랜드 EV를 통합하는 차세대 플랫폼. 2025~2030년 핵심 성장동력.
- **Cruise 리부트**: 사고 후 구조조정 완료. GM 주도로 자율주행 재개 예정.
- **한국GM**: 수출 물량 안정적. 부평 공장 유지.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국GM은 제조 법인 — SW 엔지니어링 직무 없음. Cruise/GM 본사(미국)의 자율주행 엔지니어링은 현재 구조조정 여파로 채용 축소 중. 단기 지원 우선순위 낮음. |
| 추천 직무 | Software Engineer (Autonomy) — 미국 본사 한정. 한국은 제조·생산 직군만. |
| 한국 지사 지원 | 한국GM 채용: 생산직/관리직 위주 |
| 비자 스폰 가능성 (미국 본사) | ★ — 현재 구조조정 중으로 채용 축소 |
| 고졸 채용 가능성 | 한국GM: 생산직 가능. 미국 SW: 학위 필수. |

---

## 🔗 관련 정보

- 홈페이지: [gm.com](https://www.gm.com)
- 한국GM: [gm-korea.co.kr](https://www.gm-korea.co.kr)
- 채용: [gm.com/careers](https://www.gm.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: gm.com 공식, gm-korea.co.kr, 뉴스 (2026.05 기준)*
