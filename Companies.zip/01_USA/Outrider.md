---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Outrider"
size: "스타트업"
fit: "★"
business: "자율주행 야드 트럭 SW (창고·물류 야드 자동화)"
hq: "Louisville, Colorado, USA"
founded: "2018"
employees: "~200명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Outrider

> 자율주행 야드 트럭 SW | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Louisville, CO 80027, USA |
| 설립 연도 | 2018년 |
| 창업자 | Andrew Smith |
| 임직원 수 | ~200명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 (Amazon Investment, UPS Ventures 투자) |
| 주력 사업 | 물류 야드(창고 주차장) 내 자율주행 야드 트럭 SW — 트레일러 연결·이동·주차 자동화 |
| 공식 홈페이지 | https://www.outrider.ai |

**차별점:** 공도가 아닌 야드(사유지) 내에서만 운행 → 규제 리스크 최소화.

**투자자:** Amazon, UPS, FedEx 계열

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미 물류 야드 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- Amazon·UPS 투자로 안정적 파트너십.
- 야드 내 자율주행으로 규제 리스크 낮아 상용화 빠름.
- 소규모 스타트업, 재무 불확실성 있음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 물류 야드 특화로 자동차 SW 분야와 연관성 낮음. |
| 추천 직무 | Robotics SW Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — H-1B 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [outrider.ai](https://www.outrider.ai)
- 채용: [outrider.ai/careers](https://www.outrider.ai/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: outrider.ai 공식 (2026.05 기준)*
