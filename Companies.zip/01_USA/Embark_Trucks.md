---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - fit/
country: "미국"
country_folder: "01_USA"
company_name: "Embark Trucks"
size: "스타트업"
fit: ""
business: "⚠️ 2023년 3월 폐업 (자율주행 트럭)"
hq: "San Francisco, California, USA (폐업)"
founded: "2016"
employees: "0 (폐업)"
revenue: "폐업"
ipo_status: "NASDAQ: EMBK (상장폐지)"
korea_office: "없음 (폐업)"
---

# Embark Trucks

> ⚠️ 2023년 3월 폐업 — 지원 불가

## ⚠️ 폐업 안내

**Embark Trucks는 2023년 3월 공식 폐업했습니다.** NASDAQ 상장폐지 완료. 직원 전원 해고. 지적재산권 및 자산 매각.

| 항목 | 내용 |
| :--- | :--- |
| 설립 | 2016년 (YC 2017 배치) |
| 폐업 | **2023년 3월** |
| 원인 | 자금 조달 실패, 자율주행 상용화 지연, SPAC 상장 후 주가 급락 |
| 창업자 | Alex Rodrigues, Brandon Moak |
| 이후 | 기술/특허 일부 다른 AV 기업에 매각 |

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | — |
| 핵심 추천 이유 | **폐업 기업 — 지원 불가** |
| 추천 직무 | — |
| 한국 지원 경로 | — |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: 뉴스 (2023.03 폐업 확인)*
