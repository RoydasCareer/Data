---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Motive (KeepTruckin)"
size: "대기업"
fit: "★"
business: "AI 기반 플릿 관리·안전 플랫폼"
hq: "San Francisco, California, USA"
founded: "2013"
employees: "~4,000명 (2024, 파키스탄 포함)"
revenue: "~$700M ARR (2024 추정)"
ipo_status: "비상장 (기업가치 $2.3B)"
korea_office: "없음"
---

# Motive (KeepTruckin)

> AI 기반 플릿 관리·안전 플랫폼 | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 400 Alabama St, San Francisco, CA 94110, USA |
| 설립 연도 | 2013년 (KeepTruckin으로 시작 → 2022년 Motive로 사명 변경) |
| 창업자 | Shoaib Makani, Ryan Johns |
| 임직원 수 | ~4,000명 (미국 + 파키스탄 라호르 엔지니어링 허브) |
| 규모 분류 | 대기업 (비상장) |
| ARR | ~$700M (2024 추정) |
| 기업가치 | $2.3B (2022년 시리즈 F 기준) |
| 상장 여부 | 비상장 |
| 주력 사업 | 상용 차량 ELD(전자식 운행기록), 대시캠 AI, 플릿 추적, 차량 정비 관리 |
| 공식 홈페이지 | https://gomotive.com |

**주요 고객:** Halliburton, Dollar General, Werner Enterprises 등 대형 상용차 운영사

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미 상용차 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- 미국 상용차 ELD 의무화로 시장 폭발적 성장.
- AI 대시캠·운전자 안전 분석으로 보험사·물류사 대상 SaaS 확장.
- 파키스탄 엔지니어링 허브로 비용 효율 확보.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 상용차 플릿 관리 특화 — 자동차 SW 배경과 직접 연관 낮음. 북미 집중. |
| 추천 직무 | Software Engineer (플릿 IoT/AI) — 미국 현지 또는 파키스탄 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 한국 기반 채용 없음 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [gomotive.com](https://gomotive.com)
- 채용: [gomotive.com/careers](https://gomotive.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: gomotive.com 공식, Crunchbase (2026.05 기준)*
