---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - fit/
country: "미국"
country_folder: "01_USA"
company_name: "Ghost Autonomy"
size: "스타트업"
fit: ""
business: "⚠️ 2024년 Apple 인수 후 독립 종료"
hq: "Mountain View, California, USA (독립 종료)"
founded: "2017"
employees: "0 (인수 후 독립 종료)"
revenue: "비공개"
ipo_status: "비상장 (인수됨)"
korea_office: "없음"
---

# Ghost Autonomy

> ⚠️ 2024년 Apple에 인수 — 독립 기업 아님

## ⚠️ 인수 안내

**Ghost Autonomy는 2024년 초 Apple에 인수되었습니다.** 팀 대부분이 Apple Special Projects Group(자율주행 프로젝트)으로 흡수. 독립 법인으로서의 채용 없음.

| 항목 | 내용 |
| :--- | :--- |
| 설립 | 2017년 |
| 인수 | **2024년 초, Apple Inc.** |
| 창업자 | John Hayes, Rubin Ortiz |
| 기술 | 고속도로 ADAS·자율주행 SW (카메라 기반) |
| 이후 | Apple 자율주행 팀에 통합 |

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | — |
| 핵심 추천 이유 | **Apple에 인수 — 독립 채용 불가. Apple Special Projects 채용 페이지 참고.** |
| 추천 직무 | — (Apple을 통해 채용) |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: 뉴스 (2024 Apple 인수 확인)*
