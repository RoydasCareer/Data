---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/software
  - automotive/mobility
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Urgently"
size: "스타트업"
fit: "★"
business: "AI 긴급출동·로드사이드 지원 플랫폼 (Otonomo 합병)"
hq: "Arlington, Virginia, USA"
founded: "2013"
employees: "~200명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (2023년 Otonomo와 합병)"
korea_office: "없음"
---

# Urgently

> AI 긴급출동·로드사이드 지원 플랫폼 | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Arlington, VA, USA |
| 설립 연도 | 2013년 |
| 창업자 | Anthony Eaton |
| 임직원 수 | ~200명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 (2023년 Otonomo Technologies 합병) |
| 주력 사업 | AI 기반 로드사이드 어시스턴스 플랫폼 — 긴급출동 네트워크 연결, OEM·보험사·딜러에 API 제공 |
| 공식 홈페이지 | https://www.geturgently.com |

**주요 고객:** AAA, Agero, BMW, GM, Ford (OEM 로드사이드 서비스 API)
**합병:** 2023년 이스라엘 커넥티드카 데이터 기업 Otonomo와 합병

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·유럽 보험·OEM 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 로드사이드 어시스턴스 디지털화 수혜.
- Otonomo 합병으로 커넥티드카 데이터 역량 추가.
- 소규모 스타트업, 재무 압박 있음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 긴급출동 플랫폼 특화 — 자동차 SW 엔지니어링과 직접 연관 낮음. |
| 추천 직무 | Backend Platform Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [geturgently.com](https://www.geturgently.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: geturgently.com 공식, 뉴스 (2026.05 기준)*
