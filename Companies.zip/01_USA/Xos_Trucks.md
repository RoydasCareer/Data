---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/ev
  - automotive/commercial
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Xos Trucks"
size: "스타트업"
fit: "★"
business: "전기 중형·대형 트럭 제조 및 플릿 SW"
hq: "Los Angeles, California, USA"
founded: "2020"
employees: "~300명 (2024)"
revenue: "$26M (FY2023)"
ipo_status: "NASDAQ: XOS (2021 SPAC 상장, 2024 상장폐지 위기)"
korea_office: "없음"
---

# Xos Trucks

> 전기 중형·대형 트럭 | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Los Angeles, CA, USA |
| 설립 연도 | 2020년 (前 Thor Trucks, 2016년 창업) |
| 창업자 | Dakota Semler, Giordano Sordoni |
| 임직원 수 | ~300명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | NASDAQ: XOS (2021년 SPAC 상장 — 상장 후 재무 어려움) |
| 주력 사업 | 클래스 5–8 전기트럭 제조 및 Xosphere™ 플릿 관리 SW |
| 공식 홈페이지 | https://xostrucks.com |

**주요 고객:** FedEx, Loomis, Aramark (라스트마일 배송·서비스 차량)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미 상용차 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 상용 EV 수요 증가 수혜. FedEx 등 대형 물류 고객 확보.
- 재무 압박 심각 — 2023~2024년 현금 소진 우려, 상장폐지 위기.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 재무 불안정성 매우 높음. 상장폐지 리스크 있음. |
| 추천 직무 | Vehicle SW Engineer / Embedded — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 재무 불안정으로 불확실 |
| 고졸 채용 가능성 | 경험 우선 가능성 (소규모 특성) |

---

## 🔗 관련 정보

- 홈페이지: [xostrucks.com](https://xostrucks.com)
- 채용: [xostrucks.com/careers](https://xostrucks.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: xostrucks.com 공식, NASDAQ (2026.05 기준)*
