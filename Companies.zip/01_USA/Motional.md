---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/autonomous
  - automotive/robotaxi
  - fit/★★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Motional (Hyundai 주도 AV JV)"
size: "중견기업"
fit: "★★★"
business: "Level 4 자율주행 로보택시 기술 개발"
hq: "Boston, Massachusetts, USA (Seaport District)"
founded: "2020"
employees: "~950명 (2025~2026)"
revenue: "비공개 (비상장)"
ipo_status: "비상장 — Hyundai Motor Group 지분 ~66.8% 보유 (2024.05 이후 사실상 현대차 자회사)"
korea_office: "별도 한국 법인 없음 (현대차그룹 채널 통해 접근 가능)"
---

# Motional (Hyundai 주도 AV JV)

> Level 4 자율주행 로보택시 기술 개발 | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Boston, Massachusetts, USA (Seaport District) |
| 추가 오피스 | Pittsburgh, PA / Las Vegas, NV / Singapore |
| 설립 연도 | 2020 (Hyundai-Aptiv JV로 출범) |
| 원 창립 모체 | nuTonomy (MIT 스핀오프) → Aptiv 인수 → Motional 설립 |
| 주주 구조 | **현대차그룹 ~66.8%**, Aptiv ~15%, 기타 |
| 임직원 수 | ~950명 (2025~2026, 2023년 1,463명 대비 대규모 구조조정 후) |
| 총 투자 유치 | $7.9억 (3라운드 기준, 2025.10 Series B 클로징) |
| 현대차 누적 투자 | **~$10억 이상** (2024년 $4.75억 + 지분 추가 매입 $4.48억) |
| 상장 여부 | **비상장** |
| 공식 홈페이지 | https://motional.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2017 | nuTonomy (MIT 스핀오프 AV 스타트업) Aptiv에 인수 |
| 2020 | **Hyundai Motor Group + Aptiv 50:50 JV "Motional" 설립** ($40억 합작) |
| 2021 | **IONIQ 5 로보택시** 공개 (세계 최초 완전 전기 L4 로보택시) |
| 2022 | Las Vegas Lyft 파트너십 자율주행 라이드헤일 서비스 시범 |
| 2024.02 | **550명 해고 (~40% 인력 감축), 상업 운영 일시 중단** |
| 2024.05 | **현대차그룹 $10억 투자 + Aptiv 지분 추가 매입 → 현대차 ~66.8% 대주주 확정** |
| 2025.10 | Series B 펀딩 클로징 |
| 2026.03 | **Las Vegas Uber 앱 통한 로보택시 영업 운행 재개** (안전요원 탑승 단계) |
| 2026말 | **완전 무인 상업 로보택시 출시 목표 (Las Vegas)** |

---

## 🛠️ 주력 제품 상세

| 제품명/기술 | 설명 |
| :--- | :--- |
| **IONIQ 5 Robotaxi** | 현대차 IONIQ 5 기반 SAE Level 4 완전 자율주행 전기 로보택시. 미 연방 차량 안전 인증 획득. Uber 플랫폼 연동. |
| **AV 기술 스택** | 인식·예측·계획·제어 전 계층. 규칙 기반 → **엔드투엔드 머신러닝** 전환 중 (2024~). |
| **AV 플랫폼** | OEM 독립형 자율주행 소프트웨어 플랫폼 — 현대차 SDV 로드맵 통합 예정. |
| **데이터·시뮬레이션** | 실도로 데이터 수집 + 가상 시뮬레이션 병행 검증 체계. |

---

## 🎯 전략 방향 (2024~2026)

| 분야 | 내용 |
| :--- | :--- |
| **현대차 통합** | Aptiv 후퇴 후 현대차그룹 사실상 단독 스폰서. Motional AV 기술 → 현대차 SDV 로드맵 통합. |
| **Las Vegas 상용화** | 2026말 완전 무인 로보택시 상용화 1호 도시. Uber 파트너십. |
| **ML 전환** | 규칙 기반 시스템 → 엔드투엔드 딥러닝으로 기술 패러다임 전환 (Waymo 벤치마킹). |
| **비용 절감** | 2024년 대규모 구조조정 이후 핵심 AV 기술 R&D 집중, 비핵심 사업 정리. |
| **현대차 계열 시너지** | Supernal(AAM), 현대차 자율주행 사업부와 기술 공유 기대. |

---

## 📈 성장성

**성장성 평가: ★★★☆☆**

- 현대차그룹 ~66.8% 대주주 확정 → 안정적 자금 공급원 확보.
- 2026년 Las Vegas 상업 운행 성공 시 전국·글로벌 확장 가속.
- 대규모 구조조정(2024) 이후 집중 R&D로 기술 경쟁력 재정비 중.
- Waymo·Cruise 등 경쟁사 대비 시장 진입 다소 늦음. 기술 검증이 관건.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | **현대차그룹 ~66.8% 대주주** — 현대차·기아·현대모비스 채널 통해 국내 지원 경로 존재. JLR DoIP 실차 경험 + CANoe 5년+ 기술이 IONIQ 5 로보택시 차량 통신 시스템 검증에 직접 연결. IVI QA 경력은 Motional AV 플랫폼 HMI 검증에 활용 가능. |
| 추천 직무 | AV Systems QA Engineer, Vehicle Integration Engineer, Automotive Diagnostics Engineer |
| 지원 경로 | motional.com/careers 직접 지원 또는 현대차그룹 계열사 내부 이동 |
| 비자 스폰 가능성 | ★ (미국 직접 지원 시) |
| **현실적 경로** | **현대차·현대모비스 국내 채용 후 Motional 파견·협력 프로젝트 참여가 가장 현실적** |
| 고졸 채용 가능성 | 현대차 계열 채용 경로: 기술직 경력 중심이면 고졸 가능. 미국 본사 직접: 낮음. |

---

## 🇺🇸 USA 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| H-1B | 학위 필수 + 추첨제 (연간 쿼터 65,000개) — 고졸은 해당 없음 |
| O-1A | 탁월한 능력 입증 시 학위 불필요 — 진입 장벽 높음 |
| 비자 스폰 가능성 | ★ (저) |
| **현실적 경로** | 현대차그룹 계열사 → Motional 프로젝트 파견 경로가 현실적 |

---

## 🔗 관련 정보

- 홈페이지: [motional.com](https://motional.com)
- 로보택시 정보: [motional.com/who-we-are](https://motional.com/who-we-are)
- 채용: [motional.com/careers](https://motional.com/careers)
- 현대차 연결: [[../08_Korea/Hyundai_Mobis|현대모비스]]
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Wikipedia (Motional), motional.com, Hyundai Newsroom, electrive.com, S&P Global AutoTech, KED Global, Business Insider, The Robot Report (2026.06 기준 직접 확인)*
