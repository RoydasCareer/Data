---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/adas
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Pronto.ai"
size: "스타트업"
fit: "★"
business: "상용 트럭 고속도로 자율주행 보조 시스템 (Co-Pilot)"
hq: "San Francisco, California, USA"
founded: "2018"
employees: "~100명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Pronto.ai

> 상용 트럭 고속도로 자율주행 보조 시스템 | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | San Francisco, CA, USA |
| 설립 연도 | 2018년 |
| 창업자 | Anthony Levandowski (前 Waymo), Lior Ron |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 상용 트럭 고속도로 ADAS(Co-Pilot) — 레인 킵, ACC, 전방 충돌 경고. 기존 트럭에 레트로핏. |
| 공식 홈페이지 | https://pronto.ai |

> **창업자 Anthony Levandowski는 구글 자율주행 기술 절도 사건으로 유죄 판결 후 사면(2021). 회사는 계속 운영 중.**

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 레트로핏 방식 ADAS로 진입 장벽 낮음.
- 창업자 리스크 및 소규모 스타트업으로 불확실성 높음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 스타트업. 창업자 논란으로 기업 리스크 존재. |
| 추천 직무 | ADAS SW Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모, 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [pronto.ai](https://pronto.ai)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: pronto.ai 공식, 뉴스 (2026.05 기준)*
