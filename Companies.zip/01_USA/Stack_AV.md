---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - fit/★★
country: "미국"
country_folder: "01_USA"
company_name: "Stack AV"
size: "스타트업"
fit: "★★"
business: "자율주행 장거리 트럭 SW 플랫폼"
hq: "Pittsburgh, Pennsylvania — 미국"
founded: "2022"
last_updated: "2026-06-24"
fact_checked: "2026-06-24"
---

# Stack AV

> 자율주행 장거리 트럭 SW 플랫폼 | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

Argo AI 폐업(2022) 이후 전 Ford 자율주행 핵심 임원들이 창업한 자율주행 트럭 전문 스타트업. SoftBank의 단독 $10억 투자를 유치하며 자율주행 물류 분야의 핵심 플레이어로 부상.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Pittsburgh, Pennsylvania — 미국 |
| 설립 연도 | 2022 (법인 설립), 2023 공식 런칭 |
| 규모 분류 | 스타트업 |
| 주력 사업 | 자율주행 장거리 트럭 SW 플랫폼 |
| 총 투자 유치 | $10억 이상 (SoftBank 단독) |
| 원래 사명 | Eva AV → Stack AV (2023년 7월 리브랜딩) |

## 🎯 비전 & 미션

AI 기술로 장거리 화물 운송을 완전 자동화하여 물류 산업의 구조적 효율성 혁신. 인력 부족과 안전 문제를 동시에 해결하는 것이 목표.

## 🔑 핵심 기술 & 제품

- **자율주행 트럭 SW 스택**: 고속도로 장거리 운송 전용
- **AI 기반 경로 계획 및 의사결정**: SoftBank AI 리소스 활용
- **전 Argo AI 기술 인력** 다수 흡수 — 빠른 기술 성숙

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

자율주행 트럭 시장은 규제 환경이 승용차 대비 단순하고, 고속도로 운행 특성상 기술 난도가 낮아 상업화 속도가 빠름. SoftBank의 $10억 단독 투자는 전략적 확신의 표현.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | 자율주행 SW QA·검증 포지션, ADAS 테스팅 경력 활용 |
| 추천 직무 | SW 테스팅 엔지니어, 자율주행 시스템 검증, 시뮬레이션 QA |
| 비자 스폰 가능성 | ★ (H-1B 추첨제 — 매우 어려움) |
| 고졸 채용 가능성 | 스타트업 특성상 실무 역량 중심이나 비자 장벽이 현실적 한계 |
| 비자 정보 | H-1B (학사 필수·추첨제) — 직접 취업 매우 어려움 |
| 비고 | 자율주행 트럭 SW 검증 포지션은 CAN/UDS 경력 직접 활용 가능. 단 H-1B 장벽 높음. |

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
- 관련 기업: [[Waabi_Innovation|Waabi Innovation]], [[Kodiak_Robotics|Kodiak Robotics]], [[Torc_Robotics|Torc Robotics]]
