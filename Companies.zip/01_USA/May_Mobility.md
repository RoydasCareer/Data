---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "May Mobility"
size: "중견기업"
fit: "★"
business: "자율주행 셔틀·마이크로트랜짓 SW (Multi-Policy Decision Making)"
hq: "Ann Arbor, Michigan, USA"
founded: "2017"
employees: "~400명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# May Mobility

> 자율주행 셔틀·마이크로트랜짓 SW | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 330 E Liberty St, Ann Arbor, MI 48104, USA |
| 설립 연도 | 2017년 |
| 창업자 | Edwin Olson, Tim Oates, Steve Vozar (미시간 대학교 교수진 출신) |
| 임직원 수 | ~400명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 도심·캠퍼스·공항 내 자율주행 셔틀 서비스, Multi-Policy Decision Making(MPDM) 자율주행 SW |
| 공식 홈페이지 | https://maymobility.com |

**파트너:** Toyota(투자·차량 공급), USAA, 현대차 Supernal, 아부다비 운영 계약

**운영 지역:** 미국(미시간·피닉스·조지아·노스캐롤라이나), 일본(도요타 소재지), 아부다비

---

## 🇰🇷 한국 관련

한국 사무소 없음. 미국·일본·UAE 집중 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- Toyota 투자 및 차량 공급 계약으로 안정적 파트너십.
- 아부다비 첫 해외 계약으로 글로벌 확장 시작.
- 수익화 초기 단계, 재무 불확실성 있음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 미국 미시간 집중. 자율주행 셔틀 특화라 차량 SW 연관성 있으나 현지 거주 필수. |
| 추천 직무 | Autonomy SW Engineer, Simulation Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — H-1B 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [maymobility.com](https://maymobility.com)
- 채용: [maymobility.com/careers](https://maymobility.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: maymobility.com 공식 (2026.05 기준)*
