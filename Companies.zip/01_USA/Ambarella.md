---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/adas
  - automotive/sensing
  - fit/★★
country: "미국"
country_folder: "01_USA"
company_name: "Ambarella"
size: "중견기업"
fit: "★★"
business: "자동차 비전 AI SoC (CV3·CV5 시리즈)"
hq: "Santa Clara, California, USA"
founded: "2004"
employees: "~800명 (2024)"
revenue: "$273M (FY2024)"
ipo_status: "NASDAQ: AMBA"
korea_office: "한국 영업 거점 (정식 법인 미확인 — 삼성·SK Hynix·현대차 고객 대응)"
---

# Ambarella

> 자동차 비전 AI SoC | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 3975 Freedom Cir, Santa Clara, CA 95054, USA |
| 설립 연도 | 2004년 |
| 창업자 | Fermi Wang, Les Kohn |
| 임직원 수 | ~800명 (2024 기준) |
| 규모 분류 | 중견기업 |
| 연매출 | **$273M (FY2024)** |
| 상장 여부 | **NASDAQ: AMBA** |
| 주력 사업 | 자동차 ADAS용 AI 비전 SoC, 보안 카메라 SoC, IoT 영상 AI SoC |
| 공식 홈페이지 | https://www.ambarella.com |

### 주요 제품 — 자동차 부문

| 제품 | 설명 |
| :--- | :--- |
| **CV3** | 차량용 AI 중앙컴퓨팅 SoC. 아이시클 아키텍처. L2+ ADAS 최적화. |
| **CV5** | 고성능 자동차 비전 AI SoC. 서라운드뷰·360도 카메라 처리. |
| **CV2x** | 전방 카메라용 ADAS SoC. ISO 26262 ASIL-B/D 인증. |

**주요 고객:** 현대/기아, Bosch, 콘티넨탈, ZF, 스바루 등

---

## 🇰🇷 한국 관련

| 항목 | 내용 |
| :--- | :--- |
| 한국 법인 | 정식 법인 여부 미확인 (현지 직원 또는 대리점 형태 가능) |
| 주요 한국 파트너 | **현대자동차·기아** (ADAS 카메라 SoC), 삼성파운드리 (위탁 생산) |
| 채용 방법 | ambarella.com 채용 페이지 → 한국 또는 아시아 영업직 확인 |

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- **현대/기아 공급**: 국내 최대 OEM에 ADAS SoC 직접 공급.
- **AI 비전 SoC 전문**: GPU 없이 저전력 AI 추론에 강점.
- **보안카메라→자동차 전환**: 자동차 매출 비중 확대 중.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 현대/기아 ADAS 카메라 SoC 공급사. 한국 고객 대응 영업/FAE 포지션 가능성 있음. 자동차 카메라·인식 SW 배경과 연관성 높음. |
| 추천 직무 | Field Application Engineer (Automotive), Software Engineer (Automotive) |
| 한국 지원 경로 | ambarella.com 채용 페이지 또는 LinkedIn |
| 비자 스폰 가능성 (미국 본사) | ★★ — H-1B 스폰 가능 |
| 고졸 채용 가능성 | 학위 선호 (EE/CS) |

---

## 🔗 관련 정보

- 홈페이지: [ambarella.com](https://www.ambarella.com)
- 자동차: [ambarella.com/automotive](https://www.ambarella.com/automotive/)
- 채용: [ambarella.com/company/careers](https://www.ambarella.com/company/careers/)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: ambarella.com 공식, NASDAQ 공시, 뉴스 (2026.05 기준)*
