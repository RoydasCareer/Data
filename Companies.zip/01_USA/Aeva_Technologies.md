---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/adas
  - automotive/sensing
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Aeva Technologies"
size: "스타트업"
fit: "★"
business: "4D LiDAR 센서·인식 SW (FMCW 방식)"
hq: "Mountain View, California, USA"
founded: "2017"
employees: "~230명 (2024)"
revenue: "비공개 (수익화 초기)"
ipo_status: "NYSE: AEVA (SPAC 2021)"
korea_office: "없음 (현대차그룹 투자 파트너)"
---

# Aeva Technologies

> 4D LiDAR 센서·인식 SW (FMCW 방식) | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Mountain View, CA, USA |
| 설립 연도 | 2017년 (前 Apple 엔지니어 창업) |
| 창업자 | Soroush Salehian, Mina Rezk (Apple 출신) |
| 임직원 수 | ~230명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | **NYSE: AEVA** (2021년 SPAC 상장) |
| 주력 사업 | FMCW(주파수변조연속파) 방식 4D LiDAR — 거리+속도 동시 측정 |
| 공식 홈페이지 | https://www.aeva.com |

**차별점:** 기존 펄스 방식 LiDAR와 달리 FMCW 방식으로 각 점에서 속도 정보 동시 제공 → 자율주행 인식 정확도 향상.

**주요 파트너:** 현대자동차그룹, ZF, SAIC, Denso, Torc Robotics(Daimler)

---

## 🇰🇷 한국 관련

| 항목 | 내용 |
| :--- | :--- |
| 한국 법인 | 없음 |
| 현대차 투자 | 현대자동차그룹이 Aeva 초기 투자자. 공급 계약 협의 중. |
| 한국 풀리모트 | 불가 |

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- FMCW 방식 LiDAR의 속도 정보 제공은 경쟁사 대비 강점.
- 소규모 스타트업으로 재무 불확실성 큼. 2024년 대규모 감원 단행.
- 현대차그룹·ZF 파트너십이 성장 핵심.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 스타트업으로 채용 불안정. 미국 현지 거주 필수. |
| 추천 직무 | Perception Software Engineer, LIDAR Systems Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모 스타트업, 비자 스폰 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [aeva.com](https://www.aeva.com)
- 채용: [aeva.com/careers](https://www.aeva.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: aeva.com 공식, NYSE 공시 (2026.05 기준)*
