---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Platform Science"
size: "중견기업"
fit: "★"
business: "상용차 커넥티드 SW 플랫폼 (Volvo Trucks 파트너)"
hq: "San Diego, California, USA"
founded: "2015"
employees: "~300명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (Volvo Financial Services 투자)"
korea_office: "없음"
---

# Platform Science

> 상용차 커넥티드 SW 플랫폼 | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | San Diego, CA, USA |
| 설립 연도 | 2015년 |
| 창업자 | Jack Kennedy |
| 임직원 수 | ~300명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 상용차 탑재 태블릿·앱 플랫폼 (ELD·내비·물류 앱 통합). Volvo Trucks와 전략적 파트너십. |
| 공식 홈페이지 | https://www.platformscience.com |

**파트너:** Volvo Trucks North America, Werner Enterprises, Covenant Logistics

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미 상용차 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- Volvo Trucks의 전략 투자로 안정적 파트너십.
- 미국 ELD 의무화로 상용차 디지털화 수혜.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 상용차 앱 플랫폼 특화 — 자동차 SW 배경과 직접 연관 낮음. |
| 추천 직무 | SW Engineer (모바일/IoT) — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — H-1B 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [platformscience.com](https://www.platformscience.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: platformscience.com 공식 (2026.05 기준)*
