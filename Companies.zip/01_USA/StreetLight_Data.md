---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/mobility
  - automotive/analytics
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "StreetLight Data"
size: "스타트업"
fit: "★"
business: "모빌리티 데이터 애널리틱스 (Jacobs Engineering 인수)"
hq: "San Francisco, California, USA"
founded: "2012"
employees: "~80명 (인수 후)"
revenue: "비공개"
ipo_status: "비상장 (2022년 Jacobs Engineering 인수)"
korea_office: "없음"
---

# StreetLight Data

> 모빌리티 데이터 애널리틱스 | 스타트업(인수) | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | San Francisco, CA, USA |
| 설립 연도 | 2012년 |
| 창업자 | Laura Schewel |
| 임직원 수 | ~80명 (2022년 Jacobs 인수 후) |
| 규모 분류 | 스타트업(인수됨) |
| 상장 여부 | 비상장 — 2022년 Jacobs Engineering Group(NYSE: J) 인수 |
| 주력 사업 | 스마트폰·차량 GPS 데이터 기반 교통 패턴 분석 플랫폼 (교통계획·인프라 설계 지원) |
| 공식 홈페이지 | https://www.streetlightdata.com |

**차별점:** 인구 수준(개인 비식별화) 이동 패턴 데이터 제공 — 도시계획·도로부처·컨설팅사 대상.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·유럽 교통 인프라 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- Jacobs Engineering 인수로 독립 성장 제한.
- 교통 데이터 애널리틱스 수요는 안정적이나 자동차 SW와 직접 연관 낮음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 교통 데이터 분석 특화 — 자동차 SW 엔지니어링과 직접 연관 낮음. |
| 추천 직무 | Data Engineer / GIS Analyst — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — Jacobs Engineering 글로벌 HR 통해 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [streetlightdata.com](https://www.streetlightdata.com)
- 모회사: [jacobs.com](https://www.jacobs.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: streetlightdata.com 공식, Jacobs IR (2026.05 기준)*
