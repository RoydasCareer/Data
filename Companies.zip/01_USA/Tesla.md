---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/autonomous
  - automotive/adas
  - automotive/software
  - fit/★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Tesla"
size: "대기업"
fit: "★★"
business: "전기차·FSD 자율주행 소프트웨어"
hq: "Austin, Texas, USA"
founded: "2003"
employees: "~140,473명 (2023)"
revenue: "$97.69B (2023)"
ipo_status: "NASDAQ: TSLA"
korea_office: "테슬라코리아(유) — 서울 강남구 테헤란로 419, 강남파이낸스플라자 9층"
---

# Tesla

> 전기차·FSD 자율주행 소프트웨어 | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 1 Tesla Road, Austin, TX 78725, USA (2021년 텍사스로 이전) |
| 설립 연도 | 2003년 7월 1일 |
| 창업자 | Martin Eberhard, Marc Tarpenning (Elon Musk는 2004년 A 라운드 투자 후 회장) |
| 임직원 수 | ~140,473명 (2023) / 2024년 대규모 감원으로 ~121,000명 추정 |
| 규모 분류 | 대기업 |
| 연매출 | **$97.69B (2023)** — 2024년 $97.7B (성장 정체) |
| 상장 여부 | **NASDAQ: TSLA** |
| 주력 사업 | 전기차 제조(Model S/3/X/Y/Cybertruck), FSD 자율주행 SW, Powerwall/Megapack(ESS), Optimus 로봇 |
| 공식 홈페이지 | https://www.tesla.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2003 | 창업 (샌카를로스, 캘리포니아) |
| 2008 | Roadster 1세대 출시 — 최초 양산 전기스포츠카 |
| 2010 | NASDAQ 상장 |
| 2012 | Model S 출시 |
| 2015 | 테슬라코리아(유) 한국 법인 설립 |
| 2020 | 상하이 기가팩토리(Giga Shanghai) 가동. Model Y 출시 |
| 2021 | 텍사스로 본사 이전. Giga Texas, Giga Berlin 개장 |
| 2022 | FSD v10 / v11 출시. Optimus 프로토타입 공개 |
| 2023 | Cybertruck 출시. 글로벌 인도량 180만대 돌파 |
| 2024 | FSD v12 (엔드-투-엔드 뉴럴넷) 출시. 감원 10% 단행 |

---

## 🚗 주요 제품 & 소프트웨어

| 제품 | 설명 |
| :--- | :--- |
| **FSD (Full Self-Driving)** | 레벨 2+ 자율주행 SW. v12부터 엔드-투-엔드 뉴럴넷 기반 (카메라 전용, LIDAR 미사용). 미국 일부 지역 감독 자율주행 제공. |
| **Autopilot** | 기본 탑재 ADAS. 차선 유지, ACC, 자동 차선 변경. |
| **Dojo** | Tesla 자체 개발 AI 훈련 슈퍼컴퓨터. FSD 학습용 |
| **Tesla Neural Net** | 비전 퍼스트 AI 인식 시스템 (Andrej Karpathy 前 총괄) |
| **OTA 업데이트** | 차량 소프트웨어 무선 업데이트 — 업계 최고 수준 |

---

## 🌍 글로벌 공장

| 기가팩토리 | 위치 | 생산 모델 |
| :--- | :--- | :--- |
| Giga Nevada | 스파크스, 네바다 | 배터리, Powerwall |
| Giga New York | 버팔로, 뉴욕 | Supercharger 장비 |
| Giga Texas | 오스틴, 텍사스 | Model Y, Cybertruck |
| Giga Shanghai | 상하이, 중국 | Model 3, Model Y |
| Giga Berlin | 그뤼나이데, 독일 | Model Y |

---

## 🇰🇷 한국 법인 — 테슬라코리아(유)

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | 테슬라코리아(유) |
| 설립 연도 | 2015년 |
| 주소 | 서울특별시 강남구 테헤란로 419, 강남파이낸스플라자 9층 (삼성동) |
| 대표전화 | 080-822-0291 |
| 사업자등록번호 | 524-88-00237 |
| 기업구분 | 대기업 (비상장 법인) |
| 주요 업무 | 차량 판매, 서비스센터 운영, 충전 인프라(Supercharger) 구축 |
| 직영 서비스센터 | 2개 (바디샵 포함 14개 거점 운영, 나머지는 추천 업체) |

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- **FSD 수익화 잠재력**: 차량 1대당 $8,000~12,000 FSD 판매 시 소프트웨어 마진 구조 전환.
- **Optimus 로봇**: 2026년 양산 목표. 자동차 외 새로운 성장 축.
- **에너지 사업(Powerwall/Megapack)**: 2024년 에너지 부문 매출 급성장.
- **한국 시장**: 2024년 한국 전기차 시장 점유율 상위권 유지. 충전 인프라 확장 지속.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 한국 법인은 세일즈/서비스/충전 인프라 중심. FSD/Autopilot 엔지니어링 포지션은 미국 본사(오스틴·프리몬트) 집중. 차량 SW 또는 자율주행 배경이 있다면 미국 본사 지원 고려. |
| 추천 직무 | Autopilot Software Engineer, Autopilot Test Engineer, Vehicle Software Engineer (미국 본사) / Service Advisor, Technical Support (한국) |
| 한국 지사 지원 | tesla.com/ko_kr 채용 페이지 |
| 비자 스폰 가능성 (미국 본사) | ★★ — H-1B 스폰 사례 있으나 SW 엔지니어 경쟁 치열 |
| 고졸 채용 가능성 | 한국 지사(서비스직): 가능. 미국 본사(엔지니어링): 학위 선호. |

---

## 🔗 관련 정보

- 홈페이지: [tesla.com](https://www.tesla.com/ko_kr)
- 채용: [tesla.com/careers](https://www.tesla.com/ko_kr/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: tesla.com 공식, 잡코리아, 뉴스 (2026.05 기준 확인)*
