---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/ivi
  - automotive/cluster
  - automotive/hmi
  - fit/★★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Visteon Corporation"
size: "대기업"
fit: "★★★"
business: "IVI 도메인 컨트롤러·디지털 클러스터·HMI SW — 글로벌 Tier 1"
hq: "Van Buren Township, Michigan, USA"
founded: "2000"
employees: "~10,000명"
ipo_status: "상장 (NASDAQ: VC)"
korea_office: "없음 (현대·기아차 고객사로 한국 내 프로젝트 수행)"
last_updated: "2026-08-03"
---

# Visteon Corporation

> IVI 도메인 컨트롤러·디지털 클러스터·Android Automotive | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 1 Village Center Drive, Van Buren Township, Michigan 48111, USA |
| 설립 연도 | 2000년 (Ford Motor Company에서 분사) |
| 임직원 수 | ~10,000명 (2024), 글로벌 18개국 거점 |
| 규모 분류 | 대기업 |
| 상장 여부 | 상장 (NASDAQ: VC) |
| 주력 사업 | IVI 도메인 컨트롤러(SmartCore), 디지털 클러스터, Android Automotive OS 플랫폼(AllGo) |
| 공식 홈페이지 | https://www.visteon.com |

Ford에서 독립한 글로벌 IVI·디지털 클러스터 Tier 1. **SmartCore** 도메인 컨트롤러로 IVI + 클러스터 + ADAS 디스플레이를 통합 제어. **AllGo**는 Android Automotive OS 기반 IVI 플랫폼. 현대·기아·BMW·Nissan·JLR 등 글로벌 주요 OEM 고객사 보유. 영국(Chelmsford/Solihull), 독일, 인도, 중국, 한국 프로젝트.

## 🎯 주요 제품 & 서비스

| 제품 | 내용 |
| :--- | :--- |
| **SmartCore** | IVI + 디지털 클러스터 + ADAS 디스플레이 통합 도메인 컨트롤러 |
| **AllGo** | Android Automotive OS 기반 IVI 플랫폼 — OEM 커스터마이징 지원 |
| **디지털 클러스터** | 12.3"~36" 와이드 디스플레이 클러스터 SW, Qt QML 기반 |
| **연결성** | V2X, OTA 업데이트, 커넥티드카 플랫폼 통합 |

## 📈 성장성 평가

**성장성 평가: ★★★★**

Android Automotive OS 채택 OEM 확산으로 AllGo 수요 증가. SmartCore 도메인 통합 컨트롤러 트렌드와 정확히 일치. NASDAQ 상장사로 재무 투명성 높음. 2024 매출 ~$3B.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | IVI QA·DoIP 진단·HMI 검증 경험 → SmartCore·AllGo 검증 팀 직결. Android Automotive 플랫폼 경험 강력한 어필 포인트 |
| 추천 직무 | IVI Software Test Engineer, Cluster Software Engineer, Android Automotive Engineer, Technical Program Manager (IVI), Validation Engineer |
| 비자 스폰 가능성 | ★ (미국 H-1B 추첨제 — 직접 취업 어려움) |
| 현실적 접근 | 영국(Visteon_UK.md), 인도, 한국 프로젝트 통한 경험 후 내부 전배 경로 추천 |
| 참고 | **영국 지사(Chelmsford/Solihull)** 가 IVI 엔지니어링 중심 → [[Visteon_UK|Visteon UK]] 우선 지원 |

## 🔗 관련 정보

- 공식 홈페이지: [visteon.com](https://www.visteon.com)
- 채용: [visteon.com/careers](https://www.visteon.com/careers/)
- LinkedIn: [linkedin.com/company/visteon](https://www.linkedin.com/company/visteon/)
- 관련 파일: [[Visteon_UK|Visteon UK (IVI 엔지니어링 중심)]]
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: visteon.com 공식 (2026.08 기준)*
