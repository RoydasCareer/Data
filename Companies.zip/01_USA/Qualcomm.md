---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/adas
  - automotive/software
  - fit/★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Qualcomm"
size: "대기업"
fit: "★★"
business: "Snapdragon Digital Chassis·자동차 통신 SoC"
hq: "San Diego, California, USA"
founded: "1985"
employees: "~51,000명 (2024)"
revenue: "$38.96B (FY2024)"
ipo_status: "NASDAQ: QCOM"
korea_office: "한국퀄컴(유) — 서울 용산구 한강대로 100, 15층 (아모레퍼시픽 빌딩)"
---

# Qualcomm

> Snapdragon Digital Chassis·자동차 통신 SoC | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 5775 Morehouse Drive, San Diego, CA 92121, USA |
| 설립 연도 | 1985년 7월 1일 |
| 창업자 | Irwin Jacobs, Andrew Viterbi 외 5명 (CDMA 특허 기반) |
| 임직원 수 | ~51,000명 (2024 기준) |
| 규모 분류 | 대기업 |
| 연매출 | **$38.96B (FY2024)** — 자동차 부문 $899M (전년比 +55%) |
| 상장 여부 | **NASDAQ: QCOM** |
| 주력 사업 | 모바일 SoC(Snapdragon), V2X·5G 자동차 통신, ADAS SoC(Snapdragon Ride), IVI 플랫폼 |
| 공식 홈페이지 | https://www.qualcomm.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 1985 | 창업 — CDMA 기술 개발 |
| 2000 | CDMA 칩셋 사업 매각 후 반도체 라이선싱으로 전환 |
| 2021 | Veoneer 인수 ($4.5B → Arriver 자율주행 SW 팀 확보) |
| 2021 | BMW에 Snapdragon Ride 탑재 발표 |
| 2022 | **Snapdragon Digital Chassis** 브랜드 출범 |
| 2023 | 자동차 설계 파이프라인 $30B+ 발표 |
| 2024 | Snapdragon Ride Elite 발표 (2~3 TOPS, 레벨 2+ ADAS) |

---

## 🚗 자동차 부문 (Snapdragon Digital Chassis)

| 플랫폼 | 설명 |
| :--- | :--- |
| **Snapdragon Ride** | ADAS/자율주행 전용 SoC 플랫폼. Ride Flex SoC(중앙집중형 E/E 아키텍처), Ride Elite(레벨 2+ 고효율). |
| **Snapdragon Auto** | IVI용 SoC. SA8775P 등 고성능 차량용 인포테인먼트. |
| **Snapdragon X65/X75** | 5G 자동차 통신 모뎀. V2X(C-V2X), 텔레매틱스 지원. |
| **Snapdragon Cockpit** | 디지털 클러스터 + IVI 통합 컴퓨팅 플랫폼 |

**주요 고객:** BMW, GM, Renault, Stellantis, Honda, Mercedes-Benz, Volvo Cars, SAIC

---

## 🌍 글로벌 주요 거점

미국(샌디에이고 본사), 독일(뮌헨), 영국, 인도(방갈로르·하이데라바드), 중국, 일본, 대만, **대한민국(서울)**

---

## 🇰🇷 한국 지사 — 한국퀄컴(유)

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | 한국퀄컴(유) / 퀄컴씨디엠에이테크날러지코리아(유) |
| 주소 | 서울특별시 용산구 한강대로 100, 15층 (아모레퍼시픽 빌딩) |
| 임직원 수 | ~292명 (2024) |
| 주요 업무 | 영업, 기술지원, 칩 공급 계약 (Samsung/SK Hynix 협력) |
| 주요 파트너 | 삼성전자, SK Hynix, LG전자, 현대자동차 |

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- **자동차 설계 파이프라인 $30B+(2023)**: 모바일 사업 둔화를 자동차로 대체 — 자동차 부문 FY2024 +55%.
- **SDV 핵심 칩 공급자**: 중앙집중형 E/E 아키텍처 전환 시 Snapdragon Ride 탑재 OEM 증가.
- **5G-V2X 선도**: C-V2X 표준 주도권 + 5G 모뎀 → 자동차 연결성 시장 석권 목표.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 한국 지사는 주로 삼성/SK Hynix 협력 및 현대차 계열 영업/기술지원 중심. V2X·자동차 통신 백그라운드가 있다면 FAE 포지션 가능성 있음. |
| 추천 직무 | Field Application Engineer (Automotive), Technical Marketing Manager, Business Development |
| 한국 지사 지원 | qualcomm.com 채용 페이지 또는 LinkedIn |
| 비자 스폰 가능성 (미국 본사) | ★★ — H-1B 스폰 가능하나 엔지니어링 학위 필요 |
| 고졸 채용 가능성 | 한국 지사: 경력·실무 중심이나 학위 선호. 미국 본사: 학위 필수. |

---

## 🔗 관련 정보

- 홈페이지: [qualcomm.com](https://www.qualcomm.com)
- 자동차: [qualcomm.com/automotive](https://www.qualcomm.com/products/automotive)
- 채용: [qualcomm.com/careers](https://www.qualcomm.com/company/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: qualcomm.com 공식, 리멤버, 잡코리아, NICE BizINFO (2026.05 기준 확인)*
