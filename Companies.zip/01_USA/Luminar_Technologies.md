---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/adas
  - automotive/sensing
  - fit/★★
country: "미국"
country_folder: "01_USA"
company_name: "Luminar Technologies"
size: "중견기업"
fit: "★★"
business: "자율주행용 장거리 LiDAR (Iris+) 및 인식 SW"
hq: "Orlando, Florida, USA"
founded: "2012"
employees: "~650명 (2024)"
revenue: "$77.1M (2023)"
ipo_status: "NASDAQ: LAZR (SPAC 2020)"
korea_office: "한국 파트너십 (현대차그룹 투자·공급 계약 — 정식 법인 미확인)"
---

# Luminar Technologies

> 자율주행 장거리 LiDAR (Iris+) | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 2603 Discovery Dr #100, Orlando, FL 32826, USA |
| 엔지니어링 허브 | Palo Alto, CA / Stockholm, Sweden |
| 설립 연도 | 2012년 (Austin Russell 17세 창업) |
| 창업자 | Austin Russell |
| 임직원 수 | ~650명 (2024) |
| 규모 분류 | 중견기업 |
| 연매출 | **$77.1M (2023)** |
| 상장 여부 | **NASDAQ: LAZR** (2020년 SPAC 상장) |
| 주력 사업 | Iris+ LiDAR (장거리 250m+), Sentinel 자율주행 SW 스택 |
| 공식 홈페이지 | https://www.luminartech.com |

### 주요 제품

| 제품 | 설명 |
| :--- | :--- |
| **Iris+** | 1550nm 파장 LiDAR. 250m+ 장거리. 소형·저비용. 양산 ADAS용. |
| **Sentinel** | 인식·판단 SW 스택. Iris+와 통합. OEM 공급용. |

**주요 파트너/투자자:** Volvo Cars(주요 양산 고객), Mercedes-Benz, SAIC, **현대자동차그룹($50M 투자)**, Daimler Trucks, Airbus

---

## 🇰🇷 한국 관련

| 항목 | 내용 |
| :--- | :--- |
| 한국 법인 | 정식 법인 여부 미확인 |
| 현대차그룹 투자 | 2021년 현대차그룹 $50M 투자 + 공급 파트너십 |
| 기아 적용 | 현대차·기아 차세대 모델 LiDAR 공급 협의 중 |
| 한국 채용 | 한국 엔지니어링 포지션 가능성 있음 — 확인 필요 |

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- **Volvo OEM 양산**: 2024년부터 Volvo 신차에 Iris+ 탑재 시작.
- **현대차 투자**: 한국 최대 OEM과 파트너십.
- **재무 압박**: 수익화 초기, 주가 변동 큼. 2024년 감원 단행.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 현대차그룹 $50M 투자 파트너. 한국 OEM 대응 엔지니어 포지션 가능성 있음. LiDAR 인식 SW 배경과 연관성 높음. |
| 추천 직무 | LiDAR Systems Engineer, Perception Software Engineer, Customer Application Engineer (현대/기아 담당) |
| 한국 지원 경로 | luminartech.com 채용 페이지 → 아시아 또는 한국 포지션 확인 |
| 비자 스폰 가능성 (미국 본사) | ★★ — H-1B 스폰 가능 |
| 고졸 채용 가능성 | 학위 선호 (EE/광학/CS) |

---

## 🔗 관련 정보

- 홈페이지: [luminartech.com](https://www.luminartech.com)
- 채용: [luminartech.com/careers](https://www.luminartech.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: luminartech.com 공식, NASDAQ 공시, 뉴스 (2026.05 기준)*
