---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/v2x
  - automotive/connectivity
  - automotive/data
  - fit/★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Nexar"
size: "스타트업"
fit: "★★"
business: "비전 AI 대시캠·V2V 데이터 네트워크·플릿 안전"
hq: "New York, NY, USA (Tel Aviv, Israel 주요 R&D 오피스)"
founded: "2015"
employees: "120~150명 (2024)"
revenue: "비공개 (비상장)"
ipo_status: "비상장 — Series D $5,300만 (2021.11), 총 조달 ~$1.5억"
korea_office: "없음"
---

# Nexar

> 비전 AI 대시캠·V2V 데이터 네트워크·플릿 안전 | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | New York, NY, USA |
| 주요 R&D | Tel Aviv, Israel |
| 설립 연도 | 2015 |
| 창업자 | Eran Shir (CPO), Bruno Fernandez-Ruiz (CTO) |
| 현 CEO | Zach Greenberger (2024.09 취임) |
| 임직원 수 | 120~150명 (2024) |
| 총 투자 유치 | ~$1.5억 (Series D까지) |
| 주요 투자자 | State Farm Ventures, Qumra Capital, Nationwide Insurance, Catalyst Investments |
| 상장 여부 | **비상장** |
| 공식 홈페이지 | https://www.getnexar.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2015 | 이스라엘 창업 — AI 대시캠 스타트업 |
| 2018 | Nationwide Insurance 전략적 투자 유치 |
| 2021 | State Farm Ventures 참여 Series D $5,300만 조달 |
| 2024.09 | Zach Greenberger 신임 CEO 취임 |
| 2024 | Luc Vincent 최고 R&D 책임자 취임, **BADAS 2.0** 예측 AI 출시 |
| 2025.01 | Jayesh Patel CFO 취임 |
| 2025.03 | Vay(원격 드라이빙) 플릿 안전 파트너십 체결 |
| 2025.05 | **HAAS Alert와 V2X 실시간 안전 통신 파트너십** 체결 |

---

## 🛠️ 주력 제품 상세

| 제품명 | 설명 |
| :--- | :--- |
| **Nexar One / Beam2** | 4K AI 대시캠 (클라우드 백업, AI 사고 감지, 24/7 주차 감시). 소비자·플릿 양용. |
| **Nexar Fleets** | 기업용 플릿 관리 SaaS 플랫폼. GPS 실시간 추적, 운전 행동 분석, 충돌 재구성 리포트, 지오펜스 경보. |
| **BADAS 2.0** | 행동·운전 분석 시스템 2.0. 사고 감지 → **사고 예측** AI 모델로 업그레이드 (2024). AV·ADAS 데이터셋 활용. |
| **V2V 네트워크** | 크라우드소싱 대시캠 데이터 기반 차량간 위험 정보 공유 네트워크. |
| **데이터 서비스 API** | 주행 데이터 (45PB+, 월 2억 마일 기록)를 OEM·보험사·도시계획 기관에 제공. |

---

## 🎯 전략 방향 (2024~2026)

| 분야 | 내용 |
| :--- | :--- |
| **보험 연계** | Nationwide·State Farm 투자사 기반. 사고 영상 증거로 보험 클레임 처리 40~60% 단축. NY주 보험료 할인 입법 추진 중. |
| **V2X 확장** | HAAS Alert 파트너십으로 실시간 도로 위험 경보 OEM 통합. |
| **플릿 SaaS** | HDVI(상업용 자동차 보험사) 파트너십으로 플릿 대시캠+보험 통합 패키지. |
| **AV 데이터** | 45PB+ 주행 데이터 자산을 자율주행 개발사 AI 학습 데이터로 판매. |
| **경영 쇄신** | 2024~2025년 CEO·CFO·CRO 전원 교체 — 대규모 B2B 확장 준비. |

---

## 📈 성장성

**성장성 평가: ★★★☆☆**

- 45PB+ 주행 데이터가 핵심 자산 — 경쟁사가 단기 복제 불가.
- 보험·AV 데이터·플릿 세 방향 수익화로 다각화.
- 그러나 2024~2025년 신규 펀딩 없음 — 성장 자금력 불확실.
- 직원 120~150명 소규모 — 한국 시장 진출 계획 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | JLR DoIP·CAN 통신 5년+ 경력이 대시캠-V2X 통신 프로토콜 검증에 연결 가능. BADAS 2.0 ADAS 예측 데이터 QA 역할 연결 가능. 단, **한국 오피스 없음**, 소규모 기업이라 한국 채용 가능성 낮음. |
| 추천 직무 | Automotive Data QA, ADAS Integration Engineer, Fleet Solutions Engineer |
| 비자 스폰 가능성 | ★ (저) |
| 고졸 채용 가능성 | 미국 본사: 낮음. 원격 계약직 가능성은 있음. |
| 현실적 경로 | 원격 데이터 분석·QA 계약직으로 접근 후 정직원 전환 모색 |

---

## 🇺🇸 USA 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| H-1B | 학위 필수 + 추첨제 (연간 쿼터 65,000개) — 고졸은 해당 없음 |
| O-1A | 탁월한 능력 입증 시 학위 불필요 — 진입 장벽 높음 |
| 비자 스폰 가능성 | ★ (저) |
| **현실적 경로** | 한국 내 파트너사 또는 원격 기여 검토 |

---

## 🔗 관련 정보

- 홈페이지: [getnexar.com](https://www.getnexar.com)
- 플릿 솔루션: [fleet.getnexar.com](https://fleet.getnexar.com)
- 채용: [careers.getnexar.com](https://careers.getnexar.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Wikipedia (Nexar), getnexar.com, PR Newswire, Nationwide News, TracXN, VentureBeat, Qumra Capital (2026.06 기준 직접 확인)*
