---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "BlueSpace.ai"
size: "스타트업"
fit: "★"
business: "물류 창고용 자율주행 SW (AV 모션 플래닝)"
hq: "San Jose, California, USA"
founded: "2018"
employees: "~50명 미만"
revenue: "비공개 (초기 스타트업)"
ipo_status: "비상장"
korea_office: "없음"
---

# BlueSpace.ai

> 물류 창고용 자율주행 SW | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | San Jose, CA, USA |
| 설립 연도 | 2018년 |
| 임직원 수 | ~50명 미만 |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 창고·물류센터용 자율주행 소프트웨어 플랫폼 (포크리프트·지게차·AGV 자율화) |
| 공식 홈페이지 | https://bluespace.ai |

**차별점:** 대규모 자율주행 데이터 없이도 작동하는 SW-only 접근. 기존 AGV/지게차에 소프트웨어를 얹어 자율주행화.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 미국 물류 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 소규모 스타트업, 재무 정보 비공개.
- 물류 자동화 시장은 성장세나 경쟁 치열.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 매우 소규모 스타트업으로 불안정. 자동차 분야가 아닌 물류 창고 특화. |
| 추천 직무 | Autonomy/Robotics Software Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [bluespace.ai](https://bluespace.ai)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: bluespace.ai 공식, LinkedIn (2026.05 기준)*
