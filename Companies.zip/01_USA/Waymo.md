---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Waymo (Alphabet)"
size: "대기업"
fit: "★"
business: "레벨 4 완전자율주행 로보택시 (Waymo One)"
hq: "Mountain View, California, USA"
founded: "2009 (구글 X) / 2016 (독립)"
employees: "~3,500명 (2024)"
revenue: "비공개 (Alphabet 자회사)"
ipo_status: "비상장 — Alphabet 100% 자회사"
korea_office: "없음"
---

# Waymo (Alphabet)

> 레벨 4 완전자율주행 로보택시 | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 1600 Amphitheatre Pkwy, Mountain View, CA 94043, USA |
| 설립 연도 | 2009년 (Google X 자율주행 프로젝트) / 2016년 Waymo LLC 독립 |
| 모회사 | Alphabet Inc. (Google 모회사) |
| 임직원 수 | ~3,500명 (2024) |
| 규모 분류 | 대기업 |
| 연매출 | 비공개 (Alphabet 기타 사업부에 포함) |
| 상장 여부 | **비상장** — Alphabet 100% 자회사 (2023년 기준 누적 투자 $11.1B+) |
| 주력 사업 | Waymo One(로보택시 서비스), Waymo Via(자율주행 트럭), Waymo Driver(자율주행 SW 플랫폼) |
| 공식 홈페이지 | https://waymo.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2009 | Google X 자율주행 프로젝트 시작 |
| 2016 | Waymo LLC 독립 분사 |
| 2018 | 피닉스(AZ) 상업 로보택시 시범 시작 |
| 2020 | Waymo One 유료 서비스 개시 |
| 2023 | 샌프란시스코 전면 유료 서비스 개시 |
| 2024 | LA 확장. 하루 운행 10만 회+ 돌파. |

---

## 🚗 핵심 기술

| 항목 | 내용 |
| :--- | :--- |
| **Waymo Driver** | 자체 개발 자율주행 SW 스택 — 인식·예측·계획·제어 통합 |
| **센서** | 자체 개발 LIDAR + 레이더 + 카메라 퓨전 |
| **차량** | Jaguar I-PACE, Zeekr RT (차세대), Volvo VNL (트럭) |
| **누적 자율주행** | 2024년 2,000만+ 마일 |

---

## 🇰🇷 한국 관련

한국 사무소 없음. 미국 내 서비스 집중 (피닉스·샌프란시스코·LA·오스틴).

---

## 📈 성장성 평가

**성장성 평가: ★★★★★**

- **레벨 4 자율주행 실제 서비스 유일 선두**: 미국 내 상업 로보택시 독보적 1위.
- **Alphabet 무제한 자금**: 단기 수익 없이도 장기 투자 가능.
- **Waymo Via(트럭)**: 상업용 물류 자율화로 수익화 경로 다변화.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 미국 취업 비자 필요. 자율주행 최고 수준이나 채용 경쟁 극히 치열. |
| 추천 직무 | Software Engineer (Perception/Prediction/Planning) — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — Alphabet H-1B 스폰 가능 |
| 고졸 채용 가능성 | CS/EE 석박사 선호 |

---

## 🔗 관련 정보

- 홈페이지: [waymo.com](https://waymo.com)
- 채용: [waymo.com/careers](https://waymo.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: waymo.com 공식, Alphabet 연간 보고서 (2026.05 기준)*
