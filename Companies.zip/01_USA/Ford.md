---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/autonomous
  - automotive/adas
  - automotive/software
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Ford (Latitude AI)"
size: "대기업"
fit: "★"
business: "ADAS·자율주행 소프트웨어 (Latitude AI)"
hq: "Dearborn, Michigan, USA"
founded: "1903"
employees: "~177,000명 (2023)"
revenue: "$185.0B (2023)"
ipo_status: "NYSE: F"
korea_office: "에프엘오토(주) — 서울 강남구 삼성동 144-17 골든타워 (前 포드세일즈서비스코리아)"
---

# Ford (Latitude AI)

> ADAS·자율주행 소프트웨어 (Latitude AI) | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | One American Road, Dearborn, MI 48126, USA |
| 설립 연도 | 1903년 6월 16일 |
| 창업자 | Henry Ford |
| 임직원 수 | ~177,000명 (2023 기준) |
| 규모 분류 | 대기업 |
| 연매출 | **$185.0B (2023)** |
| 상장 여부 | **NYSE: F** |
| 주력 사업 | Ford Blue(ICE), Ford Model e(EV), Ford Pro(상용), Latitude AI(ADAS SW) |
| 공식 홈페이지 | https://www.ford.com |

### Latitude AI (자율주행 자회사)

| 항목 | 내용 |
| :--- | :--- |
| 설립 | 2023년 (Ford 100% 자회사) |
| 본사 | 피츠버그, 펜실베이니아 |
| 목표 | 레벨 2+ 핸즈프리 ADAS (BlueCruise 후계 기술) |
| 주요 기술 | 엔드-투-엔드 뉴럴넷 기반 ADAS, 카메라·레이더 퓨전 |

**주요 연혁:**

| 연도 | 사건 |
| :--- | :--- |
| 1903 | 창업 (디트로이트) |
| 1908 | Model T 출시 — 대량생산 혁명 |
| 2000 | 재규어·랜드로버·볼보 인수 (2008~2010 전부 매각) |
| 2016 | Argo AI 자율주행 자회사 설립 (2022년 청산) |
| 2021 | BlueCruise (레벨 2 핸즈프리) 출시 |
| 2023 | **Latitude AI 설립** — ADAS SW 내재화 |
| 2026 | 포드코리아 사명 에프엘오토(주)로 변경 |

---

## 🇰🇷 한국 법인 — 에프엘오토(주)

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | 에프엘오토(주) (前 포드세일즈서비스코리아(유)) |
| 사명 변경 | 2026년 1월 (한국 시장 진출 30주년 기념) |
| 주소 | 서울특별시 강남구 삼성로 511, 삼성동 144-17 골든타워 |
| 주요 업무 | Ford·Lincoln 차량 판매, A/S, 마케팅 |
| 비고 | 판매 법인 — 엔지니어링 채용 없음 |

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- **Latitude AI**: 레벨 2+ ADAS 자체 개발로 BlueCruise 2.0 목표. 피츠버그·디트로이트 기반 SW 인재 채용 중.
- **EV 전환**: Ford Model e(머스탱 마하-E, F-150 라이트닝) 글로벌 확장.
- **한국 시장**: 2025~2026년 신차 출시 강화 계획 (에프엘오토 사명 변경과 함께).

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 법인(에프엘오토)은 판매/A/S 전문 — SW 엔지니어링 포지션 없음. Latitude AI(피츠버그)는 ADAS SW 엔지니어 채용 중이나 한국 원격근무 불가 가능성 높음. |
| 추천 직무 | ADAS Software Engineer, Perception Engineer (Latitude AI 미국 본사 한정) |
| 한국 지사 지원 | 에프엘오토: 자동차 영업/서비스직 위주 |
| 비자 스폰 가능성 (미국 본사) | ★ — H-1B 스폰 가능하나 자율주행 팀 규모 작음 |
| 고졸 채용 가능성 | 한국(영업직): 가능. 미국 Latitude AI: 학위 선호. |

---

## 🔗 관련 정보

- 홈페이지: [ford.com](https://www.ford.com)
- Latitude AI: [latitude.ai](https://latitude.ai)
- 채용: [ford.com/careers](https://www.ford.com/support/how-ford-works/ford-motor-company-careers/)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: ford.com 공식, latitude.ai, 뉴스(2026.01 사명 변경), 잡코리아 (2026.05 기준)*
