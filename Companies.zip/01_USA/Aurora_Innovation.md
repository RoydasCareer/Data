---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Aurora Innovation"
size: "중견기업"
fit: "★"
business: "자율주행 트럭·상용차 SW 플랫폼 (Aurora Driver)"
hq: "Pittsburgh, Pennsylvania, USA"
founded: "2017"
employees: "~1,600명 (2024)"
revenue: "비공개 (수익화 초기)"
ipo_status: "NASDAQ: AUR (SPAC 2021)"
korea_office: "없음"
---

# Aurora Innovation

> 자율주행 트럭·상용차 SW 플랫폼 | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 1600 Technology Dr, Pittsburgh, PA 15219, USA |
| 설립 연도 | 2017년 |
| 창업자 | Chris Urmson (前 Google/Waymo CTO), Sterling Anderson (前 Tesla Autopilot), Drew Bagnell (前 Uber ATG) |
| 임직원 수 | ~1,600명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | **NASDAQ: AUR** (2021년 SPAC 상장) |
| 주력 사업 | Aurora Driver(자율주행 SW), 자율주행 트럭 상용 서비스 |
| 공식 홈페이지 | https://aurora.tech |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2017 | 창업 |
| 2019 | Uber ATG 자율주행 부문 인수 |
| 2021 | SPAC NASDAQ 상장 |
| 2024 | 텍사스 달라스-휴스턴 구간 자율주행 트럭 상업 서비스 개시 |

**파트너십:** Toyota, PACCAR(켄워스·페터빌트), FedEx, Werner

---

## 🇰🇷 한국 관련

한국 사무소 없음. 미국(피츠버그·댈러스·시애틀) 집중 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 자율주행 트럭 상업화 선도. 파트너십 다수.
- 재무 리스크: 아직 수익화 초기, 주가 변동 큼.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 미국 취업 비자 필요. 자율주행 트럭 전문이라 차량 SW 연관성 있으나 현지 거주 필수. |
| 추천 직무 | Autonomy Software Engineer, Test & Validation Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — H-1B 스폰 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [aurora.tech](https://aurora.tech)
- 채용: [aurora.tech/jobs](https://aurora.tech/jobs)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: aurora.tech 공식, NASDAQ 공시 (2026.05 기준)*
