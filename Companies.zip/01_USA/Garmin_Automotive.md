---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/ivi
  - automotive/navigation
  - automotive/adas
  - fit/★★
country: "미국"
country_folder: "01_USA"
company_name: "Garmin Ltd. (Automotive Division)"
size: "대기업"
fit: "★★"
business: "OEM 임베디드 내비·ADAS 카메라·플릿 관리 SW"
hq: "Olathe, Kansas, USA (글로벌 HQ)"
founded: "1989"
employees: "~19,000명 (전체), Automotive ~3,000명"
ipo_status: "상장 (NASDAQ: GRMN)"
korea_office: "없음"
last_updated: "2026-08-03"
---

# Garmin Ltd. (Automotive Division)

> OEM 내비·DriveAssist ADAS 카메라·플릿 SW | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 1200 E 151st Street, Olathe, Kansas 66062, USA |
| 설립 연도 | 1989년 |
| 임직원 수 | ~19,000명 전체 (Automotive 부문 ~3,000명, 2024) |
| 규모 분류 | 대기업 |
| 상장 여부 | 상장 (NASDAQ: GRMN, 시총 ~$25B) |
| 주력 사업 (Automotive) | OEM 임베디드 내비게이션 SW, ADAS 카메라 시스템, 상용차 플릿 관리 |
| 공식 홈페이지 | https://www.garmin.com/automotive |

GPS 네비게이션의 선구자. Automotive 부문은 **OEM 임베디드 내비게이션**(Toyota·Honda·Subaru 등에 공급), **DriveAssist** ADAS 전방 카메라, **Fleet** 상용차 텔레매틱스 플랫폼으로 구성. 소비자용 PND(Personal Navigation Device) 대비 OEM B2B 비중 확대 중.

## 🎯 주요 제품 & 서비스 (Automotive)

| 제품 | 내용 |
| :--- | :--- |
| **OEM Embedded Navigation** | Toyota·Honda·Subaru 등 OEM 임베디드 내비 SW 공급 |
| **DriveAssist** | 전방 충돌 경보·차선 이탈 경보 ADAS 카메라 시스템 |
| **Garmin Speak** | Amazon Alexa 통합 커넥티드카 음성 디바이스 |
| **Fleet / Teltonica** | 상용차 플릿 추적·텔레매틱스·OBD 진단 플랫폼 |

## 📈 성장성 평가

**성장성 평가: ★★★**

OEM 임베디드 내비 수요는 Apple CarPlay/Android Auto 통합에 의해 일부 대체 압력 존재. 그러나 상용차 플릿·ADAS 카메라 부문은 안정 성장 중. 전체 GRMN은 Outdoor/Marine/Aviation 다각화로 건전.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | IVI·내비게이션 SW 경험 → OEM Navigation 팀. ADAS 카메라 QA 경험 → DriveAssist 검증 팀 |
| 추천 직무 | Embedded Software Engineer (Navigation), ADAS Validation Engineer, Software Test Engineer, Fleet Software Engineer |
| 비자 스폰 가능성 | ★ (미국 H-1B 추첨제) |
| 현실적 접근 | Garmin Taiwan(台灣) 또는 Garmin Europe 거점 통한 간접 접근 |
| 참고 | Aviation·Marine 등 타 부문도 임베디드 SW 엔지니어 채용 활발 — 경력 확장 가능 |

## 🔗 관련 정보

- 공식 홈페이지: [garmin.com/automotive](https://www.garmin.com/en-US/business-solutions/automotive/)
- 채용: [careers.garmin.com](https://careers.garmin.com/en-US/)
- LinkedIn: [linkedin.com/company/garmin](https://www.linkedin.com/company/garmin/)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: garmin.com 공식 (2026.08 기준)*
