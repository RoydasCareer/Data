---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/embedded
  - automotive/autosar
  - fit/★★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "LHP Engineering Solutions"
size: "중견기업"
fit: "★★★"
business: "자동차 SW 개발·임베디드 엔지니어링"
hq: "(본사 위치 미확인) — 미국"
---

# LHP Engineering Solutions

> 자동차 SW 개발·임베디드 엔지니어링 | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

자동차 ECU용 임베디드 소프트웨어 및 AUTOSAR 기반 미들웨어 개발 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 미국 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 중견기업 |
| 주력 사업 | 자동차 SW 개발·임베디드 엔지니어링 |

## 🎯 비전 & 미션

SDV 전환 시대의 AUTOSAR Adaptive 기반 차세대 임베디드 SW 플랫폼을 선도합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

전장 소프트웨어 비중 증가로 임베디드 SW 시장 지속 성장. 전기차 전환도 ECU 수 증가 촉진.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 추천 이유 | ECU·진단 통신 연계 임베디드 경험 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★ |
| 고졸 채용 가능성 | 국가별 상이 |
| 비자 정보 | 취업 비자 (국가별 상이) |
| 비고 | 해당 국가 대사관 또는 채용 공고 확인 필요. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
