---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - automotive/adas
  - fit/★★
country: "미국"
country_folder: "01_USA"
company_name: "Torc Robotics"
size: "스타트업"
fit: "★★"
business: "자율주행 트럭 SW (Daimler Truck 자회사)"
hq: "Blacksburg, Virginia, USA"
founded: "2005"
employees: "~500명 (2024)"
revenue: "비공개 (Daimler Truck 자회사)"
ipo_status: "비상장 (Daimler Truck AG 완전 자회사, 2022)"
korea_office: "없음"
---

# Torc Robotics

> 자율주행 트럭 SW | 스타트업(Daimler Truck 자회사) | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Blacksburg, VA, USA (+ Albuquerque NM, San Francisco CA) |
| 설립 연도 | 2005년 |
| 창업자 | Michael Fleming |
| 임직원 수 | ~500명 (2024) |
| 규모 분류 | 스타트업 (Daimler Truck 완전 자회사) |
| 상장 여부 | 비상장 — 2019년 Daimler Truck 다수 지분 인수, 2022년 완전 자회사 |
| 주력 사업 | SAE Level 4 자율주행 트럭 SW — 장거리 고속도로 자율주행 소프트웨어 스택 개발 (Mercedes-Benz Trucks 탑재 예정) |
| 공식 홈페이지 | https://torc.ai |

**모회사:** Daimler Truck AG (ETR: DTG)
**파트너:** NVIDIA (Drive platform), HERE Technologies

---

## 🇰🇷 한국 관련

한국 사무소 없음. 미국 내 R&D 집중. 모회사 Daimler Truck은 한국에 다임러트럭코리아(유) 운영 중이나 Torc와 직접 연관 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- Daimler Truck 자회사로 재무 안정성 확보.
- Level 4 자율주행 트럭 2027년 상용화 목표 — 고속도로 화물 자율화 핵심 플레이어.
- 경쟁사(Aurora, Waymo Via) 대비 OEM 통합 강점.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자율주행 SW 핵심 기술. Daimler Truck 모회사로 안정성. 그러나 한국 사무소 없음. |
| 추천 직무 | Autonomy SW Engineer (인식·판단·제어) — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 대기업 자회사로 H-1B 가능 |
| 고졸 채용 가능성 | 학위 필수 |

---

## 🔗 관련 정보

- 홈페이지: [torc.ai](https://torc.ai)
- 채용: [torc.ai/careers](https://torc.ai/careers)
- 모회사: [daimlertruck.com](https://www.daimlertruck.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: torc.ai 공식, Daimler Truck IR (2026.05 기준)*
