---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Cyngn"
size: "스타트업"
fit: "★"
business: "산업용 자율주행 SW (DriveMod 플랫폼)"
hq: "Menlo Park, California, USA"
founded: "2013"
employees: "~100명 (2024)"
revenue: "비공개"
ipo_status: "NASDAQ: CYN"
korea_office: "없음"
---

# Cyngn

> 산업용 자율주행 SW (DriveMod) | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 1515 S El Camino Real #200, San Mateo, CA 94402, USA |
| 설립 연도 | 2013년 (前 Coda Automotive) |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | **NASDAQ: CYN** |
| 주력 사업 | DriveMod — 산업용 지게차·AGV·견인차 자율주행 SW 플랫폼 |
| 공식 홈페이지 | https://www.cyngn.com |

**차별점:** 특정 차량 종류에 구애받지 않는 차량-독립형(vehicle-agnostic) 자율주행 SW. 공장·물류센터·항만 내 산업용 차량 자율화.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미 산업 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 산업용 물류 자동화 틈새 시장. 경쟁사(Seegrid, Vecna 등) 대비 소규모.
- NASDAQ 상장이나 주가 변동 큼, 재무 불안정.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 산업용 자율주행 특화로 자동차 SW 배경과 직접 연관 낮음. |
| 추천 직무 | Autonomy Software Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모 스타트업 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [cyngn.com](https://www.cyngn.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: cyngn.com 공식, NASDAQ 공시 (2026.05 기준)*
