---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/autonomous
  - automotive/adas
  - automotive/simulation
  - fit/★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "NVIDIA"
size: "대기업"
fit: "★★"
business: "자율주행 AI 컴퓨팅 (DRIVE 플랫폼)"
hq: "Santa Clara, California, USA"
founded: "1993"
employees: "~36,000명 (2024)"
revenue: "$130.5B (FY2025)"
ipo_status: "NASDAQ: NVDA"
korea_office: "엔비디아코리아 — 서울 강남구 영동대로 511, 코엑스 무역타워 2101호"
---

# NVIDIA

> 자율주행 AI 컴퓨팅 (DRIVE 플랫폼) | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 2788 San Tomas Expressway, Santa Clara, CA 95051, USA |
| 설립 연도 | 1993년 4월 5일 |
| 창업자 | Jensen Huang, Chris Malachowsky, Curtis Priem |
| 임직원 수 | ~36,000명 (2024 기준) |
| 규모 분류 | 대기업 |
| 연매출 | **$130.5B (FY2025)** — 전년比 +114%, 자동차 부문 $1.69B |
| 상장 여부 | **NASDAQ: NVDA** — 시가총액 약 $3.3조 (2025년 기준, 세계 1~2위) |
| 주력 사업 | GPU 설계, AI 컴퓨팅 플랫폼, 자율주행 DRIVE 플랫폼, 데이터센터 |
| 공식 홈페이지 | https://www.nvidia.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 1993 | 창업 (Jensen Huang, Malachowsky, Priem) |
| 1999 | GPU 개념 창시 — GeForce 256 출시 |
| 2006 | CUDA 병렬 컴퓨팅 플랫폼 발표 |
| 2016 | DGX-1 AI 슈퍼컴퓨터 발표 / Volvo에 DRIVE 플랫폼 공급 계약 |
| 2017 | DRIVE PX 2 기반 자율주행 연구 확산 |
| 2019 | Mellanox Technologies 인수 ($6.9B) |
| 2022 | DRIVE Thor SoC 발표 — 자율주행 + IVI 통합 |
| 2023 | 생성형 AI 붐으로 H100 GPU 수요 폭발 / 자동차 누적 설계 파이프라인 $14B |
| 2024 | Blackwell 아키텍처 발표 / DRIVE Thor 양산 OEM 공급 시작 |

---

## 🚗 자동차 부문 (NVIDIA DRIVE)

| 제품/플랫폼 | 설명 |
| :--- | :--- |
| **DRIVE Thor** | 차세대 중앙 컴퓨팅 SoC. 2,000 TOPS. 자율주행 + IVI + 파킹 + 운전자 모니터링 통합. 2024년 양산 OEM 탑재 시작. |
| **DRIVE AGX** | 자율주행용 고성능 컴퓨팅 플랫폼 하드웨어 |
| **DRIVE OS** | 자동차용 실시간 OS. ISO 26262 ASIL-D 인증 |
| **DRIVE AV** | 자율주행 SW 스택. 인식(LIDAR/카메라/레이더), 판단, 경로계획 포함 |
| **DRIVE Sim (Omniverse)** | USD 기반 물리 정확 자율주행 시뮬레이션 플랫폼. 합성 데이터 생성 포함 |
| **DRIVE Concierge** | AI 기반 IVI 어시스턴트 |

**주요 고객:** Mercedes-Benz, BYD, Volvo, XPENG, Li Auto, Jaguar Land Rover, Continental, Bosch, ZF 등

---

## 🌍 글로벌 주요 거점

미국(산타클래라 본사, 워싱턴, 텍사스, 시애틀), 캐나다(토론토), 영국(브리스톨), 독일(뮌헨), 이스라엘(텔아비브 — Mellanox 연구소), 중국(상하이·베이징), 일본, **대한민국(서울)**

---

## 🇰🇷 한국 지사 — 엔비디아코리아

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | 엔비디아코리아 (NVIDIA Korea) |
| 주소 | 서울특별시 강남구 영동대로 511, 코엑스 무역타워 2101호 (삼성동) |
| 전화 | 02-6000-8010 |
| 팩스 | 02-6000-8025 |
| 주요 업무 | 영업, 마케팅, 기술지원 (한국 OEM/Tier1 파트너십) |
| 주요 한국 파트너 | 현대자동차, 기아, Samsung, SK Hynix, LG |

---

## 📈 성장성 평가

**성장성 평가: ★★★★★**

- **자동차 부문 누적 설계 파이프라인 $14B(2023)**: SDV 전환으로 OEM들이 DRIVE Thor 채택 가속화.
- **Omniverse 시뮬레이션**: 합성 데이터 생성·자율주행 검증 분야에서 압도적 지위.
- **생성형 AI와 자동차 AI 시너지**: CUDA 생태계 + 자동차 SW 개발 가속 플랫폼이 동시 성장.
- **DRIVE Thor 2024년 양산**: 차량당 컴퓨팅 성능 요구 급증 → NVIDIA 시장 확대.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 한국 지사는 영업/마케팅/기술지원 중심. 자동차 SW 엔지니어링 포지션은 주로 미국/이스라엘 본사에 있음. 그러나 DRIVE 플랫폼 기술 지원(AE/FAE) 역할로 한국에서 지원 가능성 있음. |
| 추천 직무 | Automotive Solutions Architect, Field Application Engineer (Automotive), Technical Marketing Engineer |
| 한국 지사 지원 | nvidia.com/ko-kr 채용 페이지 또는 LinkedIn |
| 비자 스폰 가능성 (미국 본사) | ★★ — H-1B 스폰 가능하나 경쟁 매우 치열 |
| 고졸 채용 가능성 | 한국 지사: 경력·기술력 우선. 미국 본사: 학위 요건 엄격. |

---

## 🔗 관련 정보

- 홈페이지: [nvidia.com](https://www.nvidia.com/ko-kr/)
- 자동차 부문: [nvidia.com/automotive](https://www.nvidia.com/ko-kr/self-driving-cars/)
- 채용: [nvidia.com/careers](https://www.nvidia.com/ko-kr/about-nvidia/careers/)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: nvidia.com 공식, 잡코리아, 구글 지도 (2026.05 기준 확인)*
