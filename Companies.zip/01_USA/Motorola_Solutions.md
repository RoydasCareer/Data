---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/software
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Motorola Solutions"
size: "대기업"
fit: "★"
business: "공공안전·미션크리티컬 통신 솔루션"
hq: "Chicago, Illinois, USA"
founded: "1928 (모토로라) / 2011 (Motorola Solutions 분사)"
employees: "~21,000명 (2024)"
revenue: "$10.0B (2024)"
ipo_status: "NASDAQ: MSI"
korea_office: "모토로라솔루션코리아(주) — 서울 송파구 법원로11길 12, 8층 (직원 ~20명, 소규모)"
---

# Motorola Solutions

> 공공안전·미션크리티컬 통신 솔루션 | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 500 W Monroe St, Chicago, IL 60661, USA |
| 설립 연도 | 1928년 (모토로라 창업) / 2011년 Motorola Solutions 분사 |
| 임직원 수 | ~21,000명 (2024 기준) |
| 규모 분류 | 대기업 |
| 연매출 | **$10.0B (2024)** |
| 상장 여부 | **NASDAQ: MSI** |
| 주력 사업 | 무선 통신 시스템(TETRA/P25), 영상 보안(Avigilon), 공공안전 소프트웨어 |
| 공식 홈페이지 | https://www.motorolasolutions.com |

> **⚠️ 주의:** Motorola Solutions는 **자동차** 분야가 아닌 공공안전·경찰·소방·군사 통신이 주력입니다. 자동차 SW 엔지니어와의 직무 연관성은 낮습니다.

---

## 🇰🇷 한국 법인 — 모토로라솔루션코리아(주)

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | 모토로라솔루션코리아(주) |
| 주소 | 서울특별시 송파구 법원로11길 12, 8층 (문정동) |
| 임직원 수 | ~20명 (소규모) |
| 평균 연봉 | ~7,415만원 |
| 주요 업무 | 공공안전 무선통신 장비 영업·지원 |
| 자동차 관련 | **없음** (경찰·소방·군 통신 위주) |

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- **공공안전 특화**: 경찰·소방·군 통신 시장 안정적 수요.
- **Avigilon(영상AI)**: 비디오 분석·보안 솔루션 성장.
- **자동차 연관성 낮음**: 자율주행·ADAS·진단 분야 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 자동차 SW 분야와 직접 연관 없음. 한국 법인 규모 매우 소규모(~20명). SW 엔지니어 포지션 거의 없음. |
| 추천 직무 | (자동차 SW 경력과 미스매치 — 지원 불권장) |
| 한국 지사 지원 | motorolasolutions.com 채용 페이지 |
| 비자 스폰 가능성 | ★ — 한국 법인 규모 작아 채용 드묾 |
| 고졸 채용 가능성 | 확인 필요 |

---

## 🔗 관련 정보

- 홈페이지: [motorolasolutions.com](https://www.motorolasolutions.com)
- 한국: [motorolasolutions.com/ko_kr](https://www.motorolasolutions.com/ko_kr)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: motorolasolutions.com, 잡코리아, NICE BizINFO (2026.05 기준)*
