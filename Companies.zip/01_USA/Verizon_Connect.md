---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Verizon Connect"
size: "대기업"
fit: "★"
business: "플릿 관리·GPS 추적 SW (Verizon Communications 사업부)"
hq: "Atlanta, Georgia, USA"
founded: "2018 (통합); Fleetmatics 2004, Telogis 2002"
employees: "~2,000명+ (사업부 추정)"
revenue: "비공개 (Verizon NYSE: VZ 연매출 $135B)"
ipo_status: "Verizon Communications NYSE: VZ"
korea_office: "없음 (버라이존코리아는 B2B 네트워킹 전담 — Connect 플릿SW 미운영)"
---

# Verizon Connect

> 플릿 관리·GPS 추적 SW | 대기업(사업부) | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Atlanta, GA, USA |
| 설립 연도 | 2018년 (Fleetmatics + Telogis + Networkfleet 통합) |
| 모회사 | Verizon Communications (NYSE: VZ) |
| 임직원 수 | ~2,000명+ (사업부 추정) |
| 규모 분류 | 대기업 사업부 |
| 상장 여부 | Verizon Communications NYSE: VZ |
| 주력 사업 | 상용차 GPS 추적·플릿 관리·운전자 행동 분석·ELD 컴플라이언스 SaaS |
| 공식 홈페이지 | https://www.verizonconnect.com |

**주요 제품:** Reveal (GPS 추적), Reveal Fleet (플릿 관리), Driver Safety Scorecard
**주요 고객:** Waste Management, Penske, 중소 상용차 운영사 (북미 중심)

---

## 🇰🇷 한국 관련

Verizon Connect 한국 사무소 없음. 버라이존코리아(주)는 서울에서 B2B 네트워크/통신 서비스 운영 중이나 플릿 관리 SW 사업(Verizon Connect)과 별개. 한국 플릿 관리 시장 미진출.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 북미 상용차 텔레매틱스 시장 대형 플레이어.
- Verizon 모기업 5G 네트워크 연계 강점.
- 순수 SW 기업 대비 기동성 낮음 (대기업 사업부 특성).

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 플릿 관리 SW 특화 — 자동차 임베디드 SW와 직접 연관 낮음. |
| 추천 직무 | SW Engineer (Platform/IoT) — 미국 현지 한정 |
| 한국 지원 경로 | 없음 (버라이존코리아는 통신 사업 전담) |
| 비자 스폰 가능성 | ★★★ — Verizon 대기업 HR, H-1B 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [verizonconnect.com](https://www.verizonconnect.com)
- 모회사: [verizon.com](https://www.verizon.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: verizonconnect.com 공식, JobKorea (2026.05 기준)*
