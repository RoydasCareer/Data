---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/software
  - fit/★★
country: "미국"
country_folder: "01_USA"
company_name: "Sonatus"
size: "스타트업"
fit: "★★"
business: "SDV 소프트웨어 플랫폼 & AI 차량 인텔리전스"
hq: "Sunnyvale, California — 미국"
founded: "2018"
last_updated: "2026-06-24"
fact_checked: "2026-06-24"
---

# Sonatus

> SDV 소프트웨어 플랫폼 & AI 차량 인텔리전스 | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

소프트웨어 정의 차량(SDV) 시대를 위한 AI 기반 차량 인텔리전스 플랫폼 전문 기업. OEM·공급업체가 차량 수명 주기 전반에 걸쳐 SW로 차량 기능을 동적으로 제어·업데이트할 수 있도록 지원.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sunnyvale, California — 미국 |
| 설립 연도 | 2018 |
| 창업자 | Jeffrey Chou, Yu Fang |
| 규모 분류 | 스타트업 |
| 주력 사업 | SDV 소프트웨어 플랫폼 & AI 차량 인텔리전스 |
| 양산차 적용 | 6백만 대 이상 (Hyundai·Genesis·Kia, Nissan 등) |

## 🎯 비전 & 미션

차량이 판매된 후에도 SW 업데이트로 지속적으로 가치를 창출하는 "살아있는 제품"으로 변환. OEM이 SW 기반 비즈니스 모델로 전환할 수 있도록 인프라 제공.

## 🔑 핵심 기술 & 제품

- **Sonatus SDV 플랫폼**: 동적 차량 동작 제어 및 AI 기반 실시간 의사결정
- **OTA 업데이트 인프라**: 차량 수명 주기 전반 SW 배포 관리
- **파트너**: Hyundai Motor Group (Genesis·Hyundai·Kia), Nissan Technical Centre Europe, Michelin, Bosch Engineering Group, Renesas, NXP, AWS

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

SDV 시장 $2,150억(2024) → $1.298조(2032) 예상. 이미 양산차 600만 대 이상 적용이라는 검증된 트랙 레코드 보유. OEM 파트너십이 탄탄하여 지속 성장 가능성 높음.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | SDV 플랫폼 QA·통합 테스팅, OTA SW 검증 |
| 추천 직무 | SW 테스팅 엔지니어, SDV 플랫폼 QA, 차량 통합 검증 |
| 비자 스폰 가능성 | ★ (H-1B 추첨제) |
| 고졸 채용 가능성 | 실무 경력 중심이나 비자 장벽이 높음 |
| 비자 정보 | H-1B 비자 필요 — 직접 취업 어려움 |
| 비고 | Hyundai·Kia 협력사이므로 현대자동차그룹 한국 법인 → 파견 경로도 고려 가능. |

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
- 관련 기업: [[Applied_Intuition|Applied Intuition]], [[Apex.AI|Apex.AI]]
