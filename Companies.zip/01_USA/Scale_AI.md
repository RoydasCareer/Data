---
tags:
  - company
  - automotive
  - country/usa
  - size/large
  - automotive/software
  - automotive/data
  - fit/★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Scale AI"
size: "대기업"
fit: "★★"
business: "AI 학습 데이터 레이블링·AI 인프라"
hq: "San Francisco, California, USA"
founded: "2016"
employees: "900~1,000명 (2025, 정직원 기준)"
revenue: "$8.7억 (2024), $20억 목표 (2025)"
ipo_status: "비상장 — Meta $143억 투자로 기업가치 $290억 (2025.06)"
korea_office: "없음 (한국 사무소 미확인)"
---

# Scale AI

> AI 학습 데이터 레이블링·AI 인프라 | 대기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | San Francisco, California, USA |
| 설립 연도 | 2016 |
| 창업자 | Alexandr Wang (CEO, 前), Lucy Guo |
| 현 CEO | Jason Droege (2025.06 이후, Wang은 Meta Superintelligence팀 이동) |
| 임직원 수 | 정직원 900~1,000명 (2025). 크라우드소싱 작업자 포함 시 수만 명. |
| 매출 | **$8.7억 (2024)**, $20억 목표 (2025) |
| 기업가치 | **$290억 (2025.06 Meta 투자 기준)** |
| 주요 투자자 | Meta (49% 지분, $143억), Accel, Tiger Global, Index Ventures |
| 상장 여부 | **비상장** |
| 공식 홈페이지 | https://scale.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2016 | San Francisco에서 Alexandr Wang (19세) 창업 |
| 2021 | 기업가치 $73억 달성 |
| 2022 | 미 국방부 AI 계약 $2.5억 수주 |
| 2024 | 기업가치 $138억 → $140억 |
| 2025.05 | 직원 200명 해고 ("너무 빠르게 성장" 인정) |
| 2025.06 | **Meta $143억 투자, 기업가치 $290억 확정** |
| 2026.05 | 미 국방부 계약 $5억 추가 수주 |

---

## 🛠️ 주력 제품 상세

| 제품명 | 설명 |
| :--- | :--- |
| **Automotive Data Engine** | AV 모델 학습용 엔드투엔드 데이터 파이프라인 (2D/3D LiDAR·카메라·레이더 레이블링). |
| **AFM-1 (Automotive Foundation Model)** | 안전한 AV 내비게이션을 위한 트랜스포머 기반 컴퓨터 비전 모델. |
| **Model Evaluation Suite** | AV 모델 성능 분석·약점 식별 플랫폼. |
| **Data Curation Tools** | 레이블·비레이블 데이터셋 관리. |
| **Remotasks** | 자율주행 데이터 레이블링 특화 크라우드소싱 플랫폼 (자회사). |
| **RLHF / AI Safety Tools** | Meta·OpenAI·Google 등 AI 기업 모델 훈련·평가 지원. |

---

## 🎯 전략 방향 (2024~2026)

| 분야 | 내용 |
| :--- | :--- |
| **AI 기업 지원** | Meta·OpenAI·Google 등 AI 랩의 RLHF·안전성 테스트 데이터 공급. 2025년 최대 수익원. |
| **방위산업** | 미 국방부 AI 자동화 프로젝트 ("Thunderforge"). 2026년 $5억 계약 수주. |
| **자동차** | GM/Cruise·Toyota·Waymo·Valeo 등 AV 데이터 레이블링 지속 공급. |
| **Meta 파트너십** | $143억 투자 후 Superintelligence 공동 개발. AI 인프라 핵심 플레이어로 격상. |

---

## 📈 성장성

**성장성 평가: ★★★★☆**

- 2024년 매출 $8.7억 → 2025년 $20억 목표 (2.3배 성장).
- Meta $143억 투자로 안정적 성장 기반 확보.
- 자동차 AV 데이터 → AI 기업 훈련 데이터 → 미 국방부로 시장 다각화.
- 다만 2025년 직원 200명 해고로 과잉 확장 리스크 노출.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | AV 데이터 QA·레이블링 분야에서 JLR DoIP 실차 및 IVI QA 경력이 데이터 품질 검증 역할에 연결 가능. 그러나 **한국 오피스 없음**, 미국 비자 허들 높음. |
| 추천 직무 | Automotive Data QA, Data Labeling Specialist, AV Sensor Annotation QA |
| 비자 스폰 가능성 | ★ (저) |
| 고졸 채용 가능성 | 크라우드소싱 태스커: 가능. 정직원: 미국 본사는 학위 선호. |
| 현실적 경로 | 한국 내 파트너사·Remotasks 플랫폼 통해 프리랜서 기여 가능 |

---

## 🇺🇸 USA 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| H-1B | 학위 필수 + 추첨제 (연간 쿼터 65,000개) — 고졸은 해당 없음 |
| O-1A | 탁월한 능력 입증 시 학위 불필요 — 진입 장벽 높음 |
| 비자 스폰 가능성 | ★ (저) |
| **현실적 경로** | Remotasks 플랫폼 통한 AV 데이터 태스커로 원격 기여 가능 |

---

## 🔗 관련 정보

- 홈페이지: [scale.com](https://scale.com)
- 자동차 솔루션: [scale.com/automotive](https://scale.com/automotive)
- 채용: [scale.com/careers](https://scale.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Wikipedia (Scale AI), scale.com, Forbes, Business Insider, FedScoop, Sacra (2026.06 기준 직접 확인)*
