---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Trimble Transportation"
size: "중견기업"
fit: "★"
business: "상용차 플릿·텔레매틱스·물류 SW (Trimble Inc. 사업부)"
hq: "Westminster, Colorado, USA"
founded: "1978 (Trimble Inc.); Transportation 사업부 2000년대"
employees: "~1,000명+ (사업부 추정)"
revenue: "비공개 (Trimble Inc. NASDAQ: TRMB 연매출 $3.7B)"
ipo_status: "Trimble Inc. NASDAQ: TRMB"
korea_office: "없음 (트림블솔루션즈코리아는 건설/BIM 사업부 — 운송 사업부 별도)"
---

# Trimble Transportation

> 상용차 플릿·텔레매틱스·물류 SW | 중견기업(사업부) | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Westminster, CO, USA |
| 설립 연도 | Trimble Inc. 1978년; Transportation 사업부 독립 운영 |
| 모회사 | Trimble Inc. (NASDAQ: TRMB, 연매출 $3.7B) |
| 임직원 수 | ~1,000명+ (Transportation 사업부 추정) |
| 규모 분류 | 중견기업 (대기업 사업부) |
| 상장 여부 | Trimble Inc. NASDAQ: TRMB |
| 주력 사업 | 트럭 운송 ELD·텔레매틱스·물류 최적화·운전자 안전 SW (TMT Fleet Maintenance, TrimFleet, PC*Miler 경로 최적화) |
| 공식 홈페이지 | https://www.trimbletl.com |

**주요 제품:** PC*Miler (경로·연료 최적화), TMT Fleet Maintenance, TMW Suite (TMS)
**주요 고객:** JB Hunt, Werner Enterprises, 북미 대형 트럭 운송사

---

## 🇰🇷 한국 관련

운송 사업부 한국 사무소 없음. 모회사 Trimble의 한국 법인인 **트림블솔루션즈코리아**(서울 강남구 삼성로96길 19, 청림빌딩 4층)는 건설 BIM(Tekla Structures, SketchUp) 솔루션 담당 — Transportation 사업부와 별개.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 북미 ELD 의무화로 텔레매틱스 수요 안정적.
- PC*Miler 경로 최적화는 업계 표준 툴.
- 모회사 Trimble이 건설·농업·지리공간 사업 분리(AGCO와 합작) 진행 중 — 조직 변동 주의.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 운송 사업부 없음. 물류 SW 특화 — 자동차 임베디드 SW와 직접 연관 낮음. |
| 추천 직무 | SW Engineer (물류·라우팅) — 미국 현지 한정 |
| 한국 지원 경로 | 없음 (트림블솔루션즈코리아는 건설 BIM 전담) |
| 비자 스폰 가능성 | ★★★ — Trimble 대기업 HR, H-1B 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [trimbletl.com](https://www.trimbletl.com)
- 모회사: [trimble.com](https://www.trimble.com)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: trimbletl.com, trimble.com 공식, JobKorea (2026.05 기준)*
