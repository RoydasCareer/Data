---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - automotive/adas
  - fit/★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Helm.ai"
size: "스타트업"
fit: "★★"
business: "AI 기반 ADAS·자율주행 DNN SW (OEM 공급형)"
hq: "Redwood City, California, USA"
founded: "2016"
employees: "78~88명 (2024~2025)"
revenue: "비공개 (비상장)"
ipo_status: "비상장 — Series C $5,500만 (2023.08), 총 조달 ~$1.01~1.65억"
korea_office: "없음"
---

# Helm.ai

> AI 기반 ADAS·자율주행 DNN SW (OEM 공급형) | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Redwood City, California, USA |
| 설립 연도 | 2016 |
| 창업자 | Vlad Voroninski (CEO), Tudor Achim (CTO) |
| 임직원 수 | 78~88명 (2024~2025) |
| 총 투자 유치 | ~$1.01~1.65억 |
| 최근 투자 | **Series C $5,500만 (2023.08)** |
| 주요 투자자 | Honda Motor, Goodyear Ventures, Sungwoo Hitech (성우하이텍), Freeman Group, ACVC Partners, Amplo |
| 상장 여부 | **비상장** |
| 공식 홈페이지 | https://helm.ai |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2016 | Redwood City 창업 — 비지도 학습 DNN 자율주행 연구 시작 |
| 2021 | Volkswagen 파트너십 (ADAS 고객사) |
| 2023.08 | **Series C $5,500만 조달 — Honda Motor 전략적 투자 참여** |
| 2023.11 | 정부 그랜트 $1,000만 추가 획득 |
| 2024 | **Honda와 다년 ADAS 공동개발 협약 체결** (양산차용 L3 자율주행) |
| 2024 | **"자율주행 공급사 올해의 상" (Autonomous Vehicle Provider of the Year)** 수상 |

---

## 🛠️ 주력 제품 상세

| 제품명 | 설명 |
| :--- | :--- |
| **Full-Stack DNN SW** | 비지도 학습 기반 실시간 AI 자율주행 소프트웨어 스택. 인식·판단·제어 전 계층 커버. |
| **Autolabeling 모델** | 대규모 주행 데이터 자동 레이블링 생성형 AI 모델 — 데이터 수집 비용 획기적 절감. |
| **Generative Simulation** | 자율주행 시나리오 생성형 시뮬레이션 모델. OEM 차량 검증 데이터 생성. |
| **Navigate on Autopilot (NOA)** | Honda 협력 개발 중인 고속도로 자율주행 플랫폼 (2027+ 양산 목표). |

---

## 🎯 전략 방향 (2024~2026)

| 분야 | 내용 |
| :--- | :--- |
| **Honda 협력** | 다년 공동개발 협약 — Honda 전 차종 ADAS 확장. 양산 목표 2027년 이후. Honda 추가 투자로 전략적 파트너 관계. |
| **대중화 ADAS** | 럭셔리 차량 한정이 아닌 **대중 시장 양산차** ADAS 공급 전략. |
| **비지도 학습** | 레이블링 없이 원시 영상 데이터로 학습 가능한 DNN — 데이터 비용 경쟁력. |
| **성우하이텍 연결** | 한국 자동차 부품사 성우하이텍이 Series C 투자자 — 한국 자동차 생태계와 간접 연결. |

---

## 📈 성장성

**성장성 평가: ★★★☆☆**

- Honda 다년 협약으로 매출 기반 확보. 2027년 양산 달성 시 수익화 가시화.
- 직원 80명대 소규모이나 Honda·VW 등 대형 OEM 고객 확보로 질적 성장.
- 성우하이텍(한국 Tier-1) 투자 — 향후 현대·기아 계열 공급망 접근 가능성.
- 비지도 학습 DNN 차별화로 데이터 확보 경쟁에서 우위.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | ADAS QA 경력 + CANoe/PCAN 5년+ 경험이 Honda DNN ADAS 검증 프로세스에 연결 가능. 성우하이텍(한국 Tier-1 투자자) 통한 간접 경로 탐색 가능. **한국 오피스 없음**. |
| 추천 직무 | ADAS Integration QA Engineer, Automotive SW Validation Engineer |
| 비자 스폰 가능성 | ★ (저) |
| 고졸 채용 가능성 | 미국 본사: 낮음 (소규모 기업, 엔지니어 중심) |
| 현실적 경로 | 성우하이텍(투자사) 통한 간접 접촉 또는 Honda 한국법인 통한 Helm.ai 프로젝트 참여 |

---

## 🇺🇸 USA 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| H-1B | 학위 필수 + 추첨제 (연간 쿼터 65,000개) — 고졸은 해당 없음 |
| O-1A | 탁월한 능력 입증 시 학위 불필요 — 진입 장벽 높음 |
| 비자 스폰 가능성 | ★ (저) |
| **현실적 경로** | 성우하이텍 또는 Honda 한국 법인 통한 간접 접근 검토 |

---

## 🔗 관련 정보

- 홈페이지: [helm.ai](https://helm.ai)
- 뉴스: [helm.ai/news](https://helm.ai/news)
- 채용: [helm.ai/careers](https://helm.ai/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: helm.ai 공식 페이지, PitchBook, WardsAuto, CBT News, The Robot Report, Wikipedia (Vlad Voroninski), TracXN (2026.06 기준 직접 확인)*
