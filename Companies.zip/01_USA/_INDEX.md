---
tags:
  - index
  - country/usa
country: "미국"
---

# 미국 🇺🇸 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 60개 |
| ★★★ 핵심 추천 | 11개 |
| ★★ 높은 적합성 | 11개 |
| ★ 보통 적합성 | 6개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | H-1B (학위 필수·추첨제), O-1A (탁월한 능력), L-1 (사내 전근) |
| 취득 용이성 | ★ (매우 어려움) |
| 학위 요건 | H-1B는 학사 이상 필수. O-1A는 학위 불필요하나 입증 부담 높음 |
| 현실적 경로 | 한국 지사·파트너사(Applied Intuition 서울, Apex.AI 판교) 통해 국내 지원 → 미국 파견 |
| 참고사항 | 미국 직접 취업은 고졸 스펙으로 매우 어려움. 한국 법인 먼저 노려볼 것. |

## ⭐ 추천 기업 #Recommand

### ★★★ 핵심 추천
- [[Keysight_Technologies|Keysight Technologies]] — 자동차 통신·전장 테스팅 솔루션
- [[MTS_Systems|MTS Systems]] — 차량 테스팅·시뮬레이션 시스템
- [[Danlaw|Danlaw]] — OBD 텔레매틱스·차량 연결 SW
- [[LHP_Engineering_Solutions|LHP Engineering Solutions]] — 자동차 SW 개발·임베디드 엔지니어링
- [[Solera_Holdings|Solera Holdings]] — 자동차 데이터·진단 SW 플랫폼
- [[Mitchell_International|Mitchell International]] — 자동차 수리·진단 SW
- [[Applied_Intuition|Applied Intuition]] — AV 시뮬레이션 (서울 오피스 있음 — 한국 지원 가능)
- [[Apex.AI|Apex.AI]] — ASIL-D 인증 자율주행 미들웨어 (판교 오피스 있음 — 한국 지원 가능)
- [[Motional|Motional (Hyundai-Aptiv JV)]] — 현대차 대주주 자율주행 JV (현대 채용 → 파견 경로)
- [[AutoCrypt_USA|AutoCrypt USA (한국 HQ)]] — V2X·OTA·EV충전 사이버보안·UN R155 (San Jose, 서울 HQ·이니텍 계열)

### ★★ 높은 적합성
- [[Visteon|Visteon Corporation]] — IVI 도메인 컨트롤러(SmartCore)·Android Automotive(AllGo)·디지털 클러스터 글로벌 Tier 1 (NASDAQ: VC)
- [[Harman_International|Harman International (Samsung)]] — 커넥티드카·인포테인먼트·자동차 SW
- [[Garmin_Automotive|Garmin (Automotive Division)]] — OEM 임베디드 내비·DriveAssist ADAS 카메라·플릿 SW (NASDAQ: GRMN)
- [[Spireon|Spireon (Powerfleet)]] — 텔레매틱스·차량 인텔리전스 SW
- [[Helm.ai|Helm.ai]] — AI 기반 ADAS·자율주행 SW
- [[Iteris|Iteris]] — V2X·스마트 모빌리티 인프라 SW
- [[VSI_Labs|VSI Labs]] — 자율주행 차량 연구·테스팅
- [[Scale_AI|Scale AI]] — AV용 데이터 레이블링·AI 학습
- [[Parallel_Domain|Parallel Domain]] — AV 학습용 합성 데이터 생성
- [[Nexar|Nexar]] — 비전 기반 V2X·대시캠 통신 SW
- [[Sonatus|Sonatus]] — AI 기반 SDV 플랫폼 (Hyundai·Nissan 양산 적용, Sunnyvale)
- [[StradVision_USA|StradVision USA (한국 HQ)]] — 카메라 ADAS 인식 SW·SVNet (San Jose·Detroit 2지사, 서울 HQ)
- [[Seoul_Robotics_USA|Seoul Robotics USA (한국 HQ)]] — 3D LiDAR 인식·자율화 인프라 SW (Silicon Valley·Detroit·Atlanta 3지사, 서울 HQ)

## 📋 전체 기업 목록 (적합도 낮은 기업 포함)

### ★ 보통 적합성
- [[Verizon_Connect|Verizon Connect]] — 플릿 관리·GPS 추적 SW
- [[Trimble_Transportation|Trimble Transportation]] — 플릿·텔레매틱스 SW
- [[Ridecell|Ridecell]] — 플릿 자동화 SW
- [[Platform_Science|Platform Science]] — 커넥티드 차량 SW 플랫폼
- [[Samsara|Samsara]] — IoT 플릿 관리·안전 SW
- [[Urgently|Urgently (Otonomo 인수)]] — 자동차 데이터 플랫폼·긴급출동 SW

### 기타 기업
- [[Waymo|Waymo (Alphabet)]] — 자율주행 소프트웨어 플랫폼
- [[NVIDIA|NVIDIA]] — 자율주행 AI 컴퓨팅 (DRIVE 플랫폼)
- [[Tesla|Tesla]] — FSD 소프트웨어·자율주행 시스템
- [[Qualcomm|Qualcomm]] — Snapdragon Digital Chassis·자동차 통신
- [[General_Motors|General Motors (Cruise)]] — 자율주행 차량 SW 개발
- [[Ford|Ford (Latitude AI)]] — ADAS·자율주행 소프트웨어
- [[Amazon|Amazon (Zoox)]] — 자율주행 라이드헤일링 차량 SW
- [[Motorola_Solutions|Motorola Solutions]] — 자동차용 미션크리티컬 통신 SW
- [[Aurora_Innovation|Aurora Innovation]] — 자율주행 시스템 (Aurora Driver)
- [[Kodiak_Robotics|Kodiak Robotics]] — 자율주행 트럭 SW
- [[Gatik|Gatik]] — 자율주행 중간 물류 SW
- [[Motive|Motive (KeepTruckin)]] — 플릿 관리·안전 SW
- [[Nauto|Nauto]] — AI 드라이버 안전·플릿 통신 SW
- [[Cerence|Cerence]] — 자동차 AI 어시스턴트·음성 인식 SW
- [[May_Mobility|May Mobility]] — 자율주행 셔틀 SW
- [[Torc_Robotics|Torc Robotics (Daimler Truck 자회사)]] — 자율주행 트럭 SW
- [[Pronto.ai|Pronto.ai]] — 중장비·트럭 자율주행 안전 시스템
- [[Outrider|Outrider]] — 자율주행 야드 운영 SW
- [[Luminar_Technologies|Luminar Technologies]] — 자율주행 인식·LiDAR SW
- [[Aeva_Technologies|Aeva Technologies]] — 4D LiDAR 인식 SW
- [[Nuro|Nuro]] — 자율배달 로봇 SW
- [[Ambarella|Ambarella]] — 자동차 비전 AI SoC·SW
- [[Waabi_Innovation|Waabi Innovation]] — AI 자율주행 트럭 SW (Canadian HQ)
- [[Perrone_Robotics|Perrone Robotics]] — AV SW 플랫폼
- [[StreetLight_Data|StreetLight Data]] — 모빌리티 애널리틱스
- [[BlueSpace.ai|BlueSpace.ai]] — AV 모션 플래닝 SW
- [[Xos_Trucks|Xos Trucks]] — 전기트럭 SW 플랫폼
- [[Cyngn|Cyngn]] — 산업용 AV SW
- [[Embark_Trucks|Embark Trucks]] — (폐업 2023)
- [[Ghost_Autonomy|Ghost Autonomy]] — (Apple 인수 2024, 독립 종료)
- [[Stack_AV|Stack AV]] — 자율주행 장거리 트럭 SW (Argo AI 창업팀·SoftBank $10억, Pittsburgh)
