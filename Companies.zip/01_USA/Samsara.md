---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/telematics
  - automotive/fleet
  - fit/★★
country: "미국"
country_folder: "01_USA"
company_name: "Samsara"
size: "중견기업"
fit: "★★"
business: "IoT 플릿 안전·운영 클라우드 플랫폼"
hq: "San Francisco, California, USA"
founded: "2015"
employees: "~2,700명 (FY2024)"
revenue: "$1.12B (FY2025)"
ipo_status: "NYSE: IOT (2021년 상장)"
korea_office: "없음 (APAC: 대만 타이베이, 인도 벵갈루루)"
---

# Samsara

> IoT 플릿 안전·운영 클라우드 플랫폼 | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | San Francisco, CA, USA |
| 설립 연도 | 2015년 |
| 창업자 | Sanjit Biswas, John Bicket (前 Cisco Meraki 공동창업자) |
| 임직원 수 | ~2,700명 (FY2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | NYSE: IOT (2021년 12월 IPO) |
| 주력 사업 | 플릿 차량 IoT 센서·대시캠·GPS 추적 + AI 안전 이벤트 감지 클라우드 플랫폼 |
| 공식 홈페이지 | https://www.samsara.com |

**주요 고객:** Amazon, FedEx, Sysco, Halliburton (북미 대형 플릿 운영사)
**경쟁사:** Geotab, Motive, Verizon Connect

---

## 🇰🇷 한국 관련

한국 공식 지사 없음. APAC 거점: 대만(타이베이), 인도(벵갈루루). 한국 시장 미진출.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- FY2025 매출 $1.12B 돌파, YoY 26% 성장 — 흑자 전환 임박.
- 북미 상용차 플릿 안전 규제 강화(ELD 의무화)로 수요 지속.
- AI 비전 기반 안전 이벤트 감지(하이 스코어링) 차별화.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 성장성 높은 상장사. 그러나 한국 사무소 없음 — 미국 현지 근무 필요. |
| 추천 직무 | Embedded SW Engineer (IoT), Backend Platform Engineer |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 상장 중견기업, H-1B 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [samsara.com](https://www.samsara.com)
- 채용: [samsara.com/company/careers](https://www.samsara.com/company/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: samsara.com 공식, NYSE IR (2026.05 기준)*
