---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/adas
  - automotive/fleet
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Nauto"
size: "중견기업"
fit: "★"
business: "AI 기반 상용차 운전자 안전 모니터링 플랫폼"
hq: "Palo Alto, California, USA"
founded: "2015"
employees: "~300명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Nauto

> AI 기반 상용차 운전자 안전 모니터링 | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Palo Alto, CA, USA |
| 설립 연도 | 2015년 |
| 창업자 | Stefan Heck, Na Li |
| 임직원 수 | ~300명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 (Toyota·BMW·Allianz 투자) |
| 주력 사업 | 상용차 AI 대시캠·운전자 집중력 모니터링·사고 예방 SaaS |
| 공식 홈페이지 | https://www.nauto.com |

**투자자:** Toyota AI Ventures, BMW iVentures, Allianz, SoftBank Vision Fund

**차별점:** 차량 외부·내부 동시 촬영으로 운전자 행동(산만함·졸음·전방주시태만) 실시간 감지·경보.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미 집중 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 운전자 안전 AI 시장은 보험사·물류사 수요로 성장 중.
- Toyota·BMW 투자사로 OEM 연계 가능성.
- 아직 수익화 초기 단계.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 운전자 안전 모니터링 SaaS 특화 — 자동차 임베디드 SW와 연관성 낮음. |
| 추천 직무 | Computer Vision Engineer, ML Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — H-1B 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [nauto.com](https://www.nauto.com)
- 채용: [nauto.com/careers](https://www.nauto.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: nauto.com 공식 (2026.05 기준)*
