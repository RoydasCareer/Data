---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/adas
  - automotive/software
  - fit/★★
country: "미국"
country_folder: "01_USA"
company_name: "Cerence"
size: "중견기업"
fit: "★★"
business: "자동차 AI 음성 어시스턴트·HMI SW"
hq: "Burlington, Massachusetts, USA"
founded: "2019 (Nuance 자동차 부문 분사)"
employees: "~1,700명 (2024)"
revenue: "$311M (FY2024)"
ipo_status: "NASDAQ: CRNC"
korea_office: "한국 파트너십 거점 (현대/기아 전담 — 정식 법인 여부 확인 필요)"
---

# Cerence

> 자동차 AI 음성 어시스턴트·HMI SW | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 15 Wayside Rd, Burlington, MA 01803, USA |
| 설립 연도 | 2019년 (Nuance Communications 자동차 부문 분사) |
| 임직원 수 | ~1,700명 (2024) |
| 규모 분류 | 중견기업 |
| 연매출 | **$311M (FY2024)** |
| 상장 여부 | **NASDAQ: CRNC** |
| 주력 사업 | 차량 내 AI 음성 어시스턴트, NLU, 멀티모달 HMI, 자동차 AI SDK |
| 공식 홈페이지 | https://www.cerence.com |

### 주요 제품

| 제품 | 설명 |
| :--- | :--- |
| **Cerence Assistant** | 차량 내 AI 음성 비서. Wake word("Hey BMW" 등) + NLU + TTS. 차종별 커스터마이징. |
| **Cerence Drive** | 클라우드 기반 차량 AI 플랫폼. OTA 업데이트 지원. |
| **Cerence Co-Pilot** | GPT 기반 생성형 AI 자동차 어시스턴트 (2023 출시) |
| **SDK/API** | OEM이 자체 음성 서비스 구축할 수 있는 개발 도구 |

**주요 OEM 고객:** BMW, Mercedes-Benz, Toyota, 현대/기아, Stellantis, Volkswagen, Ford 등 전 세계 500M+ 차량 탑재

---

## 🇰🇷 한국 관련

| 항목 | 내용 |
| :--- | :--- |
| 한국 법인 | 정식 법인 여부 미확인 |
| 주요 한국 파트너 | **현대자동차·기아** — 블루링크, 카카오i 연계 음성 서비스 |
| 한국어 지원 | Cerence 플랫폼에 한국어 TTS/STT/NLU 포함 |

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- **생성형 AI 전환**: Cerence Co-Pilot(GPT 연동) 출시로 ChatGPT 차량 내 경쟁 대응.
- **레거시 의존**: 기존 규칙 기반 음성인식 → 생성형AI로 전환 중, 전환 비용 존재.
- **현대/기아 대형 계약**: 한국 OEM과 장기 공급 관계.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 현대/기아 주요 공급사. 한국어 NLU·TTS 개발 및 한국 OEM 기술지원 포지션 가능성. 음성 AI·HMI 배경이 있다면 연관성 높음. |
| 추천 직무 | Software Engineer (NLU/TTS), Customer Engineering (한국 OEM 담당), Solutions Architect |
| 한국 지원 경로 | cerence.com 채용 페이지 또는 LinkedIn |
| 비자 스폰 가능성 (미국 본사) | ★★ — H-1B 스폰 가능 |
| 고졸 채용 가능성 | 학위 선호 (CS/언어학) |

---

## 🔗 관련 정보

- 홈페이지: [cerence.com](https://www.cerence.com)
- 채용: [cerence.com/careers](https://www.cerence.com/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: cerence.com 공식, NASDAQ 공시 (2026.05 기준)*
