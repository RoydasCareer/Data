---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Gatik"
size: "중견기업"
fit: "★"
business: "자율주행 중간물류(Middle-Mile) 트럭 SW"
hq: "Mountain View, California, USA"
founded: "2017"
employees: "~300명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음 (캐나다 온타리오 거점)"
---

# Gatik

> 자율주행 중간물류 트럭 SW | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Mountain View, CA, USA |
| 설립 연도 | 2017년 |
| 창업자 | Gautam Narang, Arjun Narang |
| 임직원 수 | ~300명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | B2B 창고 간 중간물류(middle-mile) 자율주행 소형 트럭 SW |
| 공식 홈페이지 | https://www.gatik.ai |

**차별점:** 일반도로 자율주행이 아닌 고정된 B2B 물류 루트에 특화 → 자율주행 규제 리스크 최소화.

**주요 파트너:** Walmart, Kroger, Tyson Foods, Canadian Tire

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미(미국·캐나다) 집중 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- B2B 물류 루트 특화로 규제 리스크가 낮아 상용화가 빠름.
- Walmart 등 대형 유통사와 파트너십으로 안정적 수요.
- 아직 비상장이며 수익화 초기 단계.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 북미 집중. 자율주행 SW 배경 관련성 있으나 미국 현지 거주 필수. |
| 추천 직무 | Autonomy SW Engineer, Motion Planning Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — 비상장이나 스폰 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [gatik.ai](https://www.gatik.ai)
- 채용: [gatik.ai/careers](https://www.gatik.ai/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: gatik.ai 공식 (2026.05 기준)*
