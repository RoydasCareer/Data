---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Nuro"
size: "중견기업"
fit: "★"
business: "자율배달 로봇 차량 및 자율주행 SW"
hq: "Mountain View, California, USA"
founded: "2016"
employees: "~300명 (2024, 감원 후)"
revenue: "비공개 (정부 계약 중심)"
ipo_status: "비상장 ($8.6B 기업가치, 2021년 기준)"
korea_office: "없음"
---

# Nuro

> 자율배달 로봇 차량 | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Mountain View, CA, USA |
| 설립 연도 | 2016년 |
| 창업자 | Dave Ferguson, Jiajun Zhu (前 Google Self-Driving Car 팀) |
| 임직원 수 | ~300명 (2023년 30% 감원 후) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 ($8.6B 기업가치, 2021년 SoftBank $600M 투자) |
| 주력 사업 | 소형 자율배달 로봇 차량(R2/R3) 및 자율주행 SW 라이선싱 |
| 공식 홈페이지 | https://www.nuro.ai |

**주요 고객/파트너:** 미 국방부(DARPA 계약), Walmart, Domino's, Kroger (과거)

**현황:** 2023년 소비자 배달 서비스 중단 후 DoD 자율주행 계약으로 피벗.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 미국 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 소비자 배달 서비스 중단 후 국방부 계약으로 피벗 — 방향 전환 중.
- 대규모 감원으로 재무 압박 확인됨.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. DoD 계약 전환으로 미국 시민권/영주권자 선호 가능성. 재무 불확실성 큼. |
| 추천 직무 | Autonomy SW Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — DoD 계약으로 외국인 채용 제한 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [nuro.ai](https://www.nuro.ai)
- 채용: [nuro.ai/careers](https://www.nuro.ai/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: nuro.ai 공식, 뉴스 (2026.05 기준)*
