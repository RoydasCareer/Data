---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/autonomous
  - fit/★★
country: "미국"
country_folder: "01_USA"
company_name: "Waabi Innovation"
size: "스타트업"
fit: "★★"
business: "AI 자율주행 트럭 SW (캐나다 본사)"
hq: "Toronto, Ontario, Canada (미국 사무소: Austin, TX)"
founded: "2021"
employees: "~150명 (2024)"
revenue: "비공개 ($83.5M 시리즈 A 조달)"
ipo_status: "비상장"
korea_office: "없음"
---

# Waabi Innovation

> AI 자율주행 트럭 SW | 스타트업 | 캐나다/미국 🇨🇦🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Toronto, Ontario, Canada (미국: Austin, TX) |
| 설립 연도 | 2021년 |
| 창업자 | Raquel Urtasun (前 Uber ATG Chief Scientist, U of Toronto 교수) |
| 임직원 수 | ~150명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 ($83.5M 시리즈 A — Khosla Ventures, DCVC, Uber) |
| 주력 사업 | AI-first 접근법으로 대규모 실도로 테스트 없이 시뮬레이션 기반 자율주행 트럭 SW 개발 (Waabi World 시뮬레이터) |
| 공식 홈페이지 | https://waabi.ai |

**차별점:** 실도로 주행 최소화 — 생성형 AI 시뮬레이션(Waabi World)으로 훈련·검증.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- AI 기반 자율주행 접근법으로 업계 주목.
- 창업자 학문적 배경(머신러닝 권위자)으로 기술력 인정.
- 초기 스타트업으로 상용화까지 시간 소요.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | AI/ML 자율주행 핵심 기술. 그러나 캐나다 본사·한국 사무소 없음. 북미 현지 필요. |
| 추천 직무 | ML Engineer (자율주행) — 캐나다/미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — 캐나다 워크퍼밋 또는 미국 H-1B |
| 고졸 채용 가능성 | 석사/박사 선호 |

---

## 🔗 관련 정보

- 홈페이지: [waabi.ai](https://waabi.ai)
- 채용: [waabi.ai/join](https://waabi.ai/join)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: waabi.ai 공식, LinkedIn (2026.05 기준)*
