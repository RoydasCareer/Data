---
tags:
  - company
  - automotive
  - country/usa
  - size/startup
  - automotive/software
  - automotive/safety
  - automotive/sdv
  - fit/★★★
  - recommend
country: "미국"
country_folder: "01_USA"
company_name: "Apex.AI"
size: "스타트업"
fit: "★★★"
business: "자율 모빌리티용 ASIL-D 안전 인증 미들웨어 SW"
hq: "Palo Alto, California, USA"
founded: "2017"
employees: "51~200명 (추정)"
revenue: "비공개 (비상장)"
ipo_status: "비상장 — Series B 확장 라운드 (LG전자 전략적 투자, 2025.02), 총 조달 $75~87.5M"
korea_office: "판교 오피스 운영 중 (2023.05 개설, 경기도 성남시 분당구 판교)"
---

# Apex.AI

> 자율 모빌리티용 ASIL-D 안전 인증 미들웨어 SW | 스타트업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Palo Alto, California, USA |
| 추가 오피스 | Munich (독일), Stuttgart (독일), Tokyo (일본), **Pangyo, Korea (한국)** |
| 설립 연도 | 2017 |
| 창업자 | Jan Becker (CEO), Dejan Pangercic (CTO) |
| 임직원 수 | 51~200명 (추정) |
| 총 투자 유치 | ~$75~87.5M (7라운드) |
| 최근 투자 | Series B 확장 — **LG전자 전략적 투자 (2025.02)** |
| 주요 투자자 | LG전자, Daimler Truck, Continental, Volvo Group, ZF Ventures, Toyota Ventures, JLR(InMotion Ventures), Airbus Ventures, HELLA Ventures |
| 상장 여부 | **비상장** |
| 공식 홈페이지 | https://www.apex.ai |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 2017 | Palo Alto 창업 — ROS 2 기반 자동차 안전 SW 개발 시작 |
| 2022.02 | **Apex.OS ASIL-D 기능안전 인증 취득 (TÜV Nord)** — 자동차용 ROS 2 최초 인증 |
| 2022.01 | CES 2022에서 Green Hills Software(INTEGRITY RTOS)와 ASIL-D 협업 발표 |
| 2023.05 | **한국 판교 오피스 개설** |
| 2025.02 | **LG전자 전략적 투자 유치** (Series B 확장) |

---

## 🛠️ 주력 제품 상세

| 제품명 | 설명 |
| :--- | :--- |
| **Apex.OS (현 Apex.Grace)** | ROS 2 기반 자동차 등급 안전 인증 메타 OS. **ISO 26262 ASIL-D (최고 등급)** TÜV Nord 인증. 결정론적 실시간 처리. SDV·자율주행 애플리케이션 타깃. |
| **Apex.Grace** | Apex.OS의 애플리케이션 런타임 프레임워크 및 SDK. |
| **Apex.Ida** | 고성능 통신 미들웨어 — ECU 간 데이터 전송 최적화. |
| **AUTOSAR 통합** | Classic/Adaptive AUTOSAR와 ROS 2 브리지 — SDV 아키텍처 호환. |

---

## 🎯 전략 방향 (2024~2026)

| 분야 | 내용 |
| :--- | :--- |
| **SDV (소프트웨어 정의 차량)** | AUTOSAR + ROS 2 통합으로 SDV 전환 핵심 미들웨어 공급자 포지셔닝. |
| **아시아 확장** | 판교(한국)·도쿄(일본) 오피스 통한 아시아 완성차 직접 공략. |
| **LG전자 파트너십** | LG전자 투자 이후 가전·모빌리티 SDV 플랫폼 연동 확대 기대. |
| **JLR 연결** | InMotion Ventures(JLR 벤처 부문) 투자사 — JLR DoIP 생태계와 접점. |
| **안전 인증** | ASIL-D SEooC 인증으로 Tier-1 공급사·OEM 직접 납품 경쟁력 확보. |

---

## 📈 성장성

**성장성 평가: ★★★★☆**

- ASIL-D 인증 ROS 2 미들웨어는 시장 내 사실상 독보적 포지션.
- JLR·Continental·Volvo·LG전자 등 Tier-1 전략적 투자자 → 고객사 전환 가능성.
- SDV 시장 2025년 $28억 → 2033년 $86억 예상 (연 15%+ 성장).
- **한국 판교 오피스 개설** — 현대·기아·LG전자 등 국내 고객 영업 활성화.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | **판교 한국 오피스 존재**. JLR DoIP 실차 경험 + CANoe 5년+ 경력이 Apex.OS 기반 ECU 통신 미들웨어 검증에 직접 연결. JLR(InMotion Ventures)이 투자사이므로 JLR 프로젝트 연계 가능성. LG전자 투자 이후 한국 내 고객사 영업·기술지원 수요 증가 예상. |
| 추천 직무 | Application Engineer (Korea), Automotive SW Integration Engineer, Technical Support (AUTOSAR/ROS 2) |
| 한국 지사 지원 | apex.ai/koreaoffice 또는 apex.ai/careers |
| 비자 스폰 가능성 | ★ (미국 본사 직접 지원 시) |
| **현실적 경로** | **판교 한국 오피스 직접 지원이 가장 현실적** |
| 고졸 채용 가능성 | 한국 오피스: 경력·실무 중심이면 가능성 있음 |

---

## 🇺🇸 USA 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| H-1B | 학위 필수 + 추첨제 (연간 쿼터 65,000개) — 고졸은 해당 없음 |
| O-1A | 탁월한 능력 입증 시 학위 불필요 — 진입 장벽 높음 |
| 비자 스폰 가능성 | ★ (저) |
| **현실적 경로** | **판교 한국 오피스 국내 지원 강력 권장** |

---

## 🔗 관련 정보

- 홈페이지: [apex.ai](https://www.apex.ai)
- 한국 오피스: [apex.ai/koreaoffice](https://www.apex.ai/koreaoffice)
- 채용: [apex.ai/careers](https://www.apex.ai/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: apex.ai 공식 페이지, PitchBook, TracXN, FreightWaves, The Robot Report, GHS.com (CES 2022) (2026.06 기준 직접 확인)*
