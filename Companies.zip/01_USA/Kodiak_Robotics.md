---
tags:
  - company
  - automotive
  - country/usa
  - size/mid
  - automotive/autonomous
  - fit/★
country: "미국"
country_folder: "01_USA"
company_name: "Kodiak Robotics"
size: "중견기업"
fit: "★"
business: "자율주행 장거리 트럭 SW (국방부 계약 포함)"
hq: "Mountain View, California, USA"
founded: "2018"
employees: "~300명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Kodiak Robotics

> 자율주행 장거리 트럭 SW | 중견기업 | 미국 🇺🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Mountain View, CA, USA |
| 설립 연도 | 2018년 |
| 창업자 | Don Burnette (前 Waymo), Paz Eshel |
| 임직원 수 | ~300명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 장거리(OTR) 자율주행 트럭 SW, 미국 국방부(DoD) 자율주행 군용차 계약 |
| 공식 홈페이지 | https://kodiak.ai |

**차별점:** 상업용 트럭과 미 국방부 군용차 모두에 자율주행 SW 공급 — 민·군 이중 시장.

**주요 파트너:** Bridgestone, Werner, Contract Freighters(CFI), USAF(미 공군)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 미국 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- DoD 계약으로 상업화 전 안정적 수익원 확보.
- 군용 자율주행 시장은 성장 중.
- 비상장으로 자금 조달 리스크 있음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. DoD 계약으로 미국 시민권/영주권자 선호 가능성. |
| 추천 직무 | Autonomy SW Engineer — 미국 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — DoD 계약으로 외국인 채용 제한 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [kodiak.ai](https://kodiak.ai)
- 채용: [kodiak.ai/careers](https://kodiak.ai/careers)
- 국가 인덱스: [[_INDEX|미국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: kodiak.ai 공식 (2026.05 기준)*
