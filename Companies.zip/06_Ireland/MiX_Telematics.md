---
tags:
  - company
  - automotive
  - country/ireland
  - size/large
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "MiX Telematics (Ireland)"
size: "대기업"
fit: "★"
business: "텔레매틱스·플릿 관리 (남아공 HQ, PowerFleet 합병)"
hq: "Stellenbosch, South Africa (HQ) / 아일랜드 운영"
founded: "1996"
employees: "(PowerFleet 통합)"
revenue: "비공개"
ipo_status: "비상장 (PowerFleet NASDAQ: PWFL 자회사)"
korea_office: "없음"
---

# MiX Telematics (Ireland)

> 텔레매틱스·플릿 관리 | PowerFleet 자회사 | 아일랜드 🇮🇪 운영

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Stellenbosch, South Africa (HQ) / 아일랜드 운영 |
| 설립 연도 | 1996년 |
| 임직원 수 | (PowerFleet 통합) |
| 규모 분류 | 대기업 (PowerFleet 자회사) |
| 상장 여부 | 비상장 (PowerFleet NASDAQ: PWFL 자회사) |
| 주력 사업 | 플릿 관리, 운전자 안전, 차량 도난 추적·복구 텔레매틱스 |
| 공식 홈페이지 | https://www.mixtelematics.com |

1996년 남아프리카 스텔렌보스 창업. NYSE(MIXT) 및 JSE 이중 상장 후 **2023년 PowerFleet(NASDAQ: PWFL)과 합병**. 글로벌 플릿 관리·운전자 안전·차량 도난 추적 텔레매틱스 플랫폼. 아프리카·유럽·미주·아시아 운영. 아일랜드는 유럽 운영 거점.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- PowerFleet 합병으로 글로벌 확장
- 남아공 HQ — 아일랜드는 운영 거점
- 자동차 SW 엔지니어 채용 여력 낮음 (운영 거점)

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 남아공 HQ 기업 — 아일랜드는 운영 거점. 자동차 SW 경력 직결성 낮음 |
| 추천 직무 | 해당없음 (자동차 SW 관점) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 아일랜드 운영 거점, 독립 채용 여부 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [mixtelematics.com](https://www.mixtelematics.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: mixtelematics.com 공개 정보 (2026.05 기준)*
