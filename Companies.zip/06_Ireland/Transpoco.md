---
tags:
  - company
  - automotive
  - country/ireland
  - size/small
  - automotive/telematics
  - automotive/fleet
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Transpoco"
size: "중소기업"
fit: "★★"
business: "아일랜드·UK 중소기업용 플릿 관리·텔레매틱스 SaaS"
hq: "Dublin, Ireland"
founded: "~2006년"
employees: "~50명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Transpoco

> 플릿 관리·텔레매틱스 SaaS | 중소기업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland |
| 설립 연도 | ~2006년 |
| 임직원 수 | ~50명 (확인 필요) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | GPS 기반 플릿 관리, 운전 행동 분석, 연료 효율 모니터링 SaaS |
| 공식 홈페이지 | https://transpoco.com |

더블린 창업 아일랜드 토종 플릿 관리 SaaS 기업. 중소기업 플릿(트럭·밴·영업 차량) 대상 GPS 위치 추적, 운전 행동 점수화, 연료 모니터링, 정비 일정 관리. 아일랜드·UK 시장 집중. 실시간 데이터 분석을 통한 플릿 비용 절감·사고 예방.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 아일랜드·UK 중소기업 플릿 시장 — 성장 규모 제한적
- 소규모 로컬 SaaS 기업 — 자동차 SW 엔지니어 채용 여력 낮음

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 차량 GPS·텔레매틱스 SaaS — 자동차 통신·데이터 경험 연관 가능 |
| 추천 직무 | Backend Engineer (차량 데이터), Telematics SW Engineer |
| 한국 지원 경로 | 없음 (더블린 직접 지원) |
| 비자 스폰 가능성 | ★★ — Critical Skills Employment Permit (소규모, 스폰 여부 확인 필요) |
| 고졸 채용 가능성 | 소규모 기업 — 실무 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [transpoco.com](https://transpoco.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: transpoco.com 공개 정보 (2026.05 기준)*
