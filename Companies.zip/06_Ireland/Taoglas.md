---
tags:
  - company
  - automotive
  - country/ireland
  - size/mid
  - automotive/hardware
  - automotive/connectivity
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Taoglas"
size: "중견기업"
fit: "★★"
business: "자동차·IoT용 안테나·RF 모듈 설계·제조"
hq: "Dublin, Ireland"
founded: "2004"
employees: "~500명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Taoglas

> 자동차·IoT용 안테나·RF 모듈 | 중견기업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland |
| 설립 연도 | 2004년 |
| 임직원 수 | ~500명 (확인 필요) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자동차·IoT·산업용 안테나, GPS/GNSS, LTE/5G, V2X RF 모듈 설계·제조 |
| 공식 홈페이지 | https://www.taoglas.com |

2004년 더블린 창업. IoT·자동차·산업용 안테나 및 RF(무선 주파수) 솔루션 전문 중견기업. **자동차 등급(AEC-Q200) 안테나** 설계 및 제조 — GPS/GNSS, LTE/5G, V2X(차량통신), Bluetooth, Wi-Fi 등 다양한 주파수 지원. 글로벌 자동차 OEM 및 Tier1 공급. 아일랜드·미국·독일·중국 등 글로벌 거점 운영.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 현대·기아 부품 공급 가능성 있으나 미확인.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 커넥티드카·V2X·5G 자동차 안테나 수요 급증
- 자동차 안테나는 하드웨어 제조 중심 — SW 엔지니어 직접 채용 제한적
- 아일랜드 중견기업 안정적 기반

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 RF·안테나 하드웨어 — 자동차 통신 SW 경험 연관 가능 (RF 테스팅, V2X 프로토콜) |
| 추천 직무 | RF SW Engineer, Antenna Test Engineer, Automotive Connectivity Engineer |
| 한국 지원 경로 | 없음 (더블린 직접 지원) |
| 비자 스폰 가능성 | ★★ — Critical Skills Employment Permit (중견기업) |
| 고졸 채용 가능성 | 기술 자격·실무 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [taoglas.com](https://www.taoglas.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: taoglas.com 공개 정보 (2026.05 기준)*
