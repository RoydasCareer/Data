---
tags:
  - company
  - automotive
  - country/ireland
  - size/small
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "SynX (Transpoco 자회사)"
size: "중소기업"
fit: "★"
business: "플릿·연료 관리 SaaS (Transpoco 자회사 브랜드)"
hq: "Dublin, Ireland"
founded: "(Transpoco 자회사)"
employees: "(Transpoco 통합)"
revenue: "비공개"
ipo_status: "비상장 (Transpoco 자회사)"
korea_office: "없음"
---

# SynX (Transpoco 자회사)

> 플릿·연료 관리 SaaS | Transpoco 자회사 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland |
| 설립 연도 | (Transpoco 자회사) |
| 임직원 수 | (Transpoco 통합) |
| 규모 분류 | 중소기업 (Transpoco 자회사) |
| 상장 여부 | 비상장 (Transpoco 자회사) |
| 주력 사업 | 플릿 관리·연료 모니터링·운전 행동 분석 SaaS |
| 공식 홈페이지 | https://synx.ai |

Transpoco(더블린 플릿 관리 SaaS)의 자회사·제품 브랜드. SynX는 AI 기반 플릿·연료·탄소 배출 관리 플랫폼. Transpoco와 실질적으로 동일 기업. 아일랜드·UK 중소기업 플릿 대상. 자동차 SW 엔지니어링과 직접 연관 낮음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- Transpoco/SynX 플릿 SaaS 시장 꾸준한 수요
- 자동차 SW 취업 직결성 낮음

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 플릿 연료 관리 SaaS — 자동차 SW 경력 직결성 낮음. Transpoco 자회사로 독립 채용 가능성 낮음 |
| 추천 직무 | 해당없음 (자동차 SW 관점) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모 자회사 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [synx.ai](https://synx.ai)
- 관련: [[Transpoco]]
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: synx.ai 공개 정보 (2026.05 기준)*
