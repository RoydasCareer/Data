---
tags:
  - company
  - automotive
  - country/ireland
  - size/large
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Masternaut (Ireland)"
size: "대기업"
fit: "★"
business: "텔레매틱스·플릿 관리 (프랑스 HQ, Michelin 자회사)"
hq: "Lyon, France (HQ) / 아일랜드·UK 운영"
founded: "1995"
employees: "(Michelin 통합)"
revenue: "비공개 (Michelin 자회사)"
ipo_status: "비상장 (Michelin 자회사)"
korea_office: "없음"
---

# Masternaut (Ireland)

> 텔레매틱스·플릿 관리 | Michelin 자회사 | 아일랜드 🇮🇪 운영

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Lyon, France (HQ) / 아일랜드·UK 운영 |
| 설립 연도 | 1995년 |
| 임직원 수 | (Michelin 통합) |
| 규모 분류 | 대기업 (Michelin 자회사) |
| 상장 여부 | 비상장 (Michelin SA EURONEXT: ML 자회사) |
| 주력 사업 | 차량 GPS·텔레매틱스, 플릿 관리, 운전 행동 분석 |
| 공식 홈페이지 | https://www.masternaut.com |

1995년 프랑스 리옹 창업. 유럽 최대 플릿 텔레매틱스 기업 중 하나. **2014년 Michelin(미슐랭) 그룹에 인수**. GPS 기반 차량 추적, 운전 행동 분석, 연료 효율 모니터링. 아일랜드·UK·프랑스·스페인 등 유럽 전역 운영. 아일랜드는 운영 거점.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- Michelin 편입으로 안정적 사업 기반
- 플릿 텔레매틱스 시장 꾸준한 수요
- 아일랜드는 운영 거점 — 본사 채용 아님

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 프랑스 HQ 기업 — 아일랜드는 운영 거점. 자동차 SW 경력 직결성 낮음 |
| 추천 직무 | 해당없음 (자동차 SW 관점) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 아일랜드 운영 거점, 독립 채용 여부 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [masternaut.com](https://www.masternaut.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: masternaut.com 공개 정보 (2026.05 기준)*
