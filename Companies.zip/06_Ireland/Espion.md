---
tags:
  - company
  - automotive
  - country/ireland
  - size/startup
  - automotive/cybersecurity
  - automotive/security
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Espion (BSI)"
size: "스타트업"
fit: "★★"
business: "IT·자동차 보안 컨설팅 (BSI Group 자회사)"
hq: "Dublin, Ireland"
founded: "~2000년"
employees: "(BSI 통합)"
revenue: "비공개"
ipo_status: "비상장 (BSI Group 자회사)"
korea_office: "없음"
---

# Espion (BSI)

> IT·자동차 보안 컨설팅 | BSI Group 자회사 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland |
| 설립 연도 | ~2000년 |
| 임직원 수 | (BSI 통합) |
| 규모 분류 | 스타트업 (BSI Group 자회사) |
| 상장 여부 | 비상장 (BSI Group 자회사) |
| 주력 사업 | IT 보안 컨설팅, 침투 테스팅, ISO 인증 지원 |
| 공식 홈페이지 | https://www.bsigroup.com |

더블린 창업 보안 컨설팅 기업. 정보보안 컨설팅·침투 테스팅·ISO 27001 인증 지원 전문. **BSI Group**(영국 표준화 기관, British Standards Institution)에 인수·편입. BSI 아일랜드 사이버보안 사업부로 운영. 자동차 ISO/SAE 21434, UN R155 준수 컨설팅 등 자동차 보안 서비스 제공 가능.

---

## 🇰🇷 한국 관련

한국 사무소 없음. BSI Korea 법인은 별도 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- BSI Group 편입으로 안정적 사업 기반 — 글로벌 표준화 기관 인지도 활용
- 자동차 사이버보안 인증·컨설팅 수요 증가
- 독립 스타트업 성장보다 모회사 전략에 종속

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 보안 컨설팅·ISO 인증 — 차량 보안 분야 경험 활용 가능. BSI 브랜드로 안정적 환경 |
| 추천 직무 | Security Consultant, Automotive Cybersecurity Engineer, ISO 21434 Auditor |
| 한국 지원 경로 | BSI Korea를 통한 내부 전환 가능 (확인 필요) |
| 비자 스폰 가능성 | ★★ — BSI 글로벌 법인 (Critical Skills Employment Permit) |
| 고졸 채용 가능성 | 보안 자격증·실무 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [bsigroup.com](https://www.bsigroup.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: BSI Group 공개 정보 (2026.05 기준)*
