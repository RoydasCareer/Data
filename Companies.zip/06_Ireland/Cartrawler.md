---
tags:
  - company
  - automotive
  - country/ireland
  - size/mid
  - automotive/mobility
  - fit/★
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "CarTrawler"
size: "중견기업"
fit: "★"
business: "B2B 렌터카·지상 교통 예약 기술 플랫폼 (항공사·OTA 파트너)"
hq: "Dublin, Ireland"
founded: "2004"
employees: "~500명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# CarTrawler

> B2B 렌터카·지상 교통 예약 플랫폼 | 중견기업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland |
| 설립 연도 | 2004년 |
| 임직원 수 | ~500명 (확인 필요) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 항공사·OTA 파트너 B2B 렌터카·셔틀·택시 예약 API 플랫폼 |
| 공식 홈페이지 | https://www.cartrawler.com |

더블린 창업. 항공사(Ryanair, easyJet 등)와 OTA(온라인 여행사)가 자사 플랫폼에 렌터카·지상 교통 예약을 통합할 수 있도록 B2B API 기술 제공. 150개+ 항공사 파트너. 여행 테크 기업 — 자동차 SW 개발과 직접 연관 없음.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 더블린 중심 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 여행 회복에 따른 렌터카 예약 수요 증가
- 여행 테크 틈새 시장 안정적
- 자동차 SW 엔지니어 취업 직결성 낮음

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 여행 테크 기업 — 자동차 임베디드·ADAS SW 경력 직결성 없음 |
| 추천 직무 | Backend Engineer, API Engineer |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — Critical Skills Employment Permit (중견기업, 적극 채용) |
| 고졸 채용 가능성 | 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [cartrawler.com](https://www.cartrawler.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: cartrawler.com 공식 (2026.05 기준)*
