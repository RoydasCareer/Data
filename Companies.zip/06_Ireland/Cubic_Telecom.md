---
tags:
  - company
  - automotive
  - country/ireland
  - size/mid
  - automotive/connectivity
  - automotive/esim
  - fit/★★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Cubic Telecom"
size: "중견기업"
fit: "★★★"
business: "커넥티드카 eSIM·글로벌 데이터 연결 (더블린 HQ)"
hq: "Dublin, Ireland"
founded: "2007"
employees: "~300명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Cubic Telecom

> 커넥티드카 eSIM·글로벌 데이터 연결 | 중견기업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland |
| 설립 연도 | 2007년 |
| 임직원 수 | ~300명 (확인 필요) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 커넥티드카 eSIM 기반 글로벌 모바일 데이터 연결 플랫폼 |
| 공식 홈페이지 | https://www.cubictelecom.com |

2007년 더블린 창업. 자동차용 eSIM·MVNO(가상 이동통신) 기반 글로벌 데이터 연결 플랫폼 제공. **Volkswagen Group**(VW, Audi, SEAT, Škoda), **Stellantis** 등 주요 자동차 OEM 파트너. 차량에 내장된 eSIM을 통해 해외에서도 현지 데이터 요금제 자동 전환 제공. Audi AG가 지분 투자. IoT·자동차 M2M 통신 전문.

---

## 🇰🇷 한국 관련

한국 사무소 없음. Volkswagen/Audi 한국 판매 차량에 Cubic Telecom 연결 기술 탑재 가능성 있음.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- 커넥티드카 시장 급성장 — 2030년 전 신차 대부분 상시 연결 예상
- Volkswagen Group·Stellantis 등 대형 OEM 파트너십 — 안정적 수익 기반
- eSIM·5G 전환 가속으로 차량 내 데이터 수요 폭증
- 아일랜드 자동차 SW 분야 대표 중견기업

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 커넥티드카 eSIM·통신 SW — 자동차 통신 프로토콜(DoIP·CAN) 경험 활용 가능. VW Group 파트너사로 안정성 높음 |
| 추천 직무 | Embedded SW Engineer, Automotive Connectivity Engineer, IoT Platform Engineer |
| 한국 지원 경로 | 없음 (더블린 본사 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Critical Skills Employment Permit (중견기업, 성장세) |
| 고졸 채용 가능성 | 기술 경험·포트폴리오 중시 |

---

## ⚠️ 리스크 / 고려사항

- **비상장·비공개 재무**: 재무 상태 및 경영 안정성 외부 파악 어려움
- **소규모 (~300명)**: 채용 포지션 수 제한적, 공고 빈도 낮을 수 있음
- **VW Group 의존도**: 주요 수익이 VW·Stellantis에 집중 — 파트너 관계 변화 시 리스크
- **한국 오피스 없음**: 더블린 본사 직접 지원 및 현지 거주 필요
- **직원 수 미확인**: ~300명은 추정치 — 실제 규모 채용 공고 통해 재확인 권장

## 🔗 관련 정보

- 홈페이지: [cubictelecom.com](https://www.cubictelecom.com)
- LinkedIn: [linkedin.com/company/cubictelecom](https://www.linkedin.com/company/cubictelecom/)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: cubictelecom.com 공개 정보 (2026.05 기준)*
