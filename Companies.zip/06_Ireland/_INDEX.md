---
tags:
  - index
  - country/ireland
country: "아일랜드"
---

# 아일랜드 🇮🇪 자동차·스마트모빌리티 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 29개 |
| ★★★ 핵심 추천 | 3개 |
| ★★ 높은 적합성 | 13개 |
| ★ 보통 적합성 | 13개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | Critical Skills Employment Permit (CSEP) |
| 취득 용이성 | ★★ |
| 학위 요건 | IT·엔지니어링은 경험 인정 가능 |
| 급여 요건 | €32,000+/년 (Critical Skills 기준) |
| 소득세 | 최고 40% (USC 포함 실효세율 ~50%) |
| 참고사항 | Aptiv 글로벌 HQ 더블린. 자동차 기술직 외국인 채용 활발. 영어 환경. |

## ⭐ 추천 기업 #Recommand

### ★★★★★ 최우선 추천 (2026-07-31 신규 — JLR 직접 경험 완전 일치)
- [[JLR_Shannon|Jaguar Land Rover Shannon Engineering Centre]] — JLR SW·전기화·ADAS 개발 아일랜드 허브 (Shannon, Co. Clare)

### ★★★ 핵심 추천
- [[Aptiv|Aptiv (Global HQ: Dublin)]] — 자동차 SW·전장 아키텍처·자율주행 플랫폼 (NASDAQ: APTV)
- [[Cubic_Telecom|Cubic Telecom]] — 커넥티드카·V2X 통신 SW (HQ: Dublin, Volkswagen·Audi·SEAT 고객)
- [[HARMAN_Ireland|HARMAN International (Ireland)]] — 커넥티드카·ADAS·사이버보안 SW (Samsung 자회사, Dublin)
- [[Valeo_Ireland|Valeo Ireland]] — ADAS 카메라·레이더 R&D·제조 (Tuam, Co. Galway)
- [[Continental_Cork|Continental Automotive Ireland]] — ADAS·EV 파워트레인·안전 시스템 R&D (Limerick/Cork)

### ★★ 높은 적합성
- [[Qualcomm_Ireland|Qualcomm Ireland (Cork R&D)]] — 자동차 반도체·Snapdragon Ride ADAS SoC (Cork, 2026 확장)
- [[Provizio|Provizio]] — 5D 레이더 인식 SW (HQ: Limerick)
- [[Decawave|Decawave (Qorvo)]] — 자동차 보안용 UWB·정밀 측위 SW
- [[Taoglas|Taoglas]] — 자동차 안테나·RF·커넥티비티 SW
- [[MiX_Telematics|MiX Telematics (Ireland)]] — 텔레매틱스·플릿 안전 SW (JSE 상장)
- [[Fleetmatics|Fleetmatics (Verizon Connect)]] — 텔레매틱스·플릿 관리 SW
- [[Transpoco|Transpoco]] — 텔레매틱스·플릿 관리 SW (HQ: Dublin)
- [[Ward_Solutions|Ward Solutions]] — 자동차 사이버보안·침투 테스팅
- [[Integrity360|Integrity360]] — 자동차 사이버보안·MDR 서비스
- [[Smarttech247|Smarttech247]] — 자동차 사이버보안·SOC
- [[CommSec|CommSec]] — 자동차 사이버보안·테스팅
- [[Espion|Espion (BSI)]] — 자동차 데이터 보안·QA
- [[Exigent_Networks|Exigent Networks]] — 자동차 통신·네트워킹

## 📋 전체 기업 목록

### ★ 보통 적합성
- [[SynX|SynX (Transpoco 자회사)]] — 플릿·연료 관리 SW
- [[GreenRoad|GreenRoad (Ireland)]] — 운전 행동·안전 분석 SW
- [[Masternaut|Masternaut (Ireland)]] — 텔레매틱스·플릿 SW
- [[Vehicle_Management_System|Vehicle Management System (VMS)]] — 플릿 관리 SW
- [[Tines|Tines]] — 보안 자동화·SOAR (자동차 사이버보안 워크플로우)
- [[Evervault|Evervault]] — 자동차 데이터 암호화·개인정보 SW
- [[TitanHQ|TitanHQ]] — 엔터프라이즈 보안 SW (자동차 OT 포함)
- [[Moovit|Moovit (Israel HQ, Ireland 운영)]] — 대중교통·MaaS 경로 최적화
- [[Manna_Drone_Delivery|Manna Drone Delivery]] — 자율 드론 배달 SW (Oranmore, Galway)
- [[Cartrawler|Cartrawler]] — 카 렌털·모빌리티 SW B2B 플랫폼
- [[MotorCheck_Ireland|MotorCheck Ireland]] — 차량 이력·데이터 검증 SW
- [[Credo_Mobile|Credo Mobile]] — 모바일·IoT 커넥티드카 SW
- [[Derisk360|Derisk360]] — 자동차 리스크·규정 준수 SW
