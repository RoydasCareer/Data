---
tags:
  - company
  - automotive
  - country/ireland
  - size/large
  - automotive/telematics
  - automotive/fleet
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Fleetmatics (Verizon Connect)"
size: "대기업"
fit: "★★"
business: "차량 GPS·텔레매틱스·플릿 관리 (Verizon Connect로 합병)"
hq: "Dublin, Ireland (창업) → Verizon Connect 편입"
founded: "2004"
employees: "(Verizon 통합)"
revenue: "비공개 (Verizon 자회사)"
ipo_status: "비상장 (Verizon Communications 자회사)"
korea_office: "없음"
---

# Fleetmatics (Verizon Connect)

> GPS 플릿 관리·텔레매틱스 | Verizon Connect | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland (창업) → Verizon Connect 편입 |
| 설립 연도 | 2004년 |
| 임직원 수 | (Verizon 통합) |
| 규모 분류 | 대기업 (Verizon 자회사) |
| 상장 여부 | 비상장 (Verizon Communications NYSE: VZ 자회사) |
| 주력 사업 | GPS 기반 차량 위치 추적·플릿 관리·운전 행동 분석 |
| 공식 홈페이지 | https://www.verizonconnect.com |

2004년 더블린 창업. GPS·텔레매틱스 기반 B2B 플릿 관리 SaaS 플랫폼. 차량 위치·연료·운전 행동·정비 일정 통합 관리. **2012년 NYSE 상장**(FLTX). **2016년 Verizon Communications이 24억 달러에 인수**. 이후 Telogis 등과 통합되어 **Verizon Connect** 브랜드로 재출범. 아일랜드 더블린에 엔지니어링 허브 유지.

---

## 🇰🇷 한국 관련

한국 사무소 없음. Verizon Connect는 주로 북미·유럽 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- Verizon 편입으로 안정적 대기업 환경 — 독립 성장보다 Verizon 전략 종속
- 플릿 관리·커넥티드 차량 데이터 분야 꾸준한 수요
- 더블린 R&D 허브 지속 운영

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 차량 GPS·텔레매틱스·플릿 데이터 — 자동차 통신·임베디드 경험 활용 가능. Verizon 대기업 안정성 |
| 추천 직무 | Embedded SW Engineer, Fleet Telematics Engineer, Backend Engineer (차량 데이터) |
| 한국 지원 경로 | 없음 (더블린 엔지니어링 허브 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Verizon 대기업 계열 (Critical Skills Employment Permit) |
| 고졸 채용 가능성 | 기술 경험 중시 (Verizon 대기업 정책 확인 필요) |

---

## 🔗 관련 정보

- 홈페이지: [verizonconnect.com](https://www.verizonconnect.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Verizon Connect 공개 정보 (2026.05 기준)*
