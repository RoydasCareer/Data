---
tags:
  - company
  - automotive
  - country/ireland
  - size/startup
  - automotive/adas
  - automotive/autonomous
  - automotive/sensing
  - fit/★★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Provizio"
size: "스타트업"
fit: "★★★"
business: "5D 레이더 인식 SW·ADAS (HQ: Limerick)"
hq: "Limerick, Ireland"
founded: "~2019년"
employees: "~50명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Provizio

> 5D 레이더 인식 SW·ADAS | 스타트업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Limerick, Ireland |
| 설립 연도 | ~2019년 |
| 임직원 수 | ~50명 (확인 필요) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 5D 레이더 기반 자율주행·ADAS 인식 알고리즘 (점군 + 속도 + 분류) |
| 공식 홈페이지 | https://provizio.ai |

~2019년 아일랜드 리머릭 창업. **5D 레이더** 인식 기술 전문 스타트업 — 기존 3D(XYZ) 포인트 클라우드에 **속도(도플러)·분류 신뢰도** 차원 추가. 복잡한 도심 환경에서의 보행자·차량·사이클리스트 인식 정밀도 향상. ADAS 및 자율주행 Level 2+~Level 4 적용. 창업팀은 Valeo·Mobileye 출신 전문가.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 현대·기아 ADAS 연구소와 기술 협력 가능성 있으나 미확인.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- ADAS·자율주행 인식 기술 수요 급증
- 5D 레이더 기술 차별화 — 카메라 한계(야간·악천후)를 레이더로 보완
- 아일랜드 자율주행 분야 스타트업 중 기술력 주목

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 5D 레이더·ADAS 인식 — 자동차 SW 엔지니어 경력 직결. 자율주행 기술 분야 아일랜드 주목 스타트업 |
| 추천 직무 | ADAS SW Engineer, Perception Engineer (Radar), Autonomy Engineer |
| 한국 지원 경로 | 없음 (리머릭 본사 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Critical Skills Employment Permit (자율주행 전문) |
| 고졸 채용 가능성 | 기술 포트폴리오·실무 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [provizio.ai](https://provizio.ai)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: provizio.ai 공개 정보 (2026.05 기준)*
