---
tags:
  - company
  - automotive
  - country/ireland
  - size/startup
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Vehicle Management System (VMS)"
size: "스타트업"
fit: "★"
business: "⚠️ 분류 불확실 — 플릿 관리 SW (실체 확인 필요)"
hq: "(확인 필요) — 아일랜드"
founded: "(확인 필요)"
employees: "(확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Vehicle Management System (VMS)

> ⚠️ 분류 불확실 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (확인 필요) — 아일랜드 |
| 설립 연도 | (확인 필요) |
| 임직원 수 | (확인 필요) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | (확인 필요) — 플릿 관리 SW로 분류 |

> ⚠️ **[분류 불확실]** "Vehicle Management System (VMS)"는 플릿 관리 SW로 분류되어 있으나 아일랜드 특정 기업 실체 확인 필요. "VMS"는 차량 관리 시스템의 일반 명칭으로도 사용됨.

---

## 🇰🇷 한국 관련

한국 관련 미확인.

---

## 📈 성장성 평가

**성장성 평가: — (확인 필요)**

분류 불확실로 성장성 평가 보류.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 기업 정보 불확실 — 지원 전 직접 확인 필수 |
| 추천 직무 | (확인 필요) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | — (확인 필요) |
| 고졸 채용 가능성 | (확인 필요) |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*⚠️ [분류 불확실] 실체 확인 필요 — 2026.05 기준*
