---
tags:
  - company
  - automotive
  - country/ireland
  - size/startup
  - automotive/security
  - fit/★
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "TitanHQ"
size: "스타트업"
fit: "★"
business: "⚠️ 자동차 분야 아님 — 이메일·웹 보안 솔루션 (Galway)"
hq: "Galway, Ireland"
founded: "1999"
employees: "~150명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# TitanHQ

> ⚠️ 자동차 분야 아님 | 이메일·웹 보안 솔루션 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Galway, Ireland |
| 설립 연도 | 1999년 |
| 임직원 수 | ~150명 (확인 필요) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 이메일 보안(SpamTitan), 웹 필터링(WebTitan), 이메일 아카이빙(ArcTitan) |
| 공식 홈페이지 | https://www.titanhq.com |

> ⚠️ **자동차 분야 아님.** TitanHQ는 MSP(관리형 서비스 제공자) 대상 이메일·웹 보안 솔루션 기업 — 자동차 SW와 무관.

1999년 갈웨이 창업. MSP·기업 대상 이메일 스팸 필터링(SpamTitan), 웹 콘텐츠 필터링(WebTitan), 이메일 아카이빙(ArcTitan) SaaS 제공. 전 세계 8,500+ MSP 파트너. 자동차 분야와 무관.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★ (이메일·웹 보안 분야)**

- 이메일·웹 보안 시장 안정적 수요
- 자동차 SW 취업 연관성 없음

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 이메일·웹 보안 SaaS — 자동차 SW 경력 연관성 없음 |
| 추천 직무 | 해당없음 (자동차 SW 관점) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모, 스폰서 미확인 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [titanhq.com](https://www.titanhq.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*⚠️ [분야 확인] 이메일·웹 보안 솔루션 — 자동차 분야 아님. (2026.05 기준)*
