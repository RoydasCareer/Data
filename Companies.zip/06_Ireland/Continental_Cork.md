---
tags:
  - company
  - automotive
  - country/ireland
  - size/large
  - automotive/adas
  - automotive/embedded
  - automotive/ev
  - fit/★★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Continental Automotive Ireland"
size: "대기업"
fit: "★★★"
business: "ADAS·EV 파워트레인·안전 시스템 엔지니어링·제조 아일랜드 거점"
hq: "Limerick / Cork, Ireland"
founded: "1982"
employees: "~1,000명 (아일랜드)"
ipo_status: "상장 (XETRA: CON)"
korea_office: "있음 (AUMOVIO Korea, 구 Continental Korea)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Continental Automotive Ireland

> ADAS·EV·안전 시스템 아일랜드 R&D·제조 | 대기업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Limerick / Cork, Ireland |
| 설립 연도 | 1982 |
| 임직원 수 | ~1,000명 (아일랜드) |
| 상장 여부 | 상장 (XETRA: CON) |
| 주력 사업 | ADAS 시스템, EV 파워트레인 전자 장치, 차량 안전 시스템 R&D 및 제조 |
| 공식 홈페이지 | https://www.continental-automotive.com |

## 🎯 주요 제품 & 서비스

ADAS 카메라·레이더, EV 인버터·컨버터, 에어백 ECU, ABS/ESC 제어, 타이어 압력 모니터링(TPMS). Limerick 및 Cork 지역 R&D·제조 거점.

## 🚗 자동차/모빌리티 관련성

ADAS/EV 시스템 엔지니어링 + 자동차 안전 → 전수환의 ADAS QA + EV 지식 + Technical PM 경험 연결. AUMOVIO Korea 통해 아일랜드 이동 경로. 아일랜드 Critical Skills Permit 가능.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

ADAS 의무화·EV 전환으로 아일랜드 거점 지속 확장. 아일랜드 IDA(산업개발청) 우대 투자 환경.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | ADAS QA + EV 시스템 지식 + Technical PM → Continental 아일랜드 Validation Engineer 포지션. AUMOVIO Korea 내부 이동 경로. |
| 추천 직무 | ADAS Validation Engineer, EV Systems Engineer, Technical PM |
| 지원 방법 | continental.com/careers (Ireland 위치 필터), LinkedIn |
| 비자 스폰 가능성 | ★★★★★ (글로벌 Tier-1, Critical Skills Permit 적극 지원) |

## ⚠️ 리스크 / 고려사항

- Continental → AUMOVIO 구조조정 진행 중 — 아일랜드 거점 영향 확인 필요
- Limerick/Cork는 더블린 대비 작은 도시

## 🔗 관련 정보

- 홈페이지: [continental-automotive.com](https://www.continental-automotive.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Continental Automotive 공식 홈페이지 (2026.07 기준)*
