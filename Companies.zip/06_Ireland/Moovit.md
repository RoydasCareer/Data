---
tags:
  - company
  - automotive
  - country/ireland
  - size/mid
  - automotive/mobility
  - automotive/maas
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Moovit (Intel 자회사)"
size: "중견기업"
fit: "★★"
business: "대중교통 내비게이션·MaaS 플랫폼 (Intel 2020년 ~$900M 인수)"
hq: "Tel Aviv, Israel (창업) / Intel 산하 / Dublin, Ireland (EMEA)"
founded: "2012"
employees: "~200명 (확인 필요)"
revenue: "비공개 (Intel 자회사)"
ipo_status: "비상장 (NASDAQ:INTC Intel 자회사)"
korea_office: "Moovit Korea 앱 서비스 운영 (별도 법인 미확인)"
---

# Moovit (Intel 자회사)

> 대중교통 내비게이션·MaaS 플랫폼 | Intel 자회사 | 아일랜드 🇮🇪 EMEA

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Tel Aviv, Israel (창업) / Intel 산하 / Dublin, Ireland (EMEA) |
| 설립 연도 | 2012년 |
| 임직원 수 | ~200명 (확인 필요) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 — Intel(NASDAQ:INTC) 자회사 (2020년 ~$900M 인수) |
| 주력 사업 | 대중교통 실시간 경로·스케줄 앱 + MaaS 플랫폼 SDK |
| 공식 홈페이지 | https://moovit.com |

전 세계 112개국 3,500개+ 도시 대중교통 데이터 통합 내비게이션 앱. 월간 사용자 1억명+. 2020년 Intel이 Mobileye 시너지를 위해 약 $900M에 인수. 더블린 EMEA 오피스 운영.

---

## 🇰🇷 한국 관련

한국 내 Moovit 앱 서비스 제공(서울·부산 등 대중교통 연동). 별도 한국 법인 미확인.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- Intel·Mobileye MaaS 생태계의 핵심 컴포넌트
- 자율주행 로보택시 서비스 플랫폼 확장 가능성
- 112개국 3,500+ 도시 교통 데이터 강점
- Intel 재무 불확실성이 투자 변수

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | Intel·Mobileye 생태계 MaaS 플랫폼 — 자율주행 연계 가능성, 더블린 EMEA 오피스 |
| 추천 직무 | Backend Engineer, Data Engineer, Transit Data Specialist |
| 한국 지원 경로 | 없음 (더블린/이스라엘 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Critical Skills Employment Permit (아일랜드) |
| 고졸 채용 가능성 | Intel 계열 — 학위 또는 동등 경험 |

---

## 🔗 관련 정보

- 홈페이지: [moovit.com](https://moovit.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: moovit.com 공식, Intel 공시 (2026.05 기준)*
