---
tags:
  - company
  - automotive
  - country/ireland
  - size/large
  - automotive/software
  - automotive/cybersecurity
  - automotive/adas
  - fit/★★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "HARMAN International (Ireland)"
size: "대기업"
fit: "★★★"
business: "자동차 커넥티드카·인포테인먼트·ADAS·사이버보안 SW — Samsung Electronics 자회사"
hq: "Dublin, Ireland (유럽 거점); 글로벌 HQ: Stamford, CT, USA"
founded: "1980 (HARMAN 창립); Samsung 인수: 2017년"
employees: "~30,000명 (글로벌); 더블린 오피스 규모 미공개"
revenue: "~$9B USD (FY2024)"
ipo_status: "비상장 (Samsung Electronics KRX: 005930 자회사)"
korea_office: "HARMAN Korea — 서울 (삼성전자 계열)"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# HARMAN International (Ireland)

> 커넥티드카·인포테인먼트·ADAS·사이버보안 SW | 대기업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland (유럽 거점); 글로벌 HQ: Stamford, CT, USA |
| 설립 연도 | 1980년 (HARMAN 창립); 2017년 Samsung Electronics 인수 ($8B) |
| 임직원 수 | ~30,000명 (글로벌); 더블린 규모 미공개 |
| 규모 분류 | 대기업 |
| 상장 여부 | 비상장 (Samsung Electronics KRX: 005930 완전 자회사) |
| 주력 사업 | 자동차 커넥티드카·인포테인먼트·ADAS·사이버보안·OTA SW + 프리미엄 오디오 |
| 공식 홈페이지 | https://www.harman.com / https://car.harman.com |

**2025 AutoTech Breakthrough Awards 'Connected Car Solution Provider of the Year' 수상.** 자동차 사업부 HARMAN Automotive는 커넥티드카·인포테인먼트·ADAS·사이버보안·V2X·5G 텔레매틱스·OTA 업데이트 분야의 글로벌 Tier 1. BMW·Mercedes·Toyota 등 주요 OEM 공급. **삼성전자 자회사** — 한국어 역량 보유자 우대 가능성.

---

## 🇰🇷 한국 관련

**HARMAN Korea** — 서울 소재 (삼성전자 계열 법인). 삼성전자 ↔ HARMAN 협력 프로젝트에서 한국 엔지니어 채용 기회 가능. 아일랜드 더블린 오피스 직접 지원도 가능.

---

## 📈 성장성 평가

**성장성 평가: ★★★★★**

- Connected Car·V2X·5G 텔레매틱스 시장 구조적 성장 → HARMAN 핵심 수혜
- Samsung 그룹 시너지 — 갤럭시·SmartThings·차량용 Android 생태계 통합
- 자동차 사이버보안(UN R155)·OTA(UN R156) 의무화 → HARMAN 전문 솔루션 수요 급증

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 아일랜드 더블린 자동차 SW 채용 + 삼성전자 자회사(한국 연결). V2X·사이버보안·OTA — 자동차 SW 검증 배경 직결. 아일랜드 Critical Skills Employment Permit 취득 유리. |
| 추천 직무 | Automotive SW Engineer, Connected Car SW Engineer, Cybersecurity Engineer, ADAS SW Engineer |
| 한국 지원 경로 | HARMAN Korea 또는 아일랜드 본사 직접 (harman.com/careers) |
| 비자 스폰 가능성 | ★★★ — 아일랜드 Critical Skills Employment Permit 대기업 우대 |
| 고졸 채용 가능성 | 기술 경험 중심 (임베디드 SW 포지션) |

---

## ⚠️ 리스크 / 고려사항

- **삼성전자 종속**: 삼성 전략 변화 시 HARMAN 사업 방향·예산 영향 가능
- **더블린 오피스 규모 미공개**: 구체적 팀 구성·채용 규모 LinkedIn 등 직접 확인 필요
- **대기업 관료 구조**: 글로벌 30,000명 조직 — 역할 범위 제한적일 수 있음
- **오디오·IT 사업 혼재**: 자동차 전담 포지션과 소비자 오디오 포지션 구분 필요 — 자동차 전용 JD 확인 필수

## 🔗 관련 정보

- 홈페이지: [harman.com](https://www.harman.com) / [car.harman.com](https://car.harman.com)
- LinkedIn: [linkedin.com/company/harman](https://www.linkedin.com/company/harman/)
- 채용: [harman.com/careers](https://jobsearch.harman.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: harman.com 공식, 2025 AutoTech Breakthrough Awards 수상 발표, Samsung Electronics IR (2026.06 기준)*
