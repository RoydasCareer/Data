---
tags:
  - company
  - automotive
  - country/ireland
  - size/startup
  - automotive/autonomous
  - automotive/logistics
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Manna Drone Delivery"
size: "스타트업"
fit: "★★"
business: "자율 드론 배달 서비스 (아일랜드 유럽 최초 상업 드론 배달)"
hq: "Dublin, Ireland"
founded: "2018"
employees: "~100명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Manna Drone Delivery

> 자율 드론 배달 | 아일랜드 스타트업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland |
| 설립 연도 | 2018년 |
| 임직원 수 | ~100명 (확인 필요) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자율 드론 배달 — 음식·의약품·소포 배달 서비스 |
| 공식 홈페이지 | https://manna.aero |

**바비 힐리(Bobby Healy)** 창업(2018). 아일랜드 갈웨이 오란모어에서 유럽 최초 상업 드론 배달 서비스 운영. 아일랜드 항공청(IAA) BVLOS(가시권 외) 인가 획득. 최대 순항 고도 40m, 배달 반경 3km 내외. 음식·의약품 배달.

> ℹ️ **자율 시스템 SW 기술 관련.** 드론 자율비행·경로계획·센서퓨전 등 자율주행 자동차와 기술 중첩 가능.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 아일랜드 중심 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 유럽 최초 상업 드론 배달 운영 경험 — 선행자 우위
- 규제 환경(EASA) 개선으로 확장 가능성
- 자율 시스템 기술 = 자동차 AV와 기술적 중첩

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자율 드론 SW — 자율주행 자동차 기술 중첩 (경로계획·센서퓨전·BVLOS). 아일랜드 유일 드론 배달 선도 기업 |
| 추천 직무 | Autonomy SW Engineer, Embedded Systems Engineer, Flight Control SW |
| 한국 지원 경로 | 없음 (더블린 본사 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Critical Skills Employment Permit |
| 고졸 채용 가능성 | 기술 포트폴리오 중시 |

---

## 🔗 관련 정보

- 홈페이지: [manna.aero](https://manna.aero)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: manna.aero 공식 (2026.05 기준)*
