---
tags:
  - company
  - automotive
  - country/ireland
  - size/mid
  - automotive/cybersecurity
  - automotive/security
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Integrity360"
size: "중견기업"
fit: "★★"
business: "사이버보안 관리 서비스·침투 테스팅 (더블린 HQ)"
hq: "Dublin, Ireland"
founded: "~2005년"
employees: "~200명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Integrity360

> 사이버보안 관리 서비스·침투 테스팅 | 중견기업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland |
| 설립 연도 | ~2005년 |
| 임직원 수 | ~200명 (확인 필요) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | MDR(관리형 탐지·대응), 침투 테스팅, 사이버보안 컨설팅 |
| 공식 홈페이지 | https://www.integrity360.com |

더블린 기반 사이버보안 전문 중견기업. MDR(Managed Detection & Response), SOC(보안 운영 센터) 서비스, 침투 테스팅, CISO 자문 등 제공. 아일랜드·UK·유럽 기업 대상. 자동차 분야 특화보다 범용 IT 보안 컨설팅 주력. 아일랜드 사이버보안 분야 주요 기업 중 하나.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 사이버보안 위협 증가로 MDR·SOC 수요 지속 성장
- 아일랜드 중견 규모 — 안정적 사업 기반
- 자동차 특화 사이버보안보다 범용 IT 보안

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 사이버보안 전문 — 차량 보안 경험을 IT 보안으로 확장 가능. 아일랜드 안정적 중견기업 |
| 추천 직무 | Security Analyst, Penetration Tester, SOC Analyst |
| 한국 지원 경로 | 없음 (더블린 직접 지원) |
| 비자 스폰 가능성 | ★★ — Critical Skills Employment Permit (중견기업) |
| 고졸 채용 가능성 | 보안 자격증·실무 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [integrity360.com](https://www.integrity360.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: integrity360.com 공개 정보 (2026.05 기준)*
