---
tags:
  - company
  - automotive
  - country/ireland
  - size/mid
  - automotive/semiconductor
  - automotive/uwb
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Decawave (Qorvo)"
size: "중견기업"
fit: "★★"
business: "UWB 반도체 칩 (Qorvo 자회사) — 자동차 디지털 키·측위"
hq: "Dublin, Ireland (Qorvo 편입)"
founded: "2007"
employees: "(Qorvo 통합)"
revenue: "비공개"
ipo_status: "비상장 (Qorvo NASDAQ: QRVO 자회사)"
korea_office: "없음"
---

# Decawave (Qorvo)

> UWB 반도체 칩 | Qorvo 자회사 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland (Qorvo 편입) |
| 설립 연도 | 2007년 |
| 임직원 수 | (Qorvo 통합) |
| 규모 분류 | 중견기업 (Qorvo 자회사) |
| 상장 여부 | 비상장 (Qorvo NASDAQ: QRVO 자회사) |
| 주력 사업 | UWB(초광대역) 반도체 칩 설계 — 자동차 디지털 키·정밀 측위 |
| 공식 홈페이지 | https://www.qorvo.com/products/decawave |

2007년 더블린 창업. UWB(Ultra-Wideband) 칩셋(DW1000·DW3000) 전문 팹리스 반도체 기업. **2020년 Qorvo(NASDAQ: QRVO)에 약 4억 달러에 인수**. UWB는 자동차 디지털 키(CCC Digital Key 표준), 스마트폰 기반 차량 잠금·엔진 시동 등에 사용. Apple CarKey, BMW·현대·기아 디지털 키 등에 활용. 현재 Qorvo UWB 사업부로 운영.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 현대·기아차 디지털 키 시스템에 UWB 칩 기술 연관 가능성 있음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- UWB 자동차 디지털 키 표준(CCC) 채택 확산 — 현대·BMW·GM 등 적용 중
- Qorvo 편입으로 독립 채용보다 Qorvo 아일랜드 법인 채용 형태
- 아일랜드 더블린 R&D 센터 유지 중

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | UWB 반도체·자동차 디지털 키 기술 — 임베디드·통신 경험 활용 가능 |
| 추천 직무 | Embedded SW Engineer (UWB), Automotive Digital Key Engineer |
| 한국 지원 경로 | Qorvo Korea 또는 더블린 R&D 직접 지원 |
| 비자 스폰 가능성 | ★★ — Qorvo 법인 소속 (대기업 계열) |
| 고졸 채용 가능성 | 반도체·임베디드 실무 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [qorvo.com/decawave](https://www.qorvo.com/products/decawave)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Qorvo 공개 정보 (2026.05 기준)*
