---
tags:
  - company
  - automotive
  - country/ireland
  - size/large
  - automotive/software
  - automotive/adas
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Qualcomm Ireland (Cork R&D Hub)"
size: "대기업"
fit: "★★"
business: "자동차용 반도체·ASIC R&D (Snapdragon Ride·ADAS 플랫폼) — Qualcomm NASDAQ: QCOM"
hq: "Cork, Ireland (R&D 허브); 글로벌 HQ: San Diego, CA, USA"
founded: "2013 (코크 R&D 설립)"
employees: "~780명 (코크, 2025); 1,000명+ 목표 (2026년 €125M 투자 계획)"
revenue: "$38.96B USD (Qualcomm 글로벌, FY2024)"
ipo_status: "상장 — NASDAQ: QCOM"
korea_office: "Qualcomm Korea — 서울 (글로벌 법인)"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Qualcomm Ireland (Cork R&D Hub)

> 자동차 반도체·ASIC R&D·Snapdragon Ride | 대기업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Cork, Ireland (R&D 허브); 글로벌 HQ: San Diego, CA, USA |
| 설립 연도 | 2013년 (코크 R&D 센터 개설) |
| 임직원 수 | ~780명 (코크, 2025); 1,000명+ 목표 (2026년 €125M 투자) |
| 규모 분류 | 대기업 |
| 상장 여부 | NASDAQ: QCOM |
| 주력 사업 | 자동차용 반도체·ASIC·AI 가속기 R&D (Snapdragon Ride ADAS 플랫폼, V2X 칩셋) |
| 공식 홈페이지 | https://www.qualcomm.com |

코크 R&D 허브는 Qualcomm의 주요 자동차 반도체 R&D 거점. **2026년 €125M 추가 투자·300명 채용 확장 발표**. Snapdragon Ride 플랫폼(자동차 ADAS·자율주행 SoC), 자동차 5G V2X 칩셋, 차량용 AI 가속기 개발 집중. 코크는 자동차·AI·IoT·데이터센터 복합 R&D 사이트.

---

## 🇰🇷 한국 관련

**Qualcomm Korea** — 서울 소재. 현대기아차·삼성전자·LG전자 등 한국 OEM/Tier1 협력 채널 보유. 코크 R&D는 독립 채용.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- 자동차 ADAS/자율주행 SoC 시장 Qualcomm Snapdragon Ride 확대 — BMW·GM·Mercedes 채택
- 2026년 €125M 추가 투자 발표 — 코크 R&D 1,000명+ 확장 공약
- 차량용 5G·AI 반도체 수요 구조적 성장

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 아일랜드 최대 자동차 반도체 R&D 허브. 채용 확장 중(2026). ADAS SW/임베디드 배경 연계 가능. |
| 추천 직무 | Automotive SW Engineer, ASIC Verification Engineer, Embedded Systems Engineer |
| 한국 지원 경로 | Qualcomm Korea 또는 코크 직접 (qualcomm.com/careers) |
| 비자 스폰 가능성 | ★★★ — 대기업 아일랜드 Critical Skills Employment Permit |
| 고졸 채용 가능성 | 반도체 엔지니어링 — 학위 선호 |

---

## ⚠️ 리스크 / 고려사항

- **반도체 R&D 특화**: A-SPICE/ISO26262 프로세스 컨설팅보다 칩 설계·검증 위주 — 자동차 SW 프로세스 전문 경력과 직결도 낮을 수 있음
- **더블린 아닌 코크 소재**: 아일랜드 수도 더블린에서 차로 3시간 거리 — 거주지 고려 필요
- **대형 테크 기업 경쟁도 높음**: 반도체 경력 없으면 진입 장벽 높음
- **Qualcomm 글로벌 경기 민감**: 스마트폰 사이클·자동차 수요 변동 시 채용 조정 가능

## 🔗 관련 정보

- 홈페이지: [qualcomm.com](https://www.qualcomm.com)
- LinkedIn: [linkedin.com/company/qualcomm](https://www.linkedin.com/company/qualcomm/)
- 채용: [qualcomm.com/company/careers](https://www.qualcomm.com/company/careers)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Qualcomm 공식, IDA Ireland, Irish Times (2026.01), Silicon Republic (2026.06 기준)*
*⭐ 2026년 €125M 투자·300명 채용 확장 공표 — 채용 활발한 시기*
