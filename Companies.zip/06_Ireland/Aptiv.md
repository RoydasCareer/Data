---
tags:
  - company
  - automotive
  - country/ireland
  - size/large
  - automotive/software
  - automotive/autonomous
  - automotive/adas
  - fit/★★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Aptiv (Global HQ)"
size: "대기업"
fit: "★★★"
business: "자동차 첨단 안전·연결성·지능형 엣지 기술 (NYSE:APTV, S&P 500)"
hq: "Schaffhausen, Switzerland (세금 주소) / Dublin, Ireland (운영 본사)"
founded: "1994 (GM 분사) / 2017년 Aptiv로 개명"
employees: "51,000명+ (Versigent 분사 후, 2026.04 기준)"
revenue: "US$20.398B (FY2025)"
ipo_status: "NYSE 상장 (티커: APTV, ISIN: JE00B783TY65) — S&P 500 구성 종목"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Aptiv

> 자동차 첨단 안전·연결성·지능형 엣지 기술 | 대기업 | 아일랜드 🇮🇪 | NYSE:APTV

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Aptiv PLC |
| 구 사명 | Delphi Automotive plc (2011~2017) |
| 법인 설립지 | 저지(Jersey, Channel Islands) |
| 세금 주소 | **Schaffhausen, Switzerland** (2025년 1월 아일랜드에서 이전) |
| 운영 본사 | Dublin, Ireland |
| 상장 | **NYSE: APTV** / ISIN: JE00B783TY65 / **S&P 500 구성 종목** |
| 설립 | 1994년 (GM Automotive Components Group) → 1999년 GM 분사 → 2017년 12월 Aptiv로 개명 |
| CEO | **Kevin P. Clark** (Chairman & CEO) |
| 임직원 수 | **51,000명+** (Versigent 분사 후 2026.04 기준) |
| 연매출 | **US$20.398B (FY2025)** |
| 영업이익 | US$1.184B (FY2025) |
| 순이익 | US$165M (FY2025) |
| 총자산 | US$23.413B (FY2025) |
| 공식 홈페이지 | https://www.aptiv.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 1994 | GM Automotive Components Group으로 시작 |
| 1999 | **GM에서 분사** (독립법인 Delphi Corporation) |
| 2011 | Delphi Automotive plc로 재편 |
| 2017.12 | **Aptiv로 개명** — Signal and Power Solutions(SPS) + Advanced Safety & UX(AS&UX) 양대 세그먼트 |
| 2020.01 | **Motional 합작법인 설립** (현대자동차그룹과 50:50, 기업가치 $4B) |
| 2022.01 | **Wind River Systems 인수** (cloud-native 엣지 SW, TPG로부터) |
| 2024.10 | **Maxieye Automotive Technology 18% 지분 인수** (중국 자율주행 기업) |
| 2025.01 | 세금 주소 아일랜드 → **스위스 샤프하우젠**으로 이전 |
| **2026.04** | **Versigent 분사 완료** — SPS(전선 배선 하니스 사업) → 별도 상장사 Versigent로 독립 |
| 2026.03 | **Motional 라스베이거스 Uber 로보택시 서비스 개시** (IONIQ 5 기반) |

---

## 🏗️ 사업 구조 (2026년 Versigent 분사 이후)

### Versigent 분사 이후 Aptiv의 핵심

**Aptiv는 이제 "지능형 엣지(Intelligent Edge)" 기술에 집중:**

| 기술 영역 | 내용 |
| :--- | :--- |
| **첨단 안전 (ADAS/AD)** | ADAS 센서 융합, 자율주행 알고리즘, Motional JV. |
| **연결성** | 차량-클라우드 연결, V2X, 사이버보안. |
| **Wind River** | 클라우드 네이티브 엣지 SW — SDV 플랫폼의 OS·미들웨어 역할. |
| **전기 아키텍처 (분사 전)** | SPS 사업 → Versigent로 독립 (전선 하니스·고압 케이블). |

### Versigent 분사 전 규모 (참고)

| 지표 | 수치 |
| :--- | :--- |
| 총 직원 수 | **140,000명** (2025 Annual Report, 분사 전) |
| 생산 시설 | 139개 (분사 전) / 76개 (분사 후) |
| 기술 센터 | 11개 |
| 사업 국가 | 50개 (분사 전) / 23개 (분사 후) |

---

## 🤖 Motional — 현대차그룹·Aptiv 자율주행 합작법인

| 항목 | 내용 |
| :--- | :--- |
| 지분 구조 | **Aptiv 50% + 현대자동차그룹 50%** |
| 설립 | 2019년 8월 발표 → 2020년 3월 완료 → 2020년 8월 "Motional" 명명 |
| 기업가치 | **$4B** (설립 시 기준) |
| CEO | **Laura Major** (2025년 7월 취임) |
| 서비스 차량 | 현대 **IONIQ 5** 로보택시 |
| 운영 | **라스베이거스 Uber 연계 로보택시 서비스 개시 (2026년 3월)** |
| 테스트 | 현대차 테스트 트랙(한국) 고속도로 자율주행 테스트 (2025.02) |
| AV 차량 수 | 86대 운영 중 (TAP!과 공유 데이터 기준) |

---

## 🌍 주요 사업 지역

**아시아태평양**: 매출 비중 29% (한국·중국·일본·인도 등). 한국은 Motional·현대차 관계로 핵심 시장.
**북미**: 최대 시장 / **유럽**: 독일·동유럽 공장 등 / **기타**: 중동·아프리카

---

## 🎯 전략 방향 (2025~2026)

| 분야 | 내용 |
| :--- | :--- |
| **지능형 엣지 집중** | Versigent 분사로 전선 하니스(자본집약) 사업 제거 → SW·ADAS·연결성 고마진 사업 집중. |
| **SDV 전략** | Wind River + ADAS 기술로 SDV 플랫폼 수직 통합. |
| **Motional 상용화** | 라스베이거스 Uber 로보택시 (2026.03 개시) → 매출 본격화 목표. |
| **PQC·보안** | 차량 연결성 사이버보안 강화. |
| **스위스 세금 최적화** | 2025년 1월 세금 주소 이전 → 비용 구조 최적화. |

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★☆☆**

- **$20B 매출 대기업**: 안정적 수익 기반. S&P 500 구성 종목.
- **Versigent 분사(2026.04)**: 저마진 하드웨어 사업 제거 → ADAS·SW 집중 → 마진 개선 기대.
- **Wind River 내재화**: SDV SW 스택 자체 보유 → 고마진 SW 사업 확대.
- **Motional 상용화 리스크**: 자율주행 상용화 타임라인 불확실. 대규모 투자 지속 필요.
- **무역 리스크**: 미-중 관계, 관세 정책 변화 → 글로벌 공급망 노출.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | Motional(현대차·Aptiv JV) 자율주행 개발 및 Aptiv ADAS 사업 — 차량 통신·임베디드 SW 경험 활용 가능. Wind River SDV OS 관련 포지션도 임베디드 배경 연결. 글로벌 대기업으로 커리어 성장 기회 크다. |
| 추천 직무 | ADAS Software Engineer, Automotive Cybersecurity Engineer, Embedded SW Engineer (Wind River), Systems Integration Engineer |
| 지원 방법 | aptiv.com/en/careers |
| 비자 스폰 (아일랜드) | ★★★ — Critical Skills Employment Permit. 대기업 글로벌 채용. |
| 고졸 채용 가능성 | 대기업 특성상 학력 조건 있을 수 있음. 기술직은 경험 비중 높음. 개별 확인 필요. |

---

## ⚠️ 리스크 / 고려사항

- **Versigent 분사 후 규모 축소**: 140,000명 → 51,000명 — 채용 규모 및 포지션 수 감소 가능
- **Motional 상용화 불확실성**: 자율주행 로보택시 수익화까지 시간 필요, 지속적 투자 부담
- **아일랜드 연결 약화**: 세금 주소가 스위스로 이전(2025.01) — 아일랜드 운영 본사는 유지되나 장기 변수
- **미-중 무역 리스크**: 글로벌 공급망 노출, 중국 매출 비중 있어 관세 이슈 영향 받을 수 있음
- **대기업 학력 조건**: 포지션에 따라 학사 이상 요건 있을 수 있음 — 개별 JD 확인 필수

## 🔗 관련 정보

- 홈페이지: [aptiv.com](https://www.aptiv.com)
- About: [aptiv.com/en/about](https://www.aptiv.com/en/about)
- Investor Relations: [ir.aptiv.com](https://ir.aptiv.com)
- Motional: [motional.com](https://motional.com)
- LinkedIn: [linkedin.com/company/aptiv](https://www.linkedin.com/company/aptiv/)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: aptiv.com 공식 페이지, ir.aptiv.com, Wikipedia (Aptiv — 2025 Annual Report 10-K, 2026.02.06 제출), motional.com 뉴스룸 — 2026.05.27 직접 확인*
*[중요 업데이트] Versigent 분사(2026.04), 세금 주소 스위스 이전(2025.01), Motional 라스베이거스 Uber 서비스 개시(2026.03) 반영*
