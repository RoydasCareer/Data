---
tags:
  - company
  - automotive
  - country/ireland
  - size/startup
  - automotive/cybersecurity
  - automotive/security
  - fit/★★
  - recommend
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Smarttech247"
size: "스타트업"
fit: "★★"
business: "사이버보안 관리 서비스·MDR (더블린/코크 HQ)"
hq: "Dublin / Cork, Ireland"
founded: "2013"
employees: "~200명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Smarttech247

> 사이버보안 MDR·SOC 서비스 | 스타트업 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin / Cork, Ireland |
| 설립 연도 | 2013년 |
| 임직원 수 | ~200명 (확인 필요) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | MDR(관리형 탐지·대응), SOC 서비스, 사이버보안 컨설팅 |
| 공식 홈페이지 | https://www.smarttech247.com |

2013년 아일랜드 창업. MDR(Managed Detection & Response)·SOC(보안 운영 센터) 24/7 모니터링 서비스 전문. Microsoft Azure·Sentinel 기반 위협 탐지. 아일랜드·UK·유럽 중소기업 대상. Microsoft Gold Partner. 범용 IT 보안 서비스이며 자동차 특화보다 일반 기업 대상 주력.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- MDR·SOC 수요 급증 (랜섬웨어·APT 위협 증가)
- 아일랜드 성장 스타트업 — Microsoft 파트너십 강점
- 자동차 특화 사이버보안보다 범용 IT 보안

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 사이버보안 MDR 전문 — 차량 보안 경험을 IT 보안으로 확장 가능 |
| 추천 직무 | SOC Analyst, Security Engineer, Threat Detection Engineer |
| 한국 지원 경로 | 없음 (더블린/코크 직접 지원) |
| 비자 스폰 가능성 | ★★ — Critical Skills Employment Permit (보안 전문) |
| 고졸 채용 가능성 | 보안 자격증·실무 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [smarttech247.com](https://www.smarttech247.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: smarttech247.com 공개 정보 (2026.05 기준)*
