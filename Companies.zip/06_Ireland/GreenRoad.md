---
tags:
  - company
  - automotive
  - country/ireland
  - size/startup
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "GreenRoad (Ireland)"
size: "스타트업"
fit: "★"
business: "운전 행동 분석·플릿 안전 SW (이스라엘 HQ, 아일랜드 운영)"
hq: "Ramat Gan, Israel (HQ) / 아일랜드 운영"
founded: "2004"
employees: "~200명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# GreenRoad (Ireland)

> 운전 행동 분석·플릿 안전 SW | 이스라엘 HQ | 아일랜드 🇮🇪 운영

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Ramat Gan, Israel (HQ) / 아일랜드 운영 |
| 설립 연도 | 2004년 |
| 임직원 수 | ~200명 (확인 필요) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 운전 행동 실시간 분석·점수화, 플릿 안전 관리 플랫폼 |
| 공식 홈페이지 | https://www.greenroad.com |

2004년 이스라엘 라마트간 창업. 운전자 행동(급가속·급제동·과속 등)을 실시간으로 분석·점수화하는 플릿 안전 SW 플랫폼. 버스·트럭·기업 차량 플릿 안전 관리. 아일랜드 운영 사무소 보유. 자동차 OEM 직접 연관보다 플릿 운영사 대상 B2B.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 플릿 안전 관리 시장 꾸준한 수요
- 이스라엘 HQ 기업 — 아일랜드는 운영 거점
- 자동차 SW 엔지니어 취업 직결성 낮음

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 플릿 안전 분석 SW — 자동차 SW 경력 직결성 낮음. 이스라엘 HQ 기업 |
| 추천 직무 | 해당없음 (자동차 SW 관점) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모 운영 거점, 스폰 여부 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [greenroad.com](https://www.greenroad.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: greenroad.com 공개 정보 (2026.05 기준)*
