---
tags:
  - company
  - automotive
  - country/ireland
  - size/startup
  - automotive/security
  - fit/★
country: "아일랜드"
country_folder: "06_Ireland"
company_name: "Tines"
size: "스타트업"
fit: "★"
business: "⚠️ 자동차 분야 아님 — 보안 워크플로 자동화 플랫폼 (더블린)"
hq: "Dublin, Ireland"
founded: "2018"
employees: "~200명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Tines

> ⚠️ 자동차 분야 아님 | 보안 자동화 플랫폼 | 아일랜드 🇮🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dublin, Ireland |
| 설립 연도 | 2018년 |
| 임직원 수 | ~200명 (확인 필요) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | No-code 보안 워크플로 자동화 플랫폼 (SOAR) |
| 공식 홈페이지 | https://www.tines.com |

> ⚠️ **자동차 분야 아님.** Tines는 SOC(보안 운영 센터) 업무 자동화 SOAR(Security Orchestration, Automation and Response) 플랫폼 — 자동차 SW와 무관.

2018년 더블린 창업 (Eoin Hinchy — 전 Google/Symantec). No-code 보안 자동화 플랫폼. 보안 팀이 코드 없이 알림 분류·위협 대응·워크플로를 자동화. Insight Partners 등 $115M+ 투자 유치.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★★ (보안 자동화 분야)**

- SOC 자동화 수요 급증
- 자동차 SW 취업 연관성 없음

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 보안 워크플로 자동화 SaaS — 자동차 SW 경력 연관성 없음 |
| 추천 직무 | 해당없음 (자동차 SW 관점) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — 성장 스타트업, SW 엔지니어 채용 가능 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [tines.com](https://www.tines.com)
- 국가 인덱스: [[_INDEX|아일랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*⚠️ [분야 확인] 보안 자동화 플랫폼 — 자동차 분야 아님. (2026.05 기준)*
