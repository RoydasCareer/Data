---
tags:
  - company
  - automotive
  - country/malaysia
  - size/global
  - automotive/mobility
  - automotive/maas
  - automotive/logistics
  - fit/★★★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "Grab Malaysia"
size: "글로벌대기업"
fit: "★★★"
business: "동남아시아 슈퍼앱 — 라이드헤일, 음식 배달, 물류, 핀테크"
hq: "싱가포르 (말레이시아 주요 운영거점)"
founded: "2012"
employees: "8,000명+"
revenue: "약 2.4조 원 (2023)"
ipo_status: "상장 (NASDAQ:GRAB)"
---

# Grab Malaysia

> 동남아시아 대표 슈퍼앱 | 글로벌대기업 | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Grab Holdings Limited (말레이시아 법인: MyTeksi Sdn Bhd) |
| 본사 | 싱가포르 (말레이시아 창업, 쿠알라룸푸르 운영) |
| 설립 연도 | **2012년** |
| CEO | Anthony Tan (공동 창업자) |
| 임직원 수 | **8,000명+** |
| 연매출 | 약 2.4조 원 (2023년, $1.8B USD) |
| 상장 여부 | 상장 (NASDAQ:GRAB) |
| 공식 홈페이지 | https://www.grab.com |

---

## 🎯 주요 제품 & 서비스

| 서비스 | 내용 |
| :--- | :--- |
| **GrabCar / GrabBike** | 동남아 8개국 라이드헤일 플랫폼, 실시간 경로 최적화 및 드라이버 매칭 알고리즘 |
| **GrabFood / GrabMart** | 음식 배달 및 장보기, 물류 경로·배달 파트너 플릿 관리 시스템 |
| **GrabExpress** | 동일일 소포·문서 배달 서비스, 실시간 추적 IoT 연동 |
| **GrabFinance / OVO** | 전자지갑, 보험, 소액대출 등 핀테크 생태계 |
| **Grab Maps** | 동남아 특화 지도 플랫폼, 내비게이션 및 교통 데이터 |

---

## 🇰🇷 한국 지사

**한국 법인 없음** — 한국 투자자(하이브, 현대차 등 간접 투자)와 협력 관계는 있으나 공식 한국 법인 없음. 싱가포르 본사 또는 쿠알라룸푸르 거점에서 직접 채용.

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 2023년 매출 $1.8B, 조정 EBITDA 흑자 전환 달성 (2023년 4분기 흑자)
- 동남아 8개국 700개 도시 운영, 일 평균 거래 수천만 건
- 자율주행 R&D 투자 — Uber ATG 인수 경험 보유 팀과 협업
- 2024년 GrabMaps 외부 B2B 판매 시작으로 데이터 사업 확대
- 동남아 라이드헤일 시장 점유율 약 70% 유지

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 대규모 플릿 관리 시스템, 실시간 차량 IoT 데이터 처리, 경로 최적화 알고리즘 등 모빌리티 SW 핵심 역량 활용 가능 |
| 추천 직무 | Fleet Technology Engineer, Maps & Navigation Engineer, Mobility Platform Engineer, Backend Engineer (Routing) |
| 지원 방법 | https://grab.careers, LinkedIn |
| 비자 스폰 (말레이시아) | ★★★ — Employment Pass 적극 지원, 외국인 엔지니어 다수 채용 |

---

## 🔗 관련 정보

- 홈페이지: https://www.grab.com
- 채용: https://grab.careers
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Grab 공식 홈페이지, NASDAQ 공시 — 작성 기준 2026.06.01*
