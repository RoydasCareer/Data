---
tags:
  - index
  - country/malaysia
country: "말레이시아"
---

# 말레이시아 🇲🇾 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 19개 |
| ★★★ 핵심 추천 | 1개 |
| ★★ 높은 적합성 | 7개 |
| ★ 보통 적합성 | 11개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | Employment Pass (EP) — 전문직 |
| 취득 용이성 | ★★ |
| 학위 요건 | 학사 이상 + 관련 경력 |
| 급여 요건 | 최저 MYR 5,000/월 이상 |
| 소득세 | 최고 30% (MYR 2M+ 소득) |
| 참고사항 | 영어·말레이어 혼용. Cyberjaya·KL 자동차 SW 허브. 생활비 한국 대비 저렴. |

## ⭐ 추천 기업 #Recommand

### ★★★ 핵심 추천
- [[SIRIM|SIRIM Berhad]] — 자동차 테스팅·형식 승인·QA 표준 기관 (Shah Alam)

### ★★ 높은 적합성
- [[Perodua|Perodua (Automotive Tech)]] — ADAS·SDV R&D (국영 자동차사, Rawang)
- [[eMooVit_Technology|eMooVit Technology]] — 특수 차량 자율주행 SW (Cyberjaya)
- [[Katsana|Katsana]] — 텔레매틱스·플릿 관리 SW·사고 분석
- [[Green_Packet|Green Packet (Automotive)]] — V2X·커넥티드 차량 솔루션
- [[MIMOS|MIMOS (Automotive R&D)]] — 자율주행·V2X 정부 R&D 기관
- [[Touch_'n_Go|Touch 'n Go (RFID/Automotive)]] — 커넥티드 차량 결제·하이패스 통신
- [[CyberSecurity_Malaysia|CyberSecurity Malaysia]] — 자동차 사이버보안 표준·인증

## 📋 전체 기업 목록

### ★ 보통 적합성
- [[Proton|Proton (Automotive Tech)]] — 커넥티드카·SW R&D (지리자동차 플랫폼)
- [[Sime_Darby_Motors|Sime Darby Motors (Tech)]] — 플릿 SW·디지털 모빌리티
- [[Aerodyne_Group|Aerodyne Group]] — 자율 드론·자동차 데이터 AI
- [[MARii|MARii]] — 자동차·IoT 기술 생태계 지원 기관
- [[Setel|Setel (Petronas)]] — 커넥티드 차량 결제·로열티 SW
- [[MDEC|MDEC (Smart Mobility)]] — AV·V2X 정부 이니셔티브
- [[Telekom_Malaysia|Telekom Malaysia (Automotive)]] — V2X·커넥티드 차량 통신 인프라
- [[HelloWorld_Robotics|HelloWorld Robotics]] — 자율 배달 로봇·SW
- [[SpareXHub|SpareXHub]] — 자동차 부품 데이터·마켓플레이스
- [[Vectol|Vectol]] — 자동차 서비스 관리 SW
- [[Grab_Malaysia|Grab Malaysia (Tech)]] — 모빌리티 플랫폼·플릿 데이터 (SG HQ)
