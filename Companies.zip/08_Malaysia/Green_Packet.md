---
tags:
  - company
  - automotive
  - country/malaysia
  - size/mid
  - automotive/v2x
  - automotive/connectivity
  - fit/★★
  - recommend
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "Green Packet (Automotive)"
size: "중견기업"
fit: "★★"
business: "V2X·커넥티드 차량 솔루션"
hq: "(본사 위치 미확인) — 말레이시아"
---

# Green Packet (Automotive)

> V2X·커넥티드 차량 솔루션 | 중견기업 | 말레이시아 🇲🇾

## 🏢 회사 개요

차량-사물 통신(V2X, DSRC/C-V2X) 기반 스마트 모빌리티 솔루션 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 말레이시아 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 중견기업 |
| 주력 사업 | V2X·커넥티드 차량 솔루션 |

## 🎯 비전 & 미션

자율주행과 스마트 인프라 연계로 안전하고 효율적인 교통 생태계를 구현합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

5G-V2X 표준화 진행 중. 2027년부터 유럽·미국 신차 V2X 의무화 논의.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | DoIP/CAN 통신 분석 경험 V2X로 확장 가능 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★ |
| 고졸 채용 가능성 | 국가별 상이 |
| 비자 정보 | 취업 비자 (국가별 상이) |
| 비고 | 해당 국가 대사관 또는 채용 공고 확인 필요. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
