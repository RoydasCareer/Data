---
tags:
  - company
  - automotive
  - country/malaysia
  - size/large
  - automotive/connectivity
  - automotive/iot
  - fit/★★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "Telekom Malaysia (TM)"
size: "대기업"
fit: "★★"
business: "말레이시아 국영 통신사 (IoT·커넥티드카 솔루션)"
hq: "Kuala Lumpur, Malaysia"
founded: "1987"
employees: "20,000명+"
revenue: "약 4조 원 (MYR 12억+)"
ipo_status: "상장 (Bursa Malaysia: T)"
---

# Telekom Malaysia (TM)

> 말레이시아 국영 통신사 (IoT·커넥티드카) | 대기업 | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Telekom Malaysia Berhad |
| 본사 | Kuala Lumpur, Malaysia |
| 설립 연도 | **1987년** |
| CEO | Imri Mokhtar |
| 임직원 수 | **20,000명+** |
| 연매출 | 약 MYR 12억+ (약 4조 원) |
| 상장 여부 | 상장 (Bursa Malaysia: T) |
| 공식 홈페이지 | https://www.tm.com.my |

---

## 🎯 주요 제품 & 서비스

| 서비스 | 내용 |
| :--- | :--- |
| **유선·광인터넷** | UniFi 브랜드 초고속 광섬유 인터넷 서비스 |
| **IoT 플랫폼** | TM ONE IoT: 산업용 IoT 솔루션 및 스마트시티 서비스 |
| **커넥티드카 솔루션** | 차량 원격진단, 플릿 추적, V2X 연구 참여 |
| **5G 인프라** | 5G 네트워크 확대 및 스마트팩토리·자율주행 지원 |
| **클라우드 서비스** | TM ONE 클라우드 기반 기업 IT 솔루션 |

---

## 🇰🇷 한국 지사

**한국 법인 없음** — 말레이시아 국영 통신사로 국내 및 아세안 중심 운영.

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★**

- 5G 인프라 확대와 함께 IoT, 스마트시티, 커넥티드카 솔루션 수요 증가
- TM ONE 사업부를 통해 산업용 IoT 및 차량 연결 서비스 제공
- 국영 통신사 특성상 안정적 수익 기반, 디지털 전환 투자 증가
- V2X, 커넥티드 인프라 관련 연구개발 참여 중
- 자동차 임베디드 SW보다는 통신·네트워크·IoT 플랫폼 역할 중심

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 5G·IoT 기반 커넥티드카 솔루션 사업 영위, 차량 통신 분야 경험 일부 활용 가능하나 통신 인프라 중심 기업 |
| 추천 직무 | IoT 솔루션 엔지니어, 네트워크 엔지니어, 5G 응용 서비스 개발자 |
| 지원 방법 | https://www.tm.com.my/careers, LinkedIn |
| 비자 스폰 (말레이시아) | ★★★ — Employment Pass 가능 (상장 국영 통신사, 외국인 기술직 채용 절차 정비) |

---

## 🔗 관련 정보

- 홈페이지: https://www.tm.com.my
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Telekom Malaysia 공식 홈페이지 — 작성 기준 2026.06.01*
