---
tags:
  - company
  - automotive
  - country/malaysia
  - size/mid
  - automotive/connectivity
  - automotive/iot
  - automotive/software
  - fit/★★★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "Setel"
size: "중견기업"
fit: "★★★"
business: "PETRONAS 계열 커넥티드카 연료결제·로열티 앱"
hq: "Kuala Lumpur, Malaysia"
founded: "2019"
employees: "200명+"
revenue: "비공개"
ipo_status: "비상장 (PETRONAS Digital 자회사)"
---

# Setel

> PETRONAS 커넥티드카 연료결제·로열티 앱 | 중견기업 | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Setel Ventures Sdn Bhd |
| 본사 | Kuala Lumpur, Malaysia |
| 설립 연도 | **2019년** |
| CEO | Isyraf Ismail |
| 임직원 수 | **200명+** |
| 연매출 | 비공개 (PETRONAS Digital 자회사) |
| 상장 여부 | 비상장 (PETRONAS Digital 100% 자회사) |
| 공식 홈페이지 | https://www.setel.com |

---

## 🎯 주요 제품 & 서비스

| 서비스 | 내용 |
| :--- | :--- |
| **QR 코드 연료 결제** | PETRONAS 주유소에서 앱으로 QR 결제, 비접촉 주유 |
| **로열티 프로그램** | Mesra 포인트 통합 관리 및 리워드 서비스 |
| **커넥티드카 서비스** | 차량 OBD 연동, 주행 데이터 수집 및 분석 |
| **보험 연계** | 주행 패턴 기반 자동차보험 UBI (Usage-Based Insurance) |
| **EV 충전 통합** | 전기차 충전소 위치 안내 및 결제 통합 서비스 |

---

## 🇰🇷 한국 지사

**한국 법인 없음** — PETRONAS 그룹의 말레이시아 국내 디지털 서비스 자회사로 국내 중심 운영.

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- PETRONAS라는 국영 에너지 그룹 후원으로 안정적 성장 기반 확보
- 말레이시아 최초 주유소 QR 결제 서비스로 빠른 사용자 기반 확보 (수백만 명)
- 차량 OBD 데이터 수집으로 커넥티드카 데이터 플랫폼으로 진화 중
- EV 충전 인프라 통합으로 미래 모빌리티 생태계 포지셔닝
- 자동차 사이버보안, OTA, 차량 데이터 API 관련 SW 역할 확대 예상
- UBI 보험, 예측 정비 등 차량 데이터 비즈니스 확장 추진

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | PETRONAS 계열 커넥티드카 플랫폼, 차량 OBD 데이터·IoT 연동 역할 존재, 안정적 대기업 그룹사 |
| 추천 직무 | IoT 플랫폼 엔지니어, 차량 데이터 엔지니어, 백엔드 API 개발자, 임베디드 OBD 연동 엔지니어 |
| 지원 방법 | https://www.setel.com/careers, LinkedIn |
| 비자 스폰 (말레이시아) | ★★★ — Employment Pass 가능 (PETRONAS 그룹 계열사, 절차 정비됨) |

---

## 🔗 관련 정보

- 홈페이지: https://www.setel.com
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Setel 공식 홈페이지 — 작성 기준 2026.06.01*
