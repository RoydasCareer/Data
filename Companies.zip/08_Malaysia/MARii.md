---
tags:
  - company
  - automotive
  - country/malaysia
  - size/mid
  - automotive/adas
  - automotive/iot
  - automotive/software
  - fit/★★★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "MARii"
size: "중견기업"
fit: "★★★"
business: "말레이시아 자동차·로봇·IoT 산업 진흥 정부기관 (MITI 산하)"
hq: "푸트라자야, 말레이시아"
founded: "2017"
employees: "300명+"
revenue: "비공개 (정부기관)"
ipo_status: "비상장 (정부기관)"
---

# MARii

> 말레이시아 자동차·로봇·IoT 연구원 | 중견기업(정부기관) | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Malaysia Automotive, Robotics and IoT Institute (MARii) |
| 본사 | 푸트라자야, 말레이시아 |
| 설립 연도 | **2017년** |
| 원장 | Datuk Madani Sahari (Director-General) |
| 임직원 수 | **300명+** |
| 연매출 | 비공개 (정부 예산 운영) |
| 상장 여부 | 비상장 (정부기관, MITI 산하) |
| 공식 홈페이지 | https://www.marii.com.my |

---

## 🎯 주요 제품 & 서비스

| 서비스 | 내용 |
| :--- | :--- |
| **자동차 산업 R&D 지원** | 커넥티드카, ADAS, EV, 자율주행 관련 R&D 프로젝트 지원 및 기업 컨소시엄 운영 |
| **표준·인증** | 말레이시아 자동차 IoT 표준 수립, UN-ECE 규정 국내 적용 |
| **인재 개발** | 자동차 SW·로봇·IoT 분야 전문인력 교육·인증 프로그램 |
| **스타트업 인큐베이션** | 자동차 기술 스타트업 지원, AutomotiveX 프로그램 운영 |
| **국제 협력** | ASEAN 자동차 기술 표준 조율, 해외 OEM·Tier1 협력 유치 |

---

## 🇰🇷 한국 지사

**한국 사무소 없음** — 정부기관으로 해외 법인 없으나, 한국 자동차 기업(현대·기아·LG전자 등)과 MOU 협력 사례 있음.

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 말레이시아 국가 자동차 정책(NAP 2020) 및 New Industrial Master Plan 2030의 핵심 실행기관
- EV 전환·자율주행·커넥티드카 산업 육성을 위한 정부 투자 확대
- 자동차 SW 기업 유치·생태계 조성 역할로 산업 영향력 큼
- Proton·Perodua 등 국산 OEM의 디지털 전환 지원
- 글로벌 자동차 기업 말레이시아 투자 유치 창구 역할

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 자동차 임베디드 SW, ADAS, IoT 표준 관련 정책·연구 기관. 기술 정책·표준화·R&D 경력을 원한다면 최적. 직접 SW 개발보다는 기술 기획·지원 역할 중심 |
| 추천 직무 | Automotive Technology Specialist, IoT Standards Engineer, R&D Program Manager, EV Technology Consultant |
| 지원 방법 | https://www.marii.com.my/careers, LinkedIn |
| 비자 스폰 (말레이시아) | ★★★ — 정부기관으로 Employment Pass 지원 안정적, 외국 전문가 초빙 경험 있음 |

---

## 🔗 관련 정보

- 홈페이지: https://www.marii.com.my
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: MARii 공식 홈페이지 — 작성 기준 2026.06.01*
