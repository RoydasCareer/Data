---
tags:
  - company
  - automotive
  - country/malaysia
  - size/mid
  - automotive/software
  - automotive/iot
  - fit/★★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "MDEC"
size: "중견기업"
fit: "★★"
business: "말레이시아 디지털 경제 공사 — 디지털 산업 육성·스마트 모빌리티 이니셔티브"
hq: "사이버자야, 말레이시아"
founded: "1996"
employees: "500명+"
revenue: "비공개 (정부기관)"
ipo_status: "비상장 (정부기관)"
---

# MDEC

> 말레이시아 디지털 경제 공사 | 중견기업(정부기관) | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Malaysia Digital Economy Corporation (MDEC) |
| 본사 | 사이버자야, 말레이시아 |
| 설립 연도 | **1996년** |
| CEO | Mahadhir Aziz |
| 임직원 수 | **500명+** |
| 연매출 | 비공개 (정부 예산 운영) |
| 상장 여부 | 비상장 (통상부 산하 정부기관) |
| 공식 홈페이지 | https://mdec.my |

---

## 🎯 주요 제품 & 서비스

| 서비스 | 내용 |
| :--- | :--- |
| **디지털 자유구역 (MSC)** | Cyberjaya 기반 첨단 IT 기업 유치·지원, 세금 혜택 및 비자 패스트트랙 |
| **스마트 모빌리티 이니셔티브** | 자율주행·커넥티드카·EV 생태계 육성 프로그램 |
| **DE Rantau** | 디지털 노마드 비자 프로그램 운영 |
| **투자 유치** | 글로벌 IT·자동차 기술 기업 말레이시아 투자 유치 지원 |
| **인재 개발** | GLOW(디지털 인재 개발), 디지털 기술 교육 프로그램 |

---

## 🇰🇷 한국 지사

**한국 사무소 없음** — 정부기관으로 해외 사무소 없으나, KOTRA 쿠알라룸푸르 무역관과 협력하여 한국 기업 투자 유치 활동 진행.

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★**

- Malaysia Digital Economy Blueprint 2030 실행 핵심 기관
- 자율주행차 테스트베드 구축(사이버자야), AV 시범운행 허가 발급
- 글로벌 IT 기업(구글, AWS, Microsoft) 말레이시아 데이터센터 유치 실적
- 스마트 모빌리티 관련 스타트업 지원 및 VC 연계 프로그램 운영
- 말레이시아 디지털 경제 기여도 GDP의 약 23% 목표(2025)

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 스마트 모빌리티·자율주행 이니셔티브 관련 기술 정책·표준화 업무 가능. 자동차 임베디드 SW 직접 개발 역할은 없으나 산업 생태계 이해에 유리 |
| 추천 직무 | Technology Policy Specialist, Smart Mobility Program Manager, Digital Industry Development Officer |
| 지원 방법 | https://mdec.my/careers, LinkedIn |
| 비자 스폰 (말레이시아) | ★★ — 정부기관 특성상 말레이시아 시민권자 우선 채용, 외국인 전문직은 프로젝트 기반 |

---

## 🔗 관련 정보

- 홈페이지: https://mdec.my
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: MDEC 공식 홈페이지 — 작성 기준 2026.06.01*
