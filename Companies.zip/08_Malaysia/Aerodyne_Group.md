---
tags:
  - company
  - automotive
  - country/malaysia
  - size/mid
  - automotive/software
  - automotive/data
  - fit/★★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "Aerodyne Group"
size: "중견기업"
fit: "★★"
business: "자율 드론·AI 데이터 애널리틱스 (아시아 최대 드론 기업)"
hq: "Cyberjaya, Selangor, Malaysia"
founded: "2014"
employees: "1,000명+ (글로벌)"
revenue: "비공개 (연간 $100M+ 추정)"
ipo_status: "비상장"
---

# Aerodyne Group

> 자율 드론·AI 데이터 애널리틱스 | 중견기업 | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Aerodyne Group Sdn. Bhd. |
| 본사 | Cyberjaya, Selangor, Malaysia |
| 설립 연도 | **2014년** |
| CEO | Kamarul A Muhamed (공동창업자) |
| 임직원 수 | **1,000명+** (글로벌) |
| 연매출 | 비공개 (연간 $100M+ 추정) |
| 상장 여부 | 비상장 |
| 공식 홈페이지 | https://aerodyne.group |

### 배경

Aerodyne는 **아시아 최대 드론 서비스 기업** 중 하나로, AI 기반 드론 데이터 애널리틱스 플랫폼을 통해 인프라 검사·농업·에너지·공공안전 등 다양한 산업에 서비스를 제공합니다.

---

## 🎯 주요 제품 & 서비스

| 제품/서비스 | 내용 |
| :--- | :--- |
| **드론 인프라 검사** | 송전탑, 교량, 도로, 건물 AI 드론 검사 |
| **DATAVŪ™ 플랫폼** | 드론 데이터 AI 분석·관리 플랫폼 |
| **정밀 농업** | 드론 농약 살포, 작물 모니터링 |
| **공공안전** | 재난 대응, 군경 드론 솔루션 |
| **스마트시티** | 교통 모니터링, 도시 매핑 |

---

## 🚗 자동차/모빌리티 관련성

| 분야 | 내용 |
| :--- | :--- |
| **도로 인프라 검사** | 드론으로 도로·교량 상태 AI 검사 |
| **교통 모니터링** | 드론 기반 교통량 분석 |
| **자율 드론** | 드론 자율비행 SW — 자율주행 알고리즘과 일부 연관 |

---

## 🌍 글로벌 사무소

| 지역 | 위치 |
| :--- | :--- |
| 본사 | **Cyberjaya, Malaysia** |
| 동남아 | 싱가포르, 인도네시아, 필리핀 등 |
| 중동 | UAE, 사우디아라비아 |
| 아태 | 일본, 인도 등 |

---

## 🇰🇷 한국 지사

**한국 법인 정보 없음** (확인 필요)

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 드론 서비스 시장 연 20%+ 성장
- BVLOS(가시권 외) 드론 운항 규제 완화로 시장 확대
- AI 데이터 애널리틱스 플랫폼으로 고마진 사업 확장
- 자동차 SW보다는 드론·AI 데이터 도메인

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 드론 자율비행 SW·AI 데이터 애널리틱스 — 자율주행 알고리즘(경로 계획, 인식) 경험 일부 연계 가능. 자동차 임베디드보다는 드론·AI 도메인 중심. |
| 추천 직무 | Autonomous Systems Engineer (드론), Computer Vision Engineer, AI Data Analyst |
| 지원 방법 | aerodyne.group/careers, LinkedIn |
| 비자 스폰 (말레이시아) | ★★★ — Employment Pass 지원 가능 |
| 참고 | 자동차 SW보다 드론·AI 분야 전환 관심자에게 적합 |

---

## 🔗 관련 정보

- 홈페이지: [aerodyne.group](https://aerodyne.group)
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Aerodyne Group 공식 홈페이지 — 작성 기준 2026.06.01*
