---
tags:
  - company
  - automotive
  - country/malaysia
  - size/mid
  - automotive/autonomous
  - automotive/adas
  - fit/★★
  - recommend
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "eMooVit Technology"
size: "중견기업"
fit: "★★"
business: "특수 차량 자율주행 SW (HQ: Cyberjaya)"
hq: "(본사 위치 미확인) — 말레이시아"
---

# eMooVit Technology

> 특수 차량 자율주행 SW (HQ: Cyberjaya) | 중견기업 | 말레이시아 🇲🇾

## 🏢 회사 개요

AI 기반 자율주행 소프트웨어 플랫폼을 개발하는 기업입니다. 인식·판단·제어 알고리즘과 자율주행 검증·시뮬레이션 솔루션을 제공합니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 말레이시아 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 중견기업 |
| 주력 사업 | 특수 차량 자율주행 SW (HQ: Cyberjaya) |

## 🎯 비전 & 미션

레벨 4~5 완전 자율주행 상용화로 교통사고 제로, 물류·이동 혁신을 목표로 합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

글로벌 자율주행 시장 2030년 $2조 이상 예상. 단기 규제 리스크 있으나 장기 성장은 확실.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | ADAS QA 경험 활용 가능 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★ |
| 고졸 채용 가능성 | 국가별 상이 |
| 비자 정보 | 취업 비자 (국가별 상이) |
| 비고 | 해당 국가 대사관 또는 채용 공고 확인 필요. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
