---
tags:
  - company
  - automotive
  - country/malaysia
  - size/startup
  - automotive/mobility
  - automotive/logistics
  - fit/★★★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "HelloWorld Robotics"
size: "스타트업"
fit: "★★★"
business: "자율 배달 로봇 및 라스트마일 자율주행 솔루션"
hq: "쿠알라룸푸르, 말레이시아"
founded: "2019"
employees: "50명+"
revenue: "비공개"
ipo_status: "비상장"
---

# HelloWorld Robotics

> 자율 배달 로봇 스타트업 | 스타트업 | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | HelloWorld Robotics Sdn Bhd |
| 본사 | 쿠알라룸푸르, 말레이시아 |
| 설립 연도 | **2019년** |
| CEO | 비공개 |
| 임직원 수 | **50명+** |
| 연매출 | 비공개 |
| 상장 여부 | 비상장 |
| 공식 홈페이지 | https://www.helloworldrobotics.com |

---

## 🎯 주요 제품 & 서비스

| 서비스 | 내용 |
| :--- | :--- |
| **자율 배달 로봇** | 실내외 라스트마일 배달용 자율 이동 로봇, 장애물 회피 및 엘리베이터 연동 |
| **로봇 관제 플랫폼** | 다수의 로봇을 동시에 관리하는 Fleet Management System, 실시간 위치 추적 |
| **물류 자동화 솔루션** | 빌딩·캠퍼스·병원 내 자율 물류 운반 시스템 |

---

## 🇰🇷 한국 지사

**한국 법인 없음** — 말레이시아 로컬 스타트업으로, 현재 해외 법인 없음. 싱가포르·인도네시아 확장 검토 중.

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★**

- 말레이시아 MARii(자동차·로봇 연구원) 지원 프로그램 참여사
- 이커머스 성장에 따른 라스트마일 물류 자동화 수요 급증
- 쇼핑몰·오피스·병원 등 실내 환경 중심으로 파일럿 배포
- 자율주행 SW(ROS 기반 로봇 OS) 및 컴퓨터 비전 기술 내재화
- 시리즈 A 투자유치 추진 중

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 자율주행 알고리즘(SLAM, 경로계획), 임베디드 로봇 SW, 센서 퓨전 등 자동차 ADAS 경험과 직접 연계 가능한 스타트업 |
| 추천 직무 | Robotics Software Engineer, Embedded Systems Engineer, Autonomous Navigation Engineer, Fleet Management Developer |
| 지원 방법 | https://www.helloworldrobotics.com, LinkedIn |
| 비자 스폰 (말레이시아) | ★★ — Employment Pass 가능, 스타트업 규모로 지원 절차 단순 |

---

## 🔗 관련 정보

- 홈페이지: https://www.helloworldrobotics.com
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: HelloWorld Robotics 공식 홈페이지 — 작성 기준 2026.06.01*
