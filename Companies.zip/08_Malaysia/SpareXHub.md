---
tags:
  - company
  - automotive
  - country/malaysia
  - size/startup
  - automotive/marketplace
  - fit/★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "SpareXHub"
size: "스타트업"
fit: "★"
business: "자동차 부품 B2B 온라인 마켓플레이스"
hq: "Kuala Lumpur, Malaysia"
founded: "2020"
employees: "50명 미만"
revenue: "비공개"
ipo_status: "비상장"
---

# SpareXHub

> 자동차 부품 B2B 온라인 마켓플레이스 | 스타트업 | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | SpareXHub Sdn Bhd |
| 본사 | Kuala Lumpur, Malaysia |
| 설립 연도 | **2020년** |
| CEO | 비공개 |
| 임직원 수 | **50명 미만** |
| 연매출 | 비공개 |
| 상장 여부 | 비상장 |
| 공식 홈페이지 | https://www.sparexhub.com |

---

## 🎯 주요 제품 & 서비스

| 서비스 | 내용 |
| :--- | :--- |
| **자동차 부품 B2B 마켓플레이스** | 부품 공급업체와 정비소·딜러를 연결하는 온라인 플랫폼 |
| **재고 관리 솔루션** | 자동차 부품 재고 디지털화 및 수급 최적화 |
| **부품 카탈로그** | 차종별 호환 부품 데이터베이스 제공 |
| **B2B 결제 통합** | 정비소·딜러 대상 외상 결제 및 정산 서비스 |

---

## ⚠️ 자동차 산업 연관성 분류 주의

> **SpareXHub는 자동차 부품 B2B 마켓플레이스로, 자동차 임베디드 SW 엔지니어링과 직접 연관성이 없습니다.**

---

## 🇰🇷 한국 지사

**한국 법인 없음** — 말레이시아 로컬 스타트업으로 국내 중심 운영.

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★**

- 말레이시아 자동차 부품 시장 디지털화 초기 단계, 성장 잠재력 존재
- 초기 스타트업으로 펀딩 단계 초기, 규모 작음
- 기술 역할은 플랫폼 개발·데이터 관리 중심으로 임베디드 SW와 무관
- 자동차 부품 공급망 디지털화 트렌드 수혜 가능

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 자동차 부품 B2B 플랫폼으로, 임베디드 SW·ECU·ADAS와 직접 연관성 없는 커머스 도메인 |
| 추천 직무 | 플랫폼 백엔드 개발자, 데이터 엔지니어 (자동차 SW와 무관) |
| 지원 방법 | https://www.sparexhub.com, LinkedIn |
| 비자 스폰 (말레이시아) | ★ — Employment Pass 소규모 초기 스타트업, 비자 스폰 불확실 |

---

## 🔗 관련 정보

- 홈페이지: https://www.sparexhub.com
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: SpareXHub 공식 홈페이지 — 작성 기준 2026.06.01*
