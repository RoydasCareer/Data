---
tags:
  - company
  - automotive
  - country/malaysia
  - size/large
  - automotive/adas
  - automotive/ev
  - automotive/connectivity
  - automotive/software
  - fit/★★★★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "Proton"
size: "대기업"
fit: "★★★★"
business: "말레이시아 국민 자동차 OEM (Geely 그룹 계열)"
hq: "Shah Alam, Selangor, Malaysia"
founded: "1983"
employees: "14,000명+"
revenue: "약 3조 원 (MYR 10억+)"
ipo_status: "비상장 (Geely 49.9% 지분)"
---

# Proton

> 말레이시아 국민 자동차 OEM | 대기업 | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Proton Holdings Berhad |
| 본사 | Shah Alam, Selangor, Malaysia |
| 설립 연도 | **1983년** |
| CEO | Li Chunrong |
| 임직원 수 | **14,000명+** |
| 연매출 | 약 MYR 10억+ (약 3조 원) |
| 상장 여부 | 비상장 (DRB-HICOM 50.1%, Geely 49.9%) |
| 공식 홈페이지 | https://www.proton.com |

---

## 🎯 주요 제품 & 서비스

| 서비스 | 내용 |
| :--- | :--- |
| **승용차 제조** | Saga, Preve, Exora, X50, X70, X90 등 다양한 라인업 |
| **인포테인먼트 시스템** | Geely 플랫폼 기반 커넥티드카 인포테인먼트 (GKUI 기반) |
| **ADAS 기능** | 충돌 경고, 차선 이탈 경고, 자동긴급제동(AEB) 탑재 |
| **EV 개발** | Geely SEA 플랫폼 기반 전기차 라인업 개발 추진 |
| **R&D 센터** | Shah Alam R&D 센터에서 차량 SW 및 엔지니어링 연구 |

---

## 🇰🇷 한국 지사

**한국 법인 없음** — 말레이시아 본사 중심 운영. Geely 그룹을 통해 중국 기술 협력 체계 보유.

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★★**

- Geely 49.9% 지분 인수(2017) 이후 기술력·품질·판매량 모두 급격히 개선
- X50, X70 SUV 라인업이 말레이시아 시장 판매 1·2위권 경쟁
- Geely SEA 플랫폼 기반 EV 출시 계획으로 임베디드 SW 개발 수요 증가
- ADAS, OTA 업데이트, 커넥티드카 기능 확대로 SW 엔지니어 채용 확대 추세
- 동남아시아 수출 확대 전략으로 글로벌 SW 역량 수요 증가
- AUTOSAR, ISO 26262 적용 가능성 있는 Geely 플랫폼 공유

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | 말레이시아 유일 완성차 OEM, Geely 기술 플랫폼으로 ECU·인포테인먼트·ADAS SW 개발 기회, 임베디드 SW 경험 직접 활용 가능 |
| 추천 직무 | 임베디드 SW 엔지니어, ADAS 소프트웨어 개발자, 차량 통신(CAN/LIN) 엔지니어, 인포테인먼트 SW 개발자, OTA 업데이트 엔지니어 |
| 지원 방법 | https://www.proton.com/careers, LinkedIn |
| 비자 스폰 (말레이시아) | ★★★ — Employment Pass 가능 (대기업 OEM, 외국인 SW 엔지니어 채용 전례 있음) |

---

## 🔗 관련 정보

- 홈페이지: https://www.proton.com
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Proton 공식 홈페이지 — 작성 기준 2026.06.01*
