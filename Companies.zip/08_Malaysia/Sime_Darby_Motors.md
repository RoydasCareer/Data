---
tags:
  - company
  - automotive
  - country/malaysia
  - size/large
  - automotive/fleet
  - automotive/mobility
  - fit/★★
country: "말레이시아"
country_folder: "08_Malaysia"
company_name: "Sime Darby Motors"
size: "대기업"
fit: "★★"
business: "말레이시아 최대 자동차 유통·딜러 그룹 (BMW, Ford, Hyundai, Peugeot)"
hq: "Petaling Jaya, Selangor, Malaysia"
founded: "1910"
employees: "5,000명+"
revenue: "약 3조 원 (MYR 10억+)"
ipo_status: "상장 (Bursa Malaysia: SIME)"
---

# Sime Darby Motors

> 말레이시아 최대 자동차 유통·딜러 그룹 | 대기업 | 말레이시아 🇲🇾

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Sime Darby Motors Sdn Bhd (Sime Darby Berhad 자회사) |
| 본사 | Petaling Jaya, Selangor, Malaysia |
| 설립 연도 | **1910년** (Sime Darby 그룹 기준) |
| CEO | Jeff Sandhu |
| 임직원 수 | **5,000명+** |
| 연매출 | 약 MYR 10억+ (약 3조 원, 그룹 전체 기준) |
| 상장 여부 | 상장 (Bursa Malaysia: SIME) |
| 공식 홈페이지 | https://www.simedarbymotors.com |

---

## 🎯 주요 제품 & 서비스

| 서비스 | 내용 |
| :--- | :--- |
| **완성차 유통** | BMW, MINI, Ford, Hyundai, Peugeot, Land Rover 등 공식 딜러 |
| **차량 판매·A/S** | 신차 판매 및 공식 서비스 센터 운영 |
| **플릿 솔루션** | 기업 차량 플릿 관리 및 리스 서비스 |
| **EV 인프라** | BMW·Hyundai EV 충전소 설치 및 관리 |
| **중고차 사업** | 공인 중고차 판매 플랫폼 운영 |

---

## 🇰🇷 한국 지사

**한국 법인 없음** — 말레이시아·호주·중국 등 아시아태평양 지역 중심 운영. 현대자동차 말레이시아 공식 딜러로 한국 브랜드와 협력 관계.

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★**

- BMW·Hyundai EV 라인업 확대로 EV 판매·서비스 수요 증가
- 플릿 관리 디지털화 및 커넥티드 서비스 역량 강화 추진 중
- 말레이시아 자동차 시장 회복세와 함께 안정적 성장
- 자동차 유통 중심 사업으로 SW 개발 역할은 제한적
- 디지털 전환 과정에서 IT 및 디지털 서비스 인력 수요 증가

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 완성차 유통·딜러 그룹으로 직접 SW 개발보다는 A/S·IT 역할 중심, 안정적 대기업 환경 |
| 추천 직무 | IT 시스템 엔지니어, 플릿 관리 솔루션 담당자, 디지털 서비스 개발자 |
| 지원 방법 | https://www.simedarbymotors.com/careers, LinkedIn |
| 비자 스폰 (말레이시아) | ★★ — Employment Pass 가능 (대기업이나 유통 중심, SW 역할 외국인 채용 제한적) |

---

## 🔗 관련 정보

- 홈페이지: https://www.simedarbymotors.com
- 국가 인덱스: [[_INDEX|말레이시아 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Sime Darby Motors 공식 홈페이지 — 작성 기준 2026.06.01*
