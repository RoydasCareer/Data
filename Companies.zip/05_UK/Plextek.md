---
tags:
  - company
  - automotive
  - country/uk
  - size/small
  - automotive/software
  - automotive/testing
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Plextek"
size: "중소기업"
fit: "★★"
business: "RF·레이더·전자 설계 컨설팅 (자동차 레이더·IoT 센서 전문)"
hq: "Great Chesterford, Essex, England, UK"
founded: "1998"
employees: "~80명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Plextek

> RF·레이더 전자 설계 컨설팅 | Essex 전문기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Great Chesterford, Essex, England, UK |
| 설립 연도 | 1998년 |
| 임직원 수 | ~80명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | RF·마이크로파·레이더 전자 설계 컨설팅 — 자동차 레이더(24/77GHz)·V2X 통신·IoT 센서 HW·SW |
| 공식 홈페이지 | https://plextek.com |

영국 독립 전자 설계 전문 컨설팅사. **자동차 레이더(ADAS용 24/77GHz 레이더)** 설계·검증 전문. V2X 통신 장치·IoT 센서 하드웨어·안테나 설계 등도 수행. 방산·우주 분야 경험도 보유.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- ADAS 레이더 센서 의무화 확산 → 레이더 설계 수요 증가
- 독립 컨설팅사로 다양한 OEM·Tier 1 고객 포트폴리오
- 방산·우주 다각화로 안정적 수익 기반

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 레이더·V2X 하드웨어 전문 — RF/레이더 경험자에게 적합 |
| 추천 직무 | RF Design Engineer, Radar Systems Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 전자공학 실무 경험 인정 |

---

## 🔗 관련 정보

- 홈페이지: [plextek.com](https://plextek.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: plextek.com 공식 (2026.05 기준)*
