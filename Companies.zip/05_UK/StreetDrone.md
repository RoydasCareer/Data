---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - automotive/adas
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "StreetDrone"
size: "스타트업"
fit: "★★"
business: "자율주행 차량 개발 플랫폼 (기존 차량 자율화 키트 + SW)"
hq: "Coventry, England, UK"
founded: "2018"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# StreetDrone

> 자율주행 개발 플랫폼 | Coventry 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Coventry, England, UK |
| 설립 연도 | 2018년 |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 기존 차량(닛산 리프 등)에 자율주행 키트 장착 + AV SW 플랫폼 (Open Research Platform) |
| 공식 홈페이지 | https://streetdrone.com |

양산 차량을 자율주행 연구·개발 플랫폼으로 전환하는 솔루션 전문. 닛산 리프 기반 StreetDrone Twizy/ONE로 AV 연구자·기업이 자율주행 알고리즘을 실차 테스트. UK DRIVEN 프로그램 파트너.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- AV 연구·개발 플랫폼 수요 증가 — 대학·연구기관·스타트업 고객
- UK CAV 생태계 인프라 기업 역할
- 소규모 — 상업화 속도가 변수

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | AV 실차 테스팅 플랫폼 — 자율주행 검증 경험 직결 |
| 추천 직무 | AV Platform Engineer, Robotics SW Developer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 기술 포트폴리오 중시 |

---

## 🔗 관련 정보

- 홈페이지: [streetdrone.com](https://streetdrone.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: streetdrone.com 공식 (2026.05 기준)*
