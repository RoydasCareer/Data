---
tags:
  - company
  - automotive
  - country/uk
  - size/small
  - automotive/security
  - automotive/cybersecurity
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Trustonic"
size: "중소기업"
fit: "★★"
business: "신뢰 실행 환경(TEE)·자동차 디지털 키·OTA 보안 플랫폼"
hq: "Cambridge, England, UK"
founded: "2012 (ARM·G+D·Gemalto JV 기원)"
employees: "~200명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Trustonic

> TEE 보안·자동차 디지털 키·OTA | Cambridge 보안 기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Cambridge, England, UK |
| 설립 연도 | 2012년 (ARM·G+D·Gemalto JV 기반 설립) |
| 임직원 수 | ~200명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | ARM TrustZone 기반 TEE(신뢰 실행 환경) — 자동차 디지털 키·OTA 업데이트 보안·연결된 차량 인증 |
| 공식 홈페이지 | https://trustonic.com |

ARM TrustZone 기반 **하드웨어 신뢰 실행 환경(TEE)** 선도 기업. 차량 디지털 키(스마트폰·NFC·UWB), OTA 업데이트 서명 검증, 차량 ID 인증에 Trustonic Automotive 솔루션 적용. 삼성·LG·현대차 협력사 가능성.

---

## 🇰🇷 한국 관련

한국 사무소 없음. ARM 기원으로 삼성·LG전자 등 한국 반도체/전장 기업과 기술 협력 이력.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- 디지털 키(UWB/NFC) 차량 표준화 확산 → TEE 보안 수요 급증
- UN R155 차량 사이버보안 규제 → OTA 보안 필수화
- ARM TrustZone 파트너로 자동차 SoC 보안 기본 탑재 추진

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 보안·TEE 분야 — ISO/SAE 21434·OTA 경험 직결 |
| 추천 직무 | Embedded Security Engineer, Automotive OTA Developer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 보안 임베디드 실무 경험 인정 |

---

## 🔗 관련 정보

- 홈페이지: [trustonic.com](https://trustonic.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: trustonic.com 공식 (2026.05 기준)*
