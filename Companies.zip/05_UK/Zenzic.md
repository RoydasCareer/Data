---
tags:
  - company
  - automotive
  - country/uk
  - size/public
  - automotive/autonomous
  - automotive/testing
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Zenzic"
size: "공기업"
fit: "★"
business: "커넥티드·자율주행(CAV) 테스트 생태계 조율 기관 (영국 공공-민간 파트너십)"
hq: "Birmingham, England, UK"
founded: "2019"
employees: "~30명 (2023, 폐업 전)"
revenue: "정부 기금 (비상업)"
ipo_status: "비상장 (정부-민간 파트너십)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Zenzic

> CAV 테스트 생태계 조율 | 영국 공공-민간 파트너십 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Birmingham, England, UK |
| 설립 연도 | 2019년 |
| 임직원 수 | ~30명 (2023, 폐업 전) |
| 규모 분류 | 공기업 (정부-민간 파트너십) |
| 상장 여부 | 비상장 |
| 주력 사업 | 영국 CAV(커넥티드·자율주행 차량) 테스트 인프라·생태계 조율 |
| 공식 홈페이지 | https://zenzic.io |

> ⚠️ **2024년 운영 종료.** 영국 교통부(DfT)의 CAV2 프로그램 지원 종료로 Zenzic 법인 폐업. 영국 CAV 테스트베드 네트워크(MIRA, Millbrook, TRL 등) 조율 역할 담당했으나 현재는 해체.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★ (폐업)**

- 2024년 DfT 지원 종료로 운영 중단
- 관련 AV 테스팅 인프라는 TRL·HORIBA MIRA·Millbrook 등으로 분산 지속

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | ⚠️ 2024년 폐업 — 채용 불가 |
| 추천 직무 | 해당없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 폐업 |
| 고졸 채용 가능성 | 해당없음 |

---

## 🔗 관련 정보

- 홈페이지: [zenzic.io](https://zenzic.io) (현재 비활성)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: zenzic.io, DfT 공시 (2026.05 기준) — ⚠️ 2024년 DfT 지원 종료로 폐업*
