---
tags:
  - company
  - automotive
  - country/uk
  - size/mid
  - automotive/testing
  - automotive/adas
  - automotive/ev
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Millbrook Proving Ground"
size: "중견기업"
fit: "★★★"
business: "영국 최대 자동차 종합 테스팅 시설·ADAS·EV·진단 실차 검증"
hq: "Millbrook, Bedfordshire, UK"
founded: "1970"
employees: "~500명"
ipo_status: "비상장 (Element Materials Technology 자회사)"
korea_office: "없음"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Millbrook Proving Ground

> 영국 최대 자동차 종합 테스팅 시설 | 중견기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Millbrook, Bedfordshire, UK |
| 설립 연도 | 1970 |
| 임직원 수 | ~500명 |
| 상장 여부 | 비상장 (Element Materials Technology 자회사) |
| 주력 사업 | 차량 동역학 테스팅, ADAS 실차 검증, EV 배터리 테스팅, NVH, 내구성 시험 |
| 공식 홈페이지 | https://www.millbrook.co.uk |

## 🎯 주요 제품 & 서비스

70km+ 테스트 트랙, 전용 ADAS 시나리오 구간, 챔버(기후·NVH·전자파), EV 배터리 팩 테스팅, EMC, 진단 데이터 수집. JLR·Bentley·MIRA 등 영국 OEM·Tier-1의 핵심 외부 테스팅 파트너.

## 🚗 자동차/모빌리티 관련성

실차 진단 데이터 수집·분석 + ADAS 실차 검증 → 전수환의 실차 테스팅 5년+ 경험 직결. JLR 차량 테스트 파트너로 JLR DoIP 경험 보유자 환영. CANoe 기반 실차 데이터 로깅.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

NCAP 강화·EV 인증 요건 복잡화로 테스팅 시설 수요 급증. UK ZEST(Zero Emission Vehicle Standard) 대응 테스팅 확대.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 실차 테스팅 5년+ + CANoe + JLR 차량 경험 → Validation/Test Engineer 직결. ADAS·EV 검증 모두 커버. |
| 추천 직무 | Vehicle Test Engineer, ADAS Validation Engineer, Data Acquisition Engineer |
| 지원 방법 | millbrook.co.uk/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★ (엔지니어링 시설, Skilled Worker Visa 지원 가능) |

## ⚠️ 리스크 / 고려사항

- Bedfordshire 위치 — 런던 북부 약 60km, 차량 통근 권장
- 현장 작업 위주 — 재택 근무 제한적

## 🔗 관련 정보

- 홈페이지: [millbrook.co.uk](https://www.millbrook.co.uk)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Millbrook Proving Ground 공식 홈페이지 (2026.07 기준)*
