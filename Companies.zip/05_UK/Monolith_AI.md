---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/software
  - automotive/testing
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Monolith AI"
size: "스타트업"
fit: "★★"
business: "AI 기반 엔지니어링 시뮬레이션 SW (물리적 테스트 대체, 자동차 OEM 고객)"
hq: "London, England, UK"
founded: "2017"
employees: "~50명 (2024)"
revenue: "비공개 ($26M+ 투자)"
ipo_status: "비상장"
korea_office: "없음"
---

# Monolith AI

> AI 엔지니어링 시뮬레이션 | 런던 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2017년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 ($26M+ 투자) |
| 주력 사업 | AI/ML 기반 공학 시뮬레이션 — 물리적 테스트 결과 학습 후 새 설계 예측 (자동차·항공·방산) |
| 공식 홈페이지 | https://monolith.ai |

자동차 OEM·Tier 1이 수행하는 물리적 충돌·내구성·NVH 테스트를 AI로 대체·가속화. 기존 테스트 데이터로 ML 모델 훈련 → 새 설계의 성능 예측. 개발 사이클 단축·비용 절감. 르노·볼보 등 자동차 OEM 고객.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- 자동차 개발 사이클 단축 압박 → AI 시뮬레이션 도구 수요 급증
- 물리적 테스트 비용 절감 효과 명확 — OEM 채택 가속
- 르노·볼보 등 레퍼런스 고객 확보

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 엔지니어링 테스트 AI 도구 — QA·테스팅 경험 활용 가능 |
| 추천 직무 | ML Engineer, Automotive Simulation Developer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | ML/데이터 포트폴리오 중시 |

---

## 🔗 관련 정보

- 홈페이지: [monolith.ai](https://monolith.ai)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: monolith.ai 공식 (2026.05 기준)*
