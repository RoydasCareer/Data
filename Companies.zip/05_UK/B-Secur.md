---
tags:
  - company
  - automotive
  - country/uk
  - size/small
  - automotive/security
  - automotive/adas
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "B-Secur"
size: "중소기업"
fit: "★★"
business: "ECG 기반 생체인식 인증 SW (운전자 모니터링·차량 접근 제어)"
hq: "Belfast, Northern Ireland, UK"
founded: "2014"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# B-Secur

> ECG 생체인식 인증 SW | 벨파스트 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Belfast, Northern Ireland, UK |
| 설립 연도 | 2014년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | ECG(심전도) 신호 기반 운전자 생체인식·졸음 감지·차량 접근 제어 SW |
| 공식 홈페이지 | https://b-secur.com |

스티어링 휠·시트에 내장된 ECG 센서로 운전자를 연속 인증하는 생체인식 SW. **운전자 졸음·심장발작 조기 감지** — NCAP·ALKS 등 안전 규제와 연계. 차량 도난 방지(생체인식 잠금) 및 개인화 설정(운전자 식별)에도 활용.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- DMS(운전자 모니터링 시스템) Euro NCAP 2026년부터 의무화 → 생체인식 감지 수요 직결
- 스티어링 휠 내장 ECG 독보적 기술 — OEM 관심 증가
- 헬스케어·웨어러블 연계 확장 가능

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | DMS(운전자 모니터링) 분야 ADAS 안전 기술 — 자동차 SW QA 경험 활용 가능 |
| 추천 직무 | Embedded SW Engineer, Signal Processing Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 임베디드·신호처리 실무 경험 인정 |

---

## 🔗 관련 정보

- 홈페이지: [b-secur.com](https://b-secur.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: b-secur.com 공식 (2026.05 기준)*
