---
tags:
  - company
  - automotive
  - country/uk
  - size/mid
  - automotive/testing
  - automotive/adas
  - automotive/cybersecurity
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "HORIBA MIRA"
size: "중견기업"
fit: "★★★"
business: "자동차 테스팅·검증 엔지니어링 서비스 (AV·ADAS·사이버보안·동력계)"
hq: "Watling Street, Nuneaton, CV10 0TU, UK (MIRA Technology Park, Higham on the Hill, Leicestershire)"
founded: "1946 (MIRA) / 2015 (HORIBA MIRA로 개칭)"
employees: "미공개 (누네이튼 600명+ 역사적 기록)"
ipo_status: "비상장 사기업 — 모회사 HORIBA Ltd. (도쿄증권거래소 상장, TYO: 6856)"
korea_presence: "HORIBA 그룹 한국 법인 존재"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# HORIBA MIRA

> 자동차 테스팅·검증 엔지니어링 서비스 | 중견기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | HORIBA MIRA Ltd. |
| 등록번호 | 9626352 (잉글랜드 법인) |
| 등록 주소 | Watling Street, Nuneaton, CV10 0TU, UK |
| 기술 단지 | **850에이커 MIRA Technology Park** (Enterprise Zone) — Higham on the Hill, Leicestershire |
| 설립 연도 | **1946년** — Motor Industry Research Association(MIRA)로 설립 |
| 전신 | Cycle Engineers' Institute(1898) → IAE(1906) → MIRA(1946) |
| HORIBA 인수 | **2015년 7월** — HORIBA Ltd.에 인수 후 "HORIBA MIRA Ltd."로 개칭 |
| 모회사 | **HORIBA, Ltd.** (일본 교토 본사, **도쿄증권거래소 상장: TYO 6856**) |
| 대표 | Declan Allen (Managing Director) |
| 상장 여부 | **비상장** (모회사 HORIBA Ltd.는 도쿄증권거래소 상장) |
| 매출 | 비공개 (사기업. 2013년 기준 £45.7M — 현재 수치 미공개) |
| 임직원 수 | 미공개 (Nuneaton 사이트 기준 600명+ 역사적 기록) |
| 공식 홈페이지 | https://www.horiba-mira.com |

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 1946 | MIRA (Motor Industry Research Association) 설립 |
| 2015.07 | **HORIBA Ltd. 인수** — HORIBA MIRA Ltd.로 개칭 |
| 2025 | **HORIBA MIRA 창립 10주년** / King's Award for Enterprise 수상 |
| 2025 | UK 최초 정면 차 대 차(car-to-car) 충돌 테스트 가능 Passive Safety Centre 개소 |
| 2025 | MIRA Technology Park 내 **Analytical Solution Plaza** 신설 (HORIBA 분석 기술 협력 거점) |
| 2025.09 | **Cyber Resilience Act 교육 과정** 론칭 |
| 2025.10 | **SDVerse 멤버십** 가입 (SDV 혁신 생태계 참여) |
| 2026.04 | **사이버보안 감사인 교육 과정** 신규 출시 |

---

## 🛠️ 주력 서비스 상세 (2026 현재)

| 서비스 분야 | 설명 |
| :--- | :--- |
| **차량 엔지니어링** | 파워트레인, 섀시, NVH, 경량화, 기능안전. 전체 차량 개발 주기 엔지니어링 지원. |
| **커넥티드·자율주행 (CAV)** ⭐ | **ASSURED CAV 테스트 생태계**. **세계 최초 상용 가상 검증 환경(Virtual Proving Ground)**. **CERTUS AV 검증 프로그램**. AV 함수 실도로·가상 복합 검증. |
| **추진계·탄소중립** | EV, 수소, 하이브리드 동력계 테스트·검증. |
| **전기·전자(E&E) 시스템** | ECU 통합·검증, 차량 네트워크 테스팅. |
| **인증·형식승인(Homologation)** | 글로벌 규제(UN ECE, FMVSS 등) 대응 형식승인 지원. |
| **사이버보안** ⭐ | **UN R155·Cyber Resilience Act 대응 테스팅**. 사이버보안 감사인 교육 과정(2026.04). 차량 침투 테스트(펜 테스팅). |
| **방위·보안** | 방위 분야 차량·시스템 엔지니어링. |
| **Passive Safety** | UK 최초·유일의 정면 차 대 차 충돌 테스트 센터 (2025년 개소). |

---

## 🌍 그룹 거점

**HORIBA MIRA**: 영국 Nuneaton(Main) + Basildon, Essex(near London)

**HORIBA 그룹 한국 법인:**
- Horiba Korea Ltd.
- Horiba Automotive Test Systems Ltd.
- Horiba STEC Korea, Ltd.

> HORIBA MIRA 자체의 한국 직접 거점은 없으나, HORIBA 그룹 한국 법인을 통해 국내 영업·지원 가능.

---

## 🎯 전략 방향 (2025~2026)

| 분야 | 내용 |
| :--- | :--- |
| **AV 가상 검증** | 세계 최초 상용 Virtual Proving Ground — AV 알고리즘 가상 테스트·재현 가능한 엣지 케이스 검증. |
| **사이버보안** | UN R155·EU Cyber Resilience Act 의무화 대응 교육·테스팅 서비스 급성장. |
| **SDV 생태계** | SDVerse 참여(2025.10) — SDV 개발사와 테스팅 파트너십 구축. |
| **HORIBA 시너지** | Analytical Solution Plaza를 통한 HORIBA 계측 기술 + MIRA 테스팅 통합 서비스. |
| **탄소중립** | EV·수소 동력계 테스팅 역량 확대 — UK Net Zero 정책 대응. |

---

## 📈 성장성

**성장성 평가: ★★★★☆**

- **AV 검증 세계 최초 입지**: Virtual Proving Ground·CERTUS 프로그램으로 글로벌 AV 검증 시장 선점.
- **규제 대응 필수**: UN R155·Cyber Resilience Act 의무화로 사이버보안 테스팅 수요 구조적 증가.
- **HORIBA 그룹 배경**: 일본 상장사(TYO 6856) 산하 — 안정적 모그룹 지원.
- **850에이커 시설**: 대규모 전용 테스팅 파크는 복제 불가능한 진입장벽.
- **King's Award**: 영국 왕실 수여 기업 우수성 인증 → 고객사 신뢰도 최상.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 차량 테스팅·사이버보안·AV 검증 분야 세계 최고 수준 기관. JLR 진단 실차 경험 + CAN/UDS 프로토콜 이해 → E&E 시스템·사이버보안 테스팅 포지션 연결 가능. 영어권 취업·비자 지원 기업. |
| 추천 직무 | Automotive Test Engineer, E&E Systems Engineer, Cybersecurity Test Engineer, ADAS Validation Engineer |
| 지원 방법 | horiba-mira.com 채용 페이지 |
| 비자 스폰 (영국) | ★★★ — Skilled Worker Visa 스폰서. 급여 £26,200+ 필요. 학위 요건 없음. |
| 고졸 채용 가능성 | Skilled Worker Visa는 특정 학위 요건 없음 — 기술 경험으로 대체 가능. |

---

## ⚠️ 리스크 / 고려사항

- **재무 비공개**: 매출·직원 수 공식 비공개 — 경영 상태 파악 어려움
- **일본 모회사 종속**: HORIBA Ltd. 경영 방침에 따라 전략 변동 가능
- **중견 규모 (~600명)**: 포지션 수 제한적, 공고 빈도 낮을 수 있음
- **한국 법인은 HORIBA Korea**: HORIBA MIRA 직접 채용이 아닌 HORIBA 그룹 한국 법인 경유 가능 — 포지션 성격 상이

## 🔗 관련 정보

- 홈페이지: [horiba-mira.com](https://www.horiba-mira.com)
- LinkedIn: [linkedin.com/company/horiba-mira](https://www.linkedin.com/company/horiba-mira/)
- CAV: [horiba-mira.com/connected-autonomous-vehicles](https://www.horiba-mira.com/connected-autonomous-vehicles/)
- 모회사: [horiba.com](https://www.horiba.com) (TYO: 6856)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: horiba-mira.com 공식 페이지 (About·서비스·뉴스, 2026.05.27 직접 확인), HORIBA MIRA 10주년 보도자료 (2025.07), Wikipedia (MIRA Ltd.·HORIBA Ltd.)*
