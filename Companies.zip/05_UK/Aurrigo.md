---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Aurrigo"
size: "스타트업"
fit: "★★"
business: "자율 포드(pod)·셔틀 시스템 SW (공항·캠퍼스용 자율주행)"
hq: "Coventry, England, UK"
founded: "2018 (RDM Group 스핀아웃)"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (RDM Group 자회사)"
korea_office: "없음"
---

# Aurrigo

> 자율 포드·셔틀 SW | RDM Group 스핀아웃 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Coventry, England, UK |
| 설립 연도 | 2018년 (RDM Group 스핀아웃) |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 (RDM Group 자회사) |
| 주력 사업 | 공항·캠퍼스·병원용 자율 전기 포드(pod) 셔틀 시스템 및 SW |
| 공식 홈페이지 | https://aurrigo.com |

코번트리 기반 자율 포드 전문 스타트업. **Auto-DRT(자율 수요반응형 교통)** 솔루션 — 소형 전기 자율 셔틀로 공항·병원 캠퍼스 내 라스트마일 이동 제공. 히스로·개트윅 공항 파일럿, 싱가포르 공원 자율 셔틀 운영 이력.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 공항·병원 캠퍼스 라스트마일 자율교통 시장 초기 성장
- 소형 L4 AV 규제 선진국부터 상용화 진입 중
- 규모 대비 실증 실적 다수

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자율주행 포드 SW 개발 스타트업 — AV 검증·임베디드 경험 활용 가능 |
| 추천 직무 | AV SW Engineer, Autonomy Test Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 기술 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [aurrigo.com](https://aurrigo.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: aurrigo.com 공식 (2026.05 기준)*
