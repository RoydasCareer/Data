---
tags:
  - company
  - automotive
  - country/uk
  - size/small
  - automotive/telematics
  - automotive/fleet
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Trakm8"
size: "중소기업"
fit: "★★"
business: "플릿 텔레매틱스·커넥티드 차량·CCTV 안전 솔루션 (AIM: TRAK)"
hq: "Coleshill, Warwickshire, England, UK"
founded: "2004"
employees: "~500명 (2024)"
revenue: "~£34M GBP (FY2023)"
ipo_status: "AIM: TRAK (런던 AIM 상장)"
korea_office: "없음"
---

# Trakm8

> 플릿 텔레매틱스·커넥티드 차량 | AIM: TRAK | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Coleshill, Warwickshire, England, UK |
| 설립 연도 | 2004년 |
| 임직원 수 | ~500명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | AIM: TRAK (런던 대안 투자 시장 상장) |
| 주력 사업 | 상업용 플릿 텔레매틱스·커넥티드 차량·차량 CCTV·운전자 안전 모니터링 |
| 공식 홈페이지 | https://www.trakm8.com |

영국 상장 플릿 텔레매틱스 전문 기업. 상업 차량(밴·트럭·버스)에 차량 추적, OBD 연결 진단, 운전자 행동 모니터링, 차량 CCTV(AI 카메라) 솔루션 제공. NHS, 지방정부 등 공공 플릿 고객 다수.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 영국 상업 플릿 텔레매틱스 시장 안정적 성장
- AI 카메라 기반 운전자 안전(FORS 등 안전 기준 의무화) 수요 증가
- EV 플릿 전환 대응 EV 텔레매틱스 솔루션 확장 중

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | AIM 상장 플릿 텔레매틱스 기업. 차량 데이터·OBD·CAN 경험 직결 |
| 추천 직무 | Embedded SW Engineer, Fleet IoT Developer, QA Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원 — trakm8.com/careers) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 기술 자격 경험 인정 |

---

## 🔗 관련 정보

- 홈페이지: [trakm8.com](https://www.trakm8.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: trakm8.com 공식 (2026.05 기준)*
