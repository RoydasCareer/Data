---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Sensat"
size: "스타트업"
fit: "★"
business: "인프라 디지털 트윈·3D 매핑 SW (도로·철도·건설 인프라 — 자동차 SW 아님)"
hq: "London, England, UK"
founded: "2016"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Sensat

> 인프라 디지털 트윈·매핑 | 런던 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2016년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 도로·철도·인프라 건설 현장 3D 디지털 트윈 — 측량 데이터 시각화·협업 플랫폼 |
| 공식 홈페이지 | https://sensat.app |

> ⚠️ **자동차 SW 아님.** 도로·철도·건설 인프라 현장의 LiDAR·드론 측량 데이터를 3D 디지털 트윈으로 변환하는 플랫폼. 자동차 소프트웨어 엔지니어링과 직접 연관성 낮음.

도로 건설·인프라 공사 프로젝트 관리자·측량사·엔지니어를 위한 협업 도구. National Highways(영국 고속도로청) 등 공공 인프라 고객 다수.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 인프라 디지털화 트렌드 — 건설·엔지니어링 분야 성장
- 자동차 SW 분야와 거리 있음

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 인프라 디지털 트윈 기업 — 자동차 SW 경험 직결성 낮음 |
| 추천 직무 | 해당없음 (GIS·인프라 분야만 해당) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | GIS·측량 실무 경험 인정 |

---

## 🔗 관련 정보

- 홈페이지: [sensat.app](https://sensat.app)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: sensat.app 공식 (2026.05 기준) — ⚠️ 자동차 SW 아님, 인프라 디지털 트윈 기업*
