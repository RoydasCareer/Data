---
tags:
  - company
  - automotive
  - country/uk
  - size/large
  - automotive/semiconductor
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "ARM Holdings"
size: "대기업"
fit: "★★★"
business: "반도체 IP 라이선싱 (CPU/GPU/NPU 아키텍처) — 자동차 ASIL-D AE 프로파일"
hq: "Cambridge, England, UK"
founded: "1990"
employees: "~6,500명 (2024)"
revenue: "~$2.68B USD (FY2024)"
ipo_status: "NASDAQ: ARM (SoftBank Group ~75% 보유, 2023년 9월 재상장)"
korea_office: "ARM Korea Ltd. — 서울 종로구 (직영 법인)"
---

# ARM Holdings

> 반도체 IP 라이선싱 | NASDAQ: ARM | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Cambridge, England, UK |
| 설립 연도 | 1990년 |
| 임직원 수 | ~6,500명 (2024) |
| 규모 분류 | 대기업 |
| 상장 여부 | NASDAQ: ARM (SoftBank Group ~75% 보유, 2023년 9월 재상장) |
| 주력 사업 | CPU/GPU/NPU IP 라이선싱 — 전 세계 반도체 설계사에 코어 아키텍처 공급 |
| 공식 홈페이지 | https://www.arm.com |

전 세계 모바일·자동차·IoT 반도체의 절대 다수가 ARM 아키텍처 기반. 자동차 부문에서는 **Arm Automotive Enhanced(AE) 프로파일** — ASIL-D 안전 요건 충족 CPU/GPU IP를 자동차 SoC 설계사(NVIDIA, Qualcomm, NXP, Renesas 등)에 공급. SDV 중앙 컴퓨터 핵심 IP 공급사.

---

## 🇰🇷 한국 관련

**ARM Korea Ltd. — 서울 종로구 직영 법인 (정식 운영 중)**

- 삼성전자·SK하이닉스·LG전자·현대모비스 등 주요 한국 파트너 로컬 지원
- 반도체 IP 라이선싱 계약·엔지니어링 지원 업무
- ARM Korea 서울 오피스에서 소프트웨어 엔지니어·솔루션 아키텍트 채용

---

## 📈 성장성 평가

**성장성 평가: ★★★★★**

- SDV 전환으로 자동차 ARM IP 채택 급증 — 차량 SoC 사실상 표준
- 2030년까지 자동차 반도체 시장 $100B+ 예상
- NVIDIA DRIVE, Qualcomm Snapdragon Ride 등 차세대 자동차 SoC 모두 ARM 기반

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 한국 직영 법인 + 자동차 반도체 IP 핵심 기업. 삼성·현대 협력사 경험 직결 |
| 추천 직무 | Automotive Solutions Architect, SW Engineer (ARM Korea) |
| 한국 지원 경로 | ARM Korea Ltd. 채용 (arm.com/careers) |
| 비자 스폰 가능성 | ★★★ — 영국 본사 Skilled Worker Visa |
| 고졸 채용 가능성 | 실무 경험 중시 (ARM 생태계 경험 우선) |

---

## 🔗 관련 정보

- 홈페이지: [arm.com](https://www.arm.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: arm.com 공식, NASDAQ 공시 (2026.05 기준)*
