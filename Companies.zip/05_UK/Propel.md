---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/software
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Propel"
size: "스타트업"
fit: "★"
business: "자동차 SW 제품 라이프사이클 관리(PLM) 플랫폼"
hq: "London, England, UK"
founded: "~2018"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Propel

> 자동차 SW PLM | 런던 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | ~2018년 |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자동차 SW 제품·릴리스 라이프사이클 관리(PLM) 플랫폼 — OEM·Tier1 대상 |
| 공식 홈페이지 | ⚠️ 미확인 |

> ⚠️ **SW PLM 툴링 기업.** 자동차 SW 개발·릴리스·버전 관리를 지원하는 엔지니어링 툴 기업. 직접 차량 SW 개발이 아닌 개발 프로세스·도구 공급사로 임베디드 SW 엔지니어링 직무와 다소 거리 있음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- SDV 전환으로 SW PLM 도구 수요 증가
- 소규모 스타트업 — 생존 불확실성

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | SW PLM 툴링 기업 — 직접 차량 SW 개발 아님 |
| 추천 직무 | 해당없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모 스타트업 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: 공개 정보 (2026.05 기준)*
