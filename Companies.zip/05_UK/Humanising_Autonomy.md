---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - automotive/adas
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Humanising Autonomy"
size: "스타트업"
fit: "★★"
business: "자율주행용 보행자 행동 예측 AI (pedestrian intent prediction)"
hq: "London, England, UK"
founded: "2018 (Imperial College London 스핀아웃)"
employees: "~50명 (2024)"
revenue: "비공개 ($13M+ 투자)"
ipo_status: "비상장"
korea_office: "없음"
---

# Humanising Autonomy

> 보행자 행동 예측 AI | Imperial College 스핀아웃 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2018년 (Imperial College London 스핀아웃) |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 ($13M+ 투자, BMW·Ford 고객) |
| 주력 사업 | AV·ADAS용 취약 도로 사용자(보행자·자전거) 행동 예측 AI 플랫폼 |
| 공식 홈페이지 | https://humanisingautonomy.com |

AV 안전의 핵심 과제인 **취약 도로 사용자(VRU)** 행동 예측 AI 전문. 보행자·자전거의 의도와 다음 행동을 예측하는 딥러닝 모델. BMW·Ford 등 OEM 파트너로 실차 ADAS 통합 진행.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- AV 안전 규제(UN R155 등) 강화로 VRU 예측 AI 수요 필수화
- BMW·Ford 실사용 채택 — OEM 검증 완료
- 교통 약자 보호 AI 시장 빠른 성장

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | ADAS 안전 AI 분야 — AV 검증·ML 경험 활용 가능 |
| 추천 직무 | ML Engineer (Perception), ADAS Test Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | AI/ML 포트폴리오 중시 |

---

## 🔗 관련 정보

- 홈페이지: [humanisingautonomy.com](https://humanisingautonomy.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: humanisingautonomy.com 공식 (2026.05 기준)*
