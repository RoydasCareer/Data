---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Ultra Global"
size: "스타트업"
fit: "★"
business: "개인 신속 수송(PRT) 포드 시스템 — 히드로 T5 자율 포드 운영사"
hq: "Bath, England, UK"
founded: "2009"
employees: "~20명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Ultra Global

> PRT 자율 포드 시스템 | 바스 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Bath, England, UK |
| 설립 연도 | 2009년 |
| 임직원 수 | ~20명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | Personal Rapid Transit(PRT) 자율 포드 — 히드로 공항 T5 무인 포드 셔틀 운영 |
| 공식 홈페이지 | https://ultraglobalprt.com |

ULTra PRT 시스템으로 런던 히드로 공항 터미널 5 장기주차장 연결 무인 포드 셔틀 운영. 전기 구동·가이드웨이 기반 자율 이동 포드. 공항·도심 내 단거리 자율 이동 전문.

> ⚠️ **일반 자동차 ADAS 아님.** 가이드웨이(전용 레일·경로) 기반 PRT로 일반 도로 자율주행과 기술 스택 다름. 차량 임베디드 SW 엔지니어 포지션 희소.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 공항·도심 단거리 자율 이동 수요 존재
- 가이드웨이 PRT 시장 소규모 — 확장성 제한

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 가이드웨이 PRT 전문 — 일반 자동차 ADAS·임베디드 경험 직결성 낮음 |
| 추천 직무 | 해당없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모 스타트업 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [ultraglobalprt.com](https://ultraglobalprt.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: ultraglobalprt.com 공식 (2026.05 기준)*
