---
tags:
  - index
  - country/uk
country: "영국"
---

# 영국 🇬🇧 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 49개 |
| ★★★ 핵심 추천 | 7개 |
| ★★ 높은 적합성 | 19개 |
| ★ 보통 적합성 | 15개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | Skilled Worker Visa |
| 취득 용이성 | ★★★ |
| 학위 요건 | 직무 경험으로 학위 대체 가능 (특히 엔지니어링 직군) |
| 참고사항 | Skilled Worker Visa는 특정 학위 요건 없음. 급여 £26,200+ 및 스폰서 고용주 필요. |

## ⭐ 추천 기업 #Recommand

### ★★★★ 최우선 추천 (2026-07-31 신규 추가 — 이력서 기반 최적 매칭)
- [[Expleo_UK|Expleo UK]] — 자동차 SW 테스팅·ASPICE 컨설팅·품질 보증 (Coventry/Birmingham)
- [[KPIT_UK|KPIT Technologies UK]] — UDS/CAN 진단·ASPICE·AUTOSAR 자동차 SW (Coventry)
- [[Vector_UK|Vector Informatik UK]] — CANoe/CANalyzer 영국 기술지원·교육 (Bristol)
- [[Visteon_UK|Visteon UK]] — IVI·디지털 클러스터·HMI SW Tier-1 (Chelmsford/Solihull)

### ★★★ 핵심 추천
- [[Jaguar_Land_Rover|Jaguar Land Rover (JLR)]] — SW 정의 차량·자율주행 R&D
- [[Ricardo|Ricardo]] — 자동차 엔지니어링·SW 솔루션
- [[Horiba_MIRA|Horiba MIRA]] — 자동차 테스팅·QA·AV 엔지니어링
- [[Spirent_Communications|Spirent Communications]] — 자동차 네트워크·통신 테스팅
- [[Zenzic|Zenzic]] — 커넥티드·자율주행 테스팅 생태계
- [[Transport_Research_Laboratory|Transport Research Laboratory (TRL)]] — 자동차 안전·AV 연구·테스팅
- [[EDAG_UK|EDAG Engineering UK]] — A-SPICE·ISO26262·사이버보안 엔지니어링 (레밍턴 스파, FRA: ED4)
- [[Bentley_Motors|Bentley Motors]] — 럭셔리 EV·VW Group 진단·SDV 전환 (Crewe)
- [[AB_Dynamics|AB Dynamics]] — 차량 동역학 테스팅·ADAS 검증 장비 글로벌 선도 (Bradford-on-Avon, LSE: ABD)
- [[Millbrook_Proving_Ground|Millbrook Proving Ground]] — 영국 최대 자동차 종합 테스팅 시설 (Bedfordshire)

### ★★ 높은 적합성
- [[Delphi_Technologies|Delphi Technologies (BorgWarner)]] — 자동차 SW·전장 시스템
- [[Oxa|Oxa (Oxbotica)]] — 자율주행 SW 플랫폼 (HQ: Oxford)
- [[Humanising_Autonomy|Humanising Autonomy]] — AV용 행동 AI SW
- [[Beam_Connectivity|Beam Connectivity]] — 커넥티드카·텔레매틱스 SW
- [[Tantalum_Corporation|Tantalum Corporation]] — 커넥티드카·텔레매틱스 SW
- [[Trakm8|Trakm8]] — 텔레매틱스·플릿 관리 SW
- [[The_Floow|The Floow]] — 텔레매틱스·운전 행동 SW
- [[Trustonic|Trustonic]] — 자동차 사이버보안·TEE SW
- [[Fusion_Processing|Fusion Processing]] — 자율주행 시스템·SW
- [[Plextek|Plextek]] — 자동차 통신·센서 SW
- [[Monolith_AI|Monolith AI]] — 자동차 AI 엔지니어링 SW
- [[VNC_Automotive|VNC Automotive]] — 연결성·인포테인먼트 SW
- [[Cyber-Physical_Systems|Cyber-Physical Systems]] — 자동차 보안·테스팅
- [[Nodum|Nodum]] — 커넥티드 차량 데이터 플랫폼
- [[Smarter_Vision|Smarter Vision]] — AI 도로 안전·QA SW
- [[Five_AI|Five AI (Bosch 인수)]] — 자율주행 SW·시뮬레이션
- [[Neurolabs|Neurolabs]] — 합성 데이터 생성·AV 학습
- [[ASC_UK|Automotive Safety Consultancy (ASC)]] — ISO26262·A-SPICE·ISO21434 전문 컨설팅 (솔리헐)
- [[Blueskeye_AI|영국 2024 DMS·AV 스타트업 클러스터]] — Blueskeye AI·Maaind·EVIE Autonomous (Zenzic 지원 신생 3개사)

## 📋 전체 기업 목록 (적합도 낮은 기업 포함)

### ★ 보통 적합성
- [[ARM_Holdings|ARM Holdings]] — 자동차용 프로세서 IP·SW
- [[Wayve|Wayve]] — 구현된 AI 자율주행 (HQ: London)
- [[Aurrigo|Aurrigo]] — 자율 교통·SW 솔루션
- [[StreetDrone|StreetDrone]] — 자율 배달·야드 SW
- [[B-Secur|B-Secur]] — 자동차 SW용 생체인식 보안
- [[Sensat|Sensat]] — 디지털 트윈·자율주행 인프라 매핑
- [[Teraki|Teraki]] — AV용 엣지 AI·데이터 최적화 SW
- [[RealVNC|RealVNC]] — 자동차 인포테인먼트 원격 접근 SW
- [[Iotic|Iotic]] — 자동차 디지털 트윈 SW
- [[Miralis_Data|Miralis Data]] — 플릿 최적화·통신 SW
- [[Propel|Propel]] — 자동차 SW PLM
- [[Hadean|Hadean]] — 대규모 분산 시뮬레이션 플랫폼 (자동차 간접 연관)
- [[Conigital|Conigital]] — 무인 차량 SW·플랫폼
- [[Pervasive_Intelligence|Pervasive Intelligence]] — 자동차 데이터 애널리틱스 SW
- [[Carto|Carto]] — 위치 인텔리전스·자동차 매핑

### 기타 기업
- [[Envisics|Envisics]] — 자동차 HUD 홀로그래픽 SW
- [[Academy_of_Robotics|Academy of Robotics]] — 자율 배달 로봇·SW
- [[AppyWay|AppyWay]] — 스마트 주차·모빌리티 SW
- [[Dynium_Robot|Dynium Robot]] — 농업/산업용 AV SW
- [[Spark_EV_Technology|Spark EV Technology]] — 범위 예측·플릿 SW
- [[Ultra_Global|Ultra Global]] — 자율 포드 시스템·SW
- [[Connected_Kerb|Connected Kerb]] — 스마트 모빌리티·통신 SW
- [[Karhoo|Karhoo]] — 모빌리티 집계·SW
