---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/ev
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Connected Kerb"
size: "스타트업"
fit: "★"
business: "EV 충전 인프라·스마트 충전 플랫폼 (자동차 SW 아님 — 충전 인프라 하드웨어·SW)"
hq: "London, England, UK"
founded: "2019"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Connected Kerb

> EV 충전 인프라·스마트 충전 | 런던 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2019년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 도로변 EV 충전 인프라 설치·운영·스마트 충전 관리 플랫폼 |
| 공식 홈페이지 | https://connectedkerb.com |

> ⚠️ **자동차 SW 아님.** EV 충전 인프라(도로변 충전 포스트) 설치 및 충전 관리 플랫폼 회사. 차량 내부 SW(ADAS·IVI·임베디드) 개발과 무관. 공공 인프라 사업자 성격.

영국 지자체·공공기관과 협력해 도로 연석(kerb)에 EV 충전기를 설치하고 스마트 충전 소프트웨어로 충전 세션을 관리. 자가 충전 시설 없는 아파트 거주자 대상.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 영국 EV 전환 가속 — 충전 인프라 투자 확대
- 공공 충전 인프라 의무화 트렌드
- 자동차 SW 엔지니어 채용 포지션 없음

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | EV 충전 인프라 기업 — 자동차 임베디드 SW 경험 직결성 없음 |
| 추천 직무 | 해당없음 (충전 인프라·클라우드 분야만 해당) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [connectedkerb.com](https://connectedkerb.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: connectedkerb.com 공식 (2026.05 기준) — ⚠️ 자동차 SW 아님, EV 충전 인프라 기업*
