---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/mobility
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "AppyWay"
size: "스타트업"
fit: "★"
business: "스마트 주차·커브(노상) 관리 데이터 플랫폼 (실시간 주차 공간 API)"
hq: "London, England, UK"
founded: "2016"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# AppyWay

> 스마트 주차·커브 관리 | 런던 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2016년 |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 실시간 주차 공간·커브 데이터 API — 시·구청·주차 운영사에 디지털 커브 관리 플랫폼 제공 |
| 공식 홈페이지 | https://appyway.com |

도심 주차 공간 및 노상 커브(curb) 데이터를 실시간 디지털화하는 플랫폼. 자치단체·주차 운영사·자율주행 차량의 커브사이드 인프라 정보 제공. 자동차 SW와 직접 연관성은 낮음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 스마트 시티·자율주행 커브 데이터 수요 — 장기적 성장 가능
- 현재는 소규모 스타트업 — 재정 안정성 제한

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 스마트 주차 데이터 기업 — 자동차 SW 엔지니어링 직결성 낮음 |
| 추천 직무 | API Backend Developer (관심 분야인 경우) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | SW 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [appyway.com](https://appyway.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: appyway.com 공식 (2026.05 기준)*
