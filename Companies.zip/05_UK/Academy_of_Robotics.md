---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Academy of Robotics"
size: "스타트업"
fit: "★"
business: "자율 배달 로봇 Kar-go 개발 (물류 자동화, Royal Mail 파일럿)"
hq: "London, England, UK"
founded: "2015"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Academy of Robotics

> 자율 배달 로봇 Kar-go | 런던 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2015년 |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자율 라스트마일 배달 로봇 **Kar-go** 개발 (Royal Mail 파일럿 파트너) |
| 공식 홈페이지 | https://academyofrobotics.co.uk |

영국 자율 배달 로봇 스타트업. 소형 전기 자율 배달 차량 **Kar-go**로 UK Rural 지역 라스트마일 배달 자동화. Royal Mail과 파일럿 파트너십. 자동차보다는 물류 로보틱스 영역에 가까움.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 자율 배달 시장 장기 성장 — 단기 규제·기술 성숙도 리스크
- 소규모 스타트업 — 재정 안정성 미확인

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 물류 자율로봇 전문 — 자동차 ADAS SW 경험과 직접 연결성 낮음 |
| 추천 직무 | Robotics SW Engineer (관심 분야인 경우) |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 기술 포트폴리오 중시 |

---

## 🔗 관련 정보

- 홈페이지: [academyofrobotics.co.uk](https://academyofrobotics.co.uk)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: academyofrobotics.co.uk 공식 (2026.05 기준)*
