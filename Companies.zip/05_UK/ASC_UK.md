---
tags:
  - company
  - automotive
  - country/uk
  - size/small
  - automotive/functional-safety
  - automotive/aspice
  - automotive/cybersecurity
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Automotive Safety Consultancy (ASC)"
size: "소기업"
fit: "★★"
business: "자동차 기능안전(ISO26262)·A-SPICE·사이버보안(ISO21434) 전문 컨설팅 (영국 순수 전문 컨설팅사)"
hq: "Solihull, Birmingham, West Midlands, UK"
founded: "2012 (Companies House 등록번호: 08184859)"
employees: "[확인필요 — 소규모 전문 컨설팅, 추정 10~30명]"
revenue: "비공개"
ipo_status: "비상장 (소규모 독립 컨설팅사)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Automotive Safety Consultancy (ASC)

> 자동차 기능안전·A-SPICE·사이버보안 전문 컨설팅 | 소기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Solihull, Birmingham, West Midlands, UK |
| 설립 연도 | 2012년 (UK Companies House 등록: 08184859) |
| 임직원 수 | [확인필요] (추정 10~30명 — 전문 컨설팅 소규모 팀) |
| 규모 분류 | 소기업 |
| 상장 여부 | 비상장 (독립 소규모 컨설팅사) |
| 주력 사업 | ISO 26262 기능안전·Automotive SPICE·ISO/SAE 21434 사이버보안·IEC 62443·IATF 16949 컨설팅 |
| 공식 홈페이지 | https://automotivesafety.co.uk |

**솔리헐(Solihull)** — JLR 본사 소재지 인근 영국 자동차 산업 중심부. ISO26262·A-SPICE·ISO21434·IEC62443·IATF16949 커버하는 영국 순수 자동차 안전 전문 컨설팅사. "숙련된 기능안전 엔지니어 팀"으로 구성 — 고품질 소규모 전문사.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 영국 현지 취업 대상.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- ISO26262·A-SPICE·ISO21434 통합 컨설팅 수요 영국 내 지속 증가
- 솔리헐(JLR·자동차 클러스터) 위치 → 주요 고객사 접근성 우수
- UNECE R155/R156 의무화로 사이버보안 컨설팅 수요 급증

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | ISO26262·A-SPICE·ISO21434 3분야 전문 컨설팅사 — 역량 직결. 영국 자동차 산업 심장부 솔리헐 위치. |
| 추천 직무 | Functional Safety Consultant, A-SPICE Assessor, Cybersecurity Engineer |
| 한국 지원 경로 | 없음 (영국 직접 지원 — automotivesafety.co.uk) |
| 비자 스폰 가능성 | ★★ — 소규모 컨설팅사 Skilled Worker Visa 스폰 절차 복잡 가능 |
| 고졸 채용 가능성 | 기술 자격·경험 중심 |

---

## ⚠️ 리스크 / 고려사항

- **극소규모 (추정 10~30명)**: 채용 빈도 매우 낮음 — 공석 시 적극 네트워킹 필요
- **재무 불투명**: 소규모 비상장 — 경영 안정성 외부 확인 어려움
- **Skilled Worker Visa 스폰 불확실**: 소규모 회사 — 비자 스폰 경험·의지 사전 확인 필요
- **솔리헐 위치**: 런던에서 차로 2시간 — 거주지 선택 고려 필요

## 🔗 관련 정보

- 홈페이지: [automotivesafety.co.uk](https://automotivesafety.co.uk)
- LinkedIn: [확인필요]
- 채용: [automotivesafety.co.uk](https://automotivesafety.co.uk)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: automotivesafety.co.uk 공식, UK Companies House 등록 정보 (2026.06 기준)*
