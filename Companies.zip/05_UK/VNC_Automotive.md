---
tags:
  - company
  - automotive
  - country/uk
  - size/small
  - automotive/ivi
  - automotive/hmi
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "VNC Automotive"
size: "중소기업"
fit: "★★"
business: "차량 연결성·IVI 원격 접근·디지털 키 플랫폼 (RealVNC 자동차 사업부)"
hq: "Cambridge, England, UK"
founded: "~2015 (RealVNC 자동차 사업부 분리)"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (RealVNC 자회사·브랜드)"
korea_office: "없음"
---

# VNC Automotive

> 차량 연결성·IVI 원격 접근·디지털 키 | RealVNC 자동차 사업부 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Cambridge, England, UK |
| 설립 연도 | ~2015년 (RealVNC 자동차 사업부 분리) |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 (RealVNC 자회사·브랜드) |
| 주력 사업 | 차량 IVI 원격 진단 접근·디지털 키·스마트폰 차량 연동 미러링·OEM 포털 연결성 솔루션 |
| 공식 홈페이지 | https://vncautomotive.com |

RealVNC의 VNC 원격 접근 기술을 자동차에 특화한 솔루션. 딜러가 차량 IVI 시스템에 원격 접근해 진단·지원 수행, 스마트폰-차량 원활한 연동, 디지털 키(NFC/BLE) 솔루션. 볼보·재규어·벤츠 등 OEM 파트너.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- OTA 원격 진단·지원 확산 — 딜러 원격 접근 솔루션 수요 증가
- 디지털 키 표준화(ISO 18013-5, CCC 디지털 키) 확산
- RealVNC 기반 안정적 기술력

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | IVI 원격 접근·디지털 키 분야 — 차량 연결성·IVI SW 경험 직결 |
| 추천 직무 | Embedded SW Engineer (IVI), Connectivity Platform Developer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 임베디드·통신 실무 경험 인정 |

---

## 🔗 관련 정보

- 홈페이지: [vncautomotive.com](https://vncautomotive.com)
- 관련 파일: [[RealVNC|RealVNC (모회사)]]
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: vncautomotive.com 공식 (2026.05 기준)*
