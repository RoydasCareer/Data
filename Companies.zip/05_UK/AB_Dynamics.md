---
tags:
  - company
  - automotive
  - country/uk
  - size/mid
  - automotive/testing
  - automotive/adas
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "AB Dynamics"
size: "중견기업"
fit: "★★★"
business: "차량 동역학 테스팅 장비·ADAS 검증 로봇 글로벌 선도 (LSE 상장, 영국 HQ)"
hq: "Bradford-on-Avon, Wiltshire, UK"
founded: "1982"
employees: "~500명"
ipo_status: "상장 (LSE: ABD)"
korea_office: "없음"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# AB Dynamics

> 차량 동역학 테스팅·ADAS 검증 장비 글로벌 선도 | 중견기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Bradford-on-Avon, Wiltshire, UK |
| 설립 연도 | 1982 |
| 임직원 수 | ~500명 |
| 상장 여부 | 상장 (LSE: ABD) |
| 주력 사업 | ADAS 실차 테스팅 로봇, 드라이빙 로봇(Steer Robot), 차량 동역학 측정, HiL 시뮬레이션 |
| 공식 홈페이지 | https://www.abdynamics.com |

## 🎯 주요 제품 & 서비스

aRDE(ADAS 로봇 드라이빙 환경), GST 타겟(보행자·자전거 더미), 조향 로봇, VBOX(차량 동역학 측정), Ab-Opus 시뮬레이션. JLR·Bentley·BMW·Ford 등 글로벌 OEM 직접 납품. 영국 MIRA·Millbrook 테스팅 파트너.

## 🚗 자동차/모빌리티 관련성

ADAS 실차 검증 + CANoe 연동 자동화 테스팅 → 전수환의 CANoe 5년+ + ADAS QA 경험 직결. JLR 차량 검증 경험 보유자로 JLR 프로젝트 팀 즉시 기여 가능. 영국 HQ 직접 채용.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

Euro NCAP 2026 강화·UN R157 ALKS·Euro NCAP AEB 의무화로 ADAS 테스팅 장비 수요 폭증. LSE 상장 안정적 성장.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | ADAS 실차 테스팅 + CANoe 5년+ + JLR 실차 경험 → AB Dynamics Applications Engineer 최강 프로필. 영국 Skilled Worker Visa. |
| 추천 직무 | Applications Engineer, Test Systems Engineer, Validation Engineer |
| 지원 방법 | abdynamics.com/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★ (영국 상장사, Skilled Worker Visa 지원 가능) |

## ⚠️ 리스크 / 고려사항

- Bradford-on-Avon — Bath 인근 소도시 (런던에서 약 2시간)
- 장비 제조 중심이라 순수 SW 개발 포지션 제한적

## 🔗 관련 정보

- 홈페이지: [abdynamics.com](https://www.abdynamics.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: AB Dynamics 공식 홈페이지 (2026.07 기준)*
