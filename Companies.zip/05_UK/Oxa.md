---
tags:
  - company
  - automotive
  - country/uk
  - size/small
  - automotive/autonomous
  - automotive/adas
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Oxa (구 Oxbotica)"
size: "중소기업"
fit: "★★"
business: "상업용 자율주행 유니버설 오토노미 소프트웨어 플랫폼"
hq: "Oxford, England, UK"
founded: "2014 (Oxbotica) — 2023년 Oxa로 리브랜딩"
employees: "~200명 (2024)"
revenue: "비공개 ($225M+ 누적 투자)"
ipo_status: "비상장 ($140M Series C 2022 — bp ventures·Naviguide 등)"
korea_office: "없음"
---

# Oxa (구 Oxbotica)

> 유니버설 오토노미 SW 플랫폼 | Oxford 스핀아웃 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Oxford, England, UK |
| 설립 연도 | 2014년 (Oxbotica) — 2023년 Oxa로 리브랜딩 |
| 임직원 수 | ~200명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 ($140M Series C 2022, 누적 $225M+) |
| 주력 사업 | 다용도 자율주행 SW 플랫폼 (버스·배달·광산·공항 등 다분야 AV) |
| 공식 홈페이지 | https://oxa.tech |

옥스퍼드대 로보틱스 연구실 스핀아웃. **유니버설 오토노미(Universal Autonomy)** — 단일 SW 플랫폼으로 버스·물류 트럭·광산 차량·공항 AV 등 다양한 자율주행 응용 지원. Forth Valley CAVForth 자율버스, bp 물류 AV 파일럿 등 실증 프로젝트 진행.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- 상업용 AV 시장(물류·대중교통) 빠른 성숙 — B2B AV 솔루션 수요 증가
- bp venture 투자 — 에너지·물류 분야 AV 적용 가속
- 옥스퍼드 AI 생태계 기반 우수 인재 확보

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 영국 자율주행 핵심 스타트업. ADAS·AV 검증 경험 직결 |
| 추천 직무 | Autonomy Validation Engineer, Robotics SW Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 기술 포트폴리오 중시 |

---

## 🔗 관련 정보

- 홈페이지: [oxa.tech](https://oxa.tech)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: oxa.tech 공식 (2026.05 기준)*
