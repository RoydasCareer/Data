---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - automotive/adas
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Fusion Processing"
size: "스타트업"
fit: "★★"
business: "센서 퓨전·자율주행 제어 시스템 (CAVstar AV 플랫폼)"
hq: "Bath, England, UK"
founded: "2013"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Fusion Processing

> 센서 퓨전·AV 제어 시스템 | Bath 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Bath, England, UK |
| 설립 연도 | 2013년 |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 다중 센서 퓨전(LIDAR·레이더·카메라)·자율주행 제어 플랫폼 **CAVstar** |
| 공식 홈페이지 | https://fusionprocessing.co.uk |

Bath 기반 자율주행 시스템 전문 기업. **CAVstar** AV 플랫폼 — 센서 퓨전 + 경로 계획 + 실시간 제어 통합. **CAVForth** 자율 버스 프로그램(Edinburgh~Fife 구간) 기술 파트너. 공공 대중교통 AV 적용 실증 이력.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- CAVForth 자율버스 프로젝트 실증 완료 — 상업화 경로 확보
- 공공 대중교통 AV 시장 영국 정부 지원 지속
- 소규모 — 확장 자금 확보 여부가 변수

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 센서 퓨전·AV 시스템 실증 기업 — ADAS 검증 경험 직결 |
| 추천 직무 | Embedded SW Engineer, AV Systems Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 기술 포트폴리오 중시 |

---

## 🔗 관련 정보

- 홈페이지: [fusionprocessing.co.uk](https://fusionprocessing.co.uk)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: fusionprocessing.co.uk 공식 (2026.05 기준)*
