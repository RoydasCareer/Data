---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/adas
  - fit/★★
  - cluster
country: "영국"
country_folder: "05_UK"
company_name: "영국 2024 DMS·AV 스타트업 클러스터"
size: "스타트업"
fit: "★★"
business: "운전자 모니터링·자율주행 신생 스타트업 (Zenzic 생태계)"
hq: "영국"
last_updated: "2026-06-24"
fact_checked: "2026-06-24"
---

# 영국 2024 DMS·AV 스타트업 클러스터

> Zenzic 그랜트 수혜 신생 스타트업 3개사 | 영국 🇬🇧

영국 정부 자율주행 혁신기관 **Zenzic**이 2024년 지원한 소규모 스타트업들. 개별 규모는 작으나 DMS·AV 틈새 기술로 주목받는 업체들을 한 파일에 묶어 관리.

---

## 1. Blueskeye AI — AI 운전자 피로 탐지

| 항목 | 내용 |
| :--- | :--- |
| 설립 | ~2024 |
| 기술 | **안면 인식 + 음성 분석** 기반 실시간 졸음·피로 탐지 |
| 특징 | 경량 엣지 AI — 차량 내 저전력 처리 |
| 지원 | Zenzic 혁신 그랜트 2024 수혜 |
| 적합도 | ★★ — DMS 시스템 QA·검증 경력 활용 가능 |

## 2. Maaind — 운전자 인지 부하 평가

| 항목 | 내용 |
| :--- | :--- |
| 설립 | ~2024 |
| 기술 | 운전자의 **인지 과부하·주의력** 상태를 AI로 정밀 평가 |
| 특징 | Level 2~3 자율주행 핸드오버 최적화 솔루션 |
| 지원 | Zenzic 혁신 그랜트 2024 수혜 |
| 적합도 | ★★ — ADAS QA·DMS 검증 |

## 3. EVIE Autonomous — 전기 자율주행 셔틀

| 항목 | 내용 |
| :--- | :--- |
| 설립 | 2022 |
| 기술 | **4D 레이더 + 컴퓨터 비전** 융합 자율주행 셔틀 SW |
| 특징 | 캠퍼스·공항·병원 등 폐쇄 구역 저속 AV 운행 특화 |
| 규제 | 영국 Automated Vehicles Act 2025 수혜 예상 |
| 적합도 | ★ — 자율주행 SW QA 일부 활용 |

---

## ⭐ 공통 지원 전략

| 항목 | 내용 |
| :--- | :--- |
| 비자 | Skilled Worker Visa (£26,200+ · 스폰서 필요) |
| 비자 스폰 | ★★ — 초기 스타트업이라 불확실. Zenzic 채용 포털 모니터링 권장 |
| 고졸 채용 | 실무 역량 중심 스타트업 — 가능성 있음 |
| 접근 경로 | Zenzic Connected Places Catapult 채용 공고 → 이 세 기업 채용 정보 연결 |

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
- 관련 기업: [[Zenzic|Zenzic]], [[Humanising_Autonomy|Humanising Autonomy]], [[Oxa|Oxa]]
