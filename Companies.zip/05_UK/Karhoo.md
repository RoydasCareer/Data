---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/mobility
  - automotive/maas
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Karhoo"
size: "스타트업"
fit: "★"
business: "B2B 모빌리티 마켓플레이스 API — 지상 교통 집계 플랫폼"
hq: "London, England, UK"
founded: "2015"
employees: "~50명 (확인 필요)"
revenue: "비공개"
ipo_status: "비상장 (2017년 파산 후 재건)"
korea_office: "없음"
---

# Karhoo

> B2B 모빌리티 마켓플레이스 | 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2015년 |
| 임직원 수 | ~50명 (확인 필요) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 — 2017년 파산 후 인수·재건 |
| 주력 사업 | 택시·라이드헤일링·카셰어링 B2B API 집계 플랫폼 |
| 공식 홈페이지 | https://karhoo.com |

항공사·호텔·OTA(온라인 여행사) 등 B2B 파트너가 자사 플랫폼에 지상 교통 예약 기능을 통합할 수 있도록 API를 제공하는 MaaS(Mobility-as-a-Service) 기업. 2015년 런던에서 창업, 2017년 파산(약 $250M 투자 소진) 후 재건 이력. 현재 B2B 모빌리티 API 플랫폼으로 운영 중.

> ⚠️ **자동차 SW 직결성 낮음.** 모빌리티 플랫폼 소프트웨어 기업으로, 차량 제어·ADAS·임베디드 SW 개발과 직접적 연관성은 제한적.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 런던 중심 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- MaaS 시장 장기 성장 트렌드는 유효
- 파산 이력으로 재정 안정성 불확실
- 자율주행 연계 MaaS 생태계 확장 가능성 있으나 시기 미정

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 자동차 SW(임베디드·ADAS) 경험 직결성 낮음 — 모빌리티 API/백엔드 SW 기업 |
| 추천 직무 | Backend Engineer, Platform Engineer (자동차 SW 경력 활용 제한적) |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa (소규모 스타트업, 스폰서 여부 확인 필요) |
| 고졸 채용 가능성 | 경험 중시 — 학위 요건 유연할 수 있음 |

---

## 🔗 관련 정보

- 홈페이지: [karhoo.com](https://karhoo.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: karhoo.com 공개 정보, Crunchbase (2026.05 기준) — 파산 이력으로 일부 정보 불확실*
