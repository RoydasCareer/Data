---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/telematics
  - automotive/fleet
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Tantalum Corporation"
size: "스타트업"
fit: "★★"
business: "커넥티드카 보험 텔레매틱스·UBI(사용량 기반 보험) 데이터 플랫폼"
hq: "London, England, UK"
founded: "2013"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Tantalum Corporation

> 커넥티드카 보험 텔레매틱스·UBI | 런던 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2013년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 차량 텔레매틱스 데이터 기반 UBI(사용량 기반 보험) 솔루션 — 글로벌 보험사 파트너 |
| 공식 홈페이지 | https://tantalumcorporation.com |

전 세계 보험사에 텔레매틱스 기반 **UBI(Usage-Based Insurance)** 플랫폼 제공. 운전 행동 데이터(속도·제동·코너링)를 분석해 보험료 개인화. 아시아·남미·유럽 보험사 파트너 다수.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 한국 보험사(삼성화재·현대해상 등) 파트너십 가능성 있으나 미확인.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- UBI 보험 시장 전 세계 확산 — 커넥티드카 보급에 따른 자연 성장
- 개인화 보험료 수요 증가 — 밀레니얼 운전자 중심
- 소규모 스타트업 — 대형 보험 텔레매틱스 기업과 경쟁

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 차량 데이터·텔레매틱스 분야 경험 활용 가능 |
| 추천 직무 | Data Engineer, Telematics SW Developer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 데이터·SW 실무 경험 인정 |

---

## 🔗 관련 정보

- 홈페이지: [tantalumcorporation.com](https://tantalumcorporation.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: tantalumcorporation.com 공식 (2026.05 기준)*
