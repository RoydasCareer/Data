---
tags:
  - company
  - automotive
  - country/uk
  - size/large
  - automotive/software
  - automotive/testing
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Ricardo (WSP Global 자회사)"
size: "대기업"
fit: "★★★"
business: "자동차·에너지·방위·항공우주 기술 컨설팅·엔지니어링"
hq: "Shoreham-by-Sea, West Sussex, England (창업지·기술 센터)"
founded: "1915"
employees: "~2,700명"
revenue: "£474.7M (FY2023/24)"
ipo_status: "비상장 — 2025년 10월 WSP Global에 $670M에 인수 완료. 구 티커: LSE:RCDO (상폐)"
korea_presence: "직접 지사 미확인"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Ricardo

> 자동차·에너지·방위·항공우주 기술 컨설팅·엔지니어링 | 대기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 법인명 | Ricardo plc → **Ricardo** (WSP Global 자회사) |
| 창업지·기술 센터 | Shoreham-by-Sea, West Sussex, England |
| 설립 연도 | **1915년 2월** — Engine Patents Limited (창업자: **Harry Ricardo** — 내연기관 분야 세계적 권위자) |
| 구 주식 | **LSE: RCDO** (런던증권거래소) / ISIN: GB0007370074 — **2025년 10월 상폐** |
| 인수 | **2025년 10월 WSP Global (캐나다)에 $670M에 인수 완료** (2025년 6월 이사회 승인 → 10월 완료) |
| 현 상태 | **WSP Global의 완전 자회사** (독립 상장사 아님). 사명 유지. |
| 임직원 수 | **~2,700명** (professionals) |
| 연매출 | **£474.7M (FY2023/24)** |
| 글로벌 | 23개국 / 동시 진행 프로젝트 ~2,500건 |
| 공식 홈페이지 | https://www.ricardo.com |

> **[중요 사실]** Ricardo는 2025년 10월 이후 독립 상장사가 아닙니다. LSE 티커 RCDO는 상폐됐으며, WSP Global의 엔지니어링 컨설팅 자회사로 운영 중입니다.

> **모회사 WSP Global**: 캐나다 몬트리올 본사. 세계 최대 엔지니어링 컨설팅 기업 중 하나. TSX: WSP 상장.

### 주요 연혁

| 연도 | 사건 |
| :--- | :--- |
| 1915 | **Engine Patents Limited 창업** (Harry Ricardo) |
| 2009 | McLaren M838T 엔진 개발 (맥라렌 브랜드 재탄생 핵심) |
| 2010 | 영국 국방부 Foxhound 장갑차 프로젝트 납품 |
| 2012 | AEA Technology 인수 (£18M) |
| 2015 | Lloyd's Register Rail 인수 (£42.5M) |
| 2017 | 매출 £330M, 임직원 ~3,000명 |
| 2025.06 | WSP Global 인수 의향서 발표·이사회 권고 |
| **2025.10** | **WSP Global $670M 인수 완료** — LSE 상폐 |

---

## 🛠️ 주력 사업 분야 (2026 현재)

| 사업 영역 | 설명 |
| :--- | :--- |
| **자동차** | 파워트레인 개발·최적화, 전동화(EV/HEV), ADAS·자율주행 검증, 차량 성능 엔지니어링. |
| **클린 에너지** | 수소, 재생에너지 시스템, 탄소 감축 기술. |
| **철도·대중교통** | 철도 시스템 엔지니어링, 안전 분석. |
| **방위·항공우주** | 방위 차량, 무인 시스템, 항공우주 구조·추진. |
| **해양** | 선박 추진·에너지 효율. |
| **환경·정책** | 환경영향평가, 기후 정책 자문. |
| **정부·기관** | 교통·인프라 정책 컨설팅. |

**주요 레퍼런스:**
- **McLaren M838T 엔진**: 맥라렌 브랜드 부활의 핵심 엔진 설계 (2009)
- **Foxhound 장갑차**: 영국 국방부 조달 (2010)
- **22,500+ 기술 특허 포트폴리오** (누적)

---

## 🌍 글로벌 거점

**영국**: Shoreham-by-Sea (HQ·기술 센터), 기타 영국 내 오피스
**유럽**: 독일, 체코, 네덜란드 등
**미국**: 미시간, 캘리포니아 등
**아시아**: 일본, 중국 등
**기타**: 23개국 거점

> **한국**: 직접 지사 미확인.

---

## 🎯 전략 방향 (WSP 인수 이후, 2026~)

| 분야 | 내용 |
| :--- | :--- |
| **WSP 시너지** | WSP의 인프라·도시계획·환경 역량 + Ricardo의 자동차·에너지 기술 통합 → 스마트 모빌리티·클린 에너지 종합 솔루션. |
| **전동화·탈탄소** | 자동차 전동화(EV) + 클린 에너지(수소·재생에너지) = 핵심 성장 축. |
| **방위 다각화** | 방위·항공우주 포트폴리오 강화 — 불확실한 자동차 시장 대비. |
| **글로벌 확장** | WSP의 65개국 네트워크 활용 → Ricardo 기술 글로벌 배포 가속. |

---

## 📈 성장성 (WSP 인수 이후 관점)

**성장성 평가: ★★★☆☆**

- **$670M 인수 = 높은 가치 인정**: Ricardo의 기술력을 WSP가 전략적으로 평가.
- **안정적 수익 기반**: £474.7M 매출(FY2023/24), 2,700명 전문 인력. 자동차+에너지+방위 다각화.
- **WSP 산하 성장 잠재력**: WSP의 규모 경제·글로벌 네트워크 활용 가능.
- **불확실성**: 독립 상장사 소멸 → 전략 방향이 WSP 결정에 종속.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 자동차·클린에너지·방위 분야 종합 엔지니어링 컨설팅사. 차량 통신·진단 배경 있으면 EV 파워트레인 검증·자동차 시스템 테스팅 포지션 지원 가능. WSP 인수 후 글로벌 확장 기회도 있음. |
| 추천 직무 | Automotive Engineer, EV Systems Engineer, Technical Consultant, Powertrain Engineer |
| 지원 방법 | ricardo.com/en/careers (또는 wsp.com 채용) |
| 비자 스폰 (영국) | ★★★ — Skilled Worker Visa 스폰서. WSP Global의 대규모 글로벌 채용 여건. |
| 고졸 채용 가능성 | Skilled Worker Visa 학위 요건 없음. 기술직은 경험 우선. |

---

## ⚠️ 리스크 / 고려사항

- **WSP 인수 후 독립성 상실**: 전략 방향이 WSP Global 결정에 종속 — 자동차 집중도 희석 가능성
- **M&A 구조조정 가능성**: 인수 후 중복 기능 통폐합 리스크, 채용 규모 축소 가능
- **한국 직접 지사 없음**: 영국 본사 직접 지원 및 현지 이주 필요
- **다분야 컨설팅**: 자동차 특화 포지션 비중이 방위·에너지 대비 제한적일 수 있음
- **재무 공개 축소**: 독립 상장사 아니므로 재무 투명성 감소

## 🔗 관련 정보

- 홈페이지: [ricardo.com](https://www.ricardo.com)
- LinkedIn: [linkedin.com/company/ricardo-plc](https://www.linkedin.com/company/ricardo-plc/)
- 채용: [ricardo.com/en/careers](https://www.ricardo.com/en/careers)
- 모회사 WSP Global: [wsp.com](https://www.wsp.com) (TSX: WSP)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: ricardo.com 공식 페이지 (Who We Are·연혁), Wikipedia (Ricardo PLC — 2026년 3월 최종 편집), WSP Global 인수 공시 (2025.10) — 2026.05.27 직접 확인*
*[중요 업데이트] Ricardo는 2025년 10월 WSP Global에 $670M으로 인수 완료. LSE:RCDO 상폐. 독립 상장사 아님.*
