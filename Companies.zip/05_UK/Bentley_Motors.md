---
tags:
  - company
  - automotive
  - country/uk
  - size/large
  - automotive/ev
  - automotive/diagnostics
  - automotive/security
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Bentley Motors"
size: "대기업"
fit: "★★★"
business: "럭셔리 EV 자동차 제조·SW 정의 차량 전환·자동차 사이버보안"
hq: "Crewe, Cheshire, England, UK"
founded: "1919"
employees: "~4,500명"
ipo_status: "비상장 (Volkswagen Group 자회사)"
korea_office: "없음 (Bentley Korea 딜러 별도)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Bentley Motors

> 럭셔리 EV 자동차·SDV 전환·사이버보안 | 대기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Crewe, Cheshire, England, UK |
| 설립 연도 | 1919 |
| 임직원 수 | ~4,500명 |
| 상장 여부 | 비상장 (Volkswagen Group 자회사) |
| 주력 사업 | 럭셔리 자동차(Bentayga, Continental, Flying Spur), EV 전환, SDV 개발 |
| 공식 홈페이지 | https://www.bentleymotors.com |

## 🎯 주요 제품 & 서비스

Bentayga EWB(하이브리드), Flying Spur(PHEV), Continental GT. "Beyond100" 전략으로 2030년까지 전 라인업 전기화. VW Group MEB/PPE 플랫폼 기반 EV 개발, CARIAD 협력으로 SDV 전환 가속.

## 🚗 자동차/모빌리티 관련성

VW Group ODIS 진단 플랫폼 사용 → 전수환의 VW Group ODIS 경험 직접 활용 가능. EV 전환 가속으로 배터리·파워트레인 검증 수요 급증. Automotive Cybersecurity(ISO 21434) 도입으로 사이버보안 역할 신규 창출.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

럭셔리 EV 시장 성장 + VW Group SDV 전환(CARIAD) 수혜. 2030 완전 전기화 목표로 SW 엔지니어 대규모 채용 중.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | VW Group ODIS 경험 + 자동차 진단 통신 5년+ → Bentley 진단/검증 엔지니어 포지션. Automotive Cybersecurity 수료로 보안 역할 지원 가능. |
| 추천 직무 | Vehicle Diagnostics Engineer, Cybersecurity Analyst, EV Validation Engineer |
| 지원 방법 | bentleymotors.com/en/world-of-bentley/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★ (글로벌 자동차 OEM, Skilled Worker Visa 지원 경험) |

## ⚠️ 리스크 / 고려사항

- Crewe는 도시 규모가 작음 — 맨체스터 인근(약 30분) 거주 옵션
- 럭셔리 OEM 특성상 경력직 채용 기준 엄격
- VW Group 재정 상황에 따른 투자 변동 가능

## 🔗 관련 정보

- 홈페이지: [bentleymotors.com](https://www.bentleymotors.com)
- 관련: [[../16_Germany/Volkswagen_Group|VW Group]]
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Bentley Motors 공식 홈페이지 (2026.07 기준)*
