---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/ev
  - automotive/telematics
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Spark EV Technology"
size: "스타트업"
fit: "★"
business: "EV 주행 거리 예측·플릿 관리 SaaS"
hq: "Harrogate, North Yorkshire, England, UK"
founded: "2016"
employees: "~10명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Spark EV Technology

> EV 주행 거리 예측·플릿 SaaS | 요크셔 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Harrogate, North Yorkshire, England, UK |
| 설립 연도 | 2016년 |
| 임직원 수 | ~10명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | EV 배터리 상태·주행 가능 거리 실시간 예측 SaaS — 플릿 EV 전환 지원 |
| 공식 홈페이지 | https://sparkev.co.uk |

EV 플릿 운영사가 차량별 실시간 배터리 상태(SoC)·주행 가능 거리를 예측해 효율적으로 배차·충전 계획을 수립할 수 있는 SaaS 플랫폼.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- EV 플릿 전환 가속 — 거리 예측 솔루션 수요 증가
- 소규모 스타트업 — 성장 불확실

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | EV 플릿 SaaS 전문 — 자동차 임베디드 SW 직결성 낮음 |
| 추천 직무 | 해당없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모 스타트업 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [sparkev.co.uk](https://sparkev.co.uk)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: sparkev.co.uk 공식 (2026.05 기준)*
