---
tags:
  - company
  - automotive
  - country/uk
  - size/small
  - automotive/hmi
  - automotive/adas
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Envisics"
size: "중소기업"
fit: "★★★"
business: "홀로그래픽 AR HUD 기술 (자동차용 동적 홀로그램 헤드업 디스플레이)"
hq: "Milton Keynes, England, UK"
founded: "2017 (Two Trees Photonics 스핀아웃)"
employees: "~100명 (2024)"
revenue: "비공개 ($100M+ 누적 투자)"
ipo_status: "비상장 ($50M Series B 2021 — GM Ventures·JLR·Stellantis·Motional 투자)"
korea_office: "없음 (Motional — Hyundai·Aptiv JV — 투자 참여)"
---

# Envisics

> 홀로그래픽 AR HUD | GM·JLR·Stellantis 파트너 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Milton Keynes, England, UK |
| 설립 연도 | 2017년 (Two Trees Photonics 기술 기반 스핀아웃) |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 ($50M Series B 2021, GM Ventures·JLR·Stellantis·Motional 투자) |
| 주력 사업 | 동적 홀로그래픽 헤드업 디스플레이(HUD) — ADAS 내비·안전 경고 AR 투영 |
| 공식 홈페이지 | https://envisics.com |

차세대 자동차 **홀로그래픽 AR HUD** 선도 기업. 기존 HUD 대비 더 선명·넓은 시야각의 동적 홀로그램 이미지를 풍경에 투영. GM·JLR·Stellantis에서 전략 투자 유치. **Motional(Hyundai·Aptiv JV)**도 투자에 참여 — 현대차 그룹과 간접적 연결.

---

## 🇰🇷 한국 관련

한국 직영 법인 없음. Motional(현대차·Aptiv JV) 투자 참여로 현대차 그룹 공급망 연계 가능성.

---

## 📈 성장성 평가

**성장성 평가: ★★★★★**

- AR HUD 시장 2030년까지 $4B+ 성장 예상 — 자율주행 안전 인터페이스 핵심
- GM·JLR 양산 채택 확정 시 스케일업 고속화
- ADAS 정보 시각화 니즈와 직결 — SDV 시대 필수 HMI

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 차세대 AR HUD 선도 + GM·JLR·현대차(Motional) 투자 연결고리. ADAS HMI 최전선 |
| 추천 직무 | Embedded SW Engineer, Optical Systems Engineer, HUD Validation Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 광학·임베디드 실무 경험 중시 |

---

## 🔗 관련 정보

- 홈페이지: [envisics.com](https://envisics.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: envisics.com 공식 (2026.05 기준)*
