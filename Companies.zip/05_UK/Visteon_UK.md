---
tags:
  - company
  - automotive
  - country/uk
  - size/large
  - automotive/ivi
  - automotive/adas
  - fit/★★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Visteon UK"
size: "대기업"
fit: "★★★★"
business: "IVI·디지털 클러스터·ADAS 디스플레이 Tier-1 영국 R&D 센터"
hq: "Chelmsford, Essex / Solihull, UK (글로벌 HQ: Van Buren Township, MI, USA)"
founded: "2000"
employees: "~10,000명 글로벌"
ipo_status: "상장 (NASDAQ: VC)"
korea_office: "있음 (Visteon Korea)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Visteon UK

> IVI·디지털 클러스터·ADAS 디스플레이 Tier-1 | 대기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Chelmsford, Essex / Solihull, West Midlands, UK |
| 설립 연도 | 2000 (Ford 분사) |
| 임직원 수 | ~10,000명 글로벌 |
| 상장 여부 | 상장 (NASDAQ: VC) |
| 주력 사업 | 인포테인먼트(IVI), 디지털 클러스터, HMI SW, ADAS 디스플레이 시스템 |
| 공식 홈페이지 | https://www.visteon.com |

## 🎯 주요 제품 & 서비스

SmartCore™ 통합 콕핏 도메인 컨트롤러, AllGo IVI 플랫폼, 디지털 계기판, HMI SW, ADAS 디스플레이. JLR·Nissan·BMW·현대차 납품. 영국 Solihull 거점은 JLR 인접하여 JLR 프로젝트 직접 수행.

## 🚗 자동차/모빌리티 관련성

IVI QA(Hyundai Pleos 현재) + JLR IVI 진단 경험 → Visteon IVI 시스템 검증 역할 완전 직결. Android Automotive 기반 IVI + ADB/QFIL 실무 경험 + JLR/Hyundai 납품 경험 → 즉시 기여 가능.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

콕핏 전자화, SDV 전환, Android Automotive 채택 확대로 IVI 시장 폭발적 성장. 현대차·JLR 등 주요 고객사 SDV 가속.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | **IVI QA(Hyundai EV/HEV Pleos 검증, 현재) + ADB/QFIL/Fastboot 실무** → Visteon IVI Validation Engineer 최적 프로필. JLR 직접 납품 영국 거점에서 JLR DoIP 경험 추가 강점. Visteon Korea 통해 내부 이동 경로 가능. |
| 추천 직무 | IVI Validation Engineer, SW Test Engineer (Infotainment), HMI Test Lead |
| 지원 방법 | visteon.com/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★ (글로벌 Tier-1, Skilled Worker Visa 경험 있음) |

## ⚠️ 리스크 / 고려사항

- 반도체·자동차 경기에 따른 수주 변동 리스크
- Solihull 위치 — 버밍엄 인근, 생활 인프라 양호

## 🔗 관련 정보

- 홈페이지: [visteon.com](https://www.visteon.com)
- 관련: [[../33_India/Visteon_India|Visteon India]]
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Visteon Corporation 공식 홈페이지 (2026.07 기준)*
