---
tags:
  - company
  - automotive
  - country/uk
  - size/mid
  - automotive/testing
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Spirent Communications"
size: "중견기업"
fit: "★★★"
business: "네트워크·GNSS·자동차 이더넷 테스팅 장비·SW (Viavi Solutions 자회사, 2024년 인수)"
hq: "Crawley, West Sussex, England, UK"
founded: "1936 (전신)"
employees: "~1,800명 (2024)"
revenue: "~£420M GBP (2022, 독립 최종)"
ipo_status: "비상장 (Viavi Solutions NASDAQ:VIAV 자회사 — 2024년 10월 인수 완료)"
korea_office: "Spirent Korea Ltd. — 서울 강남구 (직영 법인, Viavi Korea 통합 진행 중)"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Spirent Communications

> 네트워크·GNSS·자동차 이더넷 테스팅 | Viavi Solutions 자회사 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Crawley, West Sussex, England, UK |
| 설립 연도 | 1936년 (Spirent plc 전신) |
| 임직원 수 | ~1,800명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 (Viavi Solutions NASDAQ:VIAV 자회사, 2024년 10월 인수) |
| 주력 사업 | GNSS 시뮬레이션·자동차 이더넷 테스팅·5G/네트워크 테스트 장비·SW |
| 공식 홈페이지 | https://www.spirent.com |

자율주행·ADAS에 필수인 **GNSS 포지셔닝 시뮬레이터** 세계 최고 수준 공급사. Spirent SimGEN/GSS 시리즈는 자동차 OEM 및 Tier 1의 GPS/GNSS 수신기 검증 표준 도구. 2024년 Viavi Solutions($1.3B)에 인수됨.

---

## 🇰🇷 한국 관련

**Spirent Korea Ltd. — 서울 강남구 직영 법인 (Viavi Korea 통합 진행 중)**

- 삼성전자·LG전자·현대자동차·SK텔레콤 등 주요 한국 고객사 지원
- GNSS 시뮬레이터·자동차 이더넷 테스트 장비 현지 영업·기술지원
- 2024년 Viavi 인수 후 Viavi Korea와 통합 절차 진행

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- 자율주행 GNSS 정밀 측위 의무화 → 시뮬레이터 수요 필수화
- 자동차 이더넷(100/1000BASE-T1) 차량 내부망 표준화 확대
- Viavi Solutions 편입으로 글로벌 테스팅 포트폴리오 강화

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 한국 직영 법인 + 자율주행 GNSS/이더넷 테스팅 핵심 기업. 자동차 QA 경험 직결 |
| 추천 직무 | Applications Engineer, Automotive Test Engineer (Korea/UK) |
| 한국 지원 경로 | Spirent Korea / Viavi Korea 채용 (spirent.com/careers) |
| 비자 스폰 가능성 | ★★★ — 영국 본사 Skilled Worker Visa |
| 고졸 채용 가능성 | 기술 자격·경험 중시 |

---

## ⚠️ 리스크 / 고려사항

- **Viavi 인수 후 통합 진행 중**: Spirent Korea·Viavi Korea 통합 과정에서 역할·직군 변동 가능성
- **독립 상장사 아님**: 전략 방향이 Viavi Solutions에 종속, 재무 투명성 감소
- **한국 법인 변동 가능성**: 통합 완료 전까지 지원 채널 혼선 가능 — 최신 채용 페이지 확인 필수
- **테스팅 장비 특화**: SW 개발보다 Applications Engineer(엔지니어링 지원) 위주 채용

## 🔗 관련 정보

- 홈페이지: [spirent.com](https://www.spirent.com)
- LinkedIn: [linkedin.com/company/spirent-communications](https://www.linkedin.com/company/spirent-communications/)
- 채용: [spirent.com/careers](https://www.spirent.com/careers)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: spirent.com 공식 (2026.05 기준) — ⚠️ 2024년 10월 Viavi Solutions 인수 완료*
