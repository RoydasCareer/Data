---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/software
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Teraki"
size: "스타트업"
fit: "★"
business: "AV용 엣지 AI·센서 데이터 압축 SW (⚠️ 독일 Berlin HQ — UK 폴더 오분류 가능성)"
hq: "Berlin, Germany (⚠️ 독일 기업 — UK 폴더 오분류 의심)"
founded: "2016"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Teraki

> AV용 엣지 AI·데이터 압축 | 독일 기업 | 🇩🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Berlin, Germany (⚠️ 독일 HQ — UK 폴더 오분류 의심) |
| 설립 연도 | 2016년 |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자율주행 차량 엣지 AI — LIDAR·카메라 센서 데이터 실시간 압축·필터링 SW |
| 공식 홈페이지 | https://teraki.com |

> ⚠️ **독일 기업(Berlin HQ) — UK 폴더 오분류.** Teraki GmbH는 독일 베를린에 설립·운영. 영국 법인 없음.

자율주행 차량에서 발생하는 방대한 센서 데이터를 엣지에서 실시간 압축·필터링하여 클라우드 전송량을 최소화하는 SW. LIDAR 포인트 클라우드·카메라 스트림 처리 특화.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- AV 데이터 처리 시장 성장 — 엣지 AI 최적화 수요 존재
- 소규모 독일 스타트업 — 독일 파일에 분류하는 것이 적합

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | ⚠️ 독일 기업 — UK 파일 위치 부정확. 독일 기업으로 재분류 필요 |
| 추천 직무 | 해당없음 (UK 폴더 오분류) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [teraki.com](https://teraki.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: teraki.com 공식 (2026.05 기준) — ⚠️ 독일(Berlin) HQ 기업, UK 폴더 오분류 확인*
