---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/software
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Iotic"
size: "스타트업"
fit: "★"
business: "IoT 시맨틱 상호운용성 플랫폼 (범용 IoT 디지털 트윈 — 자동차 간접 연관)"
hq: "London/Cambridge, England, UK"
founded: "2014"
employees: "~20명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Iotic

> IoT 디지털 트윈·상호운용성 | 영국 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London/Cambridge, England, UK |
| 설립 연도 | 2014년 |
| 임직원 수 | ~20명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | IoT 장치 간 시맨틱 데이터 상호운용성 플랫폼 — 스마트시티·인프라·산업 IoT |
| 공식 홈페이지 | https://iotic.com |

> ⚠️ **자동차 전문 기업 아님.** 범용 IoT 플랫폼으로 에너지·스마트시티·제조 산업 등에 적용. 차량 IoT 데이터 통합에 간접 활용 가능하나 자동차 전문 솔루션 아님.

Iotic은 서로 다른 IoT 장치·시스템이 의미론적(시맨틱)으로 데이터를 공유·연계할 수 있는 플랫폼을 제공. ioticSpace 프레임워크 기반.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- IoT 상호운용성 표준화 진행 — 범용 플랫폼 수요
- 자동차 SW 직접 연관성 낮음

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 범용 IoT 플랫폼 기업 — 자동차 임베디드 경험 직결성 낮음 |
| 추천 직무 | 해당없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모 스타트업 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [iotic.com](https://iotic.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: iotic.com 공개 정보 (2026.05 기준)*
