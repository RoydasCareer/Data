---
tags:
  - company
  - automotive
  - country/uk
  - size/large
  - automotive/oem
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Jaguar Land Rover"
size: "대기업"
fit: "★★★"
business: "럭셔리 자동차 OEM (SUV·세단·EV) — Tata Motors 자회사"
hq: "Coventry, England, UK"
founded: "2008 (합병 기준)"
employees: "~38,000명 (UK, 2024)"
revenue: "~£29.0B GBP (FY2024)"
ipo_status: "비상장 (Tata Motors NSE: TATAMOTORS 자회사)"
korea_office: "Jaguar Land Rover Korea Ltd. — 서울 강남구 (직영 법인)"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Jaguar Land Rover

> 럭셔리 자동차 OEM | Tata Motors 자회사 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Coventry, England, UK |
| 설립 연도 | 2008년 (Jaguar + Land Rover 합병) |
| 임직원 수 | ~38,000명 (UK), 글로벌 ~46,000명 |
| 규모 분류 | 대기업 |
| 상장 여부 | 비상장 (Tata Motors NSE: TATAMOTORS 자회사) |
| 주력 사업 | 럭셔리 자동차 제조·판매 (Jaguar, Land Rover, Defender, Range Rover) |
| 공식 홈페이지 | https://www.jaguarlandrover.com |

영국 최대 자동차 OEM. **JEA(Jaguar Electric Architecture)** 기반 완전 전동화 전환 진행 중. Solihull·Castle Bromwich·Halewood 공장 운영. EV 플래그십 Jaguar Type 00 출시 예정(2026). FY2024 £29B 역대 최고 매출.

---

## 🇰🇷 한국 관련

**Jaguar Land Rover Korea Ltd. — 서울 강남구 직영 법인 (정식 운영 중)**

- 재규어·랜드로버 브랜드 한국 공식 수입·판매·A/S 총괄
- JLR Korea 내 IT/디지털 엔지니어링 역할 채용 가능

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- FY2024 £29B 매출 — 역대 최고 실적
- Jaguar 완전 EV 전환(2025~) — 럭셔리 EV 시장 재진입
- ADAS·커넥티드카·OTA SW 개발 내재화 확대 (Coventry SW R&D 센터)

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 한국 직영 법인 + 영국 최대 자동차 OEM. ADAS·EV SW 개발 대규모 채용 |
| 추천 직무 | Embedded SW Engineer, ADAS Test Engineer, Connected Car SW (영국 본사) |
| 한국 지원 경로 | JLR Korea 채용 별도 / 영국 본사 jaguarlandrover.com/careers |
| 비자 스폰 가능성 | ★★★ — 영국 본사 Skilled Worker Visa |
| 고졸 채용 가능성 | 기술직 가능 (UK Apprenticeship 제도 활용) |

---

## ⚠️ 리스크 / 고려사항

- **Tata Motors 자회사 종속**: 인도 모회사 경영 전략에 따라 JLR 사업 방향 변동 가능
- **Jaguar EV 전환 불확실성**: 완전 전동화 브랜드 재포지셔닝 — 럭셔리 EV 시장 경쟁 치열
- **영국 공장 노조 리스크**: Unite 노조 파업 이력 — 생산 일정 영향 가능
- **한국 법인은 판매·A/S 위주**: JLR Korea 채용은 SW 엔지니어링보다 영업·A/S 직군 중심 — 영국 본사 지원 검토 필요
- **대기업 경쟁**: 글로벌 OEM 포지션 경쟁도 높음

## 🔗 관련 정보

- 홈페이지: [jaguarlandrover.com](https://www.jaguarlandrover.com)
- LinkedIn: [linkedin.com/company/jaguar-land-rover](https://www.linkedin.com/company/jaguar-land-rover/)
- 채용: [jaguarlandrover.com/careers](https://www.jaguarlandrover.com/careers)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: jaguarlandrover.com 공식 (2026.05 기준)*
