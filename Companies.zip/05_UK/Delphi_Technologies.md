---
tags:
  - company
  - automotive
  - country/uk
  - size/large
  - automotive/powertrain
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Delphi Technologies (BorgWarner)"
size: "대기업"
fit: "★★★"
business: "파워트레인·점화·전동화 부품 (BorgWarner NYSE:BWA 자회사, 2020년 인수)"
hq: "Gillingham, Kent, England, UK (BorgWarner 글로벌 HQ: Auburn Hills, MI, USA)"
founded: "2017 (Aptiv 분사) — 2020년 BorgWarner 인수"
employees: "~4,000명 (UK/Europe DT 사업부)"
revenue: "비공개 (BorgWarner 연결, 글로벌 $14.2B USD FY2023)"
ipo_status: "비상장 (NYSE: BWA BorgWarner 자회사)"
korea_office: "BorgWarner Korea Inc. — 경기도 화성시 (직영 법인)"
---

# Delphi Technologies (BorgWarner)

> 파워트레인·점화·전동화 부품 | NYSE: BWA 자회사 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Gillingham, Kent, England, UK (BorgWarner HQ: Auburn Hills, MI, USA) |
| 설립 연도 | 2017년 (Aptiv 분사) — 2020년 BorgWarner 인수 |
| 임직원 수 | ~4,000명 (UK/Europe DT 부문) |
| 규모 분류 | 대기업 |
| 상장 여부 | 비상장 (NYSE: BWA BorgWarner 자회사) |
| 주력 사업 | 엔진 관리 시스템·점화 장치·EV 파워 일렉트로닉스·HVAC 솔루션 |
| 공식 홈페이지 | https://www.borgwarner.com |

원래 Delphi Automotive의 파워트레인 사업부로 2017년 독립 상장. 2020년 BorgWarner가 $3.3B에 인수하여 BorgWarner DT로 통합. 영국 Gillingham(Kent)·Warwickshire 생산 거점 운영.

---

## 🇰🇷 한국 관련

**BorgWarner Korea Inc. — 경기도 화성시 직영 법인 (정식 운영 중)**

- 현대·기아차 파워트레인 부품 공급 핵심 협력사
- 경기 화성에 한국 생산·기술지원 법인 운영
- BorgWarner Korea 내 엔지니어링·품질 직군 채용

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- EV 전환 대응 전동화 부품(파워 일렉트로닉스·충전 시스템) 사업 확대
- BorgWarner '로드포워드' 전략 — EV 매출 비중 40%+ 목표
- 내연기관 점화 사업 점진 축소 — 전동화 전환 속도가 변수

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | BorgWarner Korea 직영 법인 화성 + 현대·기아 핵심 공급망 |
| 추천 직무 | SW Engineer (ECU), Quality Engineer, EV Systems Engineer |
| 한국 지원 경로 | BorgWarner Korea 채용 (borgwarner.com/careers) |
| 비자 스폰 가능성 | ★★★ — 영국 본사 Skilled Worker Visa |
| 고졸 채용 가능성 | 기술 자격 보유시 생산·품질직 가능 |

---

## 🔗 관련 정보

- 홈페이지: [borgwarner.com](https://www.borgwarner.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: borgwarner.com 공식 (2026.05 기준) — Delphi Technologies는 2020년 BorgWarner에 완전 통합*
