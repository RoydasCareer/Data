---
tags:
  - company
  - automotive
  - country/uk
  - size/small
  - automotive/telematics
  - automotive/fleet
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "The Floow"
size: "중소기업"
fit: "★★"
business: "운전 행동 분석·보험 텔레매틱스 데이터 사이언스 플랫폼 (LexisNexis 자회사)"
hq: "Sheffield, England, UK"
founded: "2012"
employees: "~150명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (LexisNexis Risk Solutions 자회사 ~2020년)"
korea_office: "없음"
---

# The Floow

> 운전 행동 분석·보험 텔레매틱스 | LexisNexis 자회사 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Sheffield, England, UK |
| 설립 연도 | 2012년 |
| 임직원 수 | ~150명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 (LexisNexis Risk Solutions 자회사, ~2020년 인수) |
| 주력 사업 | 스마트폰·OBD 텔레매틱스 기반 운전 점수화·보험 UBI·플릿 안전 솔루션 |
| 공식 홈페이지 | https://thefloow.com |

세계 35개국 이상에서 운전 행동 데이터를 수집·분석하는 텔레매틱스 플랫폼. 스마트폰 앱 기반으로 가속·제동·코너링·속도 초과를 실시간 분석. LexisNexis Risk Solutions(데이터 분석 대기업) 자회사로 안정적 모기업.

---

## 🇰🇷 한국 관련

한국 사무소 없음. LexisNexis 그룹 내 한국 법인 존재 가능성 있으나 Floow 사업부는 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- LexisNexis 데이터 자산과 결합한 보험 텔레매틱스 시장 확대
- 글로벌 UBI 보험 수요 증가
- LexisNexis 모기업 안정성

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 운전 데이터 분석·텔레매틱스 플랫폼 — 차량 데이터 경험 직결 |
| 추천 직무 | Data Engineer, Telematics Developer, Mobile SDK Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | SW 실무 경험 인정 |

---

## 🔗 관련 정보

- 홈페이지: [thefloow.com](https://thefloow.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: thefloow.com 공식 (2026.05 기준)*
