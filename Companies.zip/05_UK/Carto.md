---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/software
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "CARTO"
size: "중소기업"
fit: "★"
business: "위치 인텔리전스·공간 분석 플랫폼 (⚠️ 스페인·미국 HQ — UK 폴더 오분류)"
hq: "Madrid, Spain / New York, USA (⚠️ 스페인 기업 — UK 폴더 오분류 의심)"
founded: "2012"
employees: "~200명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# CARTO

> 위치 인텔리전스·공간 분석 플랫폼 | 스페인 기업 | 🇪🇸

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Madrid, Spain / New York, USA (⚠️ 스페인 HQ — UK 폴더 오분류 의심) |
| 설립 연도 | 2012년 |
| 임직원 수 | ~200명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 클라우드 기반 위치 인텔리전스·공간 데이터 분석 플랫폼 — 소매·물류·보험·모빌리티 고객 |
| 공식 홈페이지 | https://carto.com |

> ⚠️ **스페인 기업(Madrid HQ) — UK 폴더 오분류.** CARTO는 스페인 마드리드 설립 기업으로 런던 사무소도 있으나 HQ는 스페인. 스페인 파일에 분류하는 것이 적합. 또한 자동차 전문 기업이 아닌 범용 지리공간 분석 플랫폼.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 위치 인텔리전스 시장 성장 — 모빌리티·물류 분야 활용
- 자동차 SW 전문 기업 아님

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | ⚠️ 스페인 기업 — UK 파일 위치 부정확. 자동차 SW 전문 아님 |
| 추천 직무 | 해당없음 (UK 폴더 오분류) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [carto.com](https://carto.com)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: carto.com 공식 (2026.05 기준) — ⚠️ 스페인(Madrid) HQ 기업, UK 폴더 오분류 확인*
