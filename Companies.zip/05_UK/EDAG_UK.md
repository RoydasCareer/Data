---
tags:
  - company
  - automotive
  - country/uk
  - size/large
  - automotive/functional-safety
  - automotive/cybersecurity
  - automotive/aspice
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "EDAG Engineering UK"
size: "대기업"
fit: "★★★"
business: "자동차 사이버보안·기능안전(ISO26262)·A-SPICE 엔지니어링 서비스 (독일 EDAG Group 영국 법인)"
hq: "Leamington Spa, Warwickshire, UK; London Colney, Hertfordshire, UK"
founded: "[확인필요 — EDAG Group 1969년 독일 창립]"
employees: "9,133명 (EDAG Group 글로벌, 2024); 영국 오피스 규모 미공개"
revenue: "EUR ~800M (EDAG Group, FY2024 추정)"
ipo_status: "상장 — Frankfurt Stock Exchange: ED4"
korea_office: "없음 (EDAG 한국 법인 미확인)"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# EDAG Engineering UK

> 자동차 사이버보안·기능안전·A-SPICE 엔지니어링 | 대기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 레밍턴 스파 오피스 | 1 Spencer Yard, Leamington Spa, Warwickshire, CV31 3SY |
| 런던 콜니 오피스 | 273-275 High Street, London Colney, Hertfordshire, AL2 1HA |
| 설립 연도 | [확인필요] (EDAG Group 1969년 독일 창립) |
| 임직원 수 | 9,133명 (EDAG Group 글로벌, 2024); 영국 규모 미공개 |
| 규모 분류 | 대기업 |
| 상장 여부 | Frankfurt Stock Exchange: ED4 |
| 주력 사업 | 자동차 사이버보안(UNECE R155 대응)·기능안전(ISO 26262)·A-SPICE 컨설팅·엔지니어링 |
| 공식 홈페이지 | https://uk.edag.com |

독일 EDAG Group AG의 영국 법인. **레밍턴 스파(Warwickshire) — 영국 자동차 산업 심장부**(JLR·Jaguar 역사적 거점 인근). 영국·독일 테스팅 센터를 통한 **사이버보안 기능 테스팅**, ISO 26262·IEC 61508 기반 **기능안전 엔지니어링**, OEM/Tier1 협력사 대상 **A-SPICE 컨설팅** 서비스 제공. 프로젝트 팀 5~10명 전문가 구성.

---

## 🇰🇷 한국 관련

한국 법인 미확인. 독일 EDAG Group 내 한국 OEM(현대기아) 관련 프로젝트 가능성 있으나 직접 한국 채용 경로 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★☆☆**

- UNECE R155 사이버보안·R156 SW 업데이트 의무화 → 컨설팅 수요 구조적 성장
- A-SPICE 4.0 전환기 → 프로세스 개선 컨설팅 수요 증가
- 영국·독일 이중 거점 — EU/UK 고객사 양쪽 서비스 가능
- FRA: ED4 상장 → 재무 투명성 확보

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | A-SPICE·ISO26262·사이버보안 3개 분야 동시 수행 — 사용자 핵심 역량 100% 직결. 레밍턴 스파는 영국 자동차 산업 중심지. Skilled Worker Visa 스폰 가능 대기업. |
| 추천 직무 | Functional Safety Engineer, A-SPICE Consultant, Cybersecurity Test Engineer |
| 한국 지원 경로 | 없음 (영국 오피스 직접 지원 — uk.edag.com/careers) |
| 비자 스폰 가능성 | ★★★ — Skilled Worker Visa (대기업, 급여 £26,200+ 충족) |
| 고졸 채용 가능성 | 기술 자격·경험 중시 (학위 미필수 가능) |

---

## ⚠️ 리스크 / 고려사항

- **영국 오피스 규모 미공개**: 전체 9,133명이지만 영국 팀 규모 별도 확인 필요 — 채용 빈도 낮을 수 있음
- **자동차 시장 수요 의존**: FY2024 "어려운 시장 환경" 언급 — 자동차 산업 경기 민감
- **독일 본사 종속**: EDAG Group AG 전략 방향에 따라 영국 오피스 역할 변동 가능
- **한국 법인 없음**: 영국 현지 이주·Skilled Worker Visa 취득 필요

## 🔗 관련 정보

- 홈페이지: [uk.edag.com](https://uk.edag.com)
- 사이버보안·기능안전: [uk.edag.com/en/cyber-security-functional-safety-resilience](https://uk.edag.com/en/cyber-security-functional-safety-resilience)
- LinkedIn: [linkedin.com/company/edag-engineering-group](https://www.linkedin.com/company/edag-engineering-group/)
- 채용: [edag.com/en/career](https://www.edag.com/en/career)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: uk.edag.com 공식, EDAG Group AG FY2024 실적 발표, Companies House (2026.06 기준)*
