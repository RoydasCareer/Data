---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - fit/★
country: "영국"
country_folder: "05_UK"
company_name: "Conigital"
size: "스타트업"
fit: "★"
business: "자율 상용차 SW 플랫폼 (트럭·화물차 자율주행)"
hq: "London, England, UK"
founded: "2018"
employees: "~20명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Conigital

> 자율 상용차 SW | 런던 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2018년 |
| 임직원 수 | ~20명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자율 화물차·트럭용 SW 플랫폼 — 상용차 자율주행 기술 개발 |
| 공식 홈페이지 | https://conigital.com |

> ⚠️ **승용차 ADAS 직결성 낮음.** 주로 상용 화물차·대형 트럭 자율주행에 집중. 승용차 ADAS·IVI 경험과 직접 연관성 제한적. 소규모 스타트업으로 공개 채용 정보 희소.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 자율 상용차 물류 자동화 장기 트렌드 — 항만·화물 물류 자동화 수요
- 소규모 스타트업 — 생존 불확실성 존재

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 상용차 자율주행 전문 — 승용차 ADAS 경험 직결성 낮음 |
| 추천 직무 | 해당없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모 스타트업 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: conigital.com 공개 정보 (2026.05 기준)*
