---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - automotive/adas
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Wayve"
size: "스타트업"
fit: "★★★"
business: "자율주행 구현형 AI (Embodied AI) 플랫폼 — AV2.0 엔드투엔드 AI"
hq: "London, England, UK"
founded: "2017"
employees: "~600명 (2024)"
revenue: "비공개"
ipo_status: "비상장 ($1.05B Series C 2024 — Microsoft·NVIDIA·SoftBank Vision Fund 2 투자)"
korea_office: "없음"
---

# Wayve

> 자율주행 구현형 AI | $1.05B Series C | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London, England, UK |
| 설립 연도 | 2017년 |
| 임직원 수 | ~600명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 ($1.05B Series C — Microsoft·NVIDIA·SoftBank Vision Fund 2 투자) |
| 주력 사업 | 엔드투엔드 AI 기반 자율주행 플랫폼 (LINGO-1, PRISM-1 세계 모델) |
| 공식 홈페이지 | https://wayve.ai |

전 세계 자율주행 AI 분야 최고 주목 스타트업. **구현형 AI(Embodied AI)** 접근법으로 엔드투엔드 딥러닝 자율주행 구현. LINGO-1(언어 기반 설명 가능 AV), PRISM-1(세계 모델·시뮬레이션) 개발. Asda(영국 슈퍼마켓) 자율 배달 파일럿 운영.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 영국 및 미국(San Francisco) 거점 중심 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★★★★**

- $1.05B Series C(2024) — 글로벌 자율주행 스타트업 최대 투자 중 하나
- Microsoft·NVIDIA 전략적 투자 — 컴퓨팅 인프라·AI 연구 협력
- AV2.0(엔드투엔드 AI) 패러다임 선도

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 글로벌 최고 수준 AV AI 연구·개발 환경. 영국 자율주행 최전선 기업 |
| 추천 직무 | ML Engineer, AV Test Engineer, Autonomy Validation Engineer |
| 한국 지원 경로 | 없음 (영국 본사 직접 지원) |
| 비자 스폰 가능성 | ★★★ — Skilled Worker Visa, 글로벌 우수인력 적극 채용 |
| 고졸 채용 가능성 | AI/ML 포트폴리오 중시 — 학위 유연 |

---

## 🔗 관련 정보

- 홈페이지: [wayve.ai](https://wayve.ai)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: wayve.ai 공식 (2026.05 기준)*
