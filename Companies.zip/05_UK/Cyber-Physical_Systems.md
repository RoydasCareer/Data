---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/security
  - automotive/cybersecurity
  - fit/★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Cyber-Physical Systems"
size: "스타트업"
fit: "★★"
business: "자동차 사이버물리 시스템 보안·테스팅 컨설팅 (⚠️ 세부 정보 제한적)"
hq: "영국 (정확한 위치 미확인)"
founded: "⚠️ 미확인"
employees: "⚠️ 미확인 (소규모 추정)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Cyber-Physical Systems

> 자동차 사이버물리 보안·테스팅 | 영국 스타트업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | 영국 (정확한 위치 ⚠️ 미확인) |
| 설립 연도 | ⚠️ 미확인 |
| 임직원 수 | ⚠️ 소규모 추정 |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자동차 사이버물리 시스템(CPS) 보안 취약점 분석·침투 테스팅·ISO/SAE 21434 대응 컨설팅 |
| 공식 홈페이지 | ⚠️ 미확인 |

> ⚠️ **공개 정보 제한적.** 자동차 사이버보안(ISO/SAE 21434, UN R155) 분야 전문 컨설팅/테스팅 기업으로 분류됨. 구체적 회사 정보는 공식 채용 공고 및 LinkedIn을 통해 직접 확인 권장.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 자동차 사이버보안(ISO/SAE 21434) 의무화로 해당 분야 수요 급증
- 공개 정보 제한으로 성장성 평가 불확실

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 사이버보안 테스팅 분야 — CAN/DoIP 분석 경험 직결 가능 |
| 추천 직무 | Automotive Cybersecurity Engineer, Penetration Tester |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — Skilled Worker Visa |
| 고졸 채용 가능성 | 보안 실무 경험 인정 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: 공개 정보 제한적 (2026.05 기준) — LinkedIn/공식 채널 직접 확인 권장*
