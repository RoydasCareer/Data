---
tags:
  - company
  - automotive
  - country/uk
  - size/startup
  - automotive/autonomous
  - automotive/simulation
  - fit/★★
country: "영국"
country_folder: "05_UK"
company_name: "Five AI (중복)"
size: "스타트업 (Bosch 자회사)"
fit: "★★"
business: "→ FiveAI.md 참조 (동일 기업 중복 항목)"
hq: "Cambridge, England, UK"
founded: "2015"
employees: "~100명"
revenue: "비공개"
ipo_status: "비상장 (Bosch 자회사)"
korea_office: "없음"
---

# Five AI (중복 항목)

> ⚠️ 동일 기업 중복 항목 — [[FiveAI|FiveAI.md]] 참조

이 파일은 `FiveAI.md`와 동일한 기업(Five AI, Bosch 2022년 인수)의 중복 항목입니다.

모든 정보는 [[FiveAI|FiveAI.md]]를 참조하세요.

---

## 🔗 관련 정보

- 실제 파일: [[FiveAI|Five AI (Bosch 인수) — 메인 파일]]
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

## ⭐ 지원 추천 정보 #Recommand

> ⚠️ 중복 항목 — 지원 정보는 [[FiveAI|FiveAI.md]] 참조

---

*⚠️ 중복 항목 — FiveAI.md가 정식 파일*
