---
tags:
  - company
  - automotive
  - country/uk
  - size/large
  - automotive/testing
  - automotive/embedded
  - fit/★★★
  - recommend
country: "영국"
country_folder: "05_UK"
company_name: "Capgemini Engineering UK"
size: "대기업"
fit: "★★★"
business: "자동차 SW 검증·ADAS·EV 엔지니어링 서비스·디지털 변환 컨설팅"
hq: "London / Coventry / Birmingham, UK (글로벌 HQ: Paris, France)"
founded: "1967"
employees: "~50,000명 글로벌 (엔지니어링 부문)"
ipo_status: "상장 (Euronext: CAP)"
korea_office: "있음 (캡제미니코리아)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Capgemini Engineering UK

> 자동차 SW 검증·ADAS·EV 엔지니어링 서비스 | 대기업 | 영국 🇬🇧

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | London / Coventry / Birmingham, UK |
| 설립 연도 | 1967 (글로벌) |
| 임직원 수 | ~50,000명 (글로벌 엔지니어링 부문) |
| 상장 여부 | 상장 (Euronext: CAP) |
| 주력 사업 | 자동차 SW 검증, ADAS 엔지니어링, EV 시스템 개발, ASPICE 컨설팅, 기능안전 |
| 공식 홈페이지 | https://www.capgemini.com/gb-en |

## 🎯 주요 제품 & 서비스

자동차 SW 검증 자동화(HIL/SIL), ADAS 기능 개발·테스팅, EV 파워트레인 SW, ASPICE 프로세스 컨설팅, ISO 26262 기능안전. JLR·Bentley·Rolls-Royce 등 영국 OEM 파견 엔지니어 서비스. Altran(인수 통합)의 자동차 엔지니어링 역량 결합.

## 🚗 자동차/모빌리티 관련성

ASPICE + 자동차 SW 검증 + Technical PM → 영국 OEM 파견 역할. 캡제미니코리아를 통해 영국 파견 경로 가능.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

영국 자동차 SDV 전환·EV 가속으로 엔지니어링 서비스 수요 폭증.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | ASPICE Fundamentals + 자동차 SW QA 5년+ + Technical PM → Capgemini Engineering 핵심 채용 조건. 캡제미니코리아 내부 이동 경로. |
| 추천 직무 | Automotive Validation Engineer, ASPICE Consultant, Technical PM |
| 지원 방법 | capgemini.com/gb-en/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★★ (글로벌 대기업, Skilled Worker Visa 지원 풍부) |

## ⚠️ 리스크 / 고려사항

- 컨설팅 특성상 다수 클라이언트 파견
- 급여 수준 직접 고용 대비 낮을 수 있음

## 🔗 관련 정보

- 홈페이지: [capgemini.com/gb-en](https://www.capgemini.com/gb-en)
- 국가 인덱스: [[_INDEX|영국 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Capgemini Engineering 공식 홈페이지 (2026.07 기준)*
