---
tags:
  - company
  - automotive
  - country/denmark
  - size/startup
  - automotive/autonomous
  - automotive/adas
  - fit/★
country: "덴마크"
country_folder: "12_Denmark"
company_name: "Aalborg University (AV Research)"
size: "스타트업"
fit: "★"
business: "자율주행 연구"
hq: "(본사 위치 미확인) — 덴마크"
---

# Aalborg University (AV Research)

> 자율주행 연구 | 스타트업 | 덴마크 🇩🇰

## 🏢 회사 개요

AI 기반 자율주행 소프트웨어 플랫폼을 개발하는 기업입니다. 인식·판단·제어 알고리즘과 자율주행 검증·시뮬레이션 솔루션을 제공합니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 덴마크 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 스타트업 |
| 주력 사업 | 자율주행 연구 |

## 🎯 비전 & 미션

레벨 4~5 완전 자율주행 상용화로 교통사고 제로, 물류·이동 혁신을 목표로 합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

글로벌 자율주행 시장 2030년 $2조 이상 예상. 단기 규제 리스크 있으나 장기 성장은 확실.

---

## 📌 참고 정보

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ (보통) |
| 관련 역량 | ADAS QA 경험 활용 가능 |
| 비자 정보 | 취업 비자 (국가별 상이) |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|덴마크 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
