---
tags:
  - company
  - automotive
  - country/denmark
  - size/startup
  - automotive/software
  - fit/★★
  - recommend
country: "덴마크"
country_folder: "12_Denmark"
company_name: "Danish Technological Institute"
size: "스타트업"
fit: "★★"
business: "자동차 기술 R&D"
hq: "(본사 위치 미확인) — 덴마크"
---

# Danish Technological Institute

> 자동차 기술 R&D | 스타트업 | 덴마크 🇩🇰

## 🏢 회사 개요

자동차 소프트웨어 및 디지털 솔루션 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 덴마크 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 스타트업 |
| 주력 사업 | 자동차 기술 R&D |

## 🎯 비전 & 미션

자동차 산업의 디지털 전환을 지원하고 미래 모빌리티 생태계를 구축합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★**

자동차 SW 시장은 2030년까지 연 7~10% 성장 전망. SDV 전환이 핵심 성장 동력.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | 자동차 SW 분야 경험 활용 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★ |
| 고졸 채용 가능성 | 국가별 상이 |
| 비자 정보 | 취업 비자 (국가별 상이) |
| 비고 | 해당 국가 대사관 또는 채용 공고 확인 필요. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|덴마크 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
