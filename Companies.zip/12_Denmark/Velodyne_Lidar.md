---
tags:
  - company
  - automotive
  - country/denmark
  - size/startup
  - automotive/adas
  - automotive/sensing
  - fit/★
country: "덴마크"
country_folder: "12_Denmark"
company_name: "Velodyne Lidar (DK context)"
size: "스타트업"
fit: "★"
business: "LiDAR 인식 SW"
hq: "(본사 위치 미확인) — 덴마크"
---

# Velodyne Lidar (DK context)

> LiDAR 인식 SW | 스타트업 | 덴마크 🇩🇰

## 🏢 회사 개요

첨단 운전자 보조 시스템(ADAS) 소프트웨어 개발·검증 전문 기업입니다. 카메라·레이더·LiDAR 기반 인식 알고리즘을 개발합니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 덴마크 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 스타트업 |
| 주력 사업 | LiDAR 인식 SW |

## 🎯 비전 & 미션

자율주행으로 가는 중간 단계인 ADAS 기술로 교통사고 감소 및 이동 편의성을 향상시킵니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

2025년부터 ADAS 탑재 의무화 확대. 레벨 3 자율주행 상용화로 ADAS 수요 지속 증가.

---

## 📌 참고 정보

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ (보통) |
| 관련 역량 | ADAS QA(RSPA2) 경험 직접 활용 |
| 비자 정보 | 취업 비자 (국가별 상이) |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|덴마크 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
