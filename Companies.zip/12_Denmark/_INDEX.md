---
tags:
  - index
  - country/denmark
country: "덴마크"
---

# 덴마크 🇩🇰 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 31개 |
| ★★★ 핵심 추천 | 3개 |
| ★★ 높은 적합성 | 13개 |
| ★ 보통 적합성 | 15개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | 취업 비자 (국가별 상이) |
| 취득 용이성 | ★ |
| 학위 요건 | 국가별 상이 |
| 참고사항 | 해당 국가 대사관 또는 채용 공고 확인 필요. |

## ⭐ 추천 기업 #Recommand

### ★★★ 핵심 추천
- [[Universal_Robots|Universal Robots (Automotive QA)]] — 협동 로봇·자동차 QA SW
- [[Force_Technology|Force Technology (Automotive)]] — 자동차 테스팅·QA SW
- [[Falck_Teknik|Falck Teknik (Automotive)]] — 차량 검사·QA SW

### ★★ 높은 적합성
- [[Trackunit|Trackunit]] — 건설/산업용 텔레매틱스·플릿 SW
- [[MiR|MiR (Mobile Industrial Robots)]] — 자율 이동 로봇·SW
- [[CSIS_Security_Group|CSIS Security Group]] — 자동차 사이버보안·위협 인텔
- [[OnRobot|OnRobot (Automotive QA)]] — 자동차 QA용 엔드이펙터·SW
- [[Nordic_IoT_Centre|Nordic IoT Centre]] — 자동차 IoT·통신 R&D
- [[Alexandra_Institute|Alexandra Institute (AV)]] — 자율주행·V2X R&D
- [[Danish_Technological_Institute|Danish Technological Institute]] — 자동차 기술 R&D
- [[DOLL_Living_Lab|DOLL Living Lab]] — 스마트 시티·V2X 테스팅
- [[Unity_Technologies|Unity Technologies (DK R&D)]] — 자동차 시뮬레이션·HMI
- [[Sync_Innovation|Sync Innovation]] — 자동차 SW·IoT 솔루션
- [[MakerMind|MakerMind (Automotive)]] — 자동차 AI·임베디드 SW
- [[Konektio|Konektio]] — 커넥티드 차량 플랫폼
- [[Orion_Data_Network|Orion Data Network]] — 자동차 데이터·통신 SW

## 📋 전체 기업 목록 (적합도 낮은 기업 포함)

### ★ 보통 적합성
- [[Heimdal_Security|Heimdal Security]] — 자동차 엔드포인트 보안 SW
- [[Autonomous_Units|Autonomous Units]] — 자율 차량 SW (특수 작업용)
- [[Blue_Ocean_Robotics|Blue Ocean Robotics]] — 자율 서비스 로봇·SW
- [[Gate22|Gate22 (Smart Mobility)]] — 스마트 시티·V2X 이니셔티브
- [[Drivr|Drivr]] — 플릿 관리·라이드헤일 SW
- [[Vejdirektoratet|Vejdirektoratet (Road Dir.)]] — 스마트 도로·V2X SW
- [[Velodyne_Lidar|Velodyne Lidar (DK context)]] — LiDAR 인식 SW
- [[Roborace|Roborace (DK presence)]] — 자율 레이싱 SW
- [[Trifork|Trifork (Automotive)]] — 자동차 SW·디지털 변환
- [[DTU_Compute|DTU Compute (Autonomous)]] — 자율주행·ML R&D
- [[Aalborg_University|Aalborg University (AV Research)]] — 자율주행 연구
- [[Elsass|Elsass (Automotive)]] — 자동차 IoT·커넥티비티
- [[Nuuday|Nuuday (Automotive)]] — V2X·커넥티드 차량
- [[DTU|DTU (Technical University of Denmark)]] — 스마트 모빌리티·V2X R&D
- [[Sund_&_Bælt|Sund & Bælt (Smart Mobility)]] — 스마트 교량·교통 SW
