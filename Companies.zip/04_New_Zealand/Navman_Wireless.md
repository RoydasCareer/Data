---
tags:
  - company
  - automotive
  - country/new-zealand
  - size/mid
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "뉴질랜드"
country_folder: "04_New_Zealand"
company_name: "Navman Wireless (Trimble Transportation)"
size: "중견기업"
fit: "★"
business: "플릿 GPS 텔레매틱스·규정 준수 SW (NZ 기원, Trimble 자회사)"
hq: "Auckland, New Zealand (글로벌 HQ: Trimble, Sunnyvale, CA, USA)"
founded: "1994"
employees: "~600명 글로벌 (Trimble Transportation 내)"
revenue: "비공개 (Trimble 연결)"
ipo_status: "비상장 (NASDAQ: TRMB Trimble 자회사)"
korea_office: "없음"
---

# Navman Wireless (Trimble Transportation)

> 플릿 GPS 텔레매틱스·규정 준수 SW | Trimble 자회사 | 뉴질랜드 기원 🇳🇿

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Auckland, NZ (글로벌 HQ: Trimble Transportation, Sunnyvale CA) |
| 설립 연도 | 1994년 (NZ 창업) |
| 임직원 수 | ~600명 (Trimble Transportation 내) |
| 규모 분류 | 중견기업 (Trimble 자회사) |
| 상장 여부 | 비상장 (Trimble Inc. NASDAQ: TRMB 자회사) |
| 주력 사업 | 상업 플릿 GPS 추적·ELD·규정 준수 솔루션 — NZ/AU/북미 |
| 공식 홈페이지 | https://www.navmanwireless.com.au |

> ⚠️ **독립 NZ 기업 아님.** NZ 기원이나 2012년 Trimble에 인수. 현재 Trimble Transportation 브랜드로 운영.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- Trimble Transportation 포트폴리오 내 안정적 브랜드.
- NZ/AU 시장 특화 플릿 텔레매틱스.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | Trimble 자회사 — 독립 NZ 기업 아님. 한국 사무소 없음. |
| 추천 직무 | SW Engineer (플릿 추적 플랫폼) — NZ 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — AEWV 가능 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [navmanwireless.com.au](https://www.navmanwireless.com.au)
- 국가 인덱스: [[_INDEX|뉴질랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: navmanwireless.com.au + Trimble 공시 (2026.05 기준)*
