---
tags:
  - company
  - automotive
  - country/new-zealand
  - size/small
  - automotive/testing
  - fit/★
country: "뉴질랜드"
country_folder: "04_New_Zealand"
company_name: "Vehicle Inspection NZ (VINZ)"
size: "중소기업"
fit: "★"
business: "NZ 차량 안전검사(WoF·CoF) 인증 기관 (물리적 차량 검사, SW QA 아님)"
hq: "Wellington, New Zealand"
founded: "1994"
employees: "~200명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Vehicle Inspection NZ (VINZ)

> NZ 차량 안전검사(WoF·CoF) 기관 | 중소기업 | 뉴질랜드 🇳🇿

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Wellington, New Zealand |
| 설립 연도 | 1994년 |
| 임직원 수 | ~200명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | NZ 정부 위임 차량 안전검사 — WoF(운행적합증), CoF(상업용 차량 인증) 발급 |
| 공식 홈페이지 | https://www.vinz.co.nz |

> ⚠️ **자동차 SW QA 아님.** 물리적 차량 안전 검사(브레이크·조향·타이어·등화류 등) 전문 인증 기관. SW 테스팅과 구별됨.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- NZ 차량 검사 수요 안정적 — 자동차 임베디드 SW 직접 연관 낮음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 물리적 차량 검사 기관 — 자동차 SW 개발과 무관. 한국 사무소 없음. |
| 추천 직무 | 해당없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — AEWV |
| 고졸 채용 가능성 | 기술직 고졸 가능 (차량 검사관) |

---

## 🔗 관련 정보

- 홈페이지: [vinz.co.nz](https://www.vinz.co.nz)
- 국가 인덱스: [[_INDEX|뉴질랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: vinz.co.nz 공식 (2026.05 기준)*
