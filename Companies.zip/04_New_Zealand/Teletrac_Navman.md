---
tags:
  - company
  - automotive
  - country/new-zealand
  - size/mid
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "뉴질랜드"
country_folder: "04_New_Zealand"
company_name: "Teletrac Navman (NZ 법인)"
size: "중견기업"
fit: "★"
business: "상업 플릿 GPS·ELD·규정 준수 텔레매틱스 (미국 HQ Vontier 자회사)"
hq: "Auckland, New Zealand (글로벌 HQ: Vontier, Chicago, IL, USA)"
founded: "1988 (Teletrac 미국 창업)"
employees: "~600명 글로벌"
revenue: "비공개 (Vontier 연결)"
ipo_status: "비상장 (NYSE: VNT Vontier 자회사)"
korea_office: "없음"
---

# Teletrac Navman (NZ 법인)

> 상업 플릿 GPS·ELD 텔레매틱스 | Vontier 자회사 | 뉴질랜드 법인 🇳🇿

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Auckland, NZ (글로벌 HQ: Chicago, IL, USA) |
| 설립 연도 | 1988년 (Teletrac 미국 창업) |
| 임직원 수 | ~600명 글로벌 |
| 규모 분류 | 중견기업 (Vontier 자회사) |
| 상장 여부 | 비상장 (NYSE: VNT Vontier 자회사) |
| 주력 사업 | 상업 차량 GPS 추적·ELD(전자 로그 장치)·드라이버 안전·규정 준수 — NZ/AU/북미 |
| 공식 홈페이지 | https://www.teletracnavman.com |

Teletrac(미국)과 Navman Wireless(NZ)가 합병된 브랜드. 현 Vontier/Fortive 자회사. NZ/AU 법인 운영.

> ⚠️ **미국 HQ 기업.** NZ는 지역 법인. 한국 사무소 없음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- Vontier 포트폴리오 내 안정적 플릿 관리 플랫폼.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 미국 HQ 기업, NZ 지역 법인. 한국 사무소 없음. |
| 추천 직무 | SW Engineer (플릿 플랫폼) — NZ/AU 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — AEWV |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [teletracnavman.com](https://www.teletracnavman.com)
- 국가 인덱스: [[_INDEX|뉴질랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: teletracnavman.com 공식 (2026.05 기준)*
