---
tags:
  - company
  - automotive
  - country/new-zealand
  - size/mid
  - automotive/telematics
  - automotive/fleet
  - fit/★★
country: "뉴질랜드"
country_folder: "04_New_Zealand"
company_name: "Eroad"
size: "중견기업"
fit: "★★"
business: "중대형 차량 텔레매틱스·ERUC 규정 준수·플릿 관리 SaaS (NZ/AU/북미)"
hq: "Auckland, New Zealand"
founded: "2000"
employees: "~450명 (2024)"
revenue: "~$118M NZD (FY2023)"
ipo_status: "비상장 (2023년 NZX 상장폐지, Kinetic Capital 인수)"
korea_office: "없음"
---

# Eroad

> 중대형 차량 텔레매틱스·ERUC·플릿 관리 SaaS | 중견기업 | 뉴질랜드 🇳🇿

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Auckland, New Zealand |
| 설립 연도 | 2000년 |
| 임직원 수 | ~450명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 (NZX 상장폐지 2023, Kinetic Capital 비공개 인수) |
| 주력 사업 | 중대형 차량 ERUC(전자 도로 이용료) 준수 + 플릿 GPS 텔레매틱스 + ELD(미국 전자 로그 장치) SaaS |
| 공식 홈페이지 | https://www.eroad.co.nz |

NZ·AU·북미 중대형 화물차 시장 특화. ERUC 결제 시스템이 핵심 경쟁력. Coretex(화물차 안전·피로 모니터링 전문) 인수(2021)로 포트폴리오 확장.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 중대형 차량 규정 준수 플랫폼 — 안정적 반복 매출.
- NZ·AU 이외 북미 확장 중이나 성장세 둔화로 비공개 전환.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | NZ 최대 플릿 텔레매틱스 기업. SW 엔지니어 채용 지속. |
| 추천 직무 | Embedded SW / Platform Engineer (텔레매틱스 하드웨어·SaaS 백엔드) |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — AEWV (Accredited Employer Work Visa) |
| 고졸 채용 가능성 | 경험 중심 채용 가능 |

---

## 🔗 관련 정보

- 홈페이지: [eroad.co.nz](https://www.eroad.co.nz)
- 국가 인덱스: [[_INDEX|뉴질랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: eroad.co.nz 공식 + NZX 공시 (2026.05 기준)*
