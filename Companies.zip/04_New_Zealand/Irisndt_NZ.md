---
tags:
  - company
  - country/new-zealand
  - size/small
  - fit/★
country: "뉴질랜드"
country_folder: "04_New_Zealand"
company_name: "Iris NDT NZ"
size: "중소기업"
fit: "★"
business: "산업 비파괴검사(NDT) 장비·서비스 — 배관·탱크·압력용기 검사 (자동차 SW QA 무관)"
hq: "New Zealand"
founded: "—"
employees: "~30명 (NZ 법인)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Iris NDT NZ

> 산업 비파괴검사(NDT) 장비·서비스 | 중소기업 | 뉴질랜드 🇳🇿

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | New Zealand |
| 설립 연도 | 미확인 |
| 임직원 수 | ~30명 (NZ 법인) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 초음파·와전류 기반 배관·탱크·열교환기 비파괴검사(NDT) 장비·서비스 — 석유화학·발전·해양 산업 |
| 공식 홈페이지 | https://www.irisndt.com |

> ⚠️ **자동차 SW QA 무관.** 산업 NDT(비파괴검사) 기업. '자동차 QA SW'로 오분류됨.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★**

- 산업 NDT 서비스 — 자동차 SW 무관.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 자동차 SW 무관 산업 NDT 기업. 한국 사무소 없음. |
| 추천 직무 | 해당없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | 미확인 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [irisndt.com](https://www.irisndt.com)
- 국가 인덱스: [[_INDEX|뉴질랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: irisndt.com 공식 (2026.05 기준) — ⚠️ 자동차 QA 오분류 확인*
