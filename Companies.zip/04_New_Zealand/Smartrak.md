---
tags:
  - company
  - automotive
  - country/new-zealand
  - size/small
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "뉴질랜드"
country_folder: "04_New_Zealand"
company_name: "Smartrak"
size: "중소기업"
fit: "★"
business: "공공부문·정부 차량 플릿 관리 SaaS (NZ/AU)"
hq: "New Plymouth, New Zealand"
founded: "1998"
employees: "~80명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Smartrak

> 공공부문 차량 플릿 관리 SaaS | 중소기업 | 뉴질랜드 🇳🇿

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | New Plymouth, New Zealand |
| 설립 연도 | 1998년 |
| 임직원 수 | ~80명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | NZ/AU 정부기관·지자체 차량 플릿 관리 SaaS — 예약, 풀링, 드라이버 추적, 탄소 보고 |
| 공식 홈페이지 | https://www.smartrak.com |

공공부문 특화 — NZ 정부부처, 지방의회, 병원 등 공공기관 차량 관리.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- NZ/AU 공공부문 특화 — 안정적 고객 기반.
- 소규모 — 글로벌 확장 어려움.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | NZ 공공부문 특화 소기업. 한국 사무소 없음. |
| 추천 직무 | SW Engineer (SaaS 플릿 관리) — NZ 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — AEWV 가능 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [smartrak.com](https://www.smartrak.com)
- 국가 인덱스: [[_INDEX|뉴질랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: smartrak.com 공식 (2026.05 기준)*
