---
tags:
  - index
  - country/new_zealand
country: "뉴질랜드"
---

# 뉴질랜드 🇳🇿 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 11개 |
| ★★★ 핵심 추천 | 1개 |
| ★★ 높은 적합성 | 7개 |
| ★ 보통 적합성 | 3개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | Accredited Employer Work Visa (AEWV) |
| 취득 용이성 | ★★ |
| 학위 요건 | 관련 경력 3년+ 인정 (학위 대체 가능) |
| 소득세 | 최고 39% (NZD 180,000+) |
| 참고사항 | 자동차 SW 분야 외국인 채용 가능. 영어 환경. 생활비 높음(오클랜드). |

## ⭐ 추천 기업 #Recommand

### ★★★ 핵심 추천
- [[Snap-on_NZ|Snap-on NZ]] — 자동차 진단·테스팅 도구 SW

### ★★ 높은 적합성
- [[Eroad|Eroad]] — 텔레매틱스·규정준수·플릿 SW (HQ: Auckland, NZX 상장)
- [[Navman_Wireless|Navman Wireless]] — GPS·커넥티드 차량 SW
- [[Teletrac_Navman|Teletrac Navman]] — 플릿 SW·원격 통신 (NZ HQ)
- [[Coretex|Coretex (Eroad 자회사)]] — 텔레매틱스·플릿 관리 SW
- [[Irisndt_NZ|Irisndt NZ]] — 산업 검사·QA SW (비파괴검사 전문)
- [[Vehicle_Inspection_NZ|Vehicle Inspection NZ (VINZ)]] — 차량 검사·QA SW
- [[HMI_Technologies|HMI Technologies (Ohmio)]] — 자율주행 셔틀·ITS (Auckland)

## 📋 전체 기업 목록

### ★ 보통 적합성
- [[NZTA|NZTA (Waka Kotahi)]] — 차량 안전 규정·스마트 도로 SW 표준
- [[Smartrak|Smartrak]] — 플릿 관리·모빌리티 SW
- [[Waka_Kotahi|Waka Kotahi (NZ Transport Agency)]] — 스마트 도로·ITS SW
