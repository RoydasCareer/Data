---
tags:
  - company
  - automotive
  - country/new-zealand
  - size/small
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "뉴질랜드"
country_folder: "04_New_Zealand"
company_name: "Coretex (Eroad 자회사)"
size: "중소기업"
fit: "★"
business: "중대형 차량 운전자 안전·피로 모니터링·ERUC 텔레매틱스 (Eroad 자회사)"
hq: "Auckland, New Zealand"
founded: "2004"
employees: "~150명 (Eroad 통합 전 기준)"
revenue: "비공개 (Eroad 연결)"
ipo_status: "비상장 (Eroad 자회사)"
korea_office: "없음"
---

# Coretex (Eroad 자회사)

> 중대형 차량 안전·피로 모니터링 텔레매틱스 | Eroad 자회사 | 뉴질랜드 🇳🇿

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Auckland, New Zealand |
| 설립 연도 | 2004년 |
| 임직원 수 | ~150명 (Eroad 통합 전) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 (Eroad 자회사) |
| 주력 사업 | 운전자 피로·행동 모니터링 + 중대형 차량 안전 규정 준수 + ERUC 텔레매틱스 |
| 공식 홈페이지 | https://www.eroad.com |

Eroad가 2021년 인수. 현재 Eroad 브랜드로 운영. NZ/AU/US 화물차 안전 플랫폼.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- Eroad 내 화물차 안전 솔루션으로 성장 지속.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | Eroad 자회사 — Eroad로 지원 권장. 한국 사무소 없음. |
| 추천 직무 | Eroad 채용 페이지 통해 지원 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — AEWV |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [eroad.com](https://www.eroad.com)
- 국가 인덱스: [[_INDEX|뉴질랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: eroad.com 공식 (2026.05 기준)*
