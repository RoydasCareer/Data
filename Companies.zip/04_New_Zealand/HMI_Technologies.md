---
tags:
  - company
  - automotive
  - country/new_zealand
  - size/small
  - automotive/adas
  - automotive/testing
  - fit/★★
  - recommend
country: "뉴질랜드"
country_folder: "04_New_Zealand"
company_name: "HMI Technologies (Ohmio Automotion)"
size: "소기업"
fit: "★★"
business: "지능형 교통 시스템(ITS)·자율주행 차량(AV) 개발·배포 — Ohmio 자율주행 셔틀 제조"
hq: "Auckland, New Zealand"
founded: "[확인필요 — AV 분야 진출: 2017년]"
employees: "~80명 (HMI Technologies 그룹 추정); Ohmio 자회사 ~11명"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# HMI Technologies (Ohmio Automotion)

> 지능형 교통 시스템·자율주행 차량 개발 | 소기업 | 뉴질랜드 🇳🇿

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Auckland, New Zealand |
| 설립 연도 | [확인필요] (AV 사업 진출: 2017년) |
| 임직원 수 | ~80명 (HMI Technologies 그룹); Ohmio 자회사 ~11명 |
| 규모 분류 | 소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 지능형 교통 시스템(ITS)·자율주행 셔틀 개발(Ohmio 브랜드)·AV 시범 운행 |
| 공식 홈페이지 | https://www.hmitechnologies.com.au/en-nz |

뉴질랜드 대표 자율주행 기업. **2017년 크라이스트처치 국제공항과 뉴질랜드 최초 자율주행 차량 시험 운행** 수행. 자회사 **Ohmio Automotion**을 통해 자율주행 셔틀(Ohmio Hop, Ohmio LIFT) 개발·글로벌 배포. 자기 매핑 AI + 차량 군집(Platoon) 기술 보유.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 뉴질랜드 현지 AEWV 취업 비자 대상.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 뉴질랜드 정부 자율주행 시험 프레임워크 지원 → AV 시장 성장 기반
- 글로벌 AV 시범 운행 수주 — 국제 시장 진출
- 뉴질랜드 내 ITS·AV 분야 선도 기업 입지

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 뉴질랜드 유일 AV 개발사. 자율주행 차량 SW·센서 퓨전·자기 매핑 기술 — 자동차 QA 배경 연계 가능 |
| 추천 직무 | AV Software Engineer, Systems Integration Engineer, Embedded Engineer |
| 한국 지원 경로 | 없음 (뉴질랜드 직접 지원) |
| 비자 스폰 가능성 | ★★ — AEWV 가능 (소규모 기업 절차 복잡할 수 있음) |
| 고졸 채용 가능성 | 기술 경험 중시 |

---

## ⚠️ 리스크 / 고려사항

- **극소규모 (Ohmio ~11명, 그룹 ~80명)**: 채용 빈도 낮음 — 포지션 공석 시 적극 접근 필요
- **재무 불투명**: 비상장 소기업 — 경영 안정성 외부 파악 어려움
- **A-SPICE/ISO26262 포커스 없음**: 기능안전 인증보다 AV 기술 개발 위주 — 안전 인증 전문 경력에는 한계
- **뉴질랜드 시장 한계**: 소규모 국내 시장 — 대규모 채용 확장 어려움

## 🔗 관련 정보

- 홈페이지: [hmitechnologies.com.au/en-nz](https://www.hmitechnologies.com.au/en-nz)
- Ohmio: [ohmio.com](https://www.ohmio.com)
- LinkedIn: [확인필요]
- 국가 인덱스: [[_INDEX|뉴질랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: hmitechnologies.com.au/en-nz 공식, Traffic Technology Today (2026.06 기준)*
