---
tags:
  - company
  - automotive
  - country/new-zealand
  - size/public
  - automotive/v2x
  - automotive/connectivity
  - fit/★
country: "뉴질랜드"
country_folder: "04_New_Zealand"
company_name: "Waka Kotahi (NZ Transport Agency)"
size: "공기업"
fit: "★"
business: "NZ 국도 관리·운전면허·차량 인증·스마트교통·AV 파일럿 감독 기관"
hq: "Wellington, New Zealand"
founded: "1989"
employees: "~3,000명 (2024)"
revenue: "정부 기금 (비상업)"
ipo_status: "비상장 (NZ 중앙정부 기관)"
korea_office: "없음"
---

# Waka Kotahi (NZ Transport Agency)

> NZ 국도·교통 인프라 관리 기관 | 공기업 | 뉴질랜드 🇳🇿

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Wellington, New Zealand |
| 설립 연도 | 1989년 (Transit NZ 기원, 2008년 현 형태) |
| 임직원 수 | ~3,000명 (2024) |
| 규모 분류 | 공기업 (NZ 중앙정부 기관) |
| 상장 여부 | 비상장 |
| 주력 사업 | 국도(SH) 계획·건설·관리 + 운전면허 발급 + 차량 등록·인증 + 스마트교통·AV 파일럿 규정 수립 |
| 공식 홈페이지 | https://www.nzta.govt.nz |

> ⚠️ **상업 기업 아님.** NZ 교통부 산하 정부 기관. 외국인 취업 경로 제한적.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★**

- 정부 기관 — 상업 성장 해당 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 정부 교통 기관 — 외국인 취업 매우 제한적. 한국 사무소 없음. |
| 추천 직무 | IT/Platform Engineer (스마트교통) — NZ 영주권자 우선 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 정부기관, NZ 영주권자 우선 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [nzta.govt.nz](https://www.nzta.govt.nz)
- 국가 인덱스: [[_INDEX|뉴질랜드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: nzta.govt.nz 공식 (2026.05 기준)*
