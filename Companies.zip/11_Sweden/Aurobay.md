---
tags:
  - company
  - automotive
  - country/sweden
  - size/startup
  - automotive/software
  - fit/★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Aurobay (Volvo Cars-Geely JV)"
size: "스타트업"
fit: "★★"
business: "파워트레인 SW·제어"
hq: "(본사 위치 미확인) — 스웨덴"
---

# Aurobay (Volvo Cars-Geely JV)

> 파워트레인 SW·제어 | 스타트업 | 스웨덴 🇸🇪

## 🏢 회사 개요

자동차 소프트웨어 및 디지털 솔루션 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 스웨덴 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 스타트업 |
| 주력 사업 | 파워트레인 SW·제어 |

## 🎯 비전 & 미션

자동차 산업의 디지털 전환을 지원하고 미래 모빌리티 생태계를 구축합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★**

자동차 SW 시장은 2030년까지 연 7~10% 성장 전망. SDV 전환이 핵심 성장 동력.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | 자동차 SW 분야 경험 활용 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★★ |
| 고졸 채용 가능성 | 기술직 경험으로 대체 가능 |
| 비자 정보 | Work Permit |
| 비고 | Volvo, Zenseact 등 자동차 기업 외국인 채용 활발. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
