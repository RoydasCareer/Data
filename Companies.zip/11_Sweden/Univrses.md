---
tags:
  - company
  - automotive
  - country/sweden
  - size/startup
  - automotive/adas
  - automotive/sensing
  - fit/★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Univrses"
size: "스타트업"
fit: "★★"
business: "컴퓨터 비전·인식 SW"
hq: "(본사 위치 미확인) — 스웨덴"
---

# Univrses

> 컴퓨터 비전·인식 SW | 스타트업 | 스웨덴 🇸🇪

## 🏢 회사 개요

첨단 운전자 보조 시스템(ADAS) 소프트웨어 개발·검증 전문 기업입니다. 카메라·레이더·LiDAR 기반 인식 알고리즘을 개발합니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 스웨덴 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 스타트업 |
| 주력 사업 | 컴퓨터 비전·인식 SW |

## 🎯 비전 & 미션

자율주행으로 가는 중간 단계인 ADAS 기술로 교통사고 감소 및 이동 편의성을 향상시킵니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

2025년부터 ADAS 탑재 의무화 확대. 레벨 3 자율주행 상용화로 ADAS 수요 지속 증가.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 추천 이유 | ADAS QA(RSPA2) 경험 직접 활용 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★★ |
| 고졸 채용 가능성 | 기술직 경험으로 대체 가능 |
| 비자 정보 | Work Permit |
| 비고 | Volvo, Zenseact 등 자동차 기업 외국인 채용 활발. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
