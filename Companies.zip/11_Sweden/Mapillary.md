---
tags:
  - company
  - automotive
  - country/sweden
  - size/중소기업
  - automotive/adas
  - automotive/autonomous
  - fit/★★★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Mapillary"
size: "중소기업"
fit: "★★★★"
business: "거리 수준 이미지 기반 지도 데이터 플랫폼 (자율주행 HD맵 데이터)"
hq: "Malmö, Sweden (Meta 산하)"
founded: "2013"
employees: "~50명 (Meta 인수 후)"
revenue: "비공개 (Meta 자회사)"
ipo_status: "비상장 (Meta/Facebook 자회사, 2020년 인수)"
korea_office: "없음"
---

# Mapillary

> 거리 이미지 기반 지도 데이터 플랫폼 | 중소기업 | 스웨덴 🇸🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Malmö, Sweden (Meta 산하) |
| 설립 연도 | 2013 |
| 임직원 수 | ~50명 |
| 주력 사업 | 크라우드소싱 거리 이미지 수집·처리, 컴퓨터 비전 기반 지도 데이터 생성 |

## 🎯 주요 제품 & 서비스

Mapillary는 스웨덴 말뫼에서 창업한 거리 수준 이미지(Street-level Imagery) 플랫폼으로, 2020년 Meta(Facebook)에 인수되었습니다. 전 세계 수십억 장의 거리 사진을 크라우드소싱으로 수집하고 컴퓨터 비전 AI로 분석해 도로 표지판, 차선, 도로 시설물 등을 자동 감지·지도화합니다. OpenStreetMap 생태계와 긴밀히 연동되며, 자율주행용 HD맵 데이터 생성에도 활용됩니다.

## 🚗 자동차/모빌리티 관련성

Mapillary의 핵심 기술은 자율주행 지도 데이터 구축에 직접 활용됩니다. 도로 표지판 인식, 차선 감지, 도로 환경 분류 등 ADAS 및 자율주행 시스템의 인식 레이어에 필요한 데이터를 대규모로 생성합니다. HERE, TomTom 등 지도 기업 및 자율주행 스타트업에 데이터를 공급하며, Meta의 AI 연구 역량과 결합해 컴퓨터 비전 기반 지도 자동화 기술을 발전시키고 있습니다.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

자율주행 HD맵 데이터 시장은 레벨 3 이상 자율주행 상용화와 함께 폭발적 성장이 전망됩니다. Meta의 지원 하에 AI 연구 및 데이터 인프라 역량이 크게 강화되었습니다. 크라우드소싱 방식의 저비용 데이터 수집 모델이 경쟁력 있으며, 자율주행 기업들의 지도 데이터 수요 증가로 성장세가 지속될 것으로 예상됩니다.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | 컴퓨터 비전·HD맵 데이터·자율주행 인식 기술 분야 직무 적합, Meta 생태계 내 성장 기회 |
| 추천 직무 | Computer Vision Engineer, Autonomous Driving Data Engineer, ML Engineer (Perception) |
| 지원 방법 | Meta Careers (mapillary.com 통해 연결), LinkedIn |
| 한국 채용 | 없음 (말뫼 본사 및 Meta 원격 기준) |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
