---
tags:
  - company
  - automotive
  - country/sweden
  - size/중소기업
  - automotive/sensor
  - automotive/security
  - fit/★★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Fingerprint Cards"
size: "중소기업"
fit: "★★★"
business: "지문 인식 센서 및 생체인식 솔루션 제공 (자동차 포함)"
hq: "Gothenburg, Sweden"
founded: "1997"
employees: "~400명"
revenue: "비공개"
ipo_status: "Nasdaq Stockholm 상장 (FING B)"
korea_office: "없음"
---

# Fingerprint Cards

> 지문 인식 센서 및 생체인식 솔루션 | 중소기업 | 스웨덴 🇸🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Gothenburg, Sweden |
| 설립 연도 | 1997 |
| 임직원 수 | ~400명 |
| 주력 사업 | 지문 인식 센서 칩 및 생체인식 알고리즘 개발 |

## 🎯 주요 제품 & 서비스

Fingerprint Cards(FPC)는 지문 센서 IC 및 생체인식 소프트웨어 알고리즘 개발에 특화된 스웨덴 반도체 기업입니다. 스마트카드, 모바일, PC용 지문 센서를 주력으로 하며, 자동차 분야에서는 운전자 인증(드라이버 식별) 및 차량 접근 제어(Keyless Entry) 솔루션을 제공합니다. 경쟁사인 노르웨이 IDEX Biometrics와 함께 자동차 생체인식 시장을 선도하고 있습니다.

## 🚗 자동차/모빌리티 관련성

자동차 분야에서 지문 기반 드라이버 인증, 스마트 시동 키, 차량 공유(카셰어링) 사용자 식별 시스템에 FPC의 센서 기술이 활용됩니다. 커넥티드카와 자율주행차에서 운전자 모니터링(DMS) 및 다중 사용자 프로파일 전환에 생체인식 기술의 수요가 증가하고 있습니다. Bosch, Continental 등 자동차 Tier-1 공급업체와의 협력 관계를 구축하고 있습니다.

## 📈 성장성 & 전망

**성장성 평가: ★★★**

스마트폰 지문 센서 시장 포화로 자동차·스마트카드·IoT 등 신규 시장으로 다각화를 진행 중입니다. 자동차 생체인식 시장은 2028년까지 연 15% 이상 성장이 전망됩니다. 다만 중국 경쟁업체와의 가격 경쟁 심화와 매출 변동성이 리스크 요인으로 존재합니다.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 자동차용 생체인식 센서 개발 경험, 임베디드 SW 및 보안 알고리즘 역량 활용 가능 |
| 추천 직무 | Embedded SW Engineer, Automotive Application Engineer, Algorithm Developer |
| 지원 방법 | www.fingerprints.com/careers, LinkedIn |
| 한국 채용 | 없음 (스웨덴 고텐버그 본사 기준 채용) |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
