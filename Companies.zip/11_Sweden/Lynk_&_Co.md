---
tags:
  - company
  - automotive
  - country/sweden
  - size/중견기업
  - automotive/connected
  - automotive/maas
  - fit/★★★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Lynk & Co"
size: "중견기업"
fit: "★★★★"
business: "Geely 지원 구독형 자동차 브랜드 및 커넥티드카 플랫폼"
hq: "Gothenburg, Sweden"
founded: "2016"
employees: "~1,000명"
revenue: "비공개"
ipo_status: "비상장 (Geely Holding 자회사)"
korea_office: "없음"
---

# Lynk & Co

> 구독형 자동차 브랜드 및 커넥티드카 플랫폼 | 중견기업 | 스웨덴 🇸🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Gothenburg, Sweden |
| 설립 연도 | 2016 |
| 임직원 수 | ~1,000명 |
| 주력 사업 | 구독형 차량 소유 모델, 커넥티드카 플랫폼, 카셰어링 서비스 |

## 🎯 주요 제품 & 서비스

Lynk & Co는 중국 Geely Holding이 스웨덴 Gothenburg에 설립한 글로벌 자동차 브랜드로, 전통적인 차량 구매 대신 월정액 구독 기반의 차량 이용 모델을 제공합니다. Volvo Cars와 플랫폼을 공유하며, 차량 내 커넥티드 서비스, 공유 기능(차 소유자가 사용하지 않을 때 타인에게 공유), OTA 업데이트 등 디지털 중심의 자동차 경험을 제공합니다. 유럽 시장을 주요 타깃으로 하며, 암스테르담, 바르셀로나, 고텐버그 등에 오프라인 클럽도 운영합니다.

## 🚗 자동차/모빌리티 관련성

커넥티드카 플랫폼 개발, OTA 소프트웨어 업데이트, 차량 데이터 관리, 공유 모빌리티 서비스 통합 등 자동차 SW 분야 전반과 높은 관련성을 가집니다. Volvo Cars의 기술 플랫폼(CMA/SPA)을 기반으로 하며, Android Automotive OS 탑재 차량의 앱 생태계 및 인포테인먼트 시스템 개발을 활발히 진행하고 있습니다. SDV(소프트웨어 정의 차량) 전환의 최전선에 있는 브랜드입니다.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

구독형 모빌리티와 커넥티드카 두 가지 고성장 분야를 동시에 다루고 있습니다. Geely-Volvo 생태계를 기반으로 기술 역량을 빠르게 확보하고 있으며, 유럽 전기차 전환 트렌드에 맞춰 EV 라인업을 확대 중입니다. 다만 중국 Geely 지배구조와 유럽 시장 경쟁 심화가 리스크 요인입니다.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | 커넥티드카·OTA·Android Automotive 플랫폼 개발 직무 적합, Volvo 기술 생태계 접점 |
| 추천 직무 | Connected Services SW Engineer, OTA Platform Developer, Infotainment SW Engineer |
| 지원 방법 | www.lynkco.com/careers, LinkedIn |
| 한국 채용 | 없음 (고텐버그 본사 기준) |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
