---
tags:
  - company
  - automotive
  - country/sweden
  - size/public
  - automotive/v2x
  - automotive/connectivity
  - fit/★
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Trafikverket (Smart Roads)"
size: "공기업"
fit: "★"
business: "스마트 도로·V2X 인프라"
hq: "(본사 위치 미확인) — 스웨덴"
---

# Trafikverket (Smart Roads)

> 스마트 도로·V2X 인프라 | 공기업 | 스웨덴 🇸🇪

## 🏢 회사 개요

차량-사물 통신(V2X, DSRC/C-V2X) 기반 스마트 모빌리티 솔루션 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 스웨덴 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 공기업 |
| 주력 사업 | 스마트 도로·V2X 인프라 |

## 🎯 비전 & 미션

자율주행과 스마트 인프라 연계로 안전하고 효율적인 교통 생태계를 구현합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

5G-V2X 표준화 진행 중. 2027년부터 유럽·미국 신차 V2X 의무화 논의.

---

## 📌 참고 정보

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ (보통) |
| 관련 역량 | DoIP/CAN 통신 분석 경험 V2X로 확장 가능 |
| 비자 정보 | Work Permit |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
