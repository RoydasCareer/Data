---
tags:
  - company
  - automotive
  - country/sweden
  - size/large
  - automotive/software
  - fit/★
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Scania (Autonomous Systems)"
size: "대기업"
fit: "★"
business: "자율 트럭·SW"
hq: "(본사 위치 미확인) — 스웨덴"
---

# Scania (Autonomous Systems)

> 자율 트럭·SW | 대기업 | 스웨덴 🇸🇪

## 🏢 회사 개요

자동차 소프트웨어 및 디지털 솔루션 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 스웨덴 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 대기업 |
| 주력 사업 | 자율 트럭·SW |

## 🎯 비전 & 미션

자동차 산업의 디지털 전환을 지원하고 미래 모빌리티 생태계를 구축합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★**

자동차 SW 시장은 2030년까지 연 7~10% 성장 전망. SDV 전환이 핵심 성장 동력.

---

## 📌 참고 정보

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ (보통) |
| 관련 역량 | 자동차 SW 분야 경험 활용 |
| 비자 정보 | Work Permit |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
