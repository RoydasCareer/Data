---
tags:
  - company
  - automotive
  - country/sweden
  - size/중소기업
  - automotive/software
  - automotive/consulting
  - fit/★★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Momentum Automotive"
size: "중소기업"
fit: "★★★"
business: "자동차 소프트웨어 개발 및 데이터 컨설팅 전문 기업"
hq: "Gothenburg, Sweden"
founded: "2010"
employees: "~100명"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Momentum Automotive

> 자동차 SW 개발 및 데이터 컨설팅 | 중소기업 | 스웨덴 🇸🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Gothenburg, Sweden |
| 설립 연도 | 2010 |
| 임직원 수 | ~100명 |
| 주력 사업 | 자동차 SW 개발, 차량 데이터 분석, 임베디드 시스템 컨설팅 |

## 🎯 주요 제품 & 서비스

Momentum Automotive는 스웨덴 고텐버그에 본사를 둔 자동차 소프트웨어 및 데이터 컨설팅 전문 기업입니다. Volvo Cars, Geely, Scania 등 주요 OEM 및 Tier-1 공급업체를 대상으로 임베디드 SW 개발, 차량 진단 시스템, ECU 소프트웨어, 데이터 분석 솔루션을 제공합니다. AUTOSAR 기반 SW 아키텍처 설계 및 검증 서비스도 핵심 사업 영역입니다.

## 🚗 자동차/모빌리티 관련성

자동차 임베디드 SW 개발, ECU 소프트웨어 통합, 차량 네트워크(CAN/LIN/Ethernet) 분석, OBD 진단 시스템 등 자동차 SW 엔지니어링 전 분야를 다룹니다. 스웨덴 자동차 클러스터의 중심인 고텐버그에 위치해 Volvo Cars, Zenseact, CEVT 등과의 협력 프로젝트를 지속적으로 수행합니다. 컨설팅 특성상 다양한 자동차 프로젝트 경험을 빠르게 쌓을 수 있습니다.

## 📈 성장성 & 전망

**성장성 평가: ★★★**

자동차 SW 복잡도 증가로 전문 컨설팅 수요가 지속 성장하고 있습니다. SDV 전환과 함께 임베디드 SW 개발, AUTOSAR 전문 인력 수요가 증가하고 있어 안정적인 성장이 예상됩니다. 다만 컨설팅 특성상 대형 OEM의 내재화 전략에 따른 영향을 받을 수 있습니다.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 임베디드 SW·ECU·AUTOSAR 경험 직접 활용 가능, 스웨덴 자동차 산업 네트워크 진입점 |
| 추천 직무 | Embedded SW Engineer, Automotive SW Consultant, ECU Integration Engineer |
| 지원 방법 | LinkedIn, 회사 웹사이트 직접 지원 |
| 한국 채용 | 없음 (고텐버그 본사 기준) |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
