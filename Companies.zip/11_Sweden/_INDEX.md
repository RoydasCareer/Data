---
tags:
  - index
  - country/sweden
country: "스웨덴"
---

# 스웨덴 🇸🇪 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 44개 |
| ★★★ 핵심 추천 | 20개 |
| ★★ 높은 적합성 | 21개 |
| ★ 보통 적합성 | 3개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | Work Permit |
| 취득 용이성 | ★★ |
| 학위 요건 | 기술직 경험으로 대체 가능 |
| 참고사항 | Volvo, Zenseact 등 자동차 기업 외국인 채용 활발. |

## ⭐ 추천 기업 #Recommand

### ★★★ 핵심 추천
- [[WirelessCar|WirelessCar (Volvo Group 자회사)]] — 커넥티드카·텔레매틱스 SW
- [[Kognic|Kognic (Annotell)]] — AV용 데이터셋 관리·QA
- [[Annotell|Annotell (→Kognic)]] — AV 데이터 품질·QA SW
- [[Prevas|Prevas (Automotive)]] — 자동차 임베디드 SW 개발
- [[Combitech|Combitech (Automotive)]] — 자동차 사이버보안·SW 개발
- [[RISE_Research_Institutes|RISE Research Institutes (Automotive)]] — 자동차 테스팅·R&D
- [[Intevo|Intevo (Automotive)]] — 상용차 예측 정비 SW
- [[Hella_Gutmann|Hella Gutmann (Delphi Tech SW)]] — 자동차 진단·SW 솔루션
- [[RISE|RISE (Research Institutes of Sweden)]] — 자동차 테스팅·QA R&D
- [[AFRY_Automotive|AFRY (Automotive Division)]] — 자동차 ISO26262·A-SPICE·임베디드 SW·EV·테스팅 엔지니어링 (스웨덴 최대, Nasdaq: AFRY, 17,000명+)
- [[Knightec_Group|Knightec Group (구 Semcon+Knightec)]] — 자동차 임베디드 SW·ISO26262·EV·자율주행 엔지니어링 (합병 북유럽 최대, 2,400명)
- [[Fingerprint_Cards|Fingerprint Cards (Automotive)]] — 자동차 생체인식 보안 SW
- [[Hogia|Hogia (Automotive)]] — 상용차 플릿·운송 관리 SW
- [[Momentum_Automotive|Momentum Automotive]] — 자동차 임베디드 SW·ECU 컨설팅
- [[Chalmers_University|Chalmers University (Autonomous)]] — 자율주행·ADAS 최상위 연구대학 (산학 연구직)
- [[KTH_Royal_Institute|KTH Royal Institute (Automotive)]] — 자동차 SW·V2X R&D (산학 연구직)
- [[Hana_Microdisplay|Hana Microdisplay (SE)]] — 자동차 HUD·AR 디스플레이 SW
- [[Einride|Einride]] — 자율 트럭·화물 SW
- [[Lynk_&_Co|Lynk & Co (Tech)]] — 커넥티드카·디지털 플랫폼
- [[Mapillary|Mapillary (Meta)]] — 크라우드소싱 매핑·자동차 비전

### ★★ 높은 적합성
- [[Volvo_Autonomous_Solutions|Volvo Autonomous Solutions]] — 자율 교통·SW (Volvo Group 자회사)
- [[Volvo_Cars|Volvo Cars (SW Division)]] — SW 정의 차량·ADAS
- [[Ericsson|Ericsson (Automotive)]] — V2X·5G·커넥티드 차량 SW
- [[Autoliv|Autoliv]] — 자동차 안전 SW·전장
- [[Veoneer|Veoneer (Magna 인수)]] — ADAS·자율주행 SW
- [[Zenseact|Zenseact (Volvo Cars 자회사)]] — 자율주행 SW 플랫폼
- [[Tobii|Tobii (Automotive)]] — 아이트래킹 드라이버 모니터링 SW
- [[Drivec|Drivec]] — 플릿·드라이버 분석 SW
- [[Terranet|Terranet]] — 인식 SW·센싱 (HQ: Lund)
- [[Viscando|Viscando]] — AI 교통 센싱·V2X SW
- [[Univrses|Univrses]] — 컴퓨터 비전·인식 SW
- [[Vehco|Vehco (Volvo Group)]] — 상용차 텔레매틱스·SW
- [[Transics|Transics (ZF 자회사)]] — 상용차 플릿 관리 SW
- [[Ecarx|Ecarx (Sweden R&D)]] — 자동차 디지털 플랫폼 SW
- [[Sentient|Sentient (Automotive AI)]] — 자율주행 AI SW
- [[Cinemo|Cinemo]] — 자동차 인포테인먼트 SW
- [[CTEK|CTEK (Automotive SW)]] — 자동차 배터리 진단·SW
- [[Opus_Inspection|Opus Inspection]] — 차량 검사·배출 테스팅 SW
- [[Aurobay|Aurobay (Volvo Cars-Geely JV)]] — 파워트레인 SW·제어
- [[Googol_Technology|Googol Technology (SE)]] — 자동차 AI·임베디드 SW
- [[SICS_Swedish_ICT|SICS Swedish ICT]] — 자동차 SW·통신 R&D

## 📋 전체 기업 목록 (적합도 낮은 기업 포함)

### ★ 보통 적합성
- [[Scania|Scania (Autonomous Systems)]] — 자율 트럭·SW
- [[Momentum_IoT|Momentum IoT]] — 플릿 관리·IoT SW
- [[Trafikverket|Trafikverket (Smart Roads)]] — 스마트 도로·V2X 인프라
