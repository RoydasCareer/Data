---
tags:
  - company
  - automotive
  - country/sweden
  - size/mid
  - automotive/telematics
  - automotive/fleet
  - fit/★★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "WirelessCar (Volvo Group 자회사)"
size: "중견기업"
fit: "★★★"
business: "커넥티드카·텔레매틱스 SW"
hq: "(본사 위치 미확인) — 스웨덴"
---

# WirelessCar (Volvo Group 자회사)

> 커넥티드카·텔레매틱스 SW | 중견기업 | 스웨덴 🇸🇪

## 🏢 회사 개요

차량 원격 데이터 수집·분석·플릿 관리 소프트웨어 전문 기업입니다.

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | (본사 위치 미확인) — 스웨덴 |
| 설립 연도 | — |
| 임직원 수 | — |
| 규모 분류 | 중견기업 |
| 주력 사업 | 커넥티드카·텔레매틱스 SW |

## 🎯 비전 & 미션

빅데이터 기반의 예측 정비, 보험, 물류 최적화로 자동차 생태계 전반을 혁신합니다.

## 📈 미래 먹거리 & 성장 가능성

**성장성 평가: ★★★★**

커넥티드카 시장 2030년까지 연 20% 성장. 보험·물류·정비 등 다양한 수익 모델.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 추천 이유 | 차량 데이터·통신 분야 경험 활용 가능 |
| 추천 직무 | (채용 공고 확인 필요) |
| 비자 스폰 가능성 | ★★ |
| 고졸 채용 가능성 | 기술직 경험으로 대체 가능 |
| 비자 정보 | Work Permit |
| 비고 | Volvo, Zenseact 등 자동차 기업 외국인 채용 활발. |

---

## 🔗 관련 정보


- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
