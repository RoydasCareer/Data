---
tags:
  - company
  - automotive
  - country/sweden
  - size/large
  - automotive/functional-safety
  - automotive/aspice
  - automotive/embedded
  - automotive/testing
  - fit/★★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "AFRY (Automotive Division)"
size: "대기업"
fit: "★★★"
business: "자동차 임베디드 SW·ISO26262·A-SPICE·EV·자율주행 엔지니어링·테스팅 컨설팅 (스웨덴 최대 엔지니어링 컨설팅 그룹, 구 ÅF Pöyry)"
hq: "Stockholm, Sweden (Gothenburg 자동차 거점)"
founded: "1895년 (ÅF 전신 창립); 2019년 AFRY 브랜드 출범"
employees: "약 17,000~19,000명 글로벌 (50개국+)"
revenue: "[확인필요 — Nasdaq Stockholm 상장 공시 참조]"
ipo_status: "상장 — Nasdaq Stockholm: AFRY"
korea_office: "[확인필요]"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# AFRY (Automotive Division)

> 자동차 ISO26262·A-SPICE·임베디드 SW·EV·테스팅 엔지니어링 | 대기업 | 스웨덴 🇸🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 스톡홀름 HQ | Stockholm, Sweden |
| 자동차 거점 | Gothenburg (Volvo Cars·Zenseact 인접) |
| 브랜드 출범 | 2019년 (ÅF + Pöyry 합병 → AFRY) |
| 창립 | 1895년 (ÅF 전신 창립) |
| 임직원 수 | 약 17,000~19,000명 글로벌 (50개국+) |
| 규모 분류 | 대기업 |
| 상장 여부 | Nasdaq Stockholm: AFRY |
| 주력 사업 | 자동차 임베디드 SW·ISO26262·A-SPICE·EV·자율주행·테스팅 엔지니어링 컨설팅 |
| 공식 홈페이지 | https://afry.com |

스웨덴 최대 규모 엔지니어링·컨설팅 그룹. **Automotive & Transportation** 전문 사업부 운영 — EV 개발·임베디드 SW·기능안전(ISO26262)·A-SPICE·자율주행·차량 테스팅·제조 엔지니어링 전 영역 커버. **Gothenburg** 오피스가 스웨덴 자동차 엔지니어링 허브 거점 (Volvo Cars·Scania·Zenseact 인접).

**주요 서비스 (Automotive):**
- **ISO 26262** 기능안전 — HARA, FTA, FMEA, 안전 케이스 개발
- **A-SPICE** 프로세스 컨설팅
- **임베디드 SW** — AUTOSAR, MISRA-C
- **ISO/SAE 21434** 사이버보안
- **EV 개발** — 전기 파워트레인, BMS 제어 SW
- **자율주행** 시스템 엔지니어링
- **차량 테스팅·검증** — HiL/SiL 포함

---

## 🇰🇷 한국 관련

AFRY 한국 법인 [확인필요]. 스웨덴 거점 직접 지원 경로.

---

## 📈 성장성 평가

**성장성 평가: ★★★★☆**

- 스웨덴 자동차 산업(Volvo Cars·Scania·Autoliv) 핵심 파트너 위치 → 구조적 수주 안정
- EV·자율주행 전환 → SW 엔지니어링 컨설팅 수요 지속 증가
- Nasdaq 상장 기업 → 재무 투명성·안정성
- 50개국 글로벌 네트워크 → 내부 이동 경력 경로 다양

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | ISO26262·A-SPICE·임베디드 SW·테스팅 전 영역 커버 — 사용자 역량 직결. Gothenburg 자동차 허브. Nasdaq 상장 대기업 안정성. |
| 추천 직무 | Functional Safety Engineer, A-SPICE Consultant, Embedded SW Engineer, Automotive Test Engineer |
| 지원 경로 | afry.com/careers (Sweden/Gothenburg 필터) |
| 비자 스폰 가능성 | ★★★ — Swedish Work Permit (대기업, SW 엔지니어링) |

---

## ⚠️ 리스크 / 고려사항

- **컨설팅 파견 특성**: 다양한 고객사 현장 파견 업무 — 이동 부담 존재
- **스웨덴어 환경**: 직장 내 영어 가능하나 장기 거주 시 스웨덴어 학습 권장
- **대형 컨설팅 경쟁**: Capgemini Engineering, Alten, Semcon 등과 경쟁 — 채용 선발 기준 높음

## 🔗 관련 정보

- 홈페이지: [afry.com](https://afry.com)
- 자동차 분야: [afry.com/automotive](https://afry.com/en/sector/automotive-and-transportation)
- LinkedIn: [확인필요]
- 채용: [afry.com/careers](https://afry.com/en/career)
- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: afry.com 공식, Nasdaq Stockholm (AFRY 상장 정보), 업계 지식 기반 (2026.06 기준)*
