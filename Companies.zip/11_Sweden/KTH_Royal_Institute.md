---
tags:
  - company
  - automotive
  - country/sweden
  - size/대기업
  - automotive/adas
  - automotive/autonomous
  - fit/★★★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "KTH Royal Institute of Technology"
size: "대기업"
fit: "★★★★"
business: "자동차·로보틱스·자율주행 연구 선도 스웨덴 최고 공과대학"
hq: "Stockholm, Sweden"
founded: "1827"
employees: "~5,000명 (교직원·연구원)"
revenue: "비공개 (국가 연구 기관)"
ipo_status: "비상장 (국립 대학)"
korea_office: "없음"
---

# KTH Royal Institute of Technology

> 자동차·로보틱스·자율주행 연구 | 대기업 (대학) | 스웨덴 🇸🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Stockholm, Sweden |
| 설립 연도 | 1827 |
| 임직원 수 | ~5,000명 (교직원·연구원·행정) |
| 주력 사업 | 공학·기술 연구 및 교육, 산학협력 프로젝트 |

## 🎯 주요 제품 & 서비스

KTH Royal Institute of Technology(왕립공과대학교)는 스웨덴 최고의 공과대학으로, 스칸디나비아 최대 규모의 기술 연구 기관입니다. 자동차·교통 분야에서는 자율주행 시스템, 차량 제어 알고리즘, 전기차 파워트레인, V2X 통신, 교통 시뮬레이션 등의 연구를 활발히 수행합니다. Volvo Cars, Scania, Veoneer, Zenseact 등 스웨덴 주요 자동차 기업과 긴밀한 산학협력 프로그램을 운영하고 있습니다.

## 🚗 자동차/모빌리티 관련성

KTH는 자율주행, ADAS, 로보틱스, 차량 동역학, 전기 모빌리티 분야에서 유럽 최고 수준의 연구 역량을 보유합니다. ITRL(Integrated Transport Research Lab) 등 자동차 특화 연구소를 운영하며, 스웨덴 자동차 산업과의 협력 네트워크가 매우 강합니다. 박사후 연구원, 연구 엔지니어, 산학협력 프로젝트 참여 등 다양한 형태로 경력을 쌓을 수 있습니다.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

자율주행·전동화·디지털화로 자동차 산업의 R&D 투자가 급증하면서 대학 연구 기관과의 협력 수요도 커지고 있습니다. EU Horizon 연구 자금 및 스웨덴 정부의 모빌리티 R&D 투자 확대로 KTH의 연구 프로젝트 규모가 지속 성장 중입니다. 업계 취업을 위한 브리지 역할로도 매우 유용한 기관입니다.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | 자율주행·ADAS·임베디드 연구 직군 진입 가능, Volvo/Scania 등 스웨덴 자동차 기업 네트워크 구축에 유리 |
| 추천 직무 | Research Engineer (Autonomous Driving), PhD Researcher, Postdoctoral Researcher, Industry Project Engineer |
| 지원 방법 | www.kth.se/en/om/work-at-kth, LinkedIn |
| 한국 채용 | 없음 (스톡홀름 캠퍼스 기준) |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
