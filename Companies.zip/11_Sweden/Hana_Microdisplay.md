---
tags:
  - company
  - automotive
  - country/sweden
  - size/스타트업
  - automotive/adas
  - automotive/display
  - fit/★★★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Hana Microdisplay"
size: "스타트업"
fit: "★★★★"
business: "자동차 HUD 및 AR 디스플레이용 마이크로디스플레이 기술 개발"
hq: "Stockholm, Sweden"
founded: "2020"
employees: "~20명"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Hana Microdisplay

> 자동차 HUD·AR 디스플레이용 마이크로디스플레이 | 스타트업 | 스웨덴 🇸🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Stockholm, Sweden |
| 설립 연도 | 2020 |
| 임직원 수 | ~20명 |
| 주력 사업 | HUD/AR용 마이크로디스플레이 칩 및 광학 시스템 개발 |

## 🎯 주요 제품 & 서비스

Hana Microdisplay는 자동차 헤드업 디스플레이(HUD) 및 증강현실(AR) 애플리케이션에 특화된 마이크로디스플레이 기술을 개발하는 스웨덴 딥테크 스타트업입니다. 고휘도·저전력 마이크로OLED 및 LCoS 기반 디스플레이 칩을 개발하며, ADAS 정보를 운전자 시야에 직접 투사하는 AR-HUD 시스템 구현을 목표로 합니다. KTH Royal Institute of Technology와의 연구 협력을 기반으로 기술을 발전시키고 있습니다.

## 🚗 자동차/모빌리티 관련성

자동차 AR-HUD 시스템에서 핵심 부품인 마이크로디스플레이 엔진을 개발합니다. 주행 정보, 내비게이션 경로, ADAS 경고를 운전자 시야 전방에 실시간 투사하여 주행 안전성을 높입니다. 자율주행 전환 단계에서 운전자-차량 인터페이스(HMI)의 핵심 기술로 주목받고 있으며, Volvo, BMW 등 프리미엄 OEM의 AR-HUD 탑재 수요 증가와 함께 성장 가능성이 높습니다.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

글로벌 자동차 HUD 시장은 2030년까지 연평균 20% 이상 성장이 전망됩니다. AR-HUD는 일반 HUD 대비 부가가치가 높고 고급 차량 중심으로 빠르게 확산되고 있습니다. 초기 스타트업 단계로 불확실성이 있으나, 딥테크 기반의 차별화된 기술력과 스웨덴의 강력한 자동차 생태계(Volvo, Zenseact 등)와의 협력 기회가 성장 동력입니다.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | 자동차 디스플레이/HMI 및 임베디드 시스템 역량 직접 적용 가능, ADAS 연계 HUD 개발 경험 우대 |
| 추천 직무 | Embedded SW Engineer, Display Systems Engineer, Automotive HMI Developer |
| 지원 방법 | LinkedIn, 회사 웹사이트 직접 지원 |
| 한국 채용 | 없음 (스톡홀름 본사 기준) |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]
