---
tags:
  - company
  - automotive
  - country/sweden
  - size/large
  - automotive/autonomous
  - automotive/adas
  - automotive/research
  - fit/★★★★
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Chalmers University of Technology"
size: "대형기관"
fit: "★★★★"
business: "자동차 공학·자율주행·ADAS 최상위 연구대학"
hq: "Gothenburg, Sweden"
founded: "1829"
employees: "약 3,100명 (교직원·연구원)"
revenue: "약 SEK 45억 (공공 연구비 포함)"
ipo_status: "국립 연구대학 (비영리)"
---
# Chalmers University of Technology

> 자동차 공학·자율주행·ADAS 최상위 연구대학 | 대형기관 | 스웨덴 🇸🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Gothenburg, Sweden |
| 설립 연도 | 1829 |
| 임직원 수 | 약 3,100명 (교직원·연구원) |
| 규모 분류 | 대형 국립 연구기관 |
| 주력 분야 | 자동차 공학, 자율주행, ADAS, 전기차, 교통안전 |
| 연간 예산 | 약 SEK 45억 (연구비 포함) |
| 상장 여부 | 국립 연구대학 (비영리) |
| 웹사이트 | https://www.chalmers.se |

Chalmers University of Technology(찰머스 공과대학교)는 스웨덴 예테보리에 위치한 세계 최고 수준의 공과대학입니다. Volvo Cars, Volvo Group, RISE Research Institute, Zenuity(현 Zenseact) 등과 긴밀히 협력하며 자율주행, ADAS, 차량 안전, 전동화 분야의 최첨단 연구를 수행합니다. SAFER Vehicle and Traffic Safety Centre를 운영하며 스웨덴 자동차 기술 혁신의 핵심 허브 역할을 담당합니다.

---

## 🎯 주요 제품 & 서비스

| 연구/프로그램 | 설명 |
| :--- | :--- |
| SAFER Centre | 차량·교통 안전 연구 센터 (Volvo, VGTT 공동 운영) |
| 자율주행 연구 | 컴퓨터 비전, LiDAR 퓨전, HD맵, 경로계획 알고리즘 |
| 전동화 연구 | 배터리 기술, 파워트레인, 충전 인프라 |
| Chalmers Ventures | 연구 기반 딥테크 스타트업 인큐베이터 |
| 산학 협력 석·박사 과정 | Volvo, AstraZeneca, SKF 등과 공동 연구 프로그램 |

---

## 🇰🇷 한국 지사

없음 (한국과의 직접 파트너십 없음. 개인 지원 필요)

---

## 📈 성장성 & 재무 동향

**성장성 평가: ★★★★**

유럽 자율주행 R&D 투자 급증으로 연구 포지션 수요 지속 증가. Volvo Cars와의 전략적 협력 심화로 산업-학계 공동 연구직 증가 추세. 2030 스웨덴 교통 탄소중립 목표에 맞춰 EV·자율주행 연구 예산 확대 중. EU Horizon Europe 프로그램을 통한 대형 연구 프로젝트 수주 활발.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | 자동차 임베디드 SW·ADAS 검증 경험 + 스웨덴 최고 자동차 연구 허브. 산학 연구원·포닥·엔지니어링 직위 지원 가능. Volvo 협력 프로젝트 경험 직접 연계 가능 |
| 추천 직무 | Research Engineer (ADAS/Autonomous), Postdoctoral Researcher (Vehicle SW), Industrial PhD (Volvo 공동), Software Engineer (Research Projects) |
| 지원 방법 | https://www.chalmers.se/en/about-chalmers/work-with-us/ 채용 공고 직접 지원 |
| 비자 스폰 | EU Work Permit / Highly Skilled Worker — 국립 연구기관으로 Work Permit 스폰 적극적. 연구직은 비자 절차 지원 일반적 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Chalmers University of Technology 공식 홈페이지 — 작성 기준 2026.06.01*
