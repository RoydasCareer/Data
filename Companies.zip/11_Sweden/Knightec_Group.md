---
tags:
  - company
  - automotive
  - country/sweden
  - size/mid
  - automotive/embedded
  - automotive/functional-safety
  - automotive/aspice
  - fit/★★★
  - recommend
country: "스웨덴"
country_folder: "11_Sweden"
company_name: "Knightec Group (구 Semcon + Knightec)"
size: "중견기업"
fit: "★★★"
business: "자동차 임베디드 SW·ISO26262·EV·자율주행·UX/HMI 엔지니어링 컨설팅 (2024년 Semcon·Knightec 합병 — 북유럽 최대 자동차 엔지니어링 컨설팅 그룹)"
hq: "Gothenburg, Sweden"
founded: "2024년 (합병); Semcon 1980년대 설립, Knightec 2000년대 설립"
employees: "약 2,400명 (합병 후, 2024년)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# Knightec Group (구 Semcon + Knightec)

> 자동차 임베디드 SW·ISO26262·EV·자율주행 엔지니어링 | 중견기업 | 스웨덴 🇸🇪

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Gothenburg, Sweden |
| 설립 배경 | 2024년 Semcon(40년+)·Knightec 합병 → Knightec Group 출범 |
| 임직원 수 | 약 2,400명 (합병 후 2024년) |
| Gothenburg 엔지니어 | 약 400명+ (Semcon Gothenburg 오피스 기반) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자동차 임베디드 SW·ISO26262·EV·자율주행·UX/HMI·제품 디지털 서비스 개발 |
| 공식 홈페이지 | https://www.knightec.se |

**북유럽 최대 전략적 제품·디지털 서비스 개발 파트너** — 2024년 Semcon(40년+ 자동차 엔지니어링 경험)과 Knightec(임베디드·기능안전 전문) 합병으로 출범. Gothenburg 기반 — Volvo Cars·Scania·Autoliv·Zenseact 핵심 고객사 인접.

**주요 서비스 (Automotive):**
- **임베디드 SW 개발** — AUTOSAR, MISRA-C, 실시간 제어
- **ISO 26262** 기능안전 — FMEA, HARA, 안전 분석
- **A-SPICE** 프로세스 컨설팅 [확인필요 — 공식 A-SPICE 심사원 보유 여부]
- **EV 개발** — 전기 파워트레인 제어·통합
- **자율주행** 시스템 엔지니어링
- **UX/HMI 설계** — 차량 인터페이스 경험 설계
- **Servitization** — 제품의 서비스화

---

## 🇰🇷 한국 관련

한국 오피스 없음. 스웨덴 현지 채용 대상. 합병 전 Semcon이 현대자동차 등 아시아 OEM 대상 프로젝트 수행 이력 있으나 세부 사항 [확인필요].

---

## 📈 성장성 평가

**성장성 평가: ★★★★☆**

- 합병으로 북유럽 최대 규모 → 대형 OEM 수주 경쟁력 대폭 강화
- Gothenburg 자동차 클러스터 중심 위치 → Volvo Cars·Scania 핵심 파트너
- EV·자율주행 전환 시기 → 임베디드 SW 컨설팅 수요 구조적 증가
- 40년+ Semcon 브랜드 레퍼런스 + Knightec 기술 역량 결합

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | ISO26262·임베디드 SW·EV 통합 자동차 엔지니어링 컨설팅 — 사용자 역량 직결. 합병으로 북유럽 최대 → 안정적 성장 기반. Gothenburg 자동차 허브. |
| 추천 직무 | Embedded SW Engineer, Functional Safety Engineer, Automotive Systems Engineer |
| 지원 경로 | knightec.se/careers / semcon.com (전환 전 채용 포털 확인) |
| 비자 스폰 가능성 | ★★ — Swedish Work Permit (중견기업, 비자 스폰 사전 확인 필요) |

---

## ⚠️ 리스크 / 고려사항

- **합병 후 통합 과도기 (2024~)**: 조직 문화·프로세스 통합 진행 중 — 안정화 여부 입사 전 확인
- **비상장 비공개 재무**: 합병 후 재무 구조 외부 확인 어려움
- **컨설팅 파견 특성**: 고객사 현장 파견 비중 높음 — 이동 부담 존재
- **A-SPICE 공식 심사 역량**: [확인필요] — intacs™ 공인 심사원 보유 여부 별도 확인 권장

## 🔗 관련 정보

- 홈페이지: [knightec.se](https://www.knightec.se)
- Semcon (구 브랜드): [semcon.com](https://www.semcon.com)
- Semcon Gothenburg: [semcon.com/office/goteborg](https://www.semcon.com/office/goteborg)
- LinkedIn: [확인필요]
- 채용: [knightec.se/careers](https://www.knightec.se/careers)
- 국가 인덱스: [[_INDEX|스웨덴 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: semcon.com 공식, Semcon-Knightec 합병 발표 (2024), semcon.com/about-us/our-history (2026.06 기준)*
