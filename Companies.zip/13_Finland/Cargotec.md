---
tags:
  - company
  - automotive
  - country/finland
  - size/global
  - automotive/autonomous
  - fit/★★★
country: "핀란드"
country_folder: "13_Finland"
company_name: "Cargotec"
size: "글로벌 대기업"
fit: "★★★"
business: "항만·물류·화물 처리 장비 — Kalmar·Hiab·MacGregor 브랜드, 산업 자동화"
hq: "Helsinki, Finland"
founded: "2005"
employees: "약 11,000명"
revenue: "약 42억 유로 (2023년)"
ipo_status: "상장 (NASDAQ Helsinki: CGCBV)"
---
# Cargotec

> 항만·물류·화물 처리 장비 — Kalmar·Hiab·MacGregor 브랜드, 산업 자동화 | 글로벌 대기업 | 핀란드 🇫🇮

## 🏢 회사 개요

| 항목 | 내용 |
|------|------|
| 법인명 | Cargotec Corporation |
| 본사 | Porkkalankatu 5, Helsinki, Finland |
| 설립연도 | 2005년 (Kone Corporation 화물 사업부 분사) |
| CEO | Casimir Lindholm |
| 임직원수 | 약 11,000명 |
| 연매출 | 약 42억 유로 (2023년) |
| 상장여부 | NASDAQ Helsinki 상장 (티커: CGCBV) |
| 공식홈페이지 | https://www.cargotec.com |

---

## 🎯 주요 제품 & 서비스

| 브랜드 | 내용 |
|------|------|
| Kalmar | 항만 컨테이너 크레인·자동화 터미널 솔루션 — 자율 AGV, 스마트 터미널 |
| Hiab | 트럭 탑재형 크레인(HIAB)·로더크레인·리프트게이트 — 자율화 솔루션 |
| MacGregor | 해양 화물 처리 장비·선박 크레인·갑판 기계 |
| 소프트웨어 | Navis (항만 운영 시스템), Kalmar 자율 AGV 제어 SW |
| 전동화 | 전동 크레인·전기 구동 지게차 솔루션 |

---

## 🇰🇷 한국 지사

**있음** — Cargotec Korea (Kalmar 영업·서비스):
- 부산 항만 자동화 프로젝트 참여
- Hiab Korea: 트럭 탑재 크레인 영업
- 인천항·광양항 터미널 자동화 솔루션 공급 이력

---

## 📈 성장성 & 재무 동향

**★★★ 양호**

- 2023년 매출 약 42억 유로, 항만 자동화 수요 성장세
- Kalmar 자율 AGV(무인운반차) 시장 글로벌 선두
- 2023년 Kalmar 분사(별도 상장) 검토 후 통합 유지 결정
- 탄소중립 목표 — 2030년 전 제품 전동화 로드맵
- 글로벌 항만 자동화 투자 증가로 중장기 성장 확실
- Hiab 커넥티드 솔루션: 크레인 IoT·원격 진단 플랫폼 확장

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
|------|------|
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | 자율 AGV·산업 자동화 SW — 임베디드 SW·자율이동 경력 활용 가능 |
| 추천 직무 | Software Engineer (Autonomous Systems / AGV), Embedded Engineer (Kalmar), Systems Engineer (Terminal Automation) |
| 지원 방법 | https://www.cargotec.com/en/careers/ |
| 비자 스폰 | 핀란드 Work Permit / EU Blue Card 지원 가능 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|핀란드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Cargotec 공식 홈페이지 — 작성 기준 2026.06.01*
