---
tags:
  - company
  - automotive
  - country/finland
  - size/startup
  - automotive/adas
  - automotive/sensor
  - fit/★★★★
country: "핀란드"
country_folder: "13_Finland"
company_name: "Canatu"
size: "스타트업"
fit: "★★★★"
business: "카본 나노튜브(CNT) 필름 소재 — 자동차 히팅 창문·LiDAR 돔·유연 디스플레이"
hq: "Helsinki, Finland"
founded: "2004"
employees: "약 100명"
revenue: "비공개"
ipo_status: "비상장"
---
# Canatu

> 카본 나노튜브(CNT) 필름 소재 — 자동차 히팅 창문·LiDAR 돔·유연 디스플레이 | 스타트업 | 핀란드 🇫🇮

## 🏢 회사 개요

| 항목 | 내용 |
|------|------|
| 법인명 | Canatu Oy |
| 본사 | Tietotie 2, Helsinki, Finland |
| 설립연도 | 2004년 (Helsinki University of Technology 스핀오프) |
| CEO | Erkki Soininen |
| 임직원수 | 약 100명 |
| 연매출 | 비공개 (Series C 이상 투자 유치) |
| 상장여부 | 비상장 |
| 공식홈페이지 | https://canatu.com |

---

## 🎯 주요 제품 & 서비스

| 제품 | 내용 |
|------|------|
| CNT 히팅 필름 | 자동차 앞유리·사이드미러 열선 필름 — 투명·유연·고효율 |
| LiDAR 돔 히터 | 자율주행 LiDAR 센서 돔 결빙 방지 히터 필름 — ADAS 핵심 부품 |
| 유연 터치 센서 | 자동차 내장 대시보드·시트 터치 인터페이스용 |
| CNT 필름 공정 | 독자 CNB™(Carbon NanoBud) 소재 — 기존 ITO 대체 |
| 항공우주 응용 | 위성·드론 제빙 시스템 |

---

## 🇰🇷 한국 지사

없음. 단, 한국 자동차 OEM(현대·기아)과 부품 공급 협력 가능성:
- 현대모비스, 한온시스템 등 Tier-1과 잠재적 파트너십
- 한국 시장 직접 진출 계획 미확인

---

## 📈 성장성 & 재무 동향

**★★★★ 우수**

- 자율주행 확산에 따른 LiDAR 히팅 필름 수요 급증
- Toyota, BMW 등 글로벌 OEM과 파트너십 진행
- EU 기후 목표에 따른 에너지 효율 히팅 솔루션 수요 증가
- Series C 이상 투자 유치, Business Finland 지원 수혜
- 2025년 이후 LiDAR 탑재 차량 대중화와 함께 핵심 공급업체로 성장 전망
- 기존 ITO 필름 대체재로 전장 시장 침투율 상승 중

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
|------|------|
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | LiDAR 히팅 시스템·ADAS 센서 부품 — 자동차 임베디드 HW/SW 경력 직접 활용 가능 |
| 추천 직무 | Automotive Application Engineer, Embedded Systems Engineer (센서 히팅 제어), Product Manager (ADAS Components) |
| 지원 방법 | https://canatu.com/careers/ |
| 비자 스폰 | 핀란드 Work Permit / EU Blue Card 지원 가능 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|핀란드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Canatu 공식 홈페이지 — 작성 기준 2026.06.01*
