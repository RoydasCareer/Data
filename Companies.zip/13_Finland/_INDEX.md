---
tags:
  - index
  - country/finland
country: "핀란드"
---

# 핀란드 🇫🇮 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 32개 |
| ★★★ 핵심 추천 | 5개 |
| ★★ 높은 적합성 | 22개 |
| ★ 보통 적합성 | 5개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | Work Permit |
| 취득 용이성 | ★★ |
| 학위 요건 | 기술직은 경험 인정 |
| 참고사항 | Traficom, Unikie 등 자동차 기업 외국인 채용. |

## ⭐ 추천 기업 #Recommand

### ★★★ 핵심 추천
- [[Unikie|Unikie]] — 자율주행·SW 엔지니어링
- [[Traficom|Traficom (Finnish Transport Authority)]] — 차량 인증·V2X 표준 SW
- [[Elektrobit_Finland|Elektrobit (EB) Finland]] — 자동차 임베디드 SW·AUTOSAR (Continental 자회사)
- [[Canatu|Canatu]] — 자동차 센서·히터 필름 기술 SW
- [[Cargotec|Cargotec]] — 자율 화물 차량·SW

### ★★ 높은 적합성
- [[Nokia|Nokia (Automotive/V2X)]] — V2X·5G·자동차 매핑 SW
- [[Valmet_Automotive|Valmet Automotive (SW Division)]] — 자동차 SW·엔지니어링
- [[Tietoevry|Tietoevry (Automotive)]] — 자동차 SW·디지털 변환
- [[Basemark|Basemark]] — 자동차 그래픽·AV SW (HQ: Helsinki)
- [[Rightware|Rightware (HQ: Helsinki)]] — 자동차 HMI·인포테인먼트 SW
- [[Sensible_4|Sensible 4]] — 악천후 자율주행 SW (HQ: Espoo)
- [[GIM_Robotics|GIM Robotics]] — AV SW·인식
- [[Tuxera|Tuxera]] — 자동차용 임베디드 파일시스템 SW
- [[Visidon|Visidon]] — 컴퓨터 비전·인식 SW
- [[WithSecure|WithSecure (F-Secure)]] — 자동차 사이버보안
- [[SSH_Communications_Security|SSH Communications Security]] — 자동차 보안·접근 제어
- [[Nixu|Nixu (DNV)]] — 자동차 사이버보안·QA
- [[Varjo|Varjo]] — 자동차 설계·시뮬레이션 VR/XR
- [[Vaisala|Vaisala (Automotive)]] — 도로 날씨 센싱·AV 데이터 SW
- [[Fintraffic|Fintraffic]] — 스마트 교통·V2X SW
- [[VTT_Technical_Research_Centre|VTT Technical Research Centre]] — 자동차 기술 R&D
- [[F-Secure|F-Secure (Automotive)]] — 자동차 사이버보안
- [[Denso|Denso (Finland R&D)]] — 자동차 SW·제어 시스템
- [[Continental|Continental (Finland R&D)]] — 자동차 SW·시스템
- [[Harman|Harman (Finland R&D)]] — 커넥티드카·인포테인먼트 SW
- [[Metso|Metso (Automotive)]] — 자동차 제조 QA SW
- [[Foreca|Foreca (Automotive)]] — 자율주행용 날씨 데이터 SW

## 📋 전체 기업 목록 (적합도 낮은 기업 포함)

### ★ 보통 적합성
- [[Remoted|Remoted]] — 자율 셔틀 운영·SW
- [[Sitowise|Sitowise (Automotive)]] — 스마트 시티·모빌리티 SW
- [[Taksi_Helsinki|Taksi Helsinki (Tech)]] — 플릿 SW·통신
- [[Probot|Probot (Finland)]] — 자율 산업 로봇·SW
- [[Solita|Solita (Automotive)]] — 자동차 데이터·SW 컨설팅
