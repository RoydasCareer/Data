---
tags:
  - company
  - automotive
  - country/finland
  - size/large
  - automotive/embedded
  - automotive/autosar
  - fit/★★★★
country: "핀란드"
country_folder: "13_Finland"
company_name: "Elektrobit (EB) Finland"
size: "대기업 (Continental 자회사)"
fit: "★★★★"
business: "자동차 임베디드 SW 전문 — AUTOSAR, EB tresos, EB corbos, ADAS 소프트웨어"
hq: "Erlangen, Germany (핀란드 오피스: Oulu / Helsinki)"
founded: "1986"
employees: "약 4,000명 (글로벌)"
revenue: "비공개 (Continental 자회사)"
ipo_status: "비상장 (Continental AG 자회사)"
---
# Elektrobit (EB) Finland

> 자동차 임베디드 SW 전문 — AUTOSAR·EB tresos·EB corbos·ADAS 소프트웨어 | 대기업 | 핀란드 🇫🇮

## 🏢 회사 개요

| 항목 | 내용 |
|------|------|
| 법인명 | Elektrobit Automotive GmbH (핀란드: Elektrobit Oy) |
| 글로벌 본사 | Am Wolfsmantel 46, Erlangen, Germany |
| 핀란드 오피스 | Oulu, Helsinki |
| 설립연도 | 1986년 (핀란드 Oulu 창립) |
| CEO | Veli-Pekka Mäkinen |
| 임직원수 | 약 4,000명 (글로벌, 20개국) |
| 연매출 | 비공개 (Continental AG 자회사) |
| 상장여부 | 비상장 (Continental AG 100% 자회사, 2015년 인수) |
| 공식홈페이지 | https://www.elektrobit.com |

---

## 🎯 주요 제품 & 서비스

| 제품 | 내용 |
|------|------|
| EB tresos AutoCore | AUTOSAR Classic 기반 ECU 미들웨어 — 글로벌 표준 플랫폼 |
| EB corbos Linux | 자동차용 Linux OS — SDV(소프트웨어 정의 차량) 핵심 |
| EB corbos AdaptiveCore | AUTOSAR Adaptive 플랫폼 — 고성능 SoC 기반 |
| EB solys | 자동차 SW 추적·분석·시각화 툴 |
| ADAS SW | 인지·판단·제어 알고리즘, 센서 인터페이스 라이브러리 |
| 커넥티드카 | OTA 업데이트, 차량 사이버보안 솔루션 |

---

## 🇰🇷 한국 지사

직접 법인 없음. 단, 모회사 Continental Korea를 통한 협력:
- Continental Korea (서울 강남): EB 제품 기술 지원
- 현대·기아차 납품 — EB tresos 기반 ECU SW 공급
- 삼성전자 Harman과 협력 프로젝트

---

## 📈 성장성 & 재무 동향

**★★★★ 우수**

- AUTOSAR Classic/Adaptive 시장 글로벌 점유율 최상위
- SDV 전환 가속 — EB corbos Linux 채택 OEM 급증
- Continental의 SW 사업부로서 안정적 투자·성장
- 2025년 이후 AUTOSAR Adaptive 기반 E/E 아키텍처 전환에서 핵심 역할
- 핀란드 Oulu 오피스가 EB의 창립지 — R&D 핵심 거점
- 포르쉐, BMW, 폭스바겐, 현대·기아 등 글로벌 OEM 전체 고객사

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
|------|------|
| 지원 적합도 | ★★★★ |
| 핵심 추천 이유 | 자동차 임베디드 SW·AUTOSAR 분야 세계 최고 수준 — 한국 경력 완벽 부합 |
| 추천 직무 | Embedded SW Engineer (AUTOSAR Classic/Adaptive), ADAS SW Engineer, SW Integration Engineer |
| 지원 방법 | https://www.elektrobit.com/careers/ — Oulu·Helsinki 오피스 포지션 집중 지원 |
| 비자 스폰 | 핀란드 Work Permit / EU Blue Card 지원 — 글로벌 기업으로 비자 절차 체계적 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|핀란드 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: Elektrobit 공식 홈페이지 — 작성 기준 2026.06.01*
