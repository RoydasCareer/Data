---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/software
  - automotive/mobility
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Bluedot"
size: "스타트업"
fit: "★"
business: "지오펜싱·위치 인텔리전스 SW (모바일·드라이브스루 자동화)"
hq: "Toronto, Ontario, Canada"
founded: "2014"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Bluedot

> 지오펜싱·위치 인텔리전스 SW | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Toronto, Ontario, Canada |
| 설립 연도 | 2014년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | SDK 기반 지오펜싱 위치 정밀도 플랫폼 — 드라이브스루 자동화, 모바일 결제 트리거, 차량 도착 알림 |
| 공식 홈페이지 | https://bluedot.io |

**자동차 관련:** 차량 위치 감지로 드라이브스루/픽업 자동화 (맥도날드, 스타벅스 등 F&B 업계 주요 고객).

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·호주 F&B 체인 중심.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 드라이브스루 자동화·차량 위치 기반 서비스 수요 증가.
- 자동차 SW보다 F&B 디지털 전환 솔루션에 가까움.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. F&B 드라이브스루 자동화 특화 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | SDK/Mobile SW Engineer — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [bluedot.io](https://bluedot.io)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: bluedot.io 공식 (2026.05 기준)*
