---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/telematics
  - automotive/connected
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Intellimotive"
size: "스타트업"
fit: "★"
business: "커넥티드카·텔레매틱스 데이터 플랫폼"
hq: "Ontario, Canada"
founded: "~2015"
employees: "~30명 미만"
revenue: "비공개 (소규모)"
ipo_status: "비상장"
korea_office: "없음"
---

# Intellimotive

> 커넥티드카·텔레매틱스 데이터 플랫폼 | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Ontario, Canada |
| 설립 연도 | ~2015년 |
| 임직원 수 | ~30명 미만 |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | OBD·CAN 데이터 기반 커넥티드카 텔레매틱스 플랫폼 — 차량 건강 모니터링, 예측 정비 |
| 공식 홈페이지 | https://intellimotive.co |

> ⚠️ 소규모 스타트업으로 공개 정보 제한적. 상세 데이터 미확인.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 로컬 중심.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 커넥티드카 데이터 플랫폼 수요 증가.
- 소규모로 대형 경쟁사(Geotab, Samsara) 대비 열세.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 매우 소규모 스타트업 — 재무 불안정성 높음. |
| 추천 직무 | SW Engineer (차량 데이터) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 경험 우선 가능 (소규모 특성) |

---

## 🔗 관련 정보

- 홈페이지: [intellimotive.co](https://intellimotive.co)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: 공개 정보 제한적 (2026.05 기준)*
