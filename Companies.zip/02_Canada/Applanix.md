---
tags:
  - company
  - automotive
  - country/canada
  - size/small
  - automotive/autonomous
  - automotive/adas
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Applanix"
size: "중소기업"
fit: "★"
business: "자율주행·모바일 매핑용 고정밀 포지셔닝 SW (Trimble 자회사)"
hq: "Richmond Hill, Ontario, Canada"
founded: "1991"
employees: "~200명 (2024)"
revenue: "비공개 (Trimble NASDAQ: TRMB 자회사)"
ipo_status: "비상장 (Trimble Inc. NASDAQ: TRMB 완전 자회사, 1999년 인수)"
korea_office: "없음 (트림블솔루션즈코리아는 건설 BIM 전담)"
---

# Applanix

> 자율주행·모바일 매핑용 고정밀 포지셔닝 SW | 중소기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Richmond Hill, ON, Canada |
| 설립 연도 | 1991년 |
| 모회사 | Trimble Inc. (NASDAQ: TRMB) — 1999년 인수 |
| 임직원 수 | ~200명 (2024) |
| 규모 분류 | 중소기업 (Trimble 자회사) |
| 상장 여부 | 비상장 (Trimble NASDAQ: TRMB) |
| 주력 사업 | INS/GNSS 통합 고정밀 포지셔닝 시스템 및 SW — 자율주행 차량·항공·모바일 LiDAR 매핑용 |
| 공식 홈페이지 | https://www.applanix.com |

**주요 제품:** POS LV (차량 탑재 포지셔닝), POSPac MMS (후처리 SW)
**주요 고객:** 자율주행 HD 맵 기업, 항공·지리공간 측량사

---

## 🇰🇷 한국 관련

한국 사무소 없음. 트림블솔루션즈코리아(서울 강남구 삼성동)는 건설 BIM 전담 — Applanix 포지셔닝 사업은 별개.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 자율주행 HD 맵 제작용 고정밀 IMU/GNSS 수요 지속.
- 항공·LiDAR 매핑 시장 안정적 수요.
- Trimble 자회사로 재무 안정적이나 독립 성장 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 포지셔닝 특화 — 일반 자동차 SW보다 틈새 시장. |
| 추천 직무 | Positioning SW Engineer, Embedded Navigation SW — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — Trimble 대기업 HR, LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [applanix.com](https://www.applanix.com)
- 모회사: [trimble.com](https://www.trimble.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: applanix.com 공식, Trimble IR (2026.05 기준)*
