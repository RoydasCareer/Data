---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/fleet
  - automotive/ev
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "CrossChasm"
size: "스타트업"
fit: "★"
business: "EV 플릿 전환 분석·채택 지원 SW"
hq: "Kingston, Ontario, Canada"
founded: "2010"
employees: "~20명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# CrossChasm

> EV 플릿 전환 분석 SW | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Kingston, Ontario, Canada |
| 설립 연도 | 2010년 |
| 임직원 수 | ~20명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 기업·정부 플릿의 EV 전환 가능성 분석·최적화 SW (C5 OPTIMAL) — 주행 패턴 분석, 충전 인프라 설계 |
| 공식 홈페이지 | https://www.crosschasm.com |

**주요 고객:** 캐나다·미국 정부기관, 공공 플릿 운영자 (EV 전환 컨설팅)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다·북미 공공 플릿 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- EV 플릿 전환 분석 틈새 시장.
- 공공 EV 전환 수요 증가로 수혜.
- 매우 소규모 — 대형 컨설팅사 경쟁.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 매우 소규모 스타트업. EV 분석 컨설팅 중심 — 임베디드 SW와 연관 낮음. |
| 추천 직무 | Data Analyst / EV Systems Consultant — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [crosschasm.com](https://www.crosschasm.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: crosschasm.com 공식 (2026.05 기준)*
