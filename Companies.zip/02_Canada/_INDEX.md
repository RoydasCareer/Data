---
tags:
  - index
  - country/canada
country: "캐나다"
---

# 캐나다 🇨🇦 자동차 기업 목록

> [[../_MOC|← 전체 기업 MOC로 돌아가기]]

## 📊 통계

| 항목 | 수치 |
| :--- | :--- |
| 전체 기업 수 | 52개 |
| ★★★ 핵심 추천 | 1개 |
| ★★ 높은 적합성 | 11개 |
| ★ 보통 적합성 | 15개 |

## 🛂 비자 정보

| 항목 | 내용 |
| :--- | :--- |
| 비자 유형 | LMIA 기반 취업 허가 |
| 취득 용이성 | ★★ |
| 학위 요건 | 경험 중시 |
| 참고사항 | 자동차 기술직 LMIA 취득 가능. 한국인 워홀 후 취업 경로도 있음. |

## ⭐ 추천 기업 #Recommand

### ★★★★ 최우선 추천 (2026-07-31 신규 — OBD 진단·EV 검증 직결)
- [[Element_Fleet_Management|Element Fleet Management]] — 북미 최대 기업 플릿 관리·OBD 진단 데이터·EV 플릿 전환 (Toronto, TSX: EFN)
- [[AVL_Canada|AVL Canada]] — 파워트레인·EV 배터리·HiL 테스팅 엔지니어링 서비스 (Windsor/Toronto)

### ★★★ 핵심 추천
- [[CS_Canada|CS Canada]] — ISO26262·A-SPICE·ISO21434 컨설팅 (TÜV-SÜD 인증, ~150명)
- [[General_Motors_Canada|General Motors Canada]] — Ultium EV·ADAS·SDV SW 개발 (Markham Tech Centre, NYSE: GM)
- [[Ballard_Power_Systems|Ballard Power Systems]] — 수소 연료전지 버스·트럭·CAN/J1939 BMS (Burnaby BC, NASDAQ: BLDP)
- [[NVIDIA_Automotive_Canada|NVIDIA Automotive Canada]] — 자율주행 AI 컴퓨팅·DRIVE 플랫폼·ADAS 검증 (Toronto/Waterloo, NASDAQ: NVDA)
- [[ABB_Canada|ABB Canada]] — EV 충전 인프라·자동차 제조 로봇·전력 자동화 (Mississauga, NYSE: ABB)

### ★★ 높은 적합성
- [[BlackBerry_QNX|BlackBerry QNX]] — 자동차 OS·보안·미들웨어 (HQ: Waterloo)
- [[Magna_International|Magna International]] — ADAS·SW·전자 시스템 (HQ: Aurora)
- [[Geotab|Geotab]] — 텔레매틱스·커넥티드 차량 SW
- [[LeddarTech|LeddarTech]] — 인식 SW·센서 퓨전 (HQ: Quebec)
- [[Applanix|Applanix (Trimble)]] — 자율주행 고정밀 포지셔닝 SW
- [[Acerta_Analytics|Acerta Analytics]] — 자동차 제조 QA용 머신러닝 SW
- [[Intellimotive|Intellimotive]] — 자동차 텔레매틱스·커넥티드카 SW
- [[Miovision|Miovision]] — 교통 인텔리전스·V2X SW
- [[LinkIt_Smart|LinkIt Smart]] — V2X·스마트 교통 SW
- [[TMA_Solutions_Canada|TMA Solutions Canada]] — 자동차 임베디드 SW·MiL/SiL 테스팅·AUTOSAR
- [[QTSI|QTSI (Quiddity Technology Solutions)]] — ISO26262 기능안전 컨설팅 (몬트리올)

## 📋 전체 기업 목록 (적합도 낮은 기업 포함)

### ★ 보통 적합성
- [[SGS_Canada|SGS Canada (SGS SA)]] — ISO26262 훈련·인증·검사 (글로벌 TIC 대기업)
- [[OpenText|OpenText]] — 자동차 데이터 관리·통신 SW
- [[CGI|CGI]] — 자동차 IT·SW 솔루션
- [[Sierra_Wireless|Sierra Wireless (Semtech)]] — IoT·자동차 통신 모듈
- [[SensorUp|SensorUp]] — IoT·센서 데이터 관리 플릿
- [[Cybera|Cybera]] — 커넥티드 차량 사이버보안
- [[Fleet_Complete|Fleet Complete]] — 커넥티드 차량·플릿 관리 SW
- [[ZTR_Control_Systems|ZTR Control Systems]] — 산업용 텔레매틱스 SW
- [[Descartes_Systems_Group|Descartes Systems Group]] — 물류·플릿 통신 SW
- [[CrossChasm|CrossChasm]] — 플릿 애널리틱스 SW
- [[Solace|Solace]] — 커넥티드카용 실시간 이벤트 스트리밍
- [[Bluedot|Bluedot (HQ: Toronto)]] — 지오펜싱·위치 인텔리전스 SW
- [[Axon|Axon (Canadian tech branch)]] — 차량 카메라·데이터 SW
- [[Pelmorex|Pelmorex (The Weather Network)]] — 자율주행용 날씨 데이터 SW
- [[Tallysman_Wireless|Tallysman Wireless]] — GNSS 안테나·자동차 포지셔닝

### 기타 기업
- [[Carmanah_Technologies|Carmanah Technologies]] — 태양광 LED 교통 신호·도로 안전 시스템 (HQ: Victoria, BC)
- [[MicroTraffic|MicroTraffic]] — AI 기반 교차로·교통 안전 분석
- [[Waabi_Innovation|Waabi Innovation]] — AI 자율주행 트럭 SW (HQ: Toronto)
- [[DarwinAI|DarwinAI (Acquired by Apple)]] — AV 테스팅용 설명가능 AI
- [[Untether_AI|Untether AI]] — AV 인식용 AI 가속기 SW
- [[Foretellix|Foretellix (Canada branch)]] — (HQ: 이스라엘, 본사만 등재)
- [[Kinaxis|Kinaxis]] — 자동차 공급망 SW
- [[Plusgrade|Plusgrade (automotive context)]] — 모빌리티 업그레이드 SW

- [[Deep_Trekker|Deep Trekker]] — 자율 수중 로봇 SW (AV 기술 전용)
- [[Exo-s|Exo-s (automotive)]] — 자동차 어쿠스틱·SW 솔루션
- [[Steer_Technologies|Steer Technologies]] — 자동차 구독·플릿 SW
- [[Movopark|Movopark]] — 스마트 파킹·모빌리티 SW
- [[AutoVerify|AutoVerify]] — 자동차 데이터·딜러 SW
- [[CarGurus_Canada|CarGurus Canada]] — 자동차 마켓플레이스·데이터
- [[Kijiji_Autos|Kijiji Autos (eBay)]] — 자동차 마켓플레이스 데이터
- [[VehicleHistory|VehicleHistory (Canada)]] — 자동차 이력·데이터 SW
- [[Serti|Serti]] — 딜러 관리·자동차 SW
- [[PBS_Systems|PBS Systems]] — 딜러 관리 SW
- [[Quorum_Information_Technologies|Quorum Information Technologies]] — 딜러 관리·자동차 SW
- [[FlixBus_Canada|FlixBus Canada (tech)]] — 모빌리티·플릿 SW
- [[Via|Via (Canada)]] — 수요 응답형 대중교통 SW
- [[Uride|Uride]] — 라이드헤일·플릿 SW
- [[Facedrive|Facedrive]] — 모빌리티 SW 플랫폼
- [[Reliable_Controls|Reliable Controls]] — 자동차 IoT·빌딩/플릿 제어 SW
- [[Nuvei|Nuvei (automotive payments)]] — 자동차 결제 SW
