---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/testing
  - automotive/autonomous
  - fit/★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "Foretellix"
size: "스타트업"
fit: "★★"
business: "자율주행 안전 검증·시나리오 테스팅 플랫폼 (HQ: 이스라엘, 캐나다 사무소)"
hq: "Tel Aviv, Israel (캐나다: Montreal, QC)"
founded: "2019"
employees: "~100명 (2024)"
revenue: "비공개 ($50M+ 조달)"
ipo_status: "비상장"
korea_office: "없음"
---

# Foretellix

> 자율주행 안전 검증·시나리오 테스팅 | 스타트업 | 이스라엘/캐나다 🇮🇱🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Tel Aviv, Israel (캐나다: Montreal, QC) |
| 설립 연도 | 2019년 |
| 창업자 | Ziv Binyamini, Avi Frisch |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 ($50M+ 시리즈 B — Insight Partners 등) |
| 주력 사업 | M-SDL(Measurable Scenario Description Language) 기반 자율주행 시나리오 생성·검증 플랫폼 |
| 공식 홈페이지 | https://www.foretellix.com |

**차별점:** 안전 측정 가능한(measurable) 검증 방법론 — "충분히 테스트했다"를 정량화.
**파트너:** GM, BMW, Aptiv (자율주행 검증 도입)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 이스라엘 본사 + 캐나다(몬트리올) + 미국(디트로이트 지역) 거점.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 자율주행 안전 검증 규제(UN WP.29, ISO 21448 SOTIF) 의무화로 수요 증가.
- 독창적 M-SDL 방법론 — 표준화 경쟁 중.
- 소규모 스타트업으로 자금 소진 리스크.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자율주행 시나리오 테스팅 전문 — ADAS 테스팅 경험 활용 가능. 그러나 한국 사무소 없음. |
| 추천 직무 | Verification Engineer, Scenario SW Engineer — 이스라엘/캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — 이스라엘 취업비자 또는 캐나다 LMIA |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [foretellix.com](https://www.foretellix.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: foretellix.com 공식 (2026.05 기준)*
