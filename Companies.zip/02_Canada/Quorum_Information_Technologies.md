---
tags:
  - company
  - automotive
  - country/canada
  - size/small
  - automotive/software
  - automotive/retail
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Quorum Information Technologies"
size: "중소기업"
fit: "★"
business: "자동차 딜러십 관리 시스템(DMS) SW"
hq: "Calgary, Alberta, Canada"
founded: "1998"
employees: "~220명 (2024)"
revenue: "~$60M CAD (FY2023)"
ipo_status: "상장 (TSX: QIS)"
korea_office: "없음"
---

# Quorum Information Technologies

> 딜러십 관리 시스템(DMS) SW | 중소기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Calgary, Alberta, Canada |
| 설립 연도 | 1998년 |
| 임직원 수 | ~220명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | TSX: QIS |
| 주력 사업 | xtime(서비스 예약)·XSELLERATOR DMS — 캐나다 자동차·트럭 딜러십 통합 관리 SW |
| 공식 홈페이지 | https://www.quorumis.com |

**주요 고객:** 캐나다 자동차 딜러십 (GM, Toyota, Honda 등 OEM 공인 DMS 파트너).

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 딜러십 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 캐나다 DMS 틈새 시장 안정적 점유.
- 자동차 임베디드 SW와 직접 연관 없음.
- TSX 상장 소형주 — 성장 제한적.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 딜러십 관리 SW 특화 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | SW Engineer (DMS/ERP) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [quorumis.com](https://www.quorumis.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: quorumis.com 공식 (2026.05 기준)*
