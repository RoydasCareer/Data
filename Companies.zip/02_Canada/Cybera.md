---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/cybersecurity
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Cybera"
size: "스타트업"
fit: "★"
business: "엔터프라이즈·커넥티드 차량 사이버보안 (Alberta 비영리 네트워크)"
hq: "Edmonton, Alberta, Canada"
founded: "2012"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (비영리 기관)"
korea_office: "없음"
---

# Cybera

> 엔터프라이즈·네트워크 사이버보안 | 비영리 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Edmonton, Alberta, Canada |
| 설립 연도 | 2012년 |
| 임직원 수 | ~50명 |
| 규모 분류 | 비영리 기관 |
| 상장 여부 | 비상장 (비영리) |
| 주력 사업 | 앨버타 연구·교육기관 대상 고속 네트워크 인프라 + 사이버보안 서비스 제공 |
| 공식 홈페이지 | https://www.cybera.ca |

> ⚠️ **자동차 전문 사이버보안 기업이 아님** — 알버타 대학·연구기관 네트워크 인프라 비영리 기관. 자동차 분야와의 직접 연관성 재검토 필요.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 앨버타 지역 한정.

---

## 📈 성장성 평가

**성장성 평가: ★**

- 비영리 기관으로 상업적 성장 목표 없음.
- 자동차 산업과 직접 연관성 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 비영리 네트워크 기관 — 자동차 SW 직접 연관 없음. |
| 추천 직무 | 해당 없음 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 비영리 불확실 |
| 고졸 채용 가능성 | 해당 없음 |

---

## 🔗 관련 정보

- 홈페이지: [cybera.ca](https://www.cybera.ca)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: cybera.ca 공식 (2026.05 기준)*
