---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/v2x
  - automotive/connectivity
  - fit/★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "Miovision"
size: "중소기업"
fit: "★★"
business: "스마트 교통 신호·V2X 인텔리전스 SW"
hq: "Kitchener, Ontario, Canada"
founded: "2007"
employees: "~200명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Miovision

> 스마트 교통 신호·V2X 인텔리전스 SW | 중소기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Kitchener, Ontario, Canada |
| 설립 연도 | 2007년 |
| 창업자 | Kurtis McBride |
| 임직원 수 | ~200명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | AI 기반 교통 신호 최적화 SW(Scout) + V2X 인프라 솔루션 — 교통 흐름 분석·신호 제어 |
| 공식 홈페이지 | https://miovision.com |

**주요 고객:** 미국·캐나다·유럽 도시 교통부
**V2X 관련:** 연결된 신호등 인프라로 자율주행 차량과의 V2I(Vehicle-to-Infrastructure) 통신 지원.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·유럽 스마트 시티 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 스마트 교통 인프라 투자 증가 수혜.
- V2X 자율주행 인프라 연계로 성장 잠재력.
- 소규모 기업으로 글로벌 확장 제한적.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | V2X·교통 인텔리전스 SW — CAN/V2X 통신 분야 경험 활용 가능. 그러나 한국 사무소 없음. |
| 추천 직무 | SW Engineer (교통 최적화, V2X) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [miovision.com](https://miovision.com)
- 채용: [miovision.com/careers](https://miovision.com/careers)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: miovision.com 공식 (2026.05 기준)*
