---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/cameras
  - automotive/fleet
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Axon Enterprise (캐나다 기술 거점)"
size: "대기업"
fit: "★"
business: "차량 탑재 카메라·경찰 BWC·데이터 SW (HQ: 미국)"
hq: "Scottsdale, Arizona, USA (캐나다: Vancouver, BC)"
founded: "1993"
employees: "~4,000명 (글로벌)"
revenue: "$2.0B (FY2024)"
ipo_status: "NASDAQ: AXON"
korea_office: "없음"
---

# Axon Enterprise

> 차량 탑재 카메라·경찰 BWC·데이터 SW | 대기업 | 미국/캐나다 🇺🇸🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Scottsdale, AZ, USA (캐나다: Vancouver, BC 기술 거점) |
| 설립 연도 | 1993년 |
| 창업자 | Rick Smith |
| 임직원 수 | ~4,000명 (글로벌) |
| 규모 분류 | 대기업 |
| 상장 여부 | NASDAQ: AXON |
| 주력 사업 | Taser 전기충격기, 경찰 차량 탑재 카메라(Fleet 3), Body Worn Camera + Axon Cloud 증거 관리 플랫폼 |
| 공식 홈페이지 | https://www.axon.com |

**자동차 관련:** 경찰차·상용차 탑재 카메라 시스템 (Fleet 3), 대시캠·실내 카메라, AI 기반 증거 처리.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·유럽 법집행기관 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- 법집행 기술 시장 연 20%+ 성장.
- 차량 탑재 카메라 + AI 증거 분석 솔루션 통합 선두.
- 자동차 SW 직접 연관성 낮음 (경찰·공공 안전 중심).

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 경찰·법집행 특화 — 자동차 임베디드 SW 직접 연관 낮음. |
| 추천 직무 | Embedded Camera Engineer, Video Analytics Engineer — 미국/캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — NASDAQ 대기업, H-1B/LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [axon.com](https://www.axon.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: axon.com 공식, NASDAQ IR (2026.05 기준)*
