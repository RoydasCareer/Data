---
tags:
  - company
  - automotive
  - country/canada
  - size/small
  - automotive/fleet
  - automotive/telematics
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Fleet Complete"
size: "중소기업"
fit: "★"
business: "플릿 관리·IoT 커넥티드 차량 SW"
hq: "Toronto, Ontario, Canada"
founded: "2000"
employees: "~300명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (Bell Canada 계열)"
korea_office: "없음"
---

# Fleet Complete

> 플릿 관리·IoT 커넥티드 차량 SW | 중소기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Toronto, Ontario, Canada |
| 설립 연도 | 2000년 |
| 창업자 | Tony Lourakis |
| 임직원 수 | ~300명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 (Bell Canada 투자) |
| 주력 사업 | GPS 추적·ELD 컴플라이언스·자산 추적·현장 서비스 관리 SaaS |
| 공식 홈페이지 | https://www.fleetcomplete.com |

**지역:** 캐나다·미국·유럽·호주 중소 플릿 운영사 대상

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·유럽 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 중소 플릿 SaaS 시장 경쟁 치열 (Geotab, Samsara 대비 규모 열세).
- Bell Canada 투자로 캐나다 내 안정적 유통망.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 플릿 SaaS — 자동차 임베디드 SW와 직접 연관 낮음. |
| 추천 직무 | SW Engineer (IoT/플릿) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [fleetcomplete.com](https://www.fleetcomplete.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: fleetcomplete.com 공식 (2026.05 기준)*
