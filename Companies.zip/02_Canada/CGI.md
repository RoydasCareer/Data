---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/software
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "CGI"
size: "대기업"
fit: "★"
business: "IT 컨설팅·자동차 디지털 전환 서비스"
hq: "Montreal, Quebec, Canada"
founded: "1976"
employees: "~90,000명 (2024)"
revenue: "$14.7B (FY2024)"
ipo_status: "TSX: GIB.A / NYSE: GIB"
korea_office: "없음"
---

# CGI

> IT 컨설팅·자동차 디지털 전환 서비스 | 대기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Montreal, Quebec, Canada |
| 설립 연도 | 1976년 |
| 창업자 | Serge Godin, André Imbeau |
| 임직원 수 | ~90,000명 (2024) |
| 규모 분류 | 대기업 |
| 상장 여부 | TSX: GIB.A / NYSE: GIB |
| 주력 사업 | IT 컨설팅·시스템 통합·아웃소싱 (자동차, 금융, 정부, 통신 업종) |
| 공식 홈페이지 | https://www.cgi.com |

**자동차 분야:** 커넥티드카 플랫폼, OTA SW 업데이트, 자동차 IT 인프라 컨설팅 — OEM 대상 디지털 전환 서비스.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 주요 거점: 캐나다, 미국, 유럽, 인도.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 글로벌 IT 컨설팅 대기업으로 안정적 수익.
- 자동차 디지털 전환 수요 증가로 자동차 사업부 성장.
- 자동차 SW 직접 개발보다 컨설팅·아웃소싱 위주.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 컨설팅·IT 서비스 중심 — 자동차 임베디드 SW 개발과 직접 연관 낮음. |
| 추천 직무 | 자동차 IT 컨설턴트, 시스템 통합 엔지니어 — 캐나다/유럽 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 대기업, LMIA/영국·유럽 취업비자 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [cgi.com](https://www.cgi.com)
- 채용: [cgi.com/careers](https://www.cgi.com/careers)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: cgi.com 공식, TSX IR (2026.05 기준)*
