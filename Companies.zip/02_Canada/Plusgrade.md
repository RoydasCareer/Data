---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/mobility
  - automotive/maas
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Plusgrade"
size: "중견기업"
fit: "★"
business: "여행·모빌리티 업셀링 수익 최적화 플랫폼"
hq: "Montreal, Quebec, Canada"
founded: "2009"
employees: "~500명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Plusgrade

> 여행·모빌리티 업셀링 플랫폼 | 중견기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Montreal, Quebec, Canada |
| 설립 연도 | 2009년 |
| 임직원 수 | ~500명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 항공·호텔·크루즈·철도사 대상 업그레이드 경매·업셀링 수익 최적화 SaaS |
| 공식 홈페이지 | https://www.plusgrade.com |

**자동차 관련:** 직접적 자동차 임베디드 SW 연관 없음. 모빌리티 서비스(기차·버스) 업셀링 플랫폼으로 분류.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 글로벌 항공·여행사 대상 서비스.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 여행 업셀링 SaaS 성장 시장.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 여행·항공 업셀링 특화 — 자동차 SW 엔지니어링과 연관 없음. |
| 추천 직무 | Backend Engineer (SaaS 플랫폼) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [plusgrade.com](https://www.plusgrade.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: plusgrade.com 공식 (2026.05 기준)*
