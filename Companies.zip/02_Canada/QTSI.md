---
tags:
  - company
  - automotive
  - country/canada
  - size/small
  - automotive/functional-safety
  - automotive/aspice
  - fit/★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "QTSI (Quiddity Technology Solutions Inc.)"
size: "소기업"
fit: "★★"
business: "ISO 26262 기능안전 컨설팅·HARA·ASIL·안전 분석 (자동차 전문)"
hq: "Dollard-des-Ormeaux, Montréal, Québec, Canada"
founded: "[확인필요]"
employees: "[확인필요 — 소규모 전문 컨설팅, 추정 10~20명]"
revenue: "비공개"
ipo_status: "비상장 (소규모 사기업)"
korea_office: "없음"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# QTSI (Quiddity Technology Solutions Inc.)

> ISO 26262 기능안전 컨설팅 | 소기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Dollard-des-Ormeaux, Montréal, Québec, Canada (H9B 3A5) |
| 설립 연도 | [확인필요] |
| 임직원 수 | [확인필요] (추정 10~20명 — 전문 컨설팅 소규모) |
| 규모 분류 | 소기업 |
| 상장 여부 | 비상장 (소규모 독립 컨설팅사) |
| 주력 사업 | ISO 26262 기능안전 컨설팅 — HARA·ASIL 분석·FTA/FMEA·안전 감사 |
| 공식 홈페이지 | https://www.quidditytech.io |

캐나다 몬트리올 기반 ISO 26262 전문 컨설팅사. HARA(위험분석·위험평가), ASIL 결정, 기능 안전 개념(FSC)·기술 안전 개념(TSC), FTA·FMEA·FMECA·DFA 안전 분석, 기능안전 감사 서비스 제공. 도구: **Ansys Medini, IBM DOORS, Polarion**. 캐나다 Controlled Goods Program 등록사. 설립자 Salim Ali는 온타리오주 등록 Professional Engineer(P.Eng).

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 몬트리올 현지 취업 대상.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- ISO 26262 의무화 확산 → 전문 컨설팅 수요 지속 증가
- 퀘벡 자동차 산업 성장 → 로컬 전문 컨설팅사 수요 확대
- 소규모 전문사 특성 — 빠른 의사결정·전문 역량 집중

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | ISO26262 기능안전 직접 전문 컨설팅 — 핵심 역량 연계 가능. 퀘벡 몬트리올 기반. |
| 추천 직무 | Functional Safety Engineer, Safety Analyst |
| 한국 지원 경로 | 없음 (캐나다 직접 지원 — quidditytech.io) |
| 비자 스폰 가능성 | ★★ — LMIA 가능하나 소규모 회사 특성상 절차 복잡할 수 있음 |
| 고졸 채용 가능성 | 기술 경험 중심 (P.Eng 같은 자격증 선호 가능) |

---

## ⚠️ 리스크 / 고려사항

- **극소규모 회사**: 추정 10~20명 — 채용 빈도 매우 낮음, 채용 안정성 불확실
- **재무·경영 투명성 낮음**: 소규모 비상장사 — 경영 상태 외부 확인 불가
- **프랑스어권 퀘벡**: 몬트리올 소재 — 영어 외 프랑스어 요구 가능성
- **한국 법인 없음**: 캐나다 현지 이주 필수

## 🔗 관련 정보

- 홈페이지: [quidditytech.io](https://www.quidditytech.io)
- LinkedIn: [확인필요]
- 채용: [quidditytech.io](https://www.quidditytech.io)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: quidditytech.io 공식, 캐나다 정부 Controlled Goods Program 등록 목록 (2026.06 기준)*
