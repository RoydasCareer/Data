---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/marketplace
  - automotive/retail
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Kijiji Autos"
size: "중견기업"
fit: "★"
business: "캐나다 자동차 온라인 중고차 마켓플레이스 (Adevinta 계열)"
hq: "Toronto, Ontario, Canada"
founded: "2005 (Kijiji); 2023 Adevinta 매각 후 재편"
employees: "~500명 (Kijiji 전체)"
revenue: "비공개"
ipo_status: "비상장 (Adevinta ASA 계열)"
korea_office: "없음"
---

# Kijiji Autos

> 캐나다 자동차 온라인 마켓플레이스 | 중견기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Toronto, Ontario, Canada |
| 설립 연도 | 2005년 (Kijiji); 자동차 섹션 별도 운영 |
| 모기업 | Adevinta ASA (노르웨이 분류 광고 플랫폼) |
| 임직원 수 | ~500명 (Kijiji 전체) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 (Adevinta 계열) |
| 주력 사업 | 캐나다 최대 분류 광고 플랫폼 Kijiji의 자동차 중고차 거래 섹션 |
| 공식 홈페이지 | https://www.kijijiautos.ca |

**시장 위치:** 캐나다 내 AutoTrader.ca와 중고차 온라인 광고 경쟁.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 내수 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 캐나다 내 온라인 중고차 거래 플랫폼.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 온라인 마켓플레이스 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Platform SW Engineer — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [kijijiautos.ca](https://www.kijijiautos.ca)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: kijiji.ca 공식 (2026.05 기준)*
