---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/gnss
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Tallysman Wireless"
size: "스타트업"
fit: "★"
business: "GNSS 안테나·자동차 포지셔닝 (ComNav Technology 인수)"
hq: "Ottawa, Ontario, Canada"
founded: "2008"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (2022년 ComNav Technology 인수)"
korea_office: "없음"
---

# Tallysman Wireless

> GNSS 안테나·자동차 포지셔닝 | 스타트업(인수됨) | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Ottawa, Ontario, Canada |
| 설립 연도 | 2008년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 — 2022년 중국 ComNav Technology 인수 |
| 주력 사업 | L1/L2/L5 다주파수 GNSS 안테나 설계·제조 — 자동차, UAV, 농업, 측량용 |
| 공식 홈페이지 | https://www.tallysman.com |

**자동차 관련:** 자율주행·ADAS 고정밀 GPS 포지셔닝 안테나.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 모회사 ComNav Technology (중국)의 한국 활동 미확인.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- GNSS 안테나 특화 제품 — 자율주행 포지셔닝 수요 증가.
- 중국 기업 인수로 지정학 리스크(미국·캐나다 수출 제한 가능성).
- 하드웨어 특화로 SW 엔지니어 채용 제한적.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 안테나 하드웨어 특화 — SW 엔지니어 채용 적합성 낮음. |
| 추천 직무 | RF/Antenna Engineer — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 중국 인수 후 불확실 |
| 고졸 채용 가능성 | RF/EE 학위 필요 |

---

## 🔗 관련 정보

- 홈페이지: [tallysman.com](https://www.tallysman.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: tallysman.com 공식 (2026.05 기준)*
