---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/software
  - automotive/retail
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "PBS Systems"
size: "중견기업"
fit: "★"
business: "자동차·상용차 딜러십 관리 시스템(DMS) SW"
hq: "Lethbridge, Alberta, Canada"
founded: "1988"
employees: "~600명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# PBS Systems

> 딜러십 관리 시스템(DMS) | 중견기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Lethbridge, Alberta, Canada |
| 설립 연도 | 1988년 |
| 임직원 수 | ~600명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자동차·트럭·RV·농기계 딜러십 전용 DMS — 인벤토리·서비스·금융·CRM 통합 관리 |
| 공식 홈페이지 | https://www.pbssystems.com |

**주요 고객:** 캐나다·미국 자동차·트럭·RV·농기계 딜러십

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다·미국 딜러십 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- DMS 틈새 시장 — 캐나다 내 안정적 고객 기반.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 딜러십 관리 SW 특화 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | SW Engineer (ERP/DMS) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [pbssystems.com](https://www.pbssystems.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: pbssystems.com 공식 (2026.05 기준)*
