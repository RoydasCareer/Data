---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/ev
  - automotive/embedded
  - fit/★★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "Ballard Power Systems"
size: "중견기업"
fit: "★★★"
business: "수소 연료전지 버스·트럭 파워트레인·CAN/J1939 기반 BMS 시스템"
hq: "Burnaby, British Columbia, Canada"
founded: "1979"
employees: "~1,500명"
ipo_status: "상장 (NASDAQ: BLDP)"
korea_office: "없음"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Ballard Power Systems

> 수소 연료전지 버스·트럭 파워트레인 | 중견기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Burnaby, British Columbia, Canada |
| 설립 연도 | 1979 |
| 임직원 수 | ~1,500명 |
| 상장 여부 | 상장 (NASDAQ: BLDP) |
| 주력 사업 | 수소 PEM 연료전지 모듈, 버스·트럭 파워트레인, BMS 통합, 연료전지 SW |
| 공식 홈페이지 | https://www.ballard.com |

## 🎯 주요 제품 & 서비스

FCmove™ 연료전지 모듈(버스·트럭용), CAN/J1939 기반 파워트레인 제어, BMS 통합 시스템, 수소 충전 인프라. 중국·유럽·북미 버스 OEM에 공급. 현대차(XCIENT 트럭) 협력사.

## 🚗 자동차/모빌리티 관련성

CAN/J1939 버스 통신 + BMS 통합 → 전수환의 CAN-FD/진단 경험 확장 적용. EV/BMS 과정(2026) + 연료전지 파워트레인 → 신규 도메인 진입. 현대차 협력사로 현재 고용주 연결점.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

수소 버스 글로벌 확대, 캐나다 정부 수소 경제 로드맵 지원. 탈탄소 상용차 전환 가속.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | CAN/J1939 통신 + EV/BMS 지식(2026) + 현대차 협력사 → Validation Engineer, Technical PM 포지션. 캐나다 Express Entry 자격. |
| 추천 직무 | Powertrain Validation Engineer, CAN Systems Engineer, Technical PM |
| 지원 방법 | ballard.com/about-ballard/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★ (NASDAQ 상장, LMIA 스폰서 가능) |

## ⚠️ 리스크 / 고려사항

- 수소 연료전지 도메인 전환 학습 필요
- Burnaby(밴쿠버 인근) — 캐나다 최고 생활비 지역 중 하나

## 🔗 관련 정보

- 홈페이지: [ballard.com](https://www.ballard.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Ballard Power Systems 공식 홈페이지 (2026.07 기준)*
