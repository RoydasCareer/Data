---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/software
  - automotive/retail
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "AutoVerify"
size: "스타트업"
fit: "★"
business: "자동차 딜러 디지털 전환 SW (차량 이력·중고차 거래 플랫폼)"
hq: "Ottawa, Ontario, Canada"
founded: "2014"
employees: "~100명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# AutoVerify

> 자동차 딜러 디지털 전환 SW | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Ottawa, Ontario, Canada |
| 설립 연도 | 2014년 |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 자동차 딜러용 디지털 소매 플랫폼 — 차량 이력 조회, 온라인 중고차 거래, 딜러 인벤토리 관리 |
| 공식 홈페이지 | https://autoverify.com |

**주요 고객:** 캐나다 자동차 딜러십

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 딜러 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 온라인 중고차 거래 디지털화 수혜.
- 캐나다 로컬 시장 집중 — 글로벌 확장 제한적.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 딜러십 SW 특화 — 자동차 임베디드 SW와 직접 연관 없음. |
| 추천 직무 | Backend SW Engineer — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [autoverify.com](https://autoverify.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: autoverify.com 공식 (2026.05 기준)*
