---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/software
  - automotive/payments
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Nuvei"
size: "대기업"
fit: "★"
business: "글로벌 결제 기술 플랫폼 (자동차 인앱·딜러 결제 포함)"
hq: "Montreal, Quebec, Canada"
founded: "2003"
employees: "~2,000명 (2024)"
revenue: "$1.3B (FY2023)"
ipo_status: "비상장 (2024년 사모펀드 인수, 상장폐지 예정)"
korea_office: "없음"
---

# Nuvei

> 글로벌 결제 기술 플랫폼 | 대기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Montreal, Quebec, Canada |
| 설립 연도 | 2003년 |
| 창업자 | Philip Fayer |
| 임직원 수 | ~2,000명 (2024) |
| 규모 분류 | 대기업 |
| 상장 여부 | NASDAQ: NVEI → 2024년 Advent International 사모펀드 인수로 상장폐지 |
| 주력 사업 | 글로벌 결제 처리 API/SDK — 150개국, 550+ 결제 수단 지원 |
| 공식 홈페이지 | https://www.nuvei.com |

**자동차 관련:** 딜러십 온라인 결제, 인차결제(IVC, In-Vehicle Commerce) 플랫폼 지원.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 글로벌 결제 처리 서비스 제공 (한국 결제 수단 지원은 가능, 직영 법인 없음).

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 글로벌 결제 시장 지속 성장.
- 자동차 인앱 결제 (EV 충전, 주차 결제) 신규 시장.
- 사모펀드 인수로 독립 성장 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 결제 기술 특화 — 자동차 임베디드 SW와 직접 연관 없음. |
| 추천 직무 | Payment Platform Engineer — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 대기업, LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [nuvei.com](https://www.nuvei.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: nuvei.com 공식 (2026.05 기준)*
