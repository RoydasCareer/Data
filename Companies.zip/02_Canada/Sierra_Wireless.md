---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/connectivity
  - automotive/iot
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Sierra Wireless"
size: "중견기업"
fit: "★"
business: "IoT·자동차 셀룰러 통신 모듈 (Semtech 인수)"
hq: "Richmond, British Columbia, Canada"
founded: "1993"
employees: "~1,000명 (인수 후)"
revenue: "비공개 (2023년 Semtech NASDAQ: SMTC 인수)"
ipo_status: "비상장 (2023년 Semtech 인수 완료)"
korea_office: "없음"
---

# Sierra Wireless

> IoT·자동차 셀룰러 통신 모듈 | 중견기업(인수됨) | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Richmond, BC, Canada |
| 설립 연도 | 1993년 |
| 임직원 수 | ~1,000명 (인수 후) |
| 규모 분류 | 중견기업 (인수됨) |
| 상장 여부 | 비상장 — 2023년 Semtech Corporation (NASDAQ: SMTC) 인수 |
| 주력 사업 | 자동차·산업 IoT용 4G/5G 셀룰러 통신 모듈 (EM/HL 시리즈), GNSS 모듈 |
| 공식 홈페이지 | https://www.sierrawireless.com |

**주요 제품:** AirLink (라우터), EM/HL (모듈) — 자동차 V2X·텔레매틱스 모뎀
**주요 고객:** GM, Ford, BMW (OEM 내장 통신 모듈)

---

## 🇰🇷 한국 관련

한국 사무소 없음. Semtech(모회사) 또한 한국 직영 법인 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- Semtech 인수로 독립 성장 제한.
- 자동차 5G 통신 모듈 수요 증가로 기술 가치는 유지.
- 반도체 경기 영향 받음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 통신 모듈 하드웨어 특화 — 자동차 SW 엔지니어링 직접 연관 낮음. |
| 추천 직무 | Embedded Firmware Engineer (통신 모듈) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [sierrawireless.com](https://www.sierrawireless.com)
- 모회사: [semtech.com](https://www.semtech.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: sierrawireless.com 공식, Semtech IR (2026.05 기준)*
