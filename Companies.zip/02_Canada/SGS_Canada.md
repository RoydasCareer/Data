---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/functional-safety
  - automotive/testing
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "SGS Canada (SGS SA)"
size: "대기업"
fit: "★"
business: "검사·검증·인증·훈련 (자동차 ISO26262 기능안전 포함) — 스위스 SGS SA 자회사"
hq: "Mississauga, Ontario, Canada (SGS Canada 주요 오피스)"
founded: "1878 (SGS SA 창립); 캐나다 법인 [확인필요]"
employees: "90,000명+ (SGS 글로벌); 캐나다 규모 미공개"
revenue: "CHF 6.6B (SGS 글로벌, 2024)"
ipo_status: "상장 — SIX: SGSN (스위스 증권거래소)"
korea_office: "SGS Korea — 서울 (그룹 법인)"
last_updated: "2026-06-10"
fact_checked: "2026-06-10"
---

# SGS Canada (SGS SA)

> 검사·검증·인증·훈련 | 대기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Mississauga, Ontario, Canada (캐나다 주요 거점) |
| 설립 연도 | 1878년 (SGS SA 창립); 캐나다 법인 [확인필요] |
| 임직원 수 | 90,000명+ (SGS 글로벌); 캐나다 규모 미공개 |
| 규모 분류 | 대기업 |
| 상장 여부 | SIX: SGSN (스위스 증권거래소, SGS SA 글로벌 상장) |
| 주력 사업 | 검사·검증·테스팅·인증(TIC) — 자동차 ISO26262 기능안전·사이버보안 포함 |
| 공식 홈페이지 | https://www.sgs.com/en-ca |

세계 최대 검사·검증·인증(TIC) 기업 SGS SA의 캐나다 법인. ISO 26262 기능안전 훈련·개인 인증, 자동차 기능안전 컨설팅, 사이버보안 서비스 제공. 단, **ISO 26262 전문 역량은 독일 글로벌 컴피턴스 센터에 집중** — 캐나다는 훈련·인증 서비스 위주.

---

## 🇰🇷 한국 관련

**SGS Korea** — 서울 소재. 그러나 자동차 기능안전 전문 채용은 독일/캐나다 본사 중심.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- SGS 글로벌 — ISO26262·사이버보안 인증 서비스 수요 안정적 성장
- 캐나다 내 자동차 안전 인증 수요 증가 중
- 그러나 자동차 기능안전 캐나다 역할은 글로벌 대비 제한적

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | ISO26262 인증 기관이지만 자동차 전문 포지션은 캐나다 내 제한적 — 글로벌 브랜드 활용한 TIC 분야 경력 가능 |
| 추천 직무 | Functional Safety Specialist, Certification Engineer (캐나다) |
| 한국 지원 경로 | SGS Korea 통해 간접 가능 (자동차 기능안전 전담 직무 별도) |
| 비자 스폰 가능성 | ★★★ — 대기업 LMIA 가능 |
| 고졸 채용 가능성 | 기술 자격 중시 |

---

## ⚠️ 리스크 / 고려사항

- **자동차 기능안전 역량 독일 집중**: 캐나다는 훈련·인증 서비스 위주 — 자동차 SW 엔지니어링 포지션 제한적
- **대기업 관료적 구조**: 90,000명 글로벌 조직 — 의사결정 느림, 역할 범위 좁을 수 있음
- **컨설팅보다 TIC 사업 모델**: 심층 기술 역량 개발보다 인증·감사 위주
- **캐나다 자동차 ISO26262 채용 빈도 낮음**: 전문 포지션은 독일·영국 거점 위주

## 🔗 관련 정보

- 홈페이지: [sgs.com/en-ca](https://www.sgs.com/en-ca)
- LinkedIn: [linkedin.com/company/sgs](https://www.linkedin.com/company/sgs/)
- 채용: [sgs.com/en/careers](https://www.sgs.com/en/careers)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: sgs.com/en-ca 공식, SGS Annual Report 2024 (2026.06 기준)*
