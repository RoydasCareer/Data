---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/telematics
  - automotive/fleet
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Geotab"
size: "중견기업"
fit: "★"
business: "플릿 텔레매틱스·커넥티드 차량 데이터 플랫폼"
hq: "Oakville, Ontario, Canada"
founded: "2000"
employees: "~2,000명 (2024)"
revenue: "비공개 ($1B+ 기업가치 추정, 비상장)"
ipo_status: "비상장 (Neil Cawse CEO 소유 — 외부 투자 미수령)"
korea_office: "없음"
---

# Geotab

> 플릿 텔레매틱스·커넥티드 차량 데이터 플랫폼 | 중견기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Oakville, Ontario, Canada |
| 설립 연도 | 2000년 |
| 창업자 | Neil Cawse |
| 임직원 수 | ~2,000명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 (창업자 100% 지분 보유) |
| 주력 사업 | OBD-II 하드웨어 + MyGeotab SaaS — GPS 추적, 운전자 행동, EV 충전 관리, 규제 컴플라이언스 |
| 공식 홈페이지 | https://www.geotab.com |

**시장 지위:** 전 세계 4,700만+ 연결 차량 — 북미 플릿 텔레매틱스 선두
**주요 고객:** Ford, GM 상용차 부문, 각국 정부 플릿 (캐나다 정부 포함)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·유럽 플릿 시장 집중. 한국 파트너사(리셀러)를 통한 간접 진출 가능성은 있으나 직영 법인 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 연결 차량 4,700만+으로 Samsara, Verizon Connect 대비 최대 규모.
- EV 플릿 전환 대응으로 EV 충전 관리 솔루션 확장.
- 비상장 독립 기업으로 재무 구조 안정적.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 플릿 SaaS 특화 — 자동차 임베디드 SW와 직접 연관 낮음. |
| 추천 직무 | Backend Platform Engineer, IoT Embedded SW — 캐나다 현지 한정 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 (중견기업) |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [geotab.com](https://www.geotab.com)
- 채용: [geotab.com/careers](https://www.geotab.com/careers)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: geotab.com 공식 (2026.05 기준)*
