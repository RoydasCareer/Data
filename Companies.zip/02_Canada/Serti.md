---
tags:
  - company
  - automotive
  - country/canada
  - size/small
  - automotive/software
  - automotive/retail
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Serti"
size: "중소기업"
fit: "★"
business: "자동차 딜러십 관리 시스템(DMS) SW — 퀘벡 특화"
hq: "Laval, Quebec, Canada"
founded: "1985"
employees: "~250명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Serti

> 딜러십 관리 시스템(DMS) SW | 중소기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Laval, Quebec, Canada |
| 설립 연도 | 1985년 |
| 임직원 수 | ~250명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 퀘벡·프랑스어권 캐나다 자동차 딜러십 전용 DMS — 판매·서비스·파이낸스·부품 통합 관리 |
| 공식 홈페이지 | https://www.serti.com |

**주요 고객:** 퀘벡 자동차·트럭 딜러십 (Toyota, Honda, GM 등 공인 DMS 파트너).

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 프랑스어권 시장 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 퀘벡 DMS 틈새 시장 — 프랑스어 지원 경쟁우위.
- 자동차 임베디드 SW와 직접 연관 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 퀘벡 딜러십 DMS 특화 — 자동차 임베디드 SW와 연관 없음. 프랑스어 필수. |
| 추천 직무 | SW Engineer (DMS) — 캐나다 현지, 프랑스어 필요 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [serti.com](https://www.serti.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: serti.com 공식 (2026.05 기준)*
