---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/robotics
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Deep Trekker"
size: "스타트업"
fit: "★"
business: "자율 수중 ROV·드론 로봇 시스템"
hq: "Kitchener, Ontario, Canada"
founded: "2009"
employees: "~100명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Deep Trekker

> 자율 수중 ROV·드론 로봇 | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Kitchener, Ontario, Canada |
| 설립 연도 | 2009년 |
| 창업자 | Sam Macdonald |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 수중 ROV(원격 조작 로봇), 수중 드론 — 인프라 검사·수색구조·수산업용 |
| 공식 홈페이지 | https://www.deeptrekker.com |

> ⚠️ **자동차 산업과 직접 연관 없음** — 수중 로봇/해양 자율주행 기술 응용. 자율주행 SW 기술 인접 영역.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·글로벌 산업/해양 시장.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 수중 로봇 검사 시장 성장 — 인프라 점검 수요.
- 자동차 SW 직접 연관성 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 수중 로봇 특화 — 자동차 SW 직접 연관 없음. |
| 추천 직무 | Embedded SW Engineer (ROV) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 |
| 고졸 채용 가능성 | 경험 우선 가능 |

---

## 🔗 관련 정보

- 홈페이지: [deeptrekker.com](https://www.deeptrekker.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: deeptrekker.com 공식 (2026.05 기준)*
