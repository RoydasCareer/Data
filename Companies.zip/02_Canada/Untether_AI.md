---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/adas
  - automotive/chips
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Untether AI"
size: "스타트업"
fit: "★"
business: "엣지 AI 추론 가속기 칩 (자율주행·ADAS 용)"
hq: "Toronto, Ontario, Canada"
founded: "2018"
employees: "~100명 (2024)"
revenue: "비공개 ($125M 시리즈 C 조달)"
ipo_status: "비상장"
korea_office: "없음"
---

# Untether AI

> 엣지 AI 추론 가속기 칩 | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Toronto, Ontario, Canada |
| 설립 연도 | 2018년 |
| 창업자 | Martin Snelgrove |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 ($125M 시리즈 C — Intel Capital, Tracker Capital 등) |
| 주력 사업 | at-memory 아키텍처 AI 추론 가속기 칩 — 자율주행·ADAS·로보틱스 엣지 추론용 |
| 공식 홈페이지 | https://www.untether.ai |

**차별점:** at-memory 컴퓨팅 — 메모리 bandwidth 병목 제거로 NVIDIA GPU 대비 전력 효율 10x↑.
**주요 파트너:** Intel (투자), 자동차 Tier-1 파트너 (미공개)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 토론토 중심 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 자동차 엣지 AI 추론 수요 급증 (ADAS 카메라 처리 등).
- 독자적 at-memory 아키텍처로 차별화.
- 칩 설계 회사로 양산까지 오랜 기간 필요, 자금 소진 리스크.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 칩 설계 특화 — 일반 자동차 SW 엔지니어보다 하드웨어 전문가 필요. |
| 추천 직무 | Chip Verification Engineer, ML Framework Engineer — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 (소규모 불확실) |
| 고졸 채용 가능성 | 학위 필수 (반도체 전공) |

---

## 🔗 관련 정보

- 홈페이지: [untether.ai](https://www.untether.ai)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: untether.ai 공식 (2026.05 기준)*
