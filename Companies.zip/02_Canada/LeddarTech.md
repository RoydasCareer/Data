---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/adas
  - automotive/sensing
  - fit/★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "LeddarTech"
size: "스타트업"
fit: "★★"
business: "ADAS·자율주행 인식 SW·센서 퓨전 (LiDAR 소프트웨어)"
hq: "Quebec City, Quebec, Canada"
founded: "2007"
employees: "~100명 (2024)"
revenue: "비공개 (NASDAQ: LDTC, 2023 SPAC 상장)"
ipo_status: "NASDAQ: LDTC (2023년 SPAC 합병 상장)"
korea_office: "없음"
---

# LeddarTech

> ADAS·자율주행 인식 SW | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Quebec City, QC, Canada |
| 설립 연도 | 2007년 |
| 창업자 | Charles Boulanger (CEO) |
| 임직원 수 | ~100명 (2024) |
| 규모 분류 | 스타트업 (상장) |
| 상장 여부 | NASDAQ: LDTC (2023년 SPAC 합병) |
| 주력 사업 | **LeddarVision** — 로우레벨 센서 퓨전·인식 SW (카메라·레이더·LiDAR 통합 환경 모델) |
| 공식 홈페이지 | https://leddartech.com |

**차별점:** 하드웨어 독립적(agnostic) 인식 SW — 어떤 센서 조합에도 적용 가능한 퓨전 스택.
**고객/파트너:** Tier-1 공급사 (미공개), GM, Stellantis 계열 파트너십 논의

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 중심 운영.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 센서 퓨전 소프트웨어 수요 증가 (카메라+레이더 퓨전 ADAS 확산).
- SPAC 상장 후 재무 압박 있음 — 매출 성장 필요.
- 기술력 인정받으나 소규모 스타트업으로 불확실성 존재.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | ADAS 인식·센서 퓨전 핵심 기술 집중. 그러나 한국 사무소 없음, 소규모 스타트업. |
| 추천 직무 | Perception SW Engineer, Sensor Fusion Engineer — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 (소규모라 불확실) |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [leddartech.com](https://leddartech.com)
- 채용: [leddartech.com/careers](https://leddartech.com/careers)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: leddartech.com 공식, NASDAQ (2026.05 기준)*
