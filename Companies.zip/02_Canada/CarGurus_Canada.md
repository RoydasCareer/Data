---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/marketplace
  - automotive/retail
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "CarGurus Canada"
size: "대기업"
fit: "★"
business: "온라인 자동차 마켓플레이스·데이터 분석 (HQ: 미국)"
hq: "Cambridge, Massachusetts, USA (캐나다 운영)"
founded: "2006"
employees: "~1,000명 (글로벌, 캐나다 일부)"
revenue: "$1.1B (FY2023, 글로벌)"
ipo_status: "NASDAQ: CARG"
korea_office: "없음"
---

# CarGurus Canada

> 온라인 자동차 마켓플레이스 | 대기업 | 미국/캐나다 🇺🇸🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Cambridge, MA, USA (캐나다 서비스 제공) |
| 설립 연도 | 2006년 |
| 창업자 | Langley Steinert (TripAdvisor 공동창업자) |
| 임직원 수 | ~1,000명 (글로벌) |
| 규모 분류 | 대기업 |
| 상장 여부 | NASDAQ: CARG |
| 주력 사업 | 소비자 대상 신차·중고차 온라인 마켓플레이스 (가격 투명성·딜러 평가 데이터 제공) |
| 공식 홈페이지 | https://www.cargurus.ca |

**캐나다:** cargurus.ca 운영 — 캐나다 딜러 연동, 가격 비교.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미(미국+캐나다)·영국 집중.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 온라인 중고차 거래 디지털화 선두 (미국 1위).
- 한국 시장 미진출로 직접 연관성 없음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 자동차 마켓플레이스 SaaS 특화 — 임베디드 SW와 연관 없음. |
| 추천 직무 | SW Engineer (플랫폼) — 미국 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — NASDAQ 상장, H-1B 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [cargurus.ca](https://www.cargurus.ca) / [cargurus.com](https://www.cargurus.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: cargurus.com 공식, NASDAQ IR (2026.05 기준)*
