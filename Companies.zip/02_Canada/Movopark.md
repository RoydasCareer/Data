---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/mobility
  - automotive/parking
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Movopark"
size: "스타트업"
fit: "★"
business: "스마트 주차·EV 충전 통합 모빌리티 SW"
hq: "Canada (위치 미확인)"
founded: "—"
employees: "—"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Movopark

> 스마트 주차·EV 충전 모빌리티 SW | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Canada (정확한 위치 미확인) |
| 설립 연도 | 미확인 |
| 임직원 수 | 미확인 |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 스마트 주차 관리 + EV 충전 인프라 예약 통합 플랫폼 |
| 공식 홈페이지 | 미확인 |

> ⚠️ **공개 정보 제한적.** 상세 데이터 미확인.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- EV 충전 인프라 연계 주차 솔루션 수요 증가.
- 소규모 스타트업으로 시장 경쟁 치열.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 주차 SW 특화 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | SW Engineer (모빌리티 플랫폼) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: 공개 정보 부족 (2026.05 기준 미확인)*
