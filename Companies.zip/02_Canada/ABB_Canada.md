---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/ev
  - automotive/testing
  - fit/★★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "ABB Canada"
size: "대기업"
fit: "★★★"
business: "EV 충전 인프라·자동차 제조 로봇·전력 자동화 캐나다 법인"
hq: "Mississauga, Ontario, Canada (글로벌 HQ: Zurich, Switzerland)"
founded: "1884 (글로벌)"
employees: "~2,000명 (캐나다)"
ipo_status: "상장 (NYSE: ABB)"
korea_office: "있음 (ABB Korea)"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# ABB Canada

> EV 충전 인프라·자동차 제조 로봇·전력 자동화 | 대기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Mississauga, Ontario, Canada |
| 설립 연도 | 1884 (글로벌) |
| 임직원 수 | ~2,000명 (캐나다) |
| 상장 여부 | 상장 (NYSE: ABB) |
| 주력 사업 | EV 충전 인프라(Terra 시리즈 DC/AC), 자동차 제조 로봇, 전력 자동화, 산업 IoT |
| 공식 홈페이지 | https://new.abb.com/ca |

## 🎯 주요 제품 & 서비스

Terra 360(초고속 DC 충전기), Terra AC(완속 충전기), 자동차 조립 로봇(용접·도장·조립), 전력 변환 시스템. GM·Ford·Stellantis 캐나다 공장 자동화 파트너.

## 🚗 자동차/모빌리티 관련성

EV 충전 인프라 + EV 기술(2026 과정) → ABB EV 충전 Technical PM 포지션. 자동차 제조 자동화 파트너로 OEM 연결. ABB Korea를 통한 캐나다 이동 경로 가능.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

캐나다 EV 충전 인프라 국가 투자(ZEVIP), 자동차 공장 전동화 전환 수요 폭증.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | EV 기술 지식(2026) + Technical PM + ABB Korea 내부 이동 경로. EV 충전 인프라 프로젝트 관리 포지션. |
| 추천 직무 | EV Infrastructure Project Manager, Technical PM, EV Systems Engineer |
| 지원 방법 | abb.com/careers, LinkedIn, ABB Korea HR 문의 |
| 비자 스폰 가능성 | ★★★★ (글로벌 대기업, LMIA 스폰서 경험 풍부) |

## ⚠️ 리스크 / 고려사항

- 자동차 진단/IVI 도메인과 거리 있음 — EV 인프라 전문성 필요
- Mississauga(토론토 서부) — 생활 인프라 양호

## 🔗 관련 정보

- 홈페이지: [new.abb.com/ca](https://new.abb.com/ca)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: ABB 공식 홈페이지 (2026.07 기준)*
