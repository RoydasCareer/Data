---
tags:
  - company
  - automotive
  - country/canada
  - size/small
  - automotive/testing
  - automotive/qa
  - fit/★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "Acerta Analytics"
size: "중소기업"
fit: "★★"
business: "자동차 제조 QA·이상 감지용 머신러닝 SW"
hq: "Waterloo, Ontario, Canada"
founded: "2015"
employees: "~50명 (2024)"
revenue: "비공개 (시리즈 B 조달)"
ipo_status: "비상장"
korea_office: "없음"
---

# Acerta Analytics

> 자동차 제조 QA용 ML SW | 중소기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Waterloo, ON, Canada |
| 설립 연도 | 2015년 |
| 창업자 | Greta Cutulenco, Andrew Marks |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 차량 제조·필드 데이터 기반 ML 이상 감지·예측 정비 플랫폼 — 제조 QA 불량 조기 검출 |
| 공식 홈페이지 | https://www.acerta.ai |

**주요 고객:** Ford, GM, Volkswagen 계열 Tier-1 공급사 (제조 QA 적용)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다·북미 중심.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 자동차 제조 QA 데이터 활용 ML 솔루션 — 신뢰성 확보 필수.
- Ford, GM 등 대형 OEM 고객 확보로 검증됨.
- 소규모로 재무 불확실성 있음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 QA·제조 이상 감지 ML 기술 — 차량 테스트 경험 활용 가능. 그러나 소규모·한국 사무소 없음. |
| 추천 직무 | ML Engineer (제조 QA), Data Scientist — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 (소규모 불확실) |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [acerta.ai](https://www.acerta.ai)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: acerta.ai 공식 (2026.05 기준)*
