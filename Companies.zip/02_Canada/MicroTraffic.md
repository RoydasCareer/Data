---
tags:
  - company
  - automotive
  - country/canada
  - size/small
  - automotive/analytics
  - automotive/safety
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "MicroTraffic"
size: "중소기업"
fit: "★"
business: "AI 기반 교차로·교통 충돌 위험 분석 SW"
hq: "Burnaby, British Columbia, Canada"
founded: "2014"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# MicroTraffic

> AI 기반 교통 안전 분석 SW | 중소기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Burnaby, BC, Canada |
| 설립 연도 | 2014년 |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 중소기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | 비디오·AI 기반 교차로 교통 충돌 예측(TCT) 분석 — 교통 안전 감사·위험 도로 식별 |
| 공식 홈페이지 | https://microtraffic.ca |

**자동차 관련:** 자율주행 안전 검증용 실세계 교통 데이터·위험 시나리오 생성 기반 기술.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다·미국 교통 부처 중심.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 교통 안전 분석 틈새 시장.
- 자율주행 훈련 데이터 수요로 잠재 성장.
- 소규모 — 대형 교통 컨설팅사 경쟁.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 교통 안전 분석 특화 — 자동차 SW 엔지니어링 직접 연관 낮음. |
| 추천 직무 | CV/ML Engineer (교통 분석) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [microtraffic.ca](https://microtraffic.ca)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: microtraffic.ca 공식 (2026.05 기준)*
