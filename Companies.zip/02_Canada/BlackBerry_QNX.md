---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/os
  - automotive/cybersecurity
  - fit/★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "BlackBerry QNX"
size: "대기업"
fit: "★★"
business: "자동차 RTOS·보안·미들웨어 (QNX OS)"
hq: "Waterloo, Ontario, Canada"
founded: "1980 (QNX); BlackBerry 인수 2010"
employees: "~3,500명 (BlackBerry 전체); QNX 사업부 ~600명"
revenue: "비공개 (BlackBerry NYSE: BB 연매출 ~$800M)"
ipo_status: "BlackBerry NYSE: BB"
korea_office: "블랙베리코리아 유한회사 — 서울 (QNX 별도 조직 아님)"
---

# BlackBerry QNX

> 자동차 RTOS·보안·미들웨어 | 대기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Waterloo, Ontario, Canada |
| 설립 연도 | 1980년 (QNX 창립); 2010년 BlackBerry 인수 |
| 임직원 수 | ~3,500명 (BlackBerry 전체); QNX 사업부 ~600명 |
| 규모 분류 | 대기업 |
| 상장 여부 | BlackBerry NYSE: BB |
| 주력 사업 | QNX RTOS (자동차 인포테인먼트·ADAS·자율주행 ECU용 실시간 OS) + 차량 사이버보안(IDP) |
| 공식 홈페이지 | https://blackberry.com/en/us/products/automotive |

**시장 지위:** 전 세계 자동차 ECU의 약 **23%**가 QNX 탑재 (GM, BMW, Ford, 현대기아차 등)
**주요 제품:** QNX OS, QNX Hypervisor, BlackBerry IVY (클라우드 데이터 플랫폼), Cylance 보안

---

## 🇰🇷 한국 관련

**블랙베리코리아 유한회사** — 서울 소재 (정확한 주소 미확인). 한국 법인은 주로 엔터프라이즈 보안(Cylance) 사업 담당. QNX 자동차 사업부 전담 조직은 별도로 없으나, 현대기아차·삼성전자 등 주요 고객사와의 기술 협력 채널 역할.

> ⚠️ QNX 전담 한국 채용은 캐나다 본사 또는 원격으로 이루어짐.

---

## 📈 성장성 평가

**성장성 평가: ★★★★**

- QNX는 자동차 RTOS 시장 압도적 1위 — 현대기아, BMW, GM 등 전 세계 OEM 채택.
- ISO 26262 ASIL-D 인증 RTOS — 안전 critical 시스템 표준.
- BlackBerry IVY로 커넥티드카 클라우드 플랫폼 확장 중.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 RTOS·임베디드 핵심 기술. 현대기아 등 한국 OEM 협력. 그러나 채용은 캐나다 현지 중심. |
| 추천 직무 | QNX Embedded SW Engineer, 차량 사이버보안 엔지니어 |
| 한국 지원 경로 | 블랙베리코리아 통해 간접 가능 (QNX 직접 채용은 캐나다) |
| 비자 스폰 가능성 | ★★★ — 대기업, LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 (임베디드 OS 전문성 필요) |

---

## 🔗 관련 정보

- 홈페이지: [blackberry.com/automotive](https://blackberry.com/en/us/products/automotive)
- 채용: [careers.blackberry.com](https://careers.blackberry.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: blackberry.com 공식, NYSE IR (2026.05 기준)*
