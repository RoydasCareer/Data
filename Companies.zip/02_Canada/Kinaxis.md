---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/software
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Kinaxis"
size: "중견기업"
fit: "★"
business: "자동차 공급망 계획·조율 SW (RapidResponse)"
hq: "Ottawa, Ontario, Canada"
founded: "1984"
employees: "~2,000명 (2024)"
revenue: "$474M (FY2023)"
ipo_status: "TSX: KXS"
korea_office: "없음"
---

# Kinaxis

> 자동차 공급망 계획·조율 SW | 중견기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Ottawa, Ontario, Canada |
| 설립 연도 | 1984년 |
| 임직원 수 | ~2,000명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | TSX: KXS |
| 주력 사업 | **RapidResponse** — 공급망 계획·수요 예측·재고 최적화 SaaS (자동차, 항공, 전자 업종) |
| 공식 홈페이지 | https://www.kinaxis.com |

**주요 고객:** Toyota, Ford, Volvo, Nissan, Raytheon (자동차 공급망 계획 소프트웨어)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·유럽·일본 중심.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 공급망 대란(2021~2023) 이후 공급망 계획 솔루션 수요 급증.
- AI 기반 공급망 예측으로 차별화.
- 자동차 공급망 복잡도 증가로 지속 수요.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 공급망 SaaS 특화 — 자동차 임베디드 SW 개발과 직접 연관 없음. |
| 추천 직무 | Supply Chain SW Engineer, Solution Consultant — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — TSX 상장, LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [kinaxis.com](https://www.kinaxis.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: kinaxis.com 공식, TSX IR (2026.05 기준)*
