---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/adas
  - automotive/data
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Pelmorex Media (The Weather Network)"
size: "중견기업"
fit: "★"
business: "날씨 데이터 미디어·ADAS 기상 API"
hq: "Oakville, Ontario, Canada"
founded: "1981"
employees: "~1,000명 (2024)"
revenue: "비공개"
ipo_status: "비상장 (사모)"
korea_office: "없음"
---

# Pelmorex Media (The Weather Network)

> 날씨 데이터·ADAS 기상 API | 중견기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Oakville, Ontario, Canada |
| 설립 연도 | 1981년 |
| 임직원 수 | ~1,000명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | The Weather Network/MétéoMédia 채널 운영 + LightningCast AI 기상 예보 API — 자동차 ADAS·자율주행 날씨 데이터 공급 |
| 공식 홈페이지 | https://www.pelmorex.com |

**자동차 관련:** LightningCast 실시간 뇌우 예측 API, 도로 위험 날씨 데이터 — 자율주행·ADAS 시스템 기상 인식 지원.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다·미국 기상 서비스 중심.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 날씨 데이터 API의 자율주행 적용 확장 중.
- 핵심 사업은 TV 방송 미디어 — 자동차 임베디드 SW와 직접 연관 낮음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 기상 데이터 API 특화 — 자동차 임베디드 SW 엔지니어링과 직접 연관 낮음. |
| 추천 직무 | Data Engineer (기상 API) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [pelmorex.com](https://www.pelmorex.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: pelmorex.com 공식 (2026.05 기준)*
