---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/ev
  - automotive/adas
  - automotive/embedded
  - fit/★★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "General Motors Canada"
size: "대기업"
fit: "★★★"
business: "GM 캐나다 기술 센터 — Ultium EV·ADAS·SDV·자율주행(Cruise) SW 개발"
hq: "Markham, Ontario, Canada (Oshawa 제조)"
founded: "1918"
employees: "~3,000명 (캐나다 기술직)"
ipo_status: "상장 (NYSE: GM)"
korea_office: "없음"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# General Motors Canada

> GM 캐나다 기술 센터 — Ultium EV·ADAS·SDV | 대기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Markham, Ontario (기술 센터) / Oshawa (제조) |
| 설립 연도 | 1918 |
| 임직원 수 | ~3,000명 (캐나다 기술직) |
| 상장 여부 | 상장 (NYSE: GM) |
| 주력 사업 | Ultium EV 플랫폼 SW, ADAS 개발, 자율주행(Cruise), 커넥티드 차량(OnStar) |
| 공식 홈페이지 | https://www.gm.ca |

## 🎯 주요 제품 & 서비스

Ultium EV 플랫폼(배터리·파워트레인·BMS), Super Cruise ADAS, Cruise 자율주행, OnStar 커넥티드 서비스. Markham Tech Centre에서 글로벌 GM 프로젝트 SW 개발.

## 🚗 자동차/모빌리티 관련성

OEM EV 플랫폼 검증 + ADAS SW + SDV → 전수환의 Hyundai EV/HEV IVI 검증 경험 직결. Technical PM으로 글로벌 OEM 다부서 조율. 캐나다 Express Entry 우선 심사 직종.

## 📈 성장성 & 전망

**성장성 평가: ★★★★**

GM 2035 전기화 목표, Ultium 플랫폼 확대, Cruise 재개. 캐나다 EV 배터리 공장 투자(Ingersoll, Oshawa).

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★★ |
| 핵심 추천 이유 | Hyundai EV 검증(현재) + Technical PM + ASPICE → GM OEM Validation Lead, Technical PM 포지션. 캐나다 Express Entry 우선 직종. |
| 추천 직무 | Validation Lead, Technical PM (EV/ADAS), SW Test Engineer |
| 지원 방법 | gm.com/company/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★★ (글로벌 OEM, LMIA 스폰서 또는 Express Entry) |

## ⚠️ 리스크 / 고려사항

- OEM 대기업 특성상 채용 절차 길고 복잡
- Markham(토론토 북부) — 차량 통근 권장

## 🔗 관련 정보

- 홈페이지: [gm.ca](https://www.gm.ca)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: General Motors Canada 공식 홈페이지 (2026.07 기준)*
