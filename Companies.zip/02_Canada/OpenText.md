---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/software
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "OpenText"
size: "대기업"
fit: "★"
business: "자동차 공급망·PLM·콘텐츠 관리 SW (Micro Focus 인수)"
hq: "Waterloo, Ontario, Canada"
founded: "1991"
employees: "~25,000명 (2024)"
revenue: "$5.8B (FY2024)"
ipo_status: "NASDAQ: OTEX / TSX: OTEX"
korea_office: "오픈텍스트코리아(유) — 서울 강남구 테헤란로 152, 강남파이낸스센터"
---

# OpenText

> 자동차 공급망·PLM·콘텐츠 관리 SW | 대기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Waterloo, Ontario, Canada |
| 설립 연도 | 1991년 |
| 임직원 수 | ~25,000명 (2024) |
| 규모 분류 | 대기업 |
| 상장 여부 | NASDAQ: OTEX / TSX: OTEX |
| 주력 사업 | 엔터프라이즈 정보 관리(EIM) — 문서 관리, EDI/B2B 통합, 공급망 관리, PLM (자동차 포함) |
| 공식 홈페이지 | https://www.opentext.com |

**자동차 관련 솔루션:** 자동차 공급망 EDI, OEM-Tier1 B2B 연결, 디지털 콘텐츠 관리.
**최근 인수:** 2023년 Micro Focus ($6B) — SW 테스팅·DevOps 솔루션 추가.

---

## 🇰🇷 한국 관련

**오픈텍스트코리아(유)** — 서울 강남구 테헤란로 152, 강남파이낸스센터 (주소 미확인, ⚠️ 검증 필요)

> ⚠️ 한국 법인은 엔터프라이즈 솔루션(문서 관리, EDI) 중심 — 자동차 전담 팀 여부 불명확.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 엔터프라이즈 소프트웨어 대기업으로 안정적 수익.
- 자동차 공급망 디지털화 수혜.
- Micro Focus 인수로 부채 증가 — 재무 압박.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 자동차 임베디드 SW와 직접 연관 낮음 (공급망·문서 관리 중심). 한국 법인은 비자동차 사업 위주. |
| 추천 직무 | 공급망 솔루션 컨설턴트, SE — 한국 또는 캐나다 |
| 한국 지원 경로 | 오픈텍스트코리아 (⚠️ 자동차 직무 미확인) |
| 비자 스폰 가능성 | ★★★ — 대기업, 글로벌 이전 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [opentext.com](https://www.opentext.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: opentext.com 공식, NASDAQ IR (2026.05 기준)*
