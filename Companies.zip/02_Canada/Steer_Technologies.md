---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/ev
  - automotive/mobility
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Steer Technologies"
size: "스타트업"
fit: "★"
business: "EV 차량 구독·카셰어링 플랫폼 SW"
hq: "Toronto, Ontario, Canada"
founded: "2018"
employees: "~30명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Steer Technologies

> EV 차량 구독·카셰어링 플랫폼 SW | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Toronto, Ontario, Canada |
| 설립 연도 | 2018년 |
| 임직원 수 | ~30명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | EV 차량 구독 서비스 플랫폼 — 딜러십 대상 구독 관리·카셰어링 SW 솔루션 제공 |
| 공식 홈페이지 | https://www.steertechnologies.com |

**자동차 관련:** 딜러십 EV 구독 플랫폼, 차량 공유 SW — 자동차 임베디드 SW와 직접 연관 낮음.

---

## 🇰🇷 한국 관련

한국 사무소 없음.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- EV 구독 서비스 초기 시장.
- 소규모 스타트업 — 자금·고객 기반 제한적.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 스타트업 — 자동차 임베디드 SW와 연관 낮음. |
| 추천 직무 | Full-Stack Engineer (구독 플랫폼) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [steertechnologies.com](https://www.steertechnologies.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: steertechnologies.com 공식 (2026.05 기준)*
