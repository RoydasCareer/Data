---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/mobility
  - automotive/maas
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Facedrive"
size: "스타트업"
fit: "★"
business: "친환경 라이드헤일·EV 모빌리티 플랫폼 (⚠️ 재무 위기)"
hq: "Toronto, Ontario, Canada"
founded: "2018"
employees: "~100명 (최전성기)"
revenue: "비공개 (소규모, 재무 위기)"
ipo_status: "TSX-V: FD (⚠️ 상장 유지 위기 — 회계 논란)"
korea_office: "없음"
---

# Facedrive

> 친환경 라이드헤일·모빌리티 플랫폼 | 스타트업 | 캐나다 🇨🇴

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Toronto, Ontario, Canada |
| 설립 연도 | 2018년 |
| 창업자 | Sayan Navaratnam, Junaid Razvi |
| 임직원 수 | ~100명 (최전성기) |
| 규모 분류 | 스타트업 |
| 상장 여부 | TSX-V: FD (⚠️ 회계 논란, 상장 유지 위기) |
| 주력 사업 | 친환경 EV 라이드헤일 앱 + Steer EV 구독 + TraceSafe 접촉 추적 (사업 다각화) |
| 공식 홈페이지 | https://facedrive.com |

> ⚠️ **중요:** 2022~2023년 회계 부정 의혹, 경영진 교체, 재무 위기 — **지원 부적합**.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 로컬 집중.

---

## 📈 성장성 평가

**성장성 평가: ★**

- 재무 위기 및 회계 논란으로 사업 불확실성 매우 높음.
- 지원 비추천.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 회계 논란·재무 위기 — 지원 부적합. 한국 사무소 없음. |
| 추천 직무 | 지원 비추천 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 재무 위기로 불가 |
| 고졸 채용 가능성 | 해당 없음 |

---

## 🔗 관련 정보

- 홈페이지: [facedrive.com](https://facedrive.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: 뉴스 보도 (2026.05 기준)*
