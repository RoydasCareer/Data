---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/fleet
  - automotive/logistics
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Descartes Systems Group"
size: "중견기업"
fit: "★"
business: "물류·운송·플릿 SaaS (EDI·라우팅·규제 컴플라이언스)"
hq: "Waterloo, Ontario, Canada"
founded: "1981"
employees: "~3,000명 (2024)"
revenue: "$582M (FY2024)"
ipo_status: "NASDAQ: DSGX / TSX: DSG"
korea_office: "없음"
---

# Descartes Systems Group

> 물류·운송·플릿 SaaS | 중견기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Waterloo, Ontario, Canada |
| 설립 연도 | 1981년 |
| 임직원 수 | ~3,000명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | NASDAQ: DSGX / TSX: DSG |
| 주력 사업 | 물류·글로벌 무역·플릿 라우팅·ELD 컴플라이언스 SaaS — 운송 네트워크 최적화 |
| 공식 홈페이지 | https://www.descartes.com |

**주요 제품:** Routing, Mobile & Telematics, Global Trade Intelligence, MacroPoint (화물 추적)

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·유럽·아태 물류 시장 집중 (한국 미진출).

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 물류·글로벌 무역 디지털화 지속 수혜.
- 분기마다 소규모 M&A로 안정적 성장.
- 자동차 임베디드 SW보다 물류 SaaS 전문.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 물류 SaaS 특화 — 자동차 임베디드 SW와 직접 연관 없음. |
| 추천 직무 | SW Engineer (물류·라우팅) — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★ — NASDAQ 상장, LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [descartes.com](https://www.descartes.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: descartes.com 공식, NASDAQ IR (2026.05 기준)*
