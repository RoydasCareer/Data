---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/mobility
  - automotive/ridehail
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Uride"
size: "스타트업"
fit: "★"
business: "소규모 도시 대상 라이드헤일링 앱"
hq: "Thunder Bay, Ontario, Canada"
founded: "2017"
employees: "~50명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Uride

> 소규모 도시 라이드헤일링 앱 | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Thunder Bay, Ontario, Canada |
| 설립 연도 | 2017년 |
| 임직원 수 | ~50명 (2024) |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | Uber/Lyft 미진출 캐나다 소규모 도시 대상 라이드헤일링 — 운전자 매칭·요금 최적화 플랫폼 |
| 공식 홈페이지 | https://www.uride.ca |

**자동차 관련:** 차량 매칭 플랫폼 — 자동차 임베디드 SW와 직접 연관 없음.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 소규모 도시 전용 서비스.

---

## 📈 성장성 평가

**성장성 평가: ★★**

- 캐나다 소도시 라이드헤일 틈새 시장.
- 소규모 스타트업 — 확장성 제한.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 소규모 라이드헤일 스타트업 — 자동차 임베디드 SW와 연관 없음. |
| 추천 직무 | Mobile/Backend Developer — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 미확인 |

---

## 🔗 관련 정보

- 홈페이지: [uride.ca](https://www.uride.ca)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: uride.ca 공식 (2026.05 기준)*
