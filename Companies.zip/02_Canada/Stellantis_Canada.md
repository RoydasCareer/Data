---
tags:
  - company
  - automotive
  - country/canada
  - size/large
  - automotive/ev
  - automotive/embedded
  - fit/★★
  - recommend
country: "캐나다"
country_folder: "02_Canada"
company_name: "Stellantis Canada"
size: "대기업"
fit: "★★"
business: "Jeep·Ram·Dodge·Chrysler EV 전환·SDV 개발 캐나다 법인 (Windsor·Brampton)"
hq: "Windsor / Brampton, Ontario, Canada"
founded: "1925 (캐나다 법인)"
employees: "~8,000명 (캐나다 제조 포함)"
ipo_status: "상장 (NYSE: STLA)"
korea_office: "없음"
last_updated: "2026-07-31"
fact_checked: "2026-07-31"
---

# Stellantis Canada

> Jeep·Ram·Dodge EV 전환·SDV 캐나다 | 대기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Windsor / Brampton, Ontario, Canada |
| 설립 연도 | 1925 (캐나다 법인) |
| 임직원 수 | ~8,000명 (캐나다) |
| 상장 여부 | 상장 (NYSE: STLA) |
| 주력 사업 | Jeep·Ram·Dodge·Chrysler 생산, EV 전환(STLA 플랫폼), SDV 개발 |
| 공식 홈페이지 | https://www.stellantis.com/en/careers |

## 🎯 주요 제품 & 서비스

Windsor 조립 공장(Chrysler Pacifica PHEV), Brampton 조립(Dodge Charger·Challenger), STLA Large/Frame EV 플랫폼 전환. SDV·커넥티드 차량 소프트웨어 개발(STLA Brain).

## 🚗 자동차/모빌리티 관련성

OEM EV 플랫폼 전환 + SDV → 전수환의 EV 검증 경험(현재) + Technical PM. 자동차 진단 통신(UDS) → OEM 내부 진단 시스템 활용.

## 📈 성장성 & 전망

**성장성 평가: ★★★**

캐나다 배터리 공장(Windsor EV Hub) 투자, EV 전환 가속. STLA Brain SDV 플랫폼 글로벌 롤아웃.

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | EV 검증 경험(Hyundai 현재) + Technical PM → Stellantis EV Validation Engineer. 캐나다 LMIA/Express Entry. |
| 추천 직무 | EV Validation Engineer, Software Test Engineer, Technical PM |
| 지원 방법 | stellantis.com/en/careers, LinkedIn |
| 비자 스폰 가능성 | ★★★ (글로벌 OEM, LMIA 스폰서 가능) |

## ⚠️ 리스크 / 고려사항

- Windsor는 디트로이트(미국) 국경 인근 제조 도시 — 생활 인프라 토론토 대비 제한
- OEM 대기업 채용 절차 길고 복잡

## 🔗 관련 정보

- 홈페이지: [stellantis.com/en/careers](https://www.stellantis.com/en/careers)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---
*데이터 출처: Stellantis 공식 홈페이지 (2026.07 기준)*
