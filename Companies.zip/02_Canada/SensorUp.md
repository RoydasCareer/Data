---
tags:
  - company
  - automotive
  - country/canada
  - size/startup
  - automotive/iot
  - fit/★
country: "캐나다"
country_folder: "02_Canada"
company_name: "SensorUp"
size: "스타트업"
fit: "★"
business: "IoT·센서 데이터 관리 플랫폼 (OGC SensorThings API)"
hq: "Calgary, Alberta, Canada"
founded: "2013"
employees: "~20명 미만"
revenue: "비공개 (소규모)"
ipo_status: "비상장"
korea_office: "없음"
---

# SensorUp

> IoT·센서 데이터 관리 플랫폼 | 스타트업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Calgary, Alberta, Canada |
| 설립 연도 | 2013년 |
| 창업자 | Steve Liang |
| 임직원 수 | ~20명 미만 |
| 규모 분류 | 스타트업 |
| 상장 여부 | 비상장 |
| 주력 사업 | OGC SensorThings API 기반 IoT 센서 데이터 연결·관리 플랫폼 — 스마트 시티, 드론, 차량 센서 |
| 공식 홈페이지 | https://sensorup.com |

**자동차 관련:** 커넥티드 차량·교통 센서 데이터 연동 (간접적).

---

## 🇰🇷 한국 관련

한국 사무소 없음. 캐나다 로컬 중심.

---

## 📈 성장성 평가

**성장성 평가: ★**

- 매우 소규모 스타트업.
- OGC 표준 기반 학문적 성격 강함.
- 자동차 산업 직접 연관성 낮음.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★ |
| 핵심 추천 이유 | 한국 사무소 없음. 매우 소규모. 자동차 SW와 직접 연관 없음. |
| 추천 직무 | IoT SW Engineer — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★ — 소규모로 불확실 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [sensorup.com](https://sensorup.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: sensorup.com 공식 (2026.05 기준)*
