---
tags:
  - company
  - automotive
  - country/canada
  - size/mid
  - automotive/software
  - automotive/connectivity
  - fit/★★
country: "캐나다"
country_folder: "02_Canada"
company_name: "Solace"
size: "중견기업"
fit: "★★"
business: "이벤트 드리븐 메시징 미들웨어 (커넥티드카·자동차 OEM 적용)"
hq: "Ottawa, Ontario, Canada"
founded: "2001"
employees: "~500명 (2024)"
revenue: "비공개"
ipo_status: "비상장"
korea_office: "없음"
---

# Solace

> 이벤트 드리븐 메시징 미들웨어 | 중견기업 | 캐나다 🇨🇦

## 🏢 회사 개요

| 항목 | 내용 |
| :--- | :--- |
| 본사 위치 | Ottawa, Ontario, Canada |
| 설립 연도 | 2001년 |
| 임직원 수 | ~500명 (2024) |
| 규모 분류 | 중견기업 |
| 상장 여부 | 비상장 |
| 주력 사업 | PubSub+ 이벤트 브로커 — MQTT/AMQP/JMS 기반 실시간 메시징 미들웨어 (자동차 OEM·금융·물류 적용) |
| 공식 홈페이지 | https://solace.com |

**자동차 관련:** BMW, Volkswagen, Bosch 등 자동차 OEM의 커넥티드카 데이터 스트리밍·차량-클라우드 통신(V2C) 미들웨어 파트너.

---

## 🇰🇷 한국 관련

한국 사무소 없음. 북미·유럽 자동차 OEM 중심.

---

## 📈 성장성 평가

**성장성 평가: ★★★**

- 커넥티드카 실시간 데이터 수요 급증.
- SDV 전환에 따른 차량-클라우드 메시징 미들웨어 수요 확대.
- 자동차 OEM 레퍼런스 보유.

---

## ⭐ 지원 추천 정보 #Recommand

| 항목 | 내용 |
| :--- | :--- |
| 지원 적합도 | ★★ |
| 핵심 추천 이유 | 자동차 OEM 대상 커넥티드카 미들웨어 — ADAS/SDV 연관 메시징 기술. 한국 사무소 없음. |
| 추천 직무 | Platform Engineer (메시징 미들웨어) / Solutions Architect — 캐나다 현지 |
| 한국 지원 경로 | 없음 |
| 비자 스폰 가능성 | ★★★ — 중견기업, LMIA 가능 |
| 고졸 채용 가능성 | 학위 선호 |

---

## 🔗 관련 정보

- 홈페이지: [solace.com](https://solace.com)
- 국가 인덱스: [[_INDEX|캐나다 기업 목록]]
- 마스터 인덱스: [[../_MOC|전체 기업 MOC]]

---

*데이터 출처: solace.com 공식 (2026.05 기준)*
