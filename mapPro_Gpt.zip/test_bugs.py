"""마커 위치 고정 & 날짜변경선 버그 검증"""
from playwright.sync_api import sync_playwright

URL = "http://localhost:8765"

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()
        page.goto(URL)
        page.wait_for_selector("#loading-overlay", state="detached", timeout=15000)
        page.wait_for_timeout(3000)

        print("=== 버그 검증 ===\n")

        # ── 버그1: 마커 위치가 지도 이동에 고정되어 있는가 ──────────────
        print("[Bug-1] 마커 CSS transition 제거 확인")
        has_bad_transition = page.evaluate("""() => {
            const el = document.querySelector('.place-marker-wrap');
            if (!el) return 'marker-not-found';
            const style = window.getComputedStyle(el);
            return style.transition;
        }""")
        print(f"  .place-marker-wrap transition 값: '{has_bad_transition}'")
        if 'transform' in str(has_bad_transition).lower():
            print("  ❌ transform transition 아직 있음 — 마커 따라다님 버그 미수정")
        else:
            print("  ✅ transform transition 없음 — 마커 위치 고정")

        # 지도 패닝 전 마커 위치 기록
        pos_before = page.evaluate("""() => {
            const m = document.querySelector('.place-marker-wrap');
            if (!m) return null;
            const r = m.getBoundingClientRect();
            return { x: Math.round(r.left), y: Math.round(r.top) };
        }""")
        print(f"  패닝 전 첫 마커 화면 좌표: {pos_before}")

        # 지도 드래그 (패닝)
        page.mouse.move(700, 450)
        page.mouse.down()
        page.mouse.move(400, 450, steps=10)
        page.mouse.up()
        page.wait_for_timeout(800)  # 애니메이션 완료 대기

        pos_after = page.evaluate("""() => {
            const m = document.querySelector('.place-marker-wrap');
            if (!m) return null;
            const r = m.getBoundingClientRect();
            return { x: Math.round(r.left), y: Math.round(r.top) };
        }""")
        print(f"  패닝 후 첫 마커 화면 좌표: {pos_after}")

        if pos_before and pos_after:
            dx = pos_after['x'] - pos_before['x']
            print(f"  마커 X 이동량: {dx}px (지도 드래그 -300px)")
            if abs(dx) > 50:
                print(f"  ✅ 마커가 지도와 함께 이동함 (지도에 고정됨)")
            else:
                print(f"  ❌ 마커가 거의 이동하지 않음 (화면에 고정됨)")

        page.screenshot(path="/tmp/bug1_after_pan.png")

        # ── 버그2: 최소 줌에서 날짜변경선 직선 확인 ──────────────────────
        print("\n[Bug-2] 날짜변경선 직선 제거 확인")

        # 최소 줌으로 이동 (지구 전체 뷰)
        page.evaluate("""() => {
            if (window.MapManager && MapManager._map) {
                MapManager._map.flyTo({ center: [20, 20], zoom: 0.5, duration: 0 });
            }
        }""")

        # MapManager 내부 map 접근이 불가능하므로 키보드 줌아웃 사용
        page.click('#map-container')
        # 여러 번 줌아웃
        for _ in range(8):
            page.keyboard.press('Minus')
            page.wait_for_timeout(50)
        page.wait_for_timeout(1500)
        page.screenshot(path="/tmp/bug2_max_zoomout.png")
        print("  → /tmp/bug2_max_zoomout.png 스크린샷으로 확인 필요")

        # GeoJSON 좌표 확인: 180도 경계 갑작스런 반전 없는지
        coords_ok = page.evaluate("""() => {
            // MapLibre source에서 routes GeoJSON 데이터 체크
            try {
                const map = document.querySelector('#map-container').__maplibre_map ||
                            window.__ml_map;
                if (!map) return 'map-not-accessible';
                const src = map.getSource('routes-src');
                if (!src) return 'source-not-found';
                const data = src._data;
                if (!data || !data.features) return 'no-data';

                let maxJump = 0;
                for (const feat of data.features) {
                    const coords = feat.geometry.coordinates;
                    for (let i = 1; i < coords.length; i++) {
                        const jump = Math.abs(coords[i][0] - coords[i-1][0]);
                        if (jump > maxJump) maxJump = jump;
                    }
                }
                return maxJump;
            } catch(e) { return 'error: ' + e.message; }
        }""")
        print(f"  경도 최대 점프값: {coords_ok}° (180 이상이면 날짜변경선 버그)")
        if isinstance(coords_ok, (int, float)) and coords_ok > 180:
            print(f"  ❌ 날짜변경선 점프 {coords_ok}° — 수평선 버그 남아있음")
        elif isinstance(coords_ok, (int, float)):
            print(f"  ✅ 최대 점프 {coords_ok}° — 날짜변경선 처리 정상")
        else:
            print(f"  ℹ️  MapLibre 내부 접근 불가, 스크린샷으로 육안 확인")

        browser.close()
        print("\n스크린샷:")
        print("  /tmp/bug1_after_pan.png — 마커 패닝 후 위치")
        print("  /tmp/bug2_max_zoomout.png — 최소줌 지구 전체 뷰")

if __name__ == "__main__":
    run()
