"""초기 로딩 후 깨끗한 상태 스크린샷"""
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    # 새 컨텍스트 (데이터 없음 — 샘플 데이터 로드)
    ctx = browser.new_context(viewport={"width": 1440, "height": 900})
    page = ctx.new_page()
    page.goto("http://localhost:8765")
    page.wait_for_selector("#loading-overlay", state="detached", timeout=15000)
    page.wait_for_timeout(3000)  # 타일+마커 로딩 대기

    # 지구본 전체 뷰
    page.screenshot(path="/tmp/fresh_globe.png")

    # 통계 탭
    page.click('.tab-btn[data-tab="stats"]')
    page.wait_for_timeout(600)
    page.screenshot(path="/tmp/fresh_stats.png")

    # 경로 탭
    page.click('.tab-btn[data-tab="routes"]')
    page.wait_for_timeout(400)
    page.screenshot(path="/tmp/fresh_routes.png")

    browser.close()
    print("완료")
