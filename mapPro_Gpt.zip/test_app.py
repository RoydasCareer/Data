"""GlobeTravel Log 자동화 검증 스크립트"""
import time
from playwright.sync_api import sync_playwright, expect

URL = "http://localhost:8765"

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(viewport={"width": 1400, "height": 900})
        page = ctx.new_page()

        errors = []
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        page.on("pageerror", lambda e: errors.append(f"PAGE ERROR: {e}"))

        print("=== GlobeTravel Log 기능 검증 ===\n")

        # ── 1. 초기 로딩 ──────────────────────────────────────
        print("[1] 초기 로딩...")
        page.goto(URL)
        # 로딩 오버레이가 사라질 때까지 최대 15초 대기
        page.wait_for_selector("#loading-overlay", state="detached", timeout=15000)
        page.screenshot(path="/tmp/01_loaded.png")
        print("    ✅ 로딩 완료")

        # ── 2. 사이드바 + 샘플 데이터 ─────────────────────────
        print("[2] 사이드바 & 샘플 데이터...")
        sidebar = page.locator("#sidebar")
        assert not sidebar.evaluate("el => el.classList.contains('hidden')"), "사이드바가 닫혀있음"

        # 장소 목록 확인 (샘플 7개)
        page.wait_for_selector(".place-item", timeout=8000)
        place_count = page.locator(".place-item").count()
        print(f"    장소 아이템: {place_count}개")
        assert place_count >= 6, f"샘플 장소가 부족: {place_count}"
        page.screenshot(path="/tmp/02_sidebar.png")
        print("    ✅ 사이드바 & 샘플 데이터 확인")

        # ── 3. 탭 전환 ────────────────────────────────────────
        print("[3] 탭 전환...")
        page.click('.tab-btn[data-tab="routes"]')
        page.wait_for_selector(".route-item", timeout=5000)
        route_count = page.locator(".route-item").count()
        print(f"    경로 아이템: {route_count}개")
        assert route_count >= 6, f"샘플 경로가 부족: {route_count}"

        page.click('.tab-btn[data-tab="stats"]')
        page.wait_for_timeout(500)
        stat_places = page.locator("#stat-places").text_content()
        stat_dist   = page.locator("#stat-dist").text_content()
        print(f"    통계 — 장소: {stat_places}, 이동거리: {stat_dist}")
        assert int(stat_places) >= 6, "통계 장소 수 오류"
        dist_num = float(stat_dist.replace(',','').replace(' km','').replace('km','').strip())
        assert dist_num > 0, f"이동거리가 0: '{stat_dist}'"
        page.screenshot(path="/tmp/03_stats.png")
        print("    ✅ 탭 전환 & 통계 확인")

        # ── 4. 장소 추가 모달 ─────────────────────────────────
        print("[4] 장소 추가 모달...")
        page.click(".tab-btn[data-tab='places']")
        page.click("#btn-add-place")
        page.wait_for_selector("#modal-place:not(.hidden)", timeout=3000)
        page.screenshot(path="/tmp/04_place_modal.png")

        page.fill("#place-name", "테스트 장소")
        page.fill("#place-lat", "35.6762")
        page.fill("#place-lng", "139.6503")
        page.fill("#place-date", "2025-01-01")
        page.click("#btn-save-place")
        # 모달이 hidden 상태(display:none)가 될 때까지 대기
        page.wait_for_selector("#modal-place", state="hidden", timeout=5000)

        # 새 장소 등장 확인 (localforage 비동기 처리 대기)
        page.wait_for_timeout(1200)
        new_count = page.locator(".place-item").count()
        assert new_count == place_count + 1, f"장소 추가 실패: {new_count} (예상 {place_count+1})"
        page.screenshot(path="/tmp/05_place_added.png")
        print(f"    ✅ 장소 추가 완료 (총 {new_count}개)")

        # ── 5. 토스트 알림 ────────────────────────────────────
        print("[5] 토스트 알림...")
        toast_visible = page.locator(".toast").count() > 0
        print(f"    토스트 표시: {toast_visible}")
        # (토스트는 빠르게 사라질 수 있으므로 결과 무관)

        # ── 6. 경로 추가 모달 ─────────────────────────────────
        print("[6] 경로 추가 모달...")
        page.click(".tab-btn[data-tab='routes']")
        page.click("#btn-add-route")
        page.wait_for_selector("#modal-route:not(.hidden)", timeout=3000)

        # 교통수단 = 비행기 → 항공사 필드 표시 확인
        transport = page.locator("#route-transport")
        transport.select_option("plane")
        page.wait_for_timeout(200)
        flight_details = page.locator("#flight-details")
        assert not flight_details.evaluate("el => el.classList.contains('hidden')"), "비행기 선택 시 항공사 필드 미표시"

        # 기차 선택 → 항공사 필드 숨김
        transport.select_option("train")
        page.wait_for_timeout(200)
        assert flight_details.evaluate("el => el.classList.contains('hidden')"), "기차 선택 시 항공사 필드 미숨김"

        # 모달 닫기
        page.keyboard.press("Escape")
        page.wait_for_selector("#modal-route", state="hidden", timeout=3000)
        page.screenshot(path="/tmp/06_route_modal.png")
        print("    ✅ 경로 모달 & 항공사 필드 토글 확인")

        # ── 7. 지도 스타일 전환 ───────────────────────────────
        print("[7] 지도 스타일 전환...")
        page.click('.tab-btn[data-tab="stats"]')
        page.wait_for_timeout(300)

        page.click('.style-btn[data-style="voyager"]')
        page.wait_for_timeout(2000)  # 스타일 로딩 대기
        active_style = page.locator(".style-btn.active").text_content()
        print(f"    활성 스타일: {active_style}")
        page.screenshot(path="/tmp/07_voyager.png")

        page.click('.style-btn[data-style="dark"]')
        page.wait_for_timeout(2000)
        page.screenshot(path="/tmp/08_dark.png")
        print("    ✅ 스타일 전환 완료")

        # ── 8. 사이드바 토글 (키보드 T) ──────────────────────
        print("[8] 사이드바 토글...")
        page.focus("body")
        page.keyboard.press("t")
        page.wait_for_timeout(300)
        hidden = sidebar.evaluate("el => el.classList.contains('hidden')")
        assert hidden, "T 키로 사이드바가 닫히지 않음"
        page.keyboard.press("t")
        page.wait_for_timeout(300)
        hidden = sidebar.evaluate("el => el.classList.contains('hidden')")
        assert not hidden, "T 키로 사이드바가 다시 열리지 않음"
        print("    ✅ 사이드바 키보드 토글 확인")

        # ── 9. 내보내기 버튼 ──────────────────────────────────
        print("[9] 내보내기...")
        with page.expect_download(timeout=5000) as dl_info:
            page.click("#btn-export")
        download = dl_info.value
        assert download.suggested_filename.startswith("globetravel-"), f"파일명 오류: {download.suggested_filename}"
        print(f"    다운로드 파일: {download.suggested_filename}")
        print("    ✅ 내보내기 확인")

        # ── 10. JS 콘솔 에러 ─────────────────────────────────
        print("[10] JS 콘솔 에러 점검...")
        # 무시할 에러 패턴 (MapLibre/외부 리소스 관련)
        ignore = ["favicon", "maplibre", "CARTO", "Failed to fetch", "ERR_BLOCKED", "net::"]
        real_errors = [e for e in errors if not any(ign.lower() in e.lower() for ign in ignore)]
        if real_errors:
            print(f"    ⚠️  JS 에러 {len(real_errors)}건:")
            for e in real_errors[:5]:
                print(f"       {e}")
        else:
            print("    ✅ 심각한 JS 에러 없음")

        # ── 최종 스크린샷 ─────────────────────────────────────
        page.screenshot(path="/tmp/final.png")

        print("\n=== 검증 완료 ===")
        print(f"스크린샷: /tmp/01_loaded.png ~ /tmp/final.png")
        if real_errors:
            print(f"⚠️  수정 필요 에러 {len(real_errors)}건 위에 표시됨")
        else:
            print("✅ 모든 핵심 기능 정상 동작")

        browser.close()

if __name__ == "__main__":
    run()
