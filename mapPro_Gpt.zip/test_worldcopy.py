"""renderWorldCopies=false 및 마커 위치 고정 검증"""
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    ctx = b.new_context(viewport={"width": 1440, "height": 900})
    pg = ctx.new_page()
    pg.goto("http://localhost:8765")
    pg.wait_for_selector("#loading-overlay", state="detached", timeout=15000)
    pg.wait_for_timeout(3000)

    # 드래그 전 마커 위치
    pos_before = pg.evaluate("""() => {
        const m = document.querySelector('.place-marker-wrap');
        if (!m) return null;
        const r = m.getBoundingClientRect();
        return { x: Math.round(r.left), y: Math.round(r.top) };
    }""")
    pg.screenshot(path="/tmp/wc_before.png")
    print(f"드래그 전 마커: {pos_before}")

    # 오른쪽으로 600px 드래그 (world copy 범위)
    pg.mouse.move(700, 450)
    pg.mouse.down()
    for i in range(6):
        pg.mouse.move(700 - (i+1)*100, 450, steps=5)
        pg.wait_for_timeout(60)
    pg.mouse.up()
    pg.wait_for_timeout(1200)

    pos_after = pg.evaluate("""() => {
        const m = document.querySelector('.place-marker-wrap');
        if (!m) return null;
        const r = m.getBoundingClientRect();
        return { x: Math.round(r.left), y: Math.round(r.top) };
    }""")
    pg.screenshot(path="/tmp/wc_after_drag.png")
    print(f"드래그 후 마커: {pos_after}")

    if pos_before and pos_after:
        dx = pos_after['x'] - pos_before['x']
        print(f"마커 이동량: {dx}px (지도 드래그 -600px)")
        if abs(dx) > 100:
            print("✅ 마커가 지도와 함께 이동")
        else:
            print("❌ 마커가 고정되어 있음 (화면에 붙어있음)")

    # world copy 경계 너머로 드래그 시도 (지도가 멈추는지)
    pg.mouse.move(400, 450)
    pg.mouse.down()
    for i in range(20):
        pg.mouse.move(400 - (i+1)*60, 450, steps=3)
        pg.wait_for_timeout(30)
    pg.mouse.up()
    pg.wait_for_timeout(1000)
    pg.screenshot(path="/tmp/wc_far_drag.png")
    print("→ 경계 너머 드래그 스크린샷: /tmp/wc_far_drag.png")

    b.close()
    print("완료")
