/* =====================================================
   places.js — 장소 CRUD UI 모듈
   Photon + Nominatim 듀얼 지오코딩, 사진 수 뱃지
   ===================================================== */
(function () {
  'use strict';

  let geocodeTimer = null;

  /* ─── 초기화 ─── */
  function init() {
    document.getElementById('btn-add-place').addEventListener('click', openAddModal);
    document.getElementById('btn-add-place-2').addEventListener('click', openAddModal);
    document.getElementById('btn-save-place').addEventListener('click', handleSave);

    document.querySelectorAll('[data-modal="place"]').forEach(el =>
      el.addEventListener('click', closeModal)
    );
    document.getElementById('place-search').addEventListener('input', () => renderList());

    _initGeocode(
      'geocode-input', 'geocode-results',
      (name, country, lat, lon) => {
        document.getElementById('place-name').value    = name;
        document.getElementById('place-country').value = country;
        document.getElementById('place-lat').value     = parseFloat(lat).toFixed(6);
        document.getElementById('place-lng').value     = parseFloat(lon).toFixed(6);
        if (window.MapManager)
          MapManager.focusPlace({ lat: parseFloat(lat), lng: parseFloat(lon) }, 12);
      }
    );
  }

  /* ─── 지오코딩 (Photon + Nominatim 듀얼) ─── */
  function _initGeocode(inputId, dropdownId, onPick) {
    const input    = document.getElementById(inputId);
    const dropdown = document.getElementById(dropdownId);
    if (!input) return;

    input.addEventListener('input', () => {
      clearTimeout(geocodeTimer);
      const q = input.value.trim();
      if (q.length < 2) { dropdown.classList.add('hidden'); return; }
      geocodeTimer = setTimeout(() => _runSearch(q, dropdown, onPick), 350);
    });
    document.addEventListener('click', e => {
      if (!input.contains(e.target) && !dropdown.contains(e.target))
        dropdown.classList.add('hidden');
    });
  }

  async function _runSearch(q, dropdown, onPick) {
    try {
      const enc = encodeURIComponent(q);
      const [photonRes, nomRes] = await Promise.allSettled([
        fetch(`https://photon.komoot.io/api/?q=${enc}&lang=ko&limit=6`)
          .then(r => r.json())
          .then(d => (d.features || []).map(f => {
            const p = f.properties;
            const parts = [p.name, p.city || p.district, p.state, p.country].filter(Boolean);
            return {
              name:    p.name || parts[0] || q,
              country: p.country || '',
              lat:     String(f.geometry.coordinates[1]),
              lon:     String(f.geometry.coordinates[0]),
              label:   [...new Set(parts)].join(', '),
            };
          })),
        fetch(`https://nominatim.openstreetmap.org/search?q=${enc}&format=json&limit=4&accept-language=ko,en&addressdetails=1`)
          .then(r => r.json())
          .then(d => d.map(r => ({
            name:    r.display_name.split(',')[0].trim(),
            country: r.address?.country || r.display_name.split(',').pop().trim(),
            lat:     r.lat,
            lon:     r.lon,
            label:   r.display_name.length > 60 ? r.display_name.slice(0, 60) + '…' : r.display_name,
          }))),
      ]);

      const all = [];
      if (photonRes.status === 'fulfilled') all.push(...photonRes.value);
      if (nomRes.status === 'fulfilled')   all.push(...nomRes.value);

      // 좌표 기반 중복 제거
      const seen = new Set();
      const results = all.filter(r => {
        const key = parseFloat(r.lat).toFixed(1) + ',' + parseFloat(r.lon).toFixed(1);
        if (seen.has(key)) return false;
        seen.add(key); return true;
      }).slice(0, 7);

      if (!results.length) { dropdown.classList.add('hidden'); return; }

      dropdown.innerHTML = results.map((r, i) =>
        `<div class="geocode-item" data-i="${i}">
           <strong style="color:var(--text-primary)">${esc(r.name)}</strong>
           ${r.country ? `<span class="geocode-country"> — ${esc(r.country)}</span>` : ''}
           <br><span style="font-size:10px;color:var(--text-muted)">${esc(r.label)}</span>
         </div>`
      ).join('');
      dropdown.classList.remove('hidden');

      dropdown.querySelectorAll('.geocode-item').forEach((item, i) => {
        item.addEventListener('click', () => {
          const r = results[i];
          onPick(r.name, r.country, r.lat, r.lon);
          document.getElementById('geocode-input').value = r.label;
          dropdown.classList.add('hidden');
        });
      });
    } catch (_) {
      dropdown.classList.add('hidden');
    }
  }

  /* ─── 모달 열기/닫기 ─── */
  function openAddModal() {
    document.getElementById('modal-place-title').textContent = '📍 장소 추가';
    document.getElementById('place-edit-id').value = '';
    document.getElementById('form-place').reset();
    document.getElementById('geocode-input').value = '';
    document.getElementById('geocode-results').classList.add('hidden');
    document.getElementById('modal-place').classList.remove('hidden');
    setTimeout(() => document.getElementById('geocode-input').focus(), 80);
  }

  function openEditModal(place) {
    document.getElementById('modal-place-title').textContent = '✏️ 장소 수정';
    document.getElementById('place-edit-id').value    = place.id;
    document.getElementById('place-name').value       = place.name      || '';
    document.getElementById('place-country').value    = place.country   || '';
    document.getElementById('place-lat').value        = place.lat       ?? '';
    document.getElementById('place-lng').value        = place.lng       ?? '';
    document.getElementById('place-date').value       = place.visitDate || '';
    document.getElementById('place-memo').value       = place.memo      || '';
    document.getElementById('geocode-input').value    = '';
    document.getElementById('geocode-results').classList.add('hidden');
    document.getElementById('modal-place').classList.remove('hidden');
  }

  function closeModal() {
    document.getElementById('modal-place').classList.add('hidden');
  }

  /* ─── 저장 ─── */
  async function handleSave() {
    const name = document.getElementById('place-name').value.trim();
    if (!name) { showToast('장소명을 입력해 주세요.', 'error'); return; }

    const latRaw = document.getElementById('place-lat').value;
    const lngRaw = document.getElementById('place-lng').value;
    const lat    = latRaw !== '' ? parseFloat(latRaw) : null;
    const lng    = lngRaw !== '' ? parseFloat(lngRaw) : null;
    const editId = document.getElementById('place-edit-id').value || undefined;

    const place = await AppData.savePlace({
      id:        editId,
      name,
      country:   document.getElementById('place-country').value.trim(),
      lat:       lat != null && !isNaN(lat) ? lat : null,
      lng:       lng != null && !isNaN(lng) ? lng : null,
      visitDate: document.getElementById('place-date').value,
      memo:      document.getElementById('place-memo').value.trim(),
    });

    closeModal();
    await refresh();
    showToast(editId ? `✏️ "${name}" 수정 완료` : `📍 "${name}" 추가 완료`, 'success');
    if (place.lat != null) MapManager.focusPlace(place, 9);
  }

  /* ─── 삭제 ─── */
  async function handleDelete(id, name) {
    if (!confirm(`"${name}"과(와) 관련 경로를 모두 삭제하시겠습니까?`)) return;
    await AppData.deletePlace(id);
    MapManager.removePlace(id);
    await refresh();
    if (window.RoutesUI) await RoutesUI.refresh();
    showToast(`🗑️ "${name}" 삭제 완료`, 'info');
  }

  /* ─── 목록 렌더링 ─── */
  async function renderList() {
    const query    = document.getElementById('place-search').value.toLowerCase();
    const places   = await AppData.getPlaces();
    const photos   = await AppData.getPhotos();
    const filtered = query
      ? places.filter(p => p.name.toLowerCase().includes(query) || (p.country||'').toLowerCase().includes(query))
      : places;

    const el = document.getElementById('places-list');

    if (!filtered.length) {
      el.innerHTML = `<div class="empty-state">${query ? '🔍 검색 결과가 없습니다.' : '📍 아직 방문한 장소가 없습니다.<br>장소를 추가해 여행을 기록하세요!'}</div>`;
      return;
    }

    // 사진 수 계산
    const photoCounts = {};
    photos.forEach(ph => { if (ph.placeId) photoCounts[ph.placeId] = (photoCounts[ph.placeId]||0)+1; });

    el.innerHTML = filtered.map(p => {
      const cnt = photoCounts[p.id] || 0;
      return `
        <div class="place-item" data-id="${esc(p.id)}">
          <div class="place-icon">📍</div>
          <div class="place-info">
            <div class="place-name">${esc(p.name)}</div>
            <div class="place-sub">
              ${p.country ? `<span>${esc(p.country)}</span>` : ''}
              ${p.visitDate ? `<span>${p.visitDate}</span>` : ''}
              ${cnt > 0 ? `<span class="place-photo-badge">📷 ${cnt}</span>` : ''}
            </div>
          </div>
          <div class="place-actions">
            <button class="btn-icon-sm" data-action="photos" title="사진 보기">📷</button>
            <button class="btn-icon-sm" data-action="edit"   title="수정">✏️</button>
            <button class="btn-icon-sm danger" data-action="delete" title="삭제">🗑️</button>
          </div>
        </div>
      `;
    }).join('');

    el.querySelectorAll('.place-item').forEach(item => {
      const id    = item.dataset.id;
      const place = places.find(p => p.id === id);
      if (!place) return;

      // 행 클릭 → 지구본 포커스
      item.addEventListener('click', e => {
        if (e.target.closest('[data-action]')) return;
        if (place.lat != null) MapManager.focusPlace(place);
        el.querySelectorAll('.place-item').forEach(x => x.classList.remove('selected'));
        item.classList.add('selected');
      });

      item.querySelector('[data-action="photos"]')
        ?.addEventListener('click', () => { window.PhotosUI?.openForPlace(place); });
      item.querySelector('[data-action="edit"]')
        ?.addEventListener('click', () => openEditModal(place));
      item.querySelector('[data-action="delete"]')
        ?.addEventListener('click', () => handleDelete(id, place.name));
    });
  }

  /* ─── 지구본 + 통계 갱신 ─── */
  async function updateGlobe() {
    const places = await AppData.getPlaces();
    const photos = await AppData.getPhotos();
    const routes = await AppData.getRoutes();

    const photoCounts = {};
    photos.forEach(ph => { if (ph.placeId) photoCounts[ph.placeId] = (photoCounts[ph.placeId]||0)+1; });

    MapManager.setPlaces(places, photoCounts);
    MapManager.setRoutes(routes, places);
  }

  async function updateStats() {
    const places   = await AppData.getPlaces();
    const photos   = await AppData.getPhotos();
    const routes   = await AppData.getRoutes();

    const countries = new Set(places.map(p => p.country).filter(Boolean));
    document.getElementById('stat-places').textContent    = places.length;
    document.getElementById('stat-countries').textContent = countries.size;
    document.getElementById('stat-photos').textContent    = photos.length;

    // 총 이동 거리
    let totalDist = 0;
    const pm = {};
    places.forEach(p => { pm[p.id] = p; });
    routes.forEach(r => {
      const from = pm[r.fromPlaceId], to = pm[r.toPlaceId];
      if (from?.lat != null && to?.lat != null)
        totalDist += AppData.haversine(from.lat, from.lng, to.lat, to.lng);
    });
    const distEl = document.getElementById('stat-dist');
    // 항상 정수 + "km" 표기 — 단위 레이블과 중복 없음
    distEl.textContent = Math.round(totalDist).toLocaleString() + ' km';

    // 교통수단 통계
    const tpCount = {};
    routes.forEach(r => { tpCount[r.transport] = (tpCount[r.transport]||0)+1; });
    const tpSection = document.getElementById('section-transport');
    const tpEl      = document.getElementById('stat-transport');
    if (Object.keys(tpCount).length) {
      const ICONS  = { plane:'✈️', car:'🚗', train:'🚂', bus:'🚌', ship:'🚢', bicycle:'🚲', walk:'🚶' };
      const LABELS = { plane:'비행기', car:'자동차', train:'기차', bus:'버스', ship:'선박', bicycle:'자전거', walk:'도보' };
      const COLORS = { plane:'var(--blue)', car:'var(--green)', train:'var(--accent)', bus:'var(--purple)', ship:'var(--cyan)', bicycle:'var(--orange)', walk:'var(--pink)' };
      const maxCnt = Math.max(...Object.values(tpCount));
      tpEl.innerHTML = Object.entries(tpCount).sort((a,b) => b[1]-a[1]).map(([t, c]) =>
        `<div class="stat-bar-row">
           <span class="stat-bar-icon">${ICONS[t]||'🚀'}</span>
           <span class="stat-bar-label">${LABELS[t]||t}</span>
           <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${(c/maxCnt*100).toFixed(0)}%;background:${COLORS[t]||'var(--accent)'}"></div></div>
           <span class="stat-bar-count">${c}</span>
         </div>`
      ).join('');
      tpSection.style.display = '';
    } else {
      tpSection.style.display = 'none';
    }

    // 연도별 방문 통계
    const byYear = {};
    places.forEach(p => { if (p.visitDate) { const y = p.visitDate.slice(0,4); byYear[y]=(byYear[y]||0)+1; } });
    routes.forEach(r => { if (r.date) { const y = r.date.slice(0,4); byYear[y]=(byYear[y]||0)+1; } });
    const yrSection = document.getElementById('section-years');
    const yrEl      = document.getElementById('stat-years');
    if (Object.keys(byYear).length) {
      const maxYr = Math.max(...Object.values(byYear));
      yrEl.innerHTML = Object.entries(byYear).sort().map(([y, c]) =>
        `<div class="stat-bar-row">
           <span class="stat-bar-icon" style="font-size:11px;width:32px;color:var(--text-muted)">${y}</span>
           <div class="stat-bar-track" style="margin-left:0">
             <div class="stat-bar-fill" style="width:${(c/maxYr*100).toFixed(0)}%;background:var(--accent)"></div>
           </div>
           <span class="stat-bar-count">${c}</span>
         </div>`
      ).join('');
      yrSection.style.display = '';
    } else {
      yrSection.style.display = 'none';
    }
  }

  async function refresh() {
    await renderList();
    await updateGlobe();
    await updateStats();
  }

  function esc(str) {
    return String(str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  window.PlacesUI = { init, refresh, openAddModal, openEditModal, updateStats };
})();
