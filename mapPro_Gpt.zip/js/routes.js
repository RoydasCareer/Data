/* =====================================================
   routes.js — 이동 경로 CRUD UI 모듈
   항공사/편명 필드, 숨김 토글, 듀얼 지오코딩
   ===================================================== */
(function () {
  'use strict';

  const TRANSPORT = {
    plane:   { icon: '✈️', label: '비행기', color: 'var(--blue)'   },
    car:     { icon: '🚗', label: '자동차', color: 'var(--green)'  },
    train:   { icon: '🚂', label: '기차',   color: 'var(--accent)' },
    bus:     { icon: '🚌', label: '버스',   color: 'var(--purple)' },
    ship:    { icon: '🚢', label: '선박',   color: 'var(--cyan)'   },
    bicycle: { icon: '🚲', label: '자전거', color: 'var(--orange)' },
    walk:    { icon: '🚶', label: '도보',   color: 'var(--pink)'   },
  };

  function init() {
    document.getElementById('btn-add-route').addEventListener('click',  openAddModal);
    document.getElementById('btn-add-route-2').addEventListener('click', openAddModal);
    document.getElementById('btn-save-route').addEventListener('click',  handleSave);

    document.querySelectorAll('[data-modal="route"]').forEach(el =>
      el.addEventListener('click', closeModal)
    );

    // 교통수단 변경 → 비행기 상세 필드 토글
    document.getElementById('route-transport').addEventListener('change', e => {
      _toggleFlightDetails(e.target.value);
    });

    _initRouteSearch('route-from-input', 'route-from-results', 'route-from-id');
    _initRouteSearch('route-to-input',   'route-to-results',   'route-to-id');
  }

  /* ─── 출발지/도착지 검색 ─── */
  function _initRouteSearch(inputId, resultsId, hiddenId) {
    const input   = document.getElementById(inputId);
    const results = document.getElementById(resultsId);
    let timer = null;

    input.addEventListener('input', () => {
      clearTimeout(timer);
      const q = input.value.trim();
      document.getElementById(hiddenId).value = '';
      if (q.length < 1) { results.classList.add('hidden'); return; }
      timer = setTimeout(() => _searchLocation(q, input, results, hiddenId), 380);
    });

    document.addEventListener('click', e => {
      if (!input.contains(e.target) && !results.contains(e.target))
        results.classList.add('hidden');
    });
  }

  async function _searchLocation(q, input, results, hiddenId) {
    const places = await AppData.getPlaces();
    const enc    = encodeURIComponent(q);

    // 저장된 장소 필터링
    const saved = places.filter(p =>
      p.name.toLowerCase().includes(q.toLowerCase()) ||
      (p.country||'').toLowerCase().includes(q.toLowerCase())
    );

    // Photon + Nominatim 병렬 검색
    const [photonRes, nomRes] = await Promise.allSettled([
      fetch(`https://photon.komoot.io/api/?q=${enc}&lang=ko&limit=4`)
        .then(r => r.json())
        .then(d => (d.features||[]).map(f => {
          const p = f.properties;
          const parts = [p.name, p.city||p.district, p.country].filter(Boolean);
          return { name: p.name||parts[0]||q, country: p.country||'', lat: f.geometry.coordinates[1], lon: f.geometry.coordinates[0], label: [...new Set(parts)].join(', ') };
        })),
      fetch(`https://nominatim.openstreetmap.org/search?q=${enc}&format=json&limit=3&accept-language=ko,en&addressdetails=1`)
        .then(r => r.json())
        .then(d => d.map(r => ({
          name:    r.display_name.split(',')[0].trim(),
          country: r.address?.country || '',
          lat:     parseFloat(r.lat),
          lon:     parseFloat(r.lon),
          label:   r.display_name.length > 55 ? r.display_name.slice(0,55)+'…' : r.display_name,
        }))),
    ]);

    const nomItems = nomRes.status === 'fulfilled' ? nomRes.value : [];
    const photonItems = photonRes.status === 'fulfilled' ? photonRes.value : [];

    results.innerHTML = '';

    // ① 저장된 장소
    saved.forEach(p => {
      const div = _makeItem(
        `📍 <strong>${esc(p.name)}</strong>${p.country ? ` <span class="geocode-country">(${esc(p.country)})</span>` : ''}`,
        'saved-place'
      );
      div.addEventListener('click', () => {
        input.value = p.name;
        document.getElementById(results.id.replace('-results','-id')).value = p.id;
        results.classList.add('hidden');
      });
      results.appendChild(div);
    });

    // ② Photon 결과 (미저장 위치)
    const allExt = [...photonItems, ...nomItems];
    const seen = new Set();
    allExt.forEach(r => {
      const key = parseFloat(r.lat).toFixed(1) + ',' + parseFloat(r.lon).toFixed(1);
      if (seen.has(key)) return; seen.add(key);
      if (saved.some(p => p.lat != null && Math.abs(p.lat - r.lat) < 0.05 && Math.abs(p.lng - r.lon) < 0.05)) return;

      const div = _makeItem(
        `🔍 <strong>${esc(r.name)}</strong> <span class="geocode-country">${esc(r.label)}</span>`
      );
      div.addEventListener('click', async () => {
        // 새 장소로 자동 저장
        const place = await AppData.savePlace({ name: r.name, country: r.country, lat: r.lat, lng: r.lon });
        if (window.PlacesUI) await PlacesUI.refresh();
        input.value = place.name;
        document.getElementById(hiddenId).value = place.id;
        results.classList.add('hidden');
        showToast(`📍 "${place.name}" 장소 자동 저장`, 'info');
      });
      results.appendChild(div);
    });

    results.classList.toggle('hidden', results.children.length === 0);
  }

  function _makeItem(html, extraClass) {
    const div = document.createElement('div');
    div.className = `geocode-item${extraClass ? ' ' + extraClass : ''}`;
    div.innerHTML = html;
    return div;
  }

  /* ─── 비행기 상세 필드 표시/숨김 ─── */
  function _toggleFlightDetails(transport) {
    const el = document.getElementById('flight-details');
    if (transport === 'plane') el.classList.remove('hidden');
    else { el.classList.add('hidden'); }
  }

  /* ─── 모달 ─── */
  async function openAddModal() {
    document.getElementById('modal-route-title').textContent = '✈️ 경로 추가';
    document.getElementById('route-edit-id').value = '';
    document.getElementById('form-route').reset();
    _clearSearch();
    _toggleFlightDetails('plane');
    document.getElementById('modal-route').classList.remove('hidden');
    setTimeout(() => document.getElementById('route-from-input').focus(), 80);
  }

  async function openEditModal(route) {
    document.getElementById('modal-route-title').textContent = '✏️ 경로 수정';
    document.getElementById('route-edit-id').value = route.id;
    _clearSearch();

    const places = await AppData.getPlaces();
    const pm = {};
    places.forEach(p => { pm[p.id] = p; });

    const from = pm[route.fromPlaceId];
    const to   = pm[route.toPlaceId];
    if (from) { document.getElementById('route-from-input').value = from.name; document.getElementById('route-from-id').value = from.id; }
    if (to)   { document.getElementById('route-to-input').value   = to.name;   document.getElementById('route-to-id').value   = to.id;   }

    document.getElementById('route-transport').value = route.transport || 'plane';
    document.getElementById('route-airline').value   = route.airline   || '';
    document.getElementById('route-flightno').value  = route.flightno  || '';
    document.getElementById('route-date').value      = route.date      || '';
    document.getElementById('route-memo').value      = route.memo      || '';
    _toggleFlightDetails(route.transport || 'plane');
    document.getElementById('modal-route').classList.remove('hidden');
  }

  function _clearSearch() {
    ['route-from-input','route-to-input'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
    ['route-from-id','route-to-id'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
    ['route-from-results','route-to-results'].forEach(id => { const el = document.getElementById(id); if (el) el.classList.add('hidden'); });
  }

  function closeModal() {
    document.getElementById('modal-route').classList.add('hidden');
  }

  /* ─── 저장 ─── */
  async function handleSave() {
    const fromId = document.getElementById('route-from-id').value;
    const toId   = document.getElementById('route-to-id').value;

    if (!fromId || !toId) {
      showToast('출발지와 도착지를 검색 후 선택해 주세요.', 'error');
      return;
    }
    if (fromId === toId) { showToast('출발지와 도착지가 같습니다.', 'error'); return; }

    const transport = document.getElementById('route-transport').value || 'plane';
    const editId    = document.getElementById('route-edit-id').value || undefined;

    const route = await AppData.saveRoute({
      id:          editId,
      fromPlaceId: fromId,
      toPlaceId:   toId,
      transport,
      airline:     transport === 'plane' ? document.getElementById('route-airline').value.trim() : '',
      flightno:    transport === 'plane' ? document.getElementById('route-flightno').value.trim() : '',
      date:        document.getElementById('route-date').value,
      memo:        document.getElementById('route-memo').value.trim(),
      visible:     true,
    });

    closeModal();
    await refresh();
    const tp = TRANSPORT[transport] || { icon: '🚀', label: transport };
    showToast(`${tp.icon} 경로 ${editId ? '수정' : '추가'} 완료`, 'success');
  }

  /* ─── 삭제 ─── */
  async function handleDelete(id) {
    if (!confirm('이 경로를 삭제하시겠습니까?')) return;
    await AppData.deleteRoute(id);
    await refresh();
    showToast('경로 삭제 완료', 'info');
  }

  /* ─── 표시/숨김 토글 ─── */
  async function toggleVisibility(id) {
    const routes = await AppData.getRoutes();
    const route  = routes.find(r => r.id === id);
    if (!route) return;
    route.visible = !(route.visible !== false);
    await AppData.saveRoute(route);
    await refresh();
  }

  /* ─── 목록 렌더링 ─── */
  async function renderList() {
    const routes = await AppData.getRoutes();
    const places = await AppData.getPlaces();
    const pm     = {};
    places.forEach(p => { pm[p.id] = p; });

    const el = document.getElementById('routes-list');

    if (!routes.length) {
      el.innerHTML = '<div class="empty-state">✈️ 아직 등록된 경로가 없습니다.</div>';
      return;
    }

    el.innerHTML = routes.map(r => {
      const from    = pm[r.fromPlaceId];
      const to      = pm[r.toPlaceId];
      const tp      = TRANSPORT[r.transport] || { icon: '🚀', label: r.transport, color: 'var(--accent)' };
      const visible = r.visible !== false;
      const subParts = [tp.label];
      if (r.date)    subParts.push(r.date);
      if (r.airline) subParts.push(r.airline + (r.flightno ? ' ' + r.flightno : ''));
      if (r.memo)    subParts.push(r.memo);

      return `
        <div class="route-item${visible ? '' : ' hidden-route'}" data-id="${esc(r.id)}">
          <div class="route-icon">${tp.icon}</div>
          <div class="route-info">
            <div class="route-name">
              ${from ? esc(from.name) : '<em style="color:var(--text-muted)">(삭제됨)</em>'}
              <span style="color:var(--text-muted);margin:0 4px">→</span>
              ${to ? esc(to.name) : '<em style="color:var(--text-muted)">(삭제됨)</em>'}
            </div>
            <div class="route-sub" style="color:${tp.color}">${subParts.join(' · ')}</div>
          </div>
          <div class="route-actions">
            <button class="btn-icon-sm eye-toggle" data-action="toggle" title="${visible?'숨기기':'표시'}">${visible?'👁':'🙈'}</button>
            <button class="btn-icon-sm" data-action="edit"   title="수정">✏️</button>
            <button class="btn-icon-sm danger" data-action="delete" title="삭제">🗑️</button>
          </div>
        </div>
      `;
    }).join('');

    el.querySelectorAll('[data-action="toggle"]').forEach(btn => {
      btn.addEventListener('click', () => toggleVisibility(btn.closest('.route-item').dataset.id));
    });
    el.querySelectorAll('[data-action="edit"]').forEach(btn => {
      const r = routes.find(x => x.id === btn.closest('.route-item').dataset.id);
      if (r) btn.addEventListener('click', () => openEditModal(r));
    });
    el.querySelectorAll('[data-action="delete"]').forEach(btn => {
      btn.addEventListener('click', () => handleDelete(btn.closest('.route-item').dataset.id));
    });
  }

  /* ─── 지도 갱신 ─── */
  async function updateGlobe() {
    const places = await AppData.getPlaces();
    const routes = await AppData.getRoutes();
    MapManager.setRoutes(routes, places);
  }

  async function refresh() {
    await renderList();
    await updateGlobe();
    if (window.PlacesUI) await PlacesUI.updateStats();
  }

  function esc(str) {
    return String(str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  window.RoutesUI = { init, refresh, openAddModal };
})();
