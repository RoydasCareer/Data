/* =====================================================
   map.js v4 — OpenFreeMap 벡터 타일 (WorldMap과 동일 계열)
   Natural Earth 기반 소프트 컬러, 무료, API 키 불필요
   ===================================================== */
(function () {
  'use strict';

  const TRANSPORT_ICON = {
    plane:'✈', car:'🚗', train:'🚂', bus:'🚌', ship:'🚢', bicycle:'🚲', walk:'🚶',
  };
  const TRANSPORT_SPEED = {
    plane:0.0028, car:0.0014, train:0.002, bus:0.0012, ship:0.0007, bicycle:0.0005, walk:0.0003,
  };
  const TRANSPORT_STYLE = {
    plane:  {color:'#60a5fa',weight:2.5},
    car:    {color:'#34d399',weight:2},
    train:  {color:'#f59e0b',weight:2.5},
    bus:    {color:'#a78bfa',weight:2},
    ship:   {color:'#22d3ee',weight:2},
    bicycle:{color:'#fb923c',weight:1.5},
    walk:   {color:'#f472b6',weight:1.5},
  };

  /* WorldMap과 동일 계열 — OpenFreeMap (완전 무료, 키 불필요) */
  const STYLE_URLS = {
    bright:   'https://tiles.openfreemap.org/styles/bright',
    positron: 'https://tiles.openfreemap.org/styles/positron',
    liberty:  'https://tiles.openfreemap.org/styles/liberty',
  };

  /* ── 상태 ── */
  let map = null;
  let mapReady = false;
  let onPlaceClickCb = null;
  let currentStyle = 'bright';

  let queuedPlaces = null;
  let queuedRoutes = null;
  let queuedPlaceArr = null;

  let _places      = [];
  let _photoCounts = {};
  let _routes      = [];

  /* ── 라벨 오버레이 (body에 fixed 포지션) ── */
  let _labelRoot = null;
  const _labelEls = {};

  /* ── 경로 애니메이션 ── */
  const _animMarkers = [];
  let animFrame = null;
  let routeAnims = [];

  /* ── 팝업 ── */
  let _currentPopup = null;

  /* ─────────────────────────────────────────────────
     동해 표기 보정
     타일 제공자가 "Sea of Japan"으로 표기하는 경우
     한국어 명칭 레이어로 덮어씌움
  ───────────────────────────────────────────────── */
  function _applyEastSeaLabel() {
    // 바다/해양 심볼 레이어에 한국어 명칭 우선 적용
    const layers = map.getStyle()?.layers || [];
    layers.forEach(layer => {
      if (layer.type !== 'symbol') return;
      const id = layer.id.toLowerCase();
      if (!id.includes('water') && !id.includes('ocean') && !id.includes('sea')) return;
      try {
        map.setLayoutProperty(layer.id, 'text-field',
          ['coalesce', ['get', 'name:ko'], ['get', 'name']]
        );
      } catch (_) {}
    });

    // 동해 위치에 직접 레이블 추가 (타일 명칭과 무관하게 표시)
    if (!map.getSource('east-sea-src')) {
      map.addSource('east-sea-src', {
        type: 'geojson',
        data: { type: 'Feature', geometry: { type: 'Point', coordinates: [134.0, 38.5] }, properties: {} }
      });
    }
    if (!map.getLayer('east-sea-label')) {
      map.addLayer({
        id: 'east-sea-label', type: 'symbol', source: 'east-sea-src',
        layout: {
          'text-field': '동해',
          'text-font': ['Noto Sans Regular'],
          'text-size': ['interpolate', ['linear'], ['zoom'], 1, 9, 5, 15],
          'text-letter-spacing': 0.15,
          'text-allow-overlap': true,
        },
        paint: {
          'text-color': '#4a7a9b',
          'text-halo-color': 'rgba(255,255,255,0.9)',
          'text-halo-width': 2,
        },
      });
    }

    // 독도·울릉도 — 지도 지명 스타일 (여행 핀 아님)
    const KR_ISLANDS = [
      { id: 'dokdo',    coord: [131.8678, 37.2426], label: '독도' },
      { id: 'ulleung',  coord: [130.8656, 37.4893], label: '울릉도' },
    ];

    KR_ISLANDS.forEach(({ id, coord, label }) => {
      const srcId = `kr-island-${id}-src`;
      const dotId = `kr-island-${id}-dot`;
      const lblId = `kr-island-${id}-label`;

      if (!map.getSource(srcId)) {
        map.addSource(srcId, {
          type: 'geojson',
          data: { type: 'Feature', geometry: { type: 'Point', coordinates: coord }, properties: { label } }
        });
      }
      // 카토그래픽 기준점 — 섬 위치를 나타내는 미세한 점
      if (!map.getLayer(dotId)) {
        map.addLayer({
          id: dotId, type: 'circle', source: srcId,
          minzoom: 4,
          paint: {
            'circle-radius': ['interpolate', ['linear'], ['zoom'], 4, 1.5, 9, 3],
            'circle-color': '#555',
            'circle-stroke-width': 0,
          },
        });
      }
      // 지명 — 타일 지도와 동일한 이탤릭 스타일
      if (!map.getLayer(lblId)) {
        map.addLayer({
          id: lblId, type: 'symbol', source: srcId,
          layout: {
            'text-field': ['get', 'label'],
            'text-font': ['Noto Sans Italic'],
            'text-size': ['interpolate', ['linear'], ['zoom'], 3, 8, 8, 12],
            'text-offset': [0, 0.9],
            'text-anchor': 'top',
            'text-allow-overlap': true,
            'text-ignore-placement': true,
          },
          paint: {
            'text-color': '#3a3a3a',
            'text-halo-color': 'rgba(255,255,255,0.75)',
            'text-halo-width': 1,
          },
        });
      }
    });
  }

  /* ─────────────────────────────────────────────────
     커스텀 소스·레이어 추가
     벡터 스타일 교체 시 기존 소스/레이어가 제거되므로
     style.load 이후 반드시 재호출
  ───────────────────────────────────────────────── */
  function _addCustomLayers() {
    if (!map.getSource('routes-src')) {
      map.addSource('routes-src', { type:'geojson', data:_fc([]) });
    }
    if (!map.getSource('places-src')) {
      map.addSource('places-src', { type:'geojson', data:_fc([]) });
    }
    if (!map.getLayer('routes-layer')) {
      map.addLayer({
        id:'routes-layer', type:'line', source:'routes-src',
        layout:{'line-cap':'round','line-join':'round'},
        paint:{'line-color':['get','color'],'line-width':['get','weight'],'line-opacity':0.88,'line-dasharray':[6,4]},
      });
    }
    if (!map.getLayer('places-glow')) {
      map.addLayer({
        id:'places-glow', type:'circle', source:'places-src',
        paint:{
          'circle-radius':16, 'circle-color':'#e8723a',
          'circle-opacity':0.22, 'circle-blur':0.6,
        },
      });
    }
    if (!map.getLayer('places-dot')) {
      map.addLayer({
        id:'places-dot', type:'circle', source:'places-src',
        paint:{
          'circle-radius':7, 'circle-color':'#e8723a',
          'circle-stroke-color':'#ffffff', 'circle-stroke-width':2,
        },
      });
    }
  }

  /* ─────────────────────────────────────────────────
     초기화
  ───────────────────────────────────────────────── */
  function init(container) {
    return new Promise(resolve => {
      map = new maplibregl.Map({
        container,
        style:             STYLE_URLS.bright,
        projection:        'globe',
        center:            [127, 37],
        zoom:              1.8,
        minZoom:           0.5,
        maxZoom:           19,
        renderWorldCopies: false,
        attributionControl: false,
      });

      const safety = setTimeout(() => { _initLabelOverlay(); _onStyleReady(); resolve(); }, 10000);

      map.on('load', () => {
        clearTimeout(safety);
        _initLabelOverlay();
        _onStyleReady();
        resolve();
      });

      map.on('error', err => {
        if (err.error) console.warn('[MapLibre]', err.error.message || err.error);
      });
    });
  }

  function _onStyleReady() {
    _addCustomLayers();
    _applyEastSeaLabel();
    _setupMapEvents();
    _setupFog();
    mapReady = true;
    if (queuedPlaces !== null) {
      _doSetPlaces(queuedPlaces, _photoCounts);
      queuedPlaces = null;
    }
    if (queuedRoutes !== null) {
      _doSetRoutes(queuedRoutes, queuedPlaceArr);
      queuedRoutes = null; queuedPlaceArr = null;
    }
  }

  /* WorldMap의 바다 색감(#c2dff0)에 맞춘 글로브 대기층 */
  function _setupFog() {
    try {
      map.setFog({
        'space-color':    '#0a1428',
        'star-intensity': 0.55,
        'horizon-blend':  0.03,
        'color':          'rgba(194,223,240,0.5)',
        'high-color':     '#4a9ece',
      });
    } catch (_) {}
  }

  /* ─────────────────────────────────────────────────
     라벨 오버레이 (HTML, fixed, z-index 5)
  ───────────────────────────────────────────────── */
  function _initLabelOverlay() {
    if (_labelRoot) return;
    _labelRoot = document.createElement('div');
    _labelRoot.id = 'pm-labels-overlay';
    Object.assign(_labelRoot.style, {
      position:'fixed', inset:'0', pointerEvents:'none',
      overflow:'hidden', zIndex:'5',
    });
    document.body.appendChild(_labelRoot);

    map.on('move',   _syncLabelPositions);
    map.on('zoom',   _syncLabelPositions);
    map.on('rotate', _syncLabelPositions);
    map.on('pitch',  _syncLabelPositions);
  }

  function _syncLabelPositions() {
    if (!map || !_labelRoot) return;
    const rect = map.getContainer().getBoundingClientRect();
    Object.entries(_labelEls).forEach(([, info]) => {
      const pos = map.project(info.coord);
      info.el.style.left = `${rect.left + pos.x}px`;
      info.el.style.top  = `${rect.top  + pos.y - 18}px`;
    });
  }

  function _rebuildLabels(places) {
    if (!_labelRoot) return;
    const newIds = new Set((places||[]).map(p => p.id));
    Object.keys(_labelEls).forEach(id => {
      if (!newIds.has(id)) { _labelEls[id].el.remove(); delete _labelEls[id]; }
    });
    (places||[]).forEach(p => {
      if (p.lat == null) return;
      if (_labelEls[p.id]) {
        _labelEls[p.id].el.textContent = p.name;
        _labelEls[p.id].coord = [p.lng, p.lat];
      } else {
        const el = document.createElement('div');
        el.className = 'pm-label';
        el.textContent = p.name;
        Object.assign(el.style, {
          position:'absolute', transform:'translate(-50%, -100%)',
          pointerEvents:'auto', cursor:'pointer',
        });
        el.addEventListener('click', () => {
          _showPlacePopup(p);
          if (onPlaceClickCb) onPlaceClickCb(p);
        });
        _labelRoot.appendChild(el);
        _labelEls[p.id] = { el, coord:[p.lng, p.lat] };
      }
    });
    _syncLabelPositions();
  }

  /* ─────────────────────────────────────────────────
     장소 GeoJSON 업데이트
  ───────────────────────────────────────────────── */
  function setPlaces(places, photoCounts) {
    _places      = places      || [];
    _photoCounts = photoCounts || {};
    if (!mapReady) { queuedPlaces = places; return; }
    _doSetPlaces(places, _photoCounts);
  }

  function _doSetPlaces(places, photoCounts) {
    const src = map.getSource('places-src');
    if (src) {
      src.setData(_fc(
        (places||[]).filter(p => p.lat != null && p.lng != null).map(p => ({
          type:'Feature',
          geometry:{ type:'Point', coordinates:[p.lng, p.lat] },
          properties:{
            id: p.id, name: p.name,
            country: p.country||'', visitDate: p.visitDate||'', memo: p.memo||'',
            photoCount: (photoCounts||{})[p.id] || 0,
          },
        }))
      ));
    }
    _rebuildLabels(places);
  }

  function removePlace(placeId) {
    _places = _places.filter(p => p.id !== placeId);
    if (_labelEls[placeId]) { _labelEls[placeId].el.remove(); delete _labelEls[placeId]; }
    const src = map.getSource('places-src');
    if (src) _doSetPlaces(_places, _photoCounts);
  }

  /* ─────────────────────────────────────────────────
     경로 GeoJSON 업데이트
  ───────────────────────────────────────────────── */
  function setRoutes(routes, places) {
    _routes = routes || [];
    if (!mapReady) { queuedRoutes = routes; queuedPlaceArr = places; return; }
    _doSetRoutes(routes, places);
  }

  function _doSetRoutes(routes, places) {
    const src = map.getSource('routes-src');
    if (!src) return;

    const pm = {};
    (places||[]).forEach(p => { pm[p.id] = p; });

    const features = [];
    routeAnims = [];
    _clearAnimMarkers();

    (routes||[]).forEach(r => {
      const from = pm[r.fromPlaceId];
      const to   = pm[r.toPlaceId];
      if (!from||!to||from.lat==null||to.lat==null) return;

      const style = TRANSPORT_STYLE[r.transport] || TRANSPORT_STYLE.plane;
      const pts   = _routePath(from.lat, from.lng, to.lat, to.lng, 80);

      if (r.visible !== false) {
        features.push({
          type:'Feature',
          geometry:{ type:'LineString', coordinates: pts.map(([la,ln]) => [ln,la]) },
          properties:{
            color:style.color, weight:style.weight,
            transport:r.transport,
            fromName:from.name, toName:to.name,
            date:r.date||'', airline:r.airline||'', flightno:r.flightno||'', memo:r.memo||'',
          },
        });
      }

      routeAnims.push({
        pts, t:Math.random(),
        speed: TRANSPORT_SPEED[r.transport]||0.002,
        icon:  TRANSPORT_ICON[r.transport]||'🚀',
        color: style.color,
        visible: r.visible!==false,
      });
    });

    src.setData(_fc(features));
    _startAnimation();
  }

  /* ─────────────────────────────────────────────────
     교통수단 이동 애니메이션
  ───────────────────────────────────────────────── */
  function _clearAnimMarkers() {
    _animMarkers.forEach(m => m.remove());
    _animMarkers.length = 0;
    if (animFrame) { cancelAnimationFrame(animFrame); animFrame = null; }
  }

  function _startAnimation() {
    _clearAnimMarkers();
    const vis = routeAnims.filter(a => a.visible);
    if (!vis.length || !map) return;

    vis.forEach(a => {
      const el = document.createElement('div');
      el.className = 'transport-anim-icon';
      el.textContent = a.icon;
      const m = new maplibregl.Marker({ element:el, anchor:'center' })
        .setLngLat([a.pts[0][1], a.pts[0][0]])
        .addTo(map);
      _animMarkers.push(m);
      a._ref = m;
    });

    function tick() {
      vis.forEach(a => {
        a.t = (a.t + a.speed) % 1;
        const idx = Math.min(Math.floor(a.t*(a.pts.length-1)), a.pts.length-2);
        if (a._ref) a._ref.setLngLat([a.pts[idx][1], a.pts[idx][0]]);
      });
      animFrame = requestAnimationFrame(tick);
    }
    tick();
  }

  /* ─────────────────────────────────────────────────
     지도 이벤트 (클릭, 호버)
  ───────────────────────────────────────────────── */
  function _setupMapEvents() {
    map.on('click', 'places-dot', e => {
      if (!e.features.length) return;
      const props  = e.features[0].properties;
      const coords = e.features[0].geometry.coordinates;
      const place  = _places.find(p => p.id === props.id);
      if (!place) return;
      _showPlacePopup(place, coords);
      if (onPlaceClickCb) onPlaceClickCb(place);
    });

    map.on('click', 'routes-layer', e => {
      if (!e.features.length) return;
      const p    = e.features[0].properties;
      const icon = TRANSPORT_ICON[p.transport] || '🚀';
      let html = `<div class="map-popup"><strong>${icon} ${esc(p.fromName)} → ${esc(p.toName)}</strong>`;
      if (p.date)    html += `<br><small>📅 ${p.date}</small>`;
      if (p.airline) html += `<br><small>✈ ${esc(p.airline)}${p.flightno?' '+esc(p.flightno):''}</small>`;
      if (p.memo)    html += `<br><small>📝 ${esc(p.memo)}</small>`;
      html += '</div>';
      new maplibregl.Popup({ closeButton:true, maxWidth:'300px' })
        .setLngLat(e.lngLat).setHTML(html).addTo(map);
    });

    ['places-dot','places-glow'].forEach(id => {
      map.on('mouseenter', id, () => { map.getCanvas().style.cursor = 'pointer'; });
      map.on('mouseleave', id, () => { map.getCanvas().style.cursor = ''; });
    });
    map.on('mouseenter', 'routes-layer', () => { map.getCanvas().style.cursor = 'pointer'; });
    map.on('mouseleave', 'routes-layer', () => { map.getCanvas().style.cursor = ''; });
  }

  function _showPlacePopup(place, coords) {
    if (_currentPopup) { _currentPopup.remove(); _currentPopup = null; }

    let html = `<div class="map-popup"><strong>${esc(place.name)}</strong>`;
    if (place.country)   html += `<br><span>${esc(place.country)}</span>`;
    if (place.visitDate) html += `<br><small>📅 ${place.visitDate}</small>`;
    if (place.memo)      html += `<br><small>📝 ${esc(place.memo)}</small>`;
    html += `<br><button class="map-popup-photo-btn">📷 사진 보기</button></div>`;

    const lngLat = coords || [place.lng, place.lat];
    _currentPopup = new maplibregl.Popup({ closeButton:true, maxWidth:'280px', offset:10 })
      .setLngLat(lngLat)
      .setHTML(html);

    _currentPopup.once('open', () => {
      const btn = _currentPopup.getElement()?.querySelector('.map-popup-photo-btn');
      if (btn) btn.addEventListener('click', () => {
        if (window.PhotosUI) PhotosUI.openForPlace(place);
      });
    });

    _currentPopup.addTo(map);
  }

  /* ─────────────────────────────────────────────────
     공개 API
  ───────────────────────────────────────────────── */
  function focusPlace(place, zoom) {
    if (!map || place.lat == null) return;
    map.flyTo({ center:[place.lng, place.lat], zoom: zoom||10, duration:1200 });
  }

  function onPlaceClick(cb) { onPlaceClickCb = cb; }

  function setStyle(name) {
    if (!map || !STYLE_URLS[name] || name === currentStyle) return;
    currentStyle = name;
    _clearAnimMarkers();

    map.setStyle(STYLE_URLS[name]);

    map.once('style.load', () => {
      _addCustomLayers();
      _applyEastSeaLabel();
      _setupMapEvents();
      _setupFog();
      _doSetPlaces(_places, _photoCounts);
      _doSetRoutes(_routes, _places);
    });
  }

  /* ─────────────────────────────────────────────────
     헬퍼
  ───────────────────────────────────────────────── */
  function _fc(features) { return { type:'FeatureCollection', features }; }

  function _routePath(lat1, lng1, lat2, lng2, n) {
    n = n || 80;
    const dLat = lat2 - lat1;
    const dLng = lng2 - lng1;
    const archLat = Math.min(Math.abs(dLng) * 0.11, 22);
    const pts = [];
    for (let i = 0; i <= n; i++) {
      const f = i / n;
      pts.push([lat1 + dLat*f + archLat*Math.sin(f*Math.PI), lng1 + dLng*f]);
    }
    return pts;
  }

  function esc(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  window.MapManager = {
    init, setPlaces, setRoutes, focusPlace, onPlaceClick, setStyle, removePlace,
  };
})();
