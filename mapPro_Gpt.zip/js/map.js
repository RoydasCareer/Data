/* =====================================================
   map.js v3 — GeoJSON circle 레이어로 장소 핀 렌더링
   HTML marker 방식 제거 → 지리 좌표 정확도 보장
   HTML 라벨 오버레이 → 사이드바 위(z=95)에 표시
   ===================================================== */
(function () {
  'use strict';

  const TRANSPORT_ICON = {
    plane:'✈', car:'🚗', train:'🚂', bus:'🚌', ship:'🚢', bicycle:'🚲', walk:'🚶',
  };
  const TRANSPORT_SPEED = {
    plane:0.0028, car:0.0014, train:0.002, bus:0.0012, ship:0.0007, bicycle:0.0005, walk:0.0003,
  };
  const TRANSPORT_STYLE = {
    plane:  {color:'#60a5fa',weight:2.5},
    car:    {color:'#34d399',weight:2},
    train:  {color:'#f59e0b',weight:2.5},
    bus:    {color:'#a78bfa',weight:2},
    ship:   {color:'#22d3ee',weight:2},
    bicycle:{color:'#fb923c',weight:1.5},
    walk:   {color:'#f472b6',weight:1.5},
  };
  const TILE_CONFIGS = {
    dark: {
      tiles: ['https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png','https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png'],
      bgColor:'#040d21',
      fog:{'space-color':'#000010','star-intensity':0.88,'horizon-blend':0.02,'color':'rgba(14,25,50,0.75)','high-color':'#1e3a6e'},
    },
    voyager: {
      tiles: ['https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png','https://b.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png'],
      bgColor:'#ddd9ce',
      fog:{'space-color':'#0a1428','star-intensity':0.55,'horizon-blend':0.04,'color':'rgba(60,80,130,0.45)','high-color':'#2a4a8a'},
    },
    light: {
      tiles: ['https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}@2x.png','https://b.basemaps.cartocdn.com/light_all/{z}/{x}/{y}@2x.png'],
      bgColor:'#f2f2ee',
      fog:{'space-color':'#1a2a4a','star-intensity':0.42,'horizon-blend':0.05,'color':'rgba(90,110,160,0.45)','high-color':'#3a5a9a'},
    },
  };

  /* ── 상태 ── */
  let map = null;
  let mapReady = false;
  let onPlaceClickCb = null;
  let currentStyle = 'dark';

  let queuedPlaces = null;
  let queuedRoutes = null;
  let queuedPlaceArr = null;

  let _places      = [];
  let _photoCounts = {};
  let _routes      = [];

  /* ── 라벨 오버레이 (body에 fixed 포지션) ── */
  let _labelRoot = null;          // <div> fixed overlay
  const _labelEls = {};           // placeId → {el, coord:[lng,lat]}

  /* ── 경로 애니메이션 ── */
  const _animMarkers = [];
  let animFrame = null;
  let routeAnims = [];

  /* ── 팝업 ── */
  let _currentPopup = null;

  /* ─────────────────────────────────────────────────
     buildStyle: base + routes-src + places-src 포함
  ───────────────────────────────────────────────── */
  function buildStyle(name) {
    const cfg = TILE_CONFIGS[name] || TILE_CONFIGS.dark;
    return {
      version: 8,
      sources: {
        'base-tiles': {
          type: 'raster', tiles: cfg.tiles, tileSize: 256,
          attribution: '© OpenStreetMap contributors © CARTO',
        },
        'routes-src': { type: 'geojson', data: _fc([]) },
        'places-src': { type: 'geojson', data: _fc([]) },
      },
      layers: [
        { id:'bg',    type:'background', paint:{'background-color':cfg.bgColor} },
        { id:'tiles', type:'raster',     source:'base-tiles' },
        /* 경로 선 */
        {
          id:'routes-layer', type:'line', source:'routes-src',
          layout:{'line-cap':'round','line-join':'round'},
          paint:{'line-color':['get','color'],'line-width':['get','weight'],'line-opacity':0.88,'line-dasharray':[6,4]},
        },
        /* 장소 글로우 */
        {
          id:'places-glow', type:'circle', source:'places-src',
          paint:{
            'circle-radius':16,
            'circle-color':'#f59e0b',
            'circle-opacity':0.18,
            'circle-blur':0.6,
          },
        },
        /* 장소 점 — 지리 좌표에 정확히 렌더링됨 */
        {
          id:'places-dot', type:'circle', source:'places-src',
          paint:{
            'circle-radius':7,
            'circle-color':'#f59e0b',
            'circle-stroke-color':'#ffffff',
            'circle-stroke-width':2,
          },
        },
      ],
    };
  }

  /* ─────────────────────────────────────────────────
     초기화
  ───────────────────────────────────────────────── */
  function init(container) {
    return new Promise(resolve => {
      map = new maplibregl.Map({
        container,
        style:             buildStyle('dark'),
        projection:        'globe',
        center:            [127, 37],
        zoom:              1.8,
        minZoom:           0.5,
        maxZoom:           19,
        renderWorldCopies: false,
        attributionControl: false,
      });

      const safety = setTimeout(() => { _initLabelOverlay(); _onStyleReady(); resolve(); }, 10000);

      map.on('load', () => {
        clearTimeout(safety);
        _initLabelOverlay();   // 반드시 _onStyleReady() 전에 호출 (_rebuildLabels가 _labelRoot 사용)
        _onStyleReady();
        resolve();
      });

      map.on('error', err => {
        if (err.error) console.warn('[MapLibre]', err.error.message || err.error);
      });
    });
  }

  function _onStyleReady() {
    _setupMapEvents();
    _setupFog(currentStyle);
    mapReady = true;
    if (queuedPlaces !== null) {
      _doSetPlaces(queuedPlaces, _photoCounts);
      queuedPlaces = null;
    }
    if (queuedRoutes !== null) {
      _doSetRoutes(queuedRoutes, queuedPlaceArr);
      queuedRoutes = null; queuedPlaceArr = null;
    }
  }

  function _setupFog(name) {
    const fog = (TILE_CONFIGS[name] || TILE_CONFIGS.dark).fog;
    try { map.setFog(fog); } catch (_) {}
  }

  /* ─────────────────────────────────────────────────
     라벨 오버레이 (HTML, fixed, z-index 95)
  ───────────────────────────────────────────────── */
  function _initLabelOverlay() {
    if (_labelRoot) return;
    _labelRoot = document.createElement('div');
    _labelRoot.id = 'pm-labels-overlay';
    Object.assign(_labelRoot.style, {
      position:'fixed', inset:'0', pointerEvents:'none',
      overflow:'hidden',
      zIndex:'5',   // 지도 캔버스(0)보다 위, 사이드바(90)·내비(100)보다 아래
                    // → 사이드바 영역 라벨은 사이드바가 자연스럽게 가려줌
    });
    document.body.appendChild(_labelRoot);

    // 지도 이동·줌 시 라벨 위치 동기화
    map.on('move',   _syncLabelPositions);
    map.on('zoom',   _syncLabelPositions);
    map.on('rotate', _syncLabelPositions);
    map.on('pitch',  _syncLabelPositions);
  }

  function _syncLabelPositions() {
    if (!map || !_labelRoot) return;
    const rect = map.getContainer().getBoundingClientRect();
    Object.entries(_labelEls).forEach(([, info]) => {
      const pos = map.project(info.coord);
      // 라벨 하단 중앙을 점 위 18px에 위치
      info.el.style.left = `${rect.left + pos.x}px`;
      info.el.style.top  = `${rect.top  + pos.y - 18}px`;
    });
  }

  function _rebuildLabels(places) {
    if (!_labelRoot) return;
    // 삭제된 장소 라벨 제거
    const newIds = new Set((places||[]).map(p => p.id));
    Object.keys(_labelEls).forEach(id => {
      if (!newIds.has(id)) { _labelEls[id].el.remove(); delete _labelEls[id]; }
    });
    // 생성·갱신
    (places||[]).forEach(p => {
      if (p.lat == null) return;
      if (_labelEls[p.id]) {
        _labelEls[p.id].el.textContent = p.name;
        _labelEls[p.id].coord = [p.lng, p.lat];
      } else {
        const el = document.createElement('div');
        el.className = 'pm-label';
        el.textContent = p.name;
        Object.assign(el.style, {
          position:'absolute',
          transform:'translate(-50%, -100%)',
          pointerEvents:'auto', cursor:'pointer',
        });
        el.addEventListener('click', () => {
          _showPlacePopup(p);
          if (onPlaceClickCb) onPlaceClickCb(p);
        });
        _labelRoot.appendChild(el);
        _labelEls[p.id] = { el, coord:[p.lng, p.lat] };
      }
    });
    _syncLabelPositions();
  }

  /* ─────────────────────────────────────────────────
     장소 GeoJSON 업데이트
  ───────────────────────────────────────────────── */
  function setPlaces(places, photoCounts) {
    _places      = places      || [];
    _photoCounts = photoCounts || {};
    if (!mapReady) { queuedPlaces = places; return; }
    _doSetPlaces(places, _photoCounts);
  }

  function _doSetPlaces(places, photoCounts) {
    const src = map.getSource('places-src');
    if (src) {
      src.setData(_fc(
        (places||[]).filter(p => p.lat != null && p.lng != null).map(p => ({
          type:'Feature',
          geometry:{ type:'Point', coordinates:[p.lng, p.lat] },
          properties:{
            id: p.id, name: p.name,
            country: p.country||'', visitDate: p.visitDate||'', memo: p.memo||'',
            photoCount: (photoCounts||{})[p.id] || 0,
          },
        }))
      ));
    }
    _rebuildLabels(places);
  }

  function removePlace(placeId) {
    _places = _places.filter(p => p.id !== placeId);
    if (_labelEls[placeId]) { _labelEls[placeId].el.remove(); delete _labelEls[placeId]; }
    const src = map.getSource('places-src');
    if (src) _doSetPlaces(_places, _photoCounts);
  }

  /* ─────────────────────────────────────────────────
     경로 GeoJSON 업데이트
  ───────────────────────────────────────────────── */
  function setRoutes(routes, places) {
    _routes = routes || [];
    if (!mapReady) { queuedRoutes = routes; queuedPlaceArr = places; return; }
    _doSetRoutes(routes, places);
  }

  function _doSetRoutes(routes, places) {
    const src = map.getSource('routes-src');
    if (!src) return;

    const pm = {};
    (places||[]).forEach(p => { pm[p.id] = p; });

    const features = [];
    routeAnims = [];
    _clearAnimMarkers();

    (routes||[]).forEach(r => {
      const from = pm[r.fromPlaceId];
      const to   = pm[r.toPlaceId];
      if (!from||!to||from.lat==null||to.lat==null) return;

      const style = TRANSPORT_STYLE[r.transport] || TRANSPORT_STYLE.plane;
      const pts   = _routePath(from.lat, from.lng, to.lat, to.lng, 80);

      if (r.visible !== false) {
        features.push({
          type:'Feature',
          geometry:{ type:'LineString', coordinates: pts.map(([la,ln]) => [ln,la]) },
          properties:{
            color:style.color, weight:style.weight,
            transport:r.transport,
            fromName:from.name, toName:to.name,
            date:r.date||'', airline:r.airline||'', flightno:r.flightno||'', memo:r.memo||'',
          },
        });
      }

      routeAnims.push({
        pts, t:Math.random(),
        speed: TRANSPORT_SPEED[r.transport]||0.002,
        icon:  TRANSPORT_ICON[r.transport]||'🚀',
        color: style.color,
        visible: r.visible!==false,
      });
    });

    src.setData(_fc(features));
    _startAnimation();
  }

  /* ─────────────────────────────────────────────────
     교통수단 이동 애니메이션
  ───────────────────────────────────────────────── */
  function _clearAnimMarkers() {
    _animMarkers.forEach(m => m.remove());
    _animMarkers.length = 0;
    if (animFrame) { cancelAnimationFrame(animFrame); animFrame = null; }
  }

  function _startAnimation() {
    _clearAnimMarkers();
    const vis = routeAnims.filter(a => a.visible);
    if (!vis.length || !map) return;

    vis.forEach(a => {
      const el = document.createElement('div');
      el.className = 'transport-anim-icon';
      el.textContent = a.icon;
      const m = new maplibregl.Marker({ element:el, anchor:'center' })
        .setLngLat([a.pts[0][1], a.pts[0][0]])
        .addTo(map);
      _animMarkers.push(m);
      a._ref = m;
    });

    function tick() {
      vis.forEach(a => {
        a.t = (a.t + a.speed) % 1;
        const idx = Math.min(Math.floor(a.t*(a.pts.length-1)), a.pts.length-2);
        if (a._ref) a._ref.setLngLat([a.pts[idx][1], a.pts[idx][0]]);
      });
      animFrame = requestAnimationFrame(tick);
    }
    tick();
  }

  /* ─────────────────────────────────────────────────
     지도 이벤트 (클릭, 호버)
  ───────────────────────────────────────────────── */
  function _setupMapEvents() {
    // 장소 점 클릭
    map.on('click', 'places-dot', e => {
      if (!e.features.length) return;
      const props  = e.features[0].properties;
      const coords = e.features[0].geometry.coordinates;
      const place  = _places.find(p => p.id === props.id);
      if (!place) return;
      _showPlacePopup(place, coords);
      if (onPlaceClickCb) onPlaceClickCb(place);
    });

    // 경로 선 클릭
    map.on('click', 'routes-layer', e => {
      if (!e.features.length) return;
      const p    = e.features[0].properties;
      const icon = TRANSPORT_ICON[p.transport] || '🚀';
      let html = `<div class="map-popup"><strong>${icon} ${esc(p.fromName)} → ${esc(p.toName)}</strong>`;
      if (p.date)    html += `<br><small>📅 ${p.date}</small>`;
      if (p.airline) html += `<br><small>✈ ${esc(p.airline)}${p.flightno?' '+esc(p.flightno):''}</small>`;
      if (p.memo)    html += `<br><small>📝 ${esc(p.memo)}</small>`;
      html += '</div>';
      new maplibregl.Popup({ closeButton:true, maxWidth:'300px' })
        .setLngLat(e.lngLat).setHTML(html).addTo(map);
    });

    // 커서
    ['places-dot','places-glow'].forEach(id => {
      map.on('mouseenter', id, () => { map.getCanvas().style.cursor = 'pointer'; });
      map.on('mouseleave', id, () => { map.getCanvas().style.cursor = ''; });
    });
    map.on('mouseenter', 'routes-layer', () => { map.getCanvas().style.cursor = 'pointer'; });
    map.on('mouseleave', 'routes-layer', () => { map.getCanvas().style.cursor = ''; });
  }

  function _showPlacePopup(place, coords) {
    if (_currentPopup) { _currentPopup.remove(); _currentPopup = null; }

    let html = `<div class="map-popup"><strong>${esc(place.name)}</strong>`;
    if (place.country)   html += `<br><span>${esc(place.country)}</span>`;
    if (place.visitDate) html += `<br><small>📅 ${place.visitDate}</small>`;
    if (place.memo)      html += `<br><small>📝 ${esc(place.memo)}</small>`;
    html += `<br><button class="map-popup-photo-btn">📷 사진 보기</button></div>`;

    const lngLat = coords || [place.lng, place.lat];
    _currentPopup = new maplibregl.Popup({ closeButton:true, maxWidth:'280px', offset:10 })
      .setLngLat(lngLat)
      .setHTML(html);

    _currentPopup.once('open', () => {
      const btn = _currentPopup.getElement()?.querySelector('.map-popup-photo-btn');
      if (btn) btn.addEventListener('click', () => {
        if (window.PhotosUI) PhotosUI.openForPlace(place);
      });
    });

    _currentPopup.addTo(map);
  }

  /* ─────────────────────────────────────────────────
     공개 API
  ───────────────────────────────────────────────── */
  function focusPlace(place, zoom) {
    if (!map || place.lat == null) return;
    map.flyTo({ center:[place.lng, place.lat], zoom: zoom||10, duration:1200 });
  }

  function onPlaceClick(cb) { onPlaceClickCb = cb; }

  /* 스타일 전환
     style.load 이벤트 타이밍에 의존하지 않음 —
     GeoJSON 소스가 실제로 맵에 등록될 때까지 rAF 폴링 후 데이터 재주입 */
  function setStyle(name) {
    if (!map || !TILE_CONFIGS[name] || name === currentStyle) return;
    currentStyle = name;
    _clearAnimMarkers();

    map.setStyle(buildStyle(name));

    let rafId;
    let tries = 0;
    function waitForSources() {
      tries++;
      const rSrc = map.getSource('routes-src');
      const pSrc = map.getSource('places-src');
      if (rSrc && pSrc) {
        cancelAnimationFrame(rafId);
        _setupMapEvents();
        _setupFog(name);
        _doSetPlaces(_places, _photoCounts);
        _doSetRoutes(_routes, _places);
      } else if (tries < 300) {            // 최대 ~5초 (60fps 기준)
        rafId = requestAnimationFrame(waitForSources);
      }
    }
    rafId = requestAnimationFrame(waitForSources);
  }

  /* ─────────────────────────────────────────────────
     헬퍼
  ───────────────────────────────────────────────── */
  function _fc(features) { return { type:'FeatureCollection', features }; }

  function _routePath(lat1, lng1, lat2, lng2, n) {
    n = n || 80;
    const dLat = lat2 - lat1;
    const dLng = lng2 - lng1;   // 시각 방향 그대로 (날짜변경선 미보정)
    const archLat = Math.min(Math.abs(dLng) * 0.11, 22);
    const pts = [];
    for (let i = 0; i <= n; i++) {
      const f = i / n;
      pts.push([lat1 + dLat*f + archLat*Math.sin(f*Math.PI), lng1 + dLng*f]);
    }
    return pts;
  }

  function esc(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  window.MapManager = {
    init, setPlaces, setRoutes, focusPlace, onPlaceClick, setStyle, removePlace,
  };
})();
