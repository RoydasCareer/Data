/* =====================================================
   app.js — 앱 초기화, 토스트, 통계, 내보내기/가져오기
   ===================================================== */
(function () {
  'use strict';

  /* ─── 토스트 시스템 ─── */
  function showToast(msg, type = 'info', duration = 3800) {
    const container = document.getElementById('toast-container');
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    // 텍스트만 사용하여 XSS 방지
    el.textContent = msg;
    container.appendChild(el);
    setTimeout(() => {
      el.classList.add('toast-out');
      setTimeout(() => el.remove(), 230);
    }, duration);
  }
  window.showToast = showToast;

  /* ─── 탭 전환 ─── */
  function openTab(name) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    const btn = document.querySelector(`.tab-btn[data-tab="${name}"]`);
    const tab = document.getElementById(`tab-${name}`);
    if (btn) btn.classList.add('active');
    if (tab) tab.classList.add('active');
  }

  /* ─── 사이드바 ─── */
  function showSidebar() { document.getElementById('sidebar').classList.remove('hidden'); }
  function hideSidebar() { document.getElementById('sidebar').classList.add('hidden');    }

  /* ─── 모달 백드롭 닫기 ─── */
  function bindBackdrops() {
    document.querySelectorAll('.modal-backdrop').forEach(bd => {
      bd.addEventListener('click', () => bd.closest('.modal').classList.add('hidden'));
    });
  }

  /* ─── 키보드 단축키 ─── */
  function bindKeyboard() {
    document.addEventListener('keydown', e => {
      // ESC는 입력 중에도 항상 모달/뷰어 닫기
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal:not(.hidden)').forEach(m => m.classList.add('hidden'));
        document.getElementById('photo-viewer').classList.add('hidden');
        return;
      }
      // 나머지 단축키는 입력 필드에서 비활성화
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
      if (e.key === 'p' || e.key === 'P') PlacesUI.openAddModal();
      if (e.key === 'r' || e.key === 'R') RoutesUI.openAddModal();
      if (e.key === 't' || e.key === 'T') document.getElementById('sidebar').classList.toggle('hidden');
    });
  }

  /* ─── 지도 스타일 전환 ─── */
  function bindStyleBtns() {
    document.querySelectorAll('.style-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.style;
        MapManager.setStyle(name);
        document.querySelectorAll('.style-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const labels = { bright: '🌍 내추럴', positron: '☀️ 라이트', liberty: '🗺 클래식' };
        showToast(`지도 스타일: ${labels[name] || name}`, 'info');
      });
    });
  }

  /* ─── 내보내기 / 가져오기 ─── */
  function bindIO() {
    document.getElementById('btn-export').addEventListener('click', async () => {
      try {
        showToast('내보내기 준비 중...', 'info');
        const json = await AppData.exportData();
        const blob = new Blob([json], { type: 'application/json' });
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href     = url;
        a.download = `globetravel-${new Date().toISOString().slice(0,10)}.json`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 10000);
        showToast('✅ 내보내기 완료!', 'success');
      } catch (e) {
        showToast('내보내기 실패: ' + e.message, 'error');
      }
    });

    const importInput = document.getElementById('import-input');
    document.getElementById('btn-import').addEventListener('click', () => importInput.click());
    importInput.addEventListener('change', async e => {
      const file = e.target.files[0];
      if (!file) return;
      e.target.value = '';

      let data;
      try {
        data = JSON.parse(await file.text());
        if (!Array.isArray(data.places) || !Array.isArray(data.routes)) throw new Error('올바른 형식이 아닙니다.');
      } catch (err) {
        showToast('가져오기 실패: ' + err.message, 'error');
        return;
      }

      const msg = `가져오기 시 현재 데이터가 모두 교체됩니다.\n\n장소 ${data.places.length}개 · 사진 ${data.photos?.length||0}장 · 경로 ${data.routes.length}개\n\n계속하시겠습니까?`;
      if (!confirm(msg)) return;

      try {
        showToast('가져오는 중...', 'info');
        await AppData.importData(JSON.stringify(data));
        await PlacesUI.refresh();
        await RoutesUI.refresh();
        showToast(`✅ 가져오기 완료! 장소 ${data.places.length}개 · 사진 ${data.photos?.length||0}장 · 경로 ${data.routes.length}개`, 'success');
      } catch (err) {
        showToast('가져오기 실패: ' + err.message, 'error');
      }
    });
  }

  /* ─── 샘플 데이터 ─── */
  const SAMPLE_DATA = {
    places: [
      { id: 'p-icn', name: '인천국제공항',       country: '대한민국', lat: 37.4602,  lng: 126.4407,  visitDate: '2024-01-15', memo: '여행의 시작점' },
      { id: 'p-bkk', name: '방콕 수완나품 공항', country: '태국',     lat: 13.6811,  lng: 100.7472,  visitDate: '2024-01-15', memo: '비엣젯 타고 도착' },
      { id: 'p-nrt', name: '도쿄 나리타 공항',   country: '일본',     lat: 35.7720,  lng: 140.3929,  visitDate: '2024-03-10', memo: '벚꽃 시즌 방문' },
      { id: 'p-cdg', name: '파리 샤를드골 공항', country: '프랑스',   lat: 49.0097,  lng: 2.5479,    visitDate: '2024-06-05', memo: '에어프랑스 AF267' },
      { id: 'p-lhr', name: '런던 히드로 공항',   country: '영국',     lat: 51.4700,  lng: -0.4543,   visitDate: '2024-06-08', memo: '유로스타로 이동' },
      { id: 'p-jfk', name: '뉴욕 JFK 공항',      country: '미국',     lat: 40.6413,  lng: -73.7781,  visitDate: '2024-08-20', memo: '브리티시 에어웨이즈' },
      { id: 'p-syd', name: '시드니 공항',         country: '호주',     lat: -33.9399, lng: 151.1753,  visitDate: '2024-10-12', memo: '콴타스 항공' },
    ],
    routes: [
      { id: 'r-1', fromPlaceId: 'p-icn', toPlaceId: 'p-bkk', transport: 'plane', airline: '비엣젯',         flightno: 'VZ869', date: '2024-01-15', memo: '약 6시간', visible: true },
      { id: 'r-2', fromPlaceId: 'p-bkk', toPlaceId: 'p-nrt', transport: 'plane', airline: '타이항공',       flightno: 'TG682', date: '2024-03-10', memo: '',       visible: true },
      { id: 'r-3', fromPlaceId: 'p-nrt', toPlaceId: 'p-cdg', transport: 'plane', airline: '에어프랑스',     flightno: 'AF267', date: '2024-06-05', memo: '12시간',  visible: true },
      { id: 'r-4', fromPlaceId: 'p-cdg', toPlaceId: 'p-lhr', transport: 'train', airline: '',               flightno: '',      date: '2024-06-08', memo: '유로스타 2시간 15분', visible: true },
      { id: 'r-5', fromPlaceId: 'p-lhr', toPlaceId: 'p-jfk', transport: 'plane', airline: 'British Airways', flightno: 'BA175', date: '2024-08-20', memo: '7시간',  visible: true },
      { id: 'r-6', fromPlaceId: 'p-jfk', toPlaceId: 'p-icn', transport: 'plane', airline: '대한항공',       flightno: 'KE082', date: '2024-08-28', memo: '14시간', visible: true },
      { id: 'r-7', fromPlaceId: 'p-icn', toPlaceId: 'p-syd', transport: 'plane', airline: '콴타스',         flightno: 'QF64',  date: '2024-10-12', memo: '10시간', visible: true },
    ],
  };

  async function loadSampleData() {
    for (const p of SAMPLE_DATA.places) await AppData.savePlace(p);
    for (const r of SAMPLE_DATA.routes)  await AppData.saveRoute(r);
  }

  /* ─── 로딩 오버레이 ─── */
  function hideLoading() {
    const el = document.getElementById('loading-overlay');
    if (!el) return;
    el.classList.add('fadeout');
    setTimeout(() => el.remove(), 450);
  }

  /* ─── 앱 초기화 ─── */
  async function init() {
    /* 탭 전환 */
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => openTab(btn.dataset.tab));
    });

    /* 사이드바 */
    document.getElementById('btn-toggle-sidebar').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('hidden');
    });
    document.getElementById('btn-close-sidebar').addEventListener('click', hideSidebar);

    bindBackdrops();
    bindKeyboard();
    bindStyleBtns();
    bindIO();

    /* 모듈 초기화 */
    PlacesUI.init();
    PhotosUI.init();
    RoutesUI.init();

    /* 지구본 마커 클릭 → 사이드바 강조
       (사진은 팝업의 "사진 보기" 버튼이나 사이드바 📷 버튼으로 진입) */
    MapManager.onPlaceClick(place => {
      const sidebar = document.getElementById('sidebar');
      if (sidebar.classList.contains('hidden')) return;
      setTimeout(() => {
        const item = document.querySelector(`.place-item[data-id="${place.id}"]`);
        if (item) {
          document.querySelectorAll('.place-item').forEach(x => x.classList.remove('selected'));
          item.classList.add('selected');
          item.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }, 60);
    });

    /* 첫 실행: 샘플 데이터 */
    const hasData = await AppData.hasData();
    if (!hasData) await loadSampleData();

    /* 초기 데이터 렌더링 */
    try {
      await PlacesUI.refresh();
      await RoutesUI.refresh();
    } catch (err) {
      console.error('초기 렌더링 오류:', err);
    }

    /* 지도 초기화 */
    try {
      await MapManager.init(document.getElementById('map-container'));
    } catch (err) {
      console.error('지도 초기화 실패:', err);
      showToast('지도 로딩 실패. 인터넷 연결을 확인하세요.', 'error');
    }

    hideLoading();
    showSidebar();

    if (!hasData) {
      showToast('🌍 GlobeTravel Log에 오신 것을 환영합니다! (샘플 데이터 로드됨)', 'info', 5000);
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
