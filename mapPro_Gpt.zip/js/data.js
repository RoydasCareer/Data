/* =====================================================
   data.js — 데이터 레이어 (localforage / IndexedDB)
   ===================================================== */
(function () {
  'use strict';

  const KEY_PLACES = 'gtl_places_v2';
  const KEY_PHOTOS  = 'gtl_photos_v2';
  const KEY_ROUTES  = 'gtl_routes_v2';

  function uuid() {
    if (crypto && crypto.randomUUID) return crypto.randomUUID();
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
  }

  async function loadAll(key) {
    return (await localforage.getItem(key)) || [];
  }
  async function saveAll(key, arr) {
    await localforage.setItem(key, arr);
  }

  /* ─── PLACES ─── */
  async function getPlaces() { return loadAll(KEY_PLACES); }

  async function savePlace(place) {
    const list = await getPlaces();
    if (!place.id) {
      place.id = uuid();
      place.createdAt = Date.now();
      list.push(place);
    } else {
      const idx = list.findIndex(p => p.id === place.id);
      if (idx >= 0) list[idx] = place; else list.push(place);
    }
    await saveAll(KEY_PLACES, list);
    return place;
  }

  async function deletePlace(id) {
    await saveAll(KEY_PLACES, (await getPlaces()).filter(p => p.id !== id));
    // 해당 장소 사진을 미지정으로 전환
    const photos = await loadAll(KEY_PHOTOS);
    await saveAll(KEY_PHOTOS, photos.map(ph => ph.placeId === id ? { ...ph, placeId: null } : ph));
    // 해당 장소 포함 경로 삭제
    await saveAll(KEY_ROUTES, (await loadAll(KEY_ROUTES)).filter(r => r.fromPlaceId !== id && r.toPlaceId !== id));
  }

  /* ─── PHOTOS ─── */
  async function getPhotos(placeId) {
    const all = await loadAll(KEY_PHOTOS);
    return placeId !== undefined ? all.filter(ph => ph.placeId === placeId) : all;
  }

  async function savePhoto(photo) {
    const list = await loadAll(KEY_PHOTOS);
    if (!photo.id) {
      photo.id = uuid();
      photo.createdAt = Date.now();
      list.push(photo);
    } else {
      const idx = list.findIndex(p => p.id === photo.id);
      if (idx >= 0) list[idx] = photo; else list.push(photo);
    }
    await saveAll(KEY_PHOTOS, list);
    return photo;
  }

  async function deletePhoto(id) {
    await saveAll(KEY_PHOTOS, (await loadAll(KEY_PHOTOS)).filter(p => p.id !== id));
  }

  /* ─── ROUTES ─── */
  async function getRoutes() { return loadAll(KEY_ROUTES); }

  async function saveRoute(route) {
    const list = await getRoutes();
    if (!route.id) {
      route.id = uuid();
      route.createdAt = Date.now();
      list.push(route);
    } else {
      const idx = list.findIndex(r => r.id === route.id);
      if (idx >= 0) list[idx] = route; else list.push(route);
    }
    await saveAll(KEY_ROUTES, list);
    return route;
  }

  async function deleteRoute(id) {
    await saveAll(KEY_ROUTES, (await getRoutes()).filter(r => r.id !== id));
  }

  async function hasData() {
    return (await getPlaces()).length > 0;
  }

  /* ─── 내보내기 / 가져오기 ─── */
  async function exportData() {
    const [places, photos, routes] = await Promise.all([getPlaces(), getPhotos(), getRoutes()]);
    return JSON.stringify({
      _app: 'GlobeTravelLog',
      _version: 2,
      _exportedAt: new Date().toISOString(),
      places, photos, routes,
    });
  }

  async function importData(jsonStr) {
    const data = JSON.parse(jsonStr);
    if (!Array.isArray(data.places) || !Array.isArray(data.routes))
      throw new Error('잘못된 형식입니다. GlobeTravel Log 내보내기 파일을 사용하세요.');
    await saveAll(KEY_PLACES, data.places || []);
    await saveAll(KEY_PHOTOS, data.photos || []);
    await saveAll(KEY_ROUTES, data.routes || []);
  }

  /* ─── Haversine 거리 계산 (km) ─── */
  function haversine(lat1, lng1, lat2, lng2) {
    const R = 6371, r = Math.PI / 180;
    const dLat = (lat2 - lat1) * r, dLng = (lng2 - lng1) * r;
    const a = Math.sin(dLat/2)**2 + Math.cos(lat1*r)*Math.cos(lat2*r)*Math.sin(dLng/2)**2;
    return R * 2 * Math.asin(Math.sqrt(a));
  }

  window.AppData = {
    uuid, haversine,
    getPlaces, savePlace, deletePlace,
    getPhotos,  savePhoto,  deletePhoto,
    getRoutes,  saveRoute,  deleteRoute,
    hasData, exportData, importData,
  };
})();
