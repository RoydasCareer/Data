"""UX 시나리오 점검: 실제 사용자 관점에서 어색한 점 탐색"""
import time
from playwright.sync_api import sync_playwright

URL = "http://localhost:8765"

def run():
    issues = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(viewport={"width": 1400, "height": 900})
        page = ctx.new_page()
        page.goto(URL)
        page.wait_for_selector("#loading-overlay", state="detached", timeout=15000)
        page.wait_for_timeout(1000)

        print("=== UX/UI 점검 ===\n")

        # ── UX 1: 지구본 마커 클릭 시 사진 모달이 바로 열리는가? ──────────
        print("[UX-1] 지구본 마커 클릭 → 무슨 일이 일어나나?")
        # 장소 아이템 클릭 (사이드바에서)
        first_place = page.locator(".place-item").first
        first_place.click()
        page.wait_for_timeout(800)
        photo_modal_open = not page.locator("#modal-photos").evaluate("el => el.classList.contains('hidden')")
        sidebar_selected = page.locator(".place-item.selected").count() > 0
        print(f"  사이드바 아이템 클릭 → 사진 모달 자동 열림: {photo_modal_open}")
        print(f"  사이드바 아이템 선택(highlight): {sidebar_selected}")
        if photo_modal_open:
            issues.append("❌ [UX-1] 장소 클릭 시 사진 모달이 자동으로 열려 놀람 — 클릭은 지도 이동만, 사진은 📷 버튼으로 진입해야 자연스러움")
        else:
            print("  ✅ 사진 모달 자동 열림 없음")
        page.keyboard.press("Escape")
        page.wait_for_timeout(300)
        page.screenshot(path="/tmp/ux1_place_click.png")

        # ── UX 2: 경로 추가 — 검색 후 클릭 없이 저장 시도 ────────────────
        print("\n[UX-2] 경로 추가 — 검색어만 입력하고 저장 버튼 누르면?")
        page.click("#btn-add-route")
        page.wait_for_selector("#modal-route:not(.hidden)", timeout=3000)
        page.fill("#route-from-input", "서울")
        page.wait_for_timeout(200)  # 드롭다운 기다리지 않고 바로 저장
        page.fill("#route-to-input", "도쿄")
        page.wait_for_timeout(200)
        page.click("#btn-save-route")
        page.wait_for_timeout(500)
        modal_still_open = not page.locator("#modal-route").evaluate("el => el.classList.contains('hidden')")
        print(f"  검색어만 입력(드롭다운 미선택) 후 저장 → 모달 유지: {modal_still_open}")
        if not modal_still_open:
            issues.append("❌ [UX-2] 출발지/도착지를 드롭다운에서 선택하지 않아도 저장 가능 — 빈 경로 생성 위험")
        else:
            print("  ✅ 미선택 상태에서 저장 차단됨")
        # toast 메시지 확인
        toast_text = ""
        if page.locator(".toast").count() > 0:
            toast_text = page.locator(".toast").first.text_content()
        print(f"  토스트 메시지: '{toast_text}'")
        page.keyboard.press("Escape")
        page.wait_for_timeout(300)

        # ── UX 3: 장소 모달 — 두 개의 이름 입력 필드 혼란 ──────────────────
        print("\n[UX-3] 장소 추가 모달 — '장소 검색'과 '장소명' 두 필드의 관계가 명확한가?")
        page.click("#btn-add-place")
        page.wait_for_selector("#modal-place:not(.hidden)", timeout=3000)
        geocode_label = page.locator("label[for='geocode-input'], label:has(+ .geocode-wrap)").first.text_content() if page.locator("label:has(+ .geocode-wrap)").count() > 0 else "(없음)"
        place_name_label = page.locator("label[for='place-name']").text_content()
        print(f"  검색 필드 레이블: '{geocode_label.strip()}'")
        print(f"  장소명 필드 레이블: '{place_name_label.strip()}'")
        # 검색 필드에 입력했을 때 장소명이 자동 채워지는지
        page.fill("#geocode-input", "Tokyo")
        page.wait_for_timeout(1500)
        dropdown_visible = page.locator("#geocode-results:not(.hidden)").count() > 0
        print(f"  검색 드롭다운 표시: {dropdown_visible}")
        if dropdown_visible:
            page.locator("#geocode-results .geocode-item").first.click()
            page.wait_for_timeout(300)
            auto_filled_name = page.locator("#place-name").input_value()
            auto_filled_lat  = page.locator("#place-lat").input_value()
            print(f"  드롭다운 선택 후 장소명 자동입력: '{auto_filled_name}'")
            print(f"  위도 자동입력: '{auto_filled_lat}'")
            if auto_filled_name:
                print("  ✅ 검색 → 자동입력 연동 정상")
            else:
                issues.append("❌ [UX-3] 검색 결과 선택 후 장소명이 자동입력되지 않음")
        page.screenshot(path="/tmp/ux3_place_modal.png")
        page.keyboard.press("Escape")
        page.wait_for_timeout(300)

        # ── UX 4: 숨김 경로의 선(라인)도 지도에서 사라지는가? ────────────
        print("\n[UX-4] 경로 숨김 토글 — 지도 선도 사라지나?")
        page.click('.tab-btn[data-tab="routes"]')
        page.wait_for_timeout(500)
        route_items = page.locator(".route-item").count()
        print(f"  경로 총 {route_items}개")
        if route_items > 0:
            toggle_btn = page.locator(".route-item").first.locator(".eye-toggle")
            toggle_btn.click()
            page.wait_for_timeout(500)
            hidden_class = page.locator(".route-item").first.evaluate("el => el.classList.contains('hidden-route')")
            print(f"  첫 번째 경로 숨김 CSS 적용: {hidden_class}")
            page.screenshot(path="/tmp/ux4_route_hidden.png")
            # 다시 표시
            toggle_btn.click()
            page.wait_for_timeout(300)
        else:
            print("  경로 없음 (건너뜀)")

        # ── UX 5: 모바일 뷰포트에서 UI 점검 ─────────────────────────────
        print("\n[UX-5] 모바일 뷰포트 (390×844) — 레이아웃 확인")
        ctx2 = browser.new_context(viewport={"width": 390, "height": 844})
        page2 = ctx2.new_page()
        page2.goto(URL)
        page2.wait_for_selector("#loading-overlay", state="detached", timeout=15000)
        page2.wait_for_timeout(1000)
        page2.screenshot(path="/tmp/ux5_mobile.png")
        sidebar_visible = not page2.locator("#sidebar").evaluate("el => el.classList.contains('hidden')")
        add_btn_visible = page2.locator("#btn-add-place").is_visible()
        print(f"  사이드바 초기 표시: {sidebar_visible}")
        print(f"  '장소 추가' 버튼 표시: {add_btn_visible}")
        if not add_btn_visible:
            issues.append("⚠️  [UX-5] 모바일에서 '장소 추가' 버튼이 숨겨짐 — 사이드바에서만 접근 가능 (의도적이나 첫 진입 시 혼란)")
        ctx2.close()

        # ── UX 6: 장소 삭제 확인 다이얼로그 ─────────────────────────────
        print("\n[UX-6] 장소 삭제 흐름")
        page.click('.tab-btn[data-tab="places"]')
        page.wait_for_timeout(300)
        # 삭제 버튼 hover 시 나타나는지
        first_item = page.locator(".place-item").first
        first_item.hover()
        page.wait_for_timeout(300)
        delete_visible = first_item.locator('[data-action="delete"]').is_visible()
        print(f"  hover 시 삭제 버튼 표시: {delete_visible}")
        if delete_visible:
            print("  ✅ 삭제 버튼은 hover에서만 노출 (안전)")
        else:
            issues.append("⚠️  [UX-6] hover 시에도 삭제 버튼이 안 보임")

        # ── UX 7: 사진 없는 장소의 📷 버튼 ──────────────────────────────
        print("\n[UX-7] 사진이 없는 장소의 📷 버튼 클릭")
        first_item.locator('[data-action="photos"]').click()
        page.wait_for_timeout(500)
        photo_modal = not page.locator("#modal-photos").evaluate("el => el.classList.contains('hidden')")
        if photo_modal:
            grid_content = page.locator("#photo-grid").inner_text()
            print(f"  사진 없는 장소 → 빈 갤러리 모달 열림: ✅")
            print(f"  빈 상태 메시지: '{grid_content[:60]}'")
        page.keyboard.press("Escape")
        page.wait_for_timeout(300)

        # ── UX 8: 통계 탭 — 데이터 없을 때 ────────────────────────────
        print("\n[UX-8] 통계 바 차트 가시성")
        page.click('.tab-btn[data-tab="stats"]')
        page.wait_for_timeout(300)
        transport_visible = page.locator("#section-transport").is_visible()
        years_visible     = page.locator("#section-years").is_visible()
        print(f"  교통수단 섹션 표시: {transport_visible}")
        print(f"  연도별 섹션 표시: {years_visible}")
        page.screenshot(path="/tmp/ux8_stats_full.png")

        # ── 최종 정리 ───────────────────────────────────────────────────
        print("\n" + "="*50)
        print("발견된 UX 이슈:")
        if issues:
            for iss in issues:
                print(f"  {iss}")
        else:
            print("  없음")

        browser.close()

if __name__ == "__main__":
    run()
