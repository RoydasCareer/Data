"""최종 확인: 줌인 상태에서 마커 위치 고정 + 세계 경계 제한"""
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    ctx = b.new_context(viewport={"width": 1440, "height": 900})
    pg = ctx.new_page()
    pg.goto("http://localhost:8765")
    pg.wait_for_selector("#loading-overlay", state="detached", timeout=15000)
    pg.wait_for_timeout(3000)
    pg.screenshot(path="/tmp/final_zoom1.png")

    # 한국/일본 지역으로 줌인 (zoom ~5 — 지도 타일 명확히 보이는 수준)
    pg.mouse.move(700, 450)
    for _ in range(6):
        pg.mouse.wheel(0, -200)   # wheel(delta_x, delta_y)
        pg.wait_for_timeout(100)
    pg.wait_for_timeout(1200)
    pg.screenshot(path="/tmp/final_zoom2_in.png")

    # 줌인 상태에서 마커 위치 확인
    m1 = pg.evaluate("""() => {
        const m = document.querySelector('.place-marker-wrap');
        return m ? Math.round(m.getBoundingClientRect().left) : null;
    }""")
    print(f"줌인 후 마커 x: {m1}")

    # 좌로 드래그 (동쪽으로 팬)
    pg.mouse.move(700, 450)
    pg.mouse.down()
    pg.mouse.move(400, 450, steps=10)
    pg.mouse.up()
    pg.wait_for_timeout(800)

    m2 = pg.evaluate("""() => {
        const m = document.querySelector('.place-marker-wrap');
        return m ? Math.round(m.getBoundingClientRect().left) : null;
    }""")
    print(f"드래그(-300px) 후 마커 x: {m2}")
    pg.screenshot(path="/tmp/final_zoom3_panned.png")

    if m1 is not None and m2 is not None:
        dx = m2 - m1
        print(f"이동량: {dx}px")
        if abs(dx) > 80:
            print("✅ 줌인 상태에서 마커가 지도와 함께 이동 (지리 좌표에 고정)")
        else:
            print("⚠️  마커가 거의 이동하지 않음")

    # 오른쪽으로 세계 경계 너머 팬 시도 (1200px 이동)
    pg.mouse.move(200, 450)
    pg.mouse.down()
    pg.mouse.move(1400, 450, steps=20)
    pg.mouse.up()
    pg.wait_for_timeout(800)
    pg.screenshot(path="/tmp/final_zoom4_boundary.png")
    print("경계 너머 팬 시도 완료 → /tmp/final_zoom4_boundary.png")

    b.close()
