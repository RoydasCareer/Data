@echo off
REM ─────────────────────────────────────────────────────
REM  Windows Task Scheduler 등록 스크립트
REM  관리자 권한으로 실행하거나, 일반 권한도 /ru "" 옵션으로 가능
REM  실행: schedule_setup.bat (더블클릭 또는 cmd)
REM ─────────────────────────────────────────────────────

set SCRIPT_DIR=%~dp0
set PYTHON=python
set TASK_NAME=AutomotiveNewsDigest

echo [1/2] 기존 태스크 삭제 (없으면 무시)...
schtasks /delete /tn "%TASK_NAME%" /f 2>nul

echo [2/2] 태스크 등록 (매일 07:00)...
schtasks /create ^
  /tn "%TASK_NAME%" ^
  /tr "%PYTHON% \"%SCRIPT_DIR%main.py\"" ^
  /sc DAILY ^
  /st 07:00 ^
  /sd %date% ^
  /f

echo.
echo 완료. 확인:
schtasks /query /tn "%TASK_NAME%"
pause
