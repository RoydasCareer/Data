#!/usr/bin/env python3
"""
뉴스 다이제스트 전체 검증 테스트
API 키 불필요 — LLM은 mock으로 대체

Usage: python test.py
"""
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

# ── 항상 news_digest 디렉토리 기준으로 실행 ─────────────
HERE = Path(__file__).resolve().parent
os.chdir(HERE)
sys.path.insert(0, str(HERE))

# ── config를 테스트용으로 오버라이드 (임포트 전에) ───────
import config
config.LLM_MODE    = 'claude'
config.LLM_MODEL   = 'claude-haiku-4-5'
config.ANTHROPIC_API_KEY = 'sk-ant-mock-key'
config.OUTPUT_DIR  = tempfile.mkdtemp(prefix='digest_test_')
config.NOTIFY_METHODS = ['file']

import main
import llm
from notify import notify
from datetime import datetime as _ndt


# ════════════════════════════════════════════════════════
# 1. 기업 리스트 로드
# ════════════════════════════════════════════════════════
class T1_LoadCompanies(unittest.TestCase):

    def test_count(self):
        companies = main.load_companies()
        self.assertGreater(len(companies), 700)
        print(f'\n    기업 수: {len(companies)}개')

    def test_known_companies_exist(self):
        companies = main.load_companies()
        for name in ['Hyundai Motor Group', 'Tesla', 'BMW Group', 'Continental']:
            self.assertIn(name, companies, f'"{name}" 누락')

    def test_no_empty_or_dash(self):
        companies = main.load_companies()
        for c in companies:
            self.assertTrue(c.strip(), f'빈 이름: "{c}"')
            self.assertFalse(c.startswith('- '), f'"- " 미제거: "{c}"')

    def test_works_from_different_cwd(self):
        """다른 디렉토리에서 실행해도 company_list.md를 찾아야 함"""
        original = os.getcwd()
        try:
            os.chdir(tempfile.gettempdir())
            companies = main.load_companies()
            self.assertGreater(len(companies), 700)
        finally:
            os.chdir(original)


# ════════════════════════════════════════════════════════
# 2. 키워드 프리필터
# ════════════════════════════════════════════════════════
class T2_KeywordFilter(unittest.TestCase):

    def _e(self, title, summary=''):
        return {'title': title, 'summary': summary}

    def test_ivi_hit(self):
        hits = main.keyword_hits(self._e('Hyundai launches new IVI system'))
        self.assertIn('IVI', hits)

    def test_uds_hit(self):
        hits = main.keyword_hits(self._e('Continental UDS diagnostic update'))
        self.assertIn('UDS', hits)

    def test_ev_hit(self):
        hits = main.keyword_hits(self._e('Samsung SDI battery BMS breakthrough'))
        self.assertTrue(any(k in hits for k in ('BMS', 'battery')))

    def test_no_hit_irrelevant(self):
        hits = main.keyword_hits(self._e('Seoul weather forecast for tomorrow'))
        self.assertEqual(hits, [])

    def test_case_insensitive(self):
        hits = main.keyword_hits(self._e('new ivi platform'))
        self.assertIn('IVI', hits)

    def test_summary_also_scanned(self):
        hits = main.keyword_hits(self._e('Company news', 'Details about DoIP protocol'))
        self.assertIn('DoIP', hits)


# ════════════════════════════════════════════════════════
# 3. LLM 응답 파싱
# ════════════════════════════════════════════════════════
class T3_LLMParsing(unittest.TestCase):

    def test_normal(self):
        s, r = llm._parse('SCORE: 8\nREASON: Directly relevant to IVI validation')
        self.assertEqual(s, 8)
        self.assertIn('IVI', r)

    def test_lowercase(self):
        s, r = llm._parse('score: 5\nreason: Automotive domain')
        self.assertEqual(s, 5)

    def test_pipe_format(self):
        s, r = llm._parse('SCORE: 7 | REASON: Matches cybersecurity background')
        self.assertEqual(s, 7)

    def test_clamp_max(self):
        s, _ = llm._parse('SCORE: 99\nREASON: Too high')
        self.assertLessEqual(s, 10)

    def test_clamp_min(self):
        s, _ = llm._parse('SCORE: -5\nREASON: Negative')
        self.assertGreaterEqual(s, 0)

    def test_malformed_returns_zero(self):
        s, r = llm._parse('I think this article is great')
        self.assertEqual(s, 0)
        self.assertEqual(r, '')

    def test_extra_whitespace(self):
        s, _ = llm._parse('  SCORE:   9  \n  REASON:   Test  ')
        self.assertEqual(s, 9)


# ════════════════════════════════════════════════════════
# 4. 기사 정규화
# ════════════════════════════════════════════════════════
class T4_Normalize(unittest.TestCase):

    def test_basic_fields(self):
        entry = {
            'title': 'Test Article',
            'link': 'https://example.com',
            'summary': 'A' * 500,  # 500자 → 400자로 잘려야 함
            'source': {'title': 'Reuters'},
            'published': '2026-08-05T10:00:00Z',
        }
        a = main.normalize(entry)
        self.assertEqual(a['title'], 'Test Article')
        self.assertEqual(a['link'], 'https://example.com')
        self.assertLessEqual(len(a['snippet']), 400)
        self.assertEqual(a['src'], 'Reuters')
        self.assertEqual(a['pub'], '2026-08-05T10:00')

    def test_missing_fields_no_crash(self):
        a = main.normalize({})
        self.assertEqual(a['title'], '')
        self.assertEqual(a['link'], '#')
        self.assertEqual(a['src'], '')


# ════════════════════════════════════════════════════════
# 5. 파일 출력
# ════════════════════════════════════════════════════════
class T5_OutputFile(unittest.TestCase):

    def _sample_articles(self):
        return [
            {'title': 'Hyundai IVI OTA Update Released',
             'link': 'https://example.com/1',
             'src': 'Reuters', 'pub': '2026-08-05',
             'score': 9, 'reason': 'Directly matches IVI validation work'},
            {'title': 'JLR DoIP Diagnostic Toolchain',
             'link': 'https://example.com/2',
             'src': 'Automotive News', 'pub': '2026-08-05',
             'score': 8, 'reason': 'DoIP is core expertise'},
        ]

    def _today_path(self) -> Path:
        return Path(config.OUTPUT_DIR) / f'digest_{_ndt.now():%Y-%m-%d}.md'

    def test_file_created(self):
        high = self._sample_articles()
        mid  = [{'title': 'EV Battery Tech', 'link': 'https://example.com/3',
                  'src': 'Bloomberg', 'pub': '2026-08-05',
                  'score': 5, 'reason': 'General EV news'}]
        notify(high, mid)
        self.assertTrue(self._today_path().exists())

    def test_content_correct(self):
        high = self._sample_articles()
        notify(high, [])
        content = self._today_path().read_text(encoding='utf-8')
        self.assertIn('Hyundai IVI OTA Update Released', content)
        self.assertIn('Score 9', content)   # notify.py 포맷: "Score 9" (콜론 없음)
        self.assertIn('JLR DoIP', content)
        self.assertIn('⭐', content)

    def test_empty_lists_no_crash(self):
        notify([], [])
        self.assertTrue(self._today_path().exists())

    def test_output_dir_auto_created(self):
        new_dir = Path(config.OUTPUT_DIR) / 'subdir_test'
        config.OUTPUT_DIR = str(new_dir)
        notify([], [])
        self.assertTrue(new_dir.exists())
        config.OUTPUT_DIR = tempfile.mkdtemp(prefix='digest_test_')  # 복구


# ════════════════════════════════════════════════════════
# 6. RSS 수집 (실제 네트워크, 소규모)
# ════════════════════════════════════════════════════════
class T6_RSSFetch(unittest.TestCase):

    def test_returns_list(self):
        entries = main._fetch_batch(['Hyundai', 'Tesla'])
        self.assertIsInstance(entries, list)
        print(f'\n    Hyundai+Tesla RSS: {len(entries)}건')

    def test_entries_have_title_and_link(self):
        entries = main._fetch_batch(['BMW Group'])
        for e in entries[:5]:
            self.assertIn('title', e)
            self.assertIn('link', e)

    def test_unknown_company_no_crash(self):
        entries = main._fetch_batch(['XYZCOMPANY_DOESNOTEXIST_ABC123'])
        self.assertIsInstance(entries, list)

    def test_deduplication(self):
        """같은 배치에 중복 회사가 있어도 URL 중복 없어야 함"""
        entries1 = main.fetch_all(['Hyundai', 'Tesla', 'BMW Group'])
        urls = [e.get('link', '') for e in entries1]
        self.assertEqual(len(urls), len(set(urls)), '중복 URL 발견')
        print(f'\n    3개 기업 fetch_all: {len(entries1)}건 (중복 없음)')


# ════════════════════════════════════════════════════════
# 7. 전체 파이프라인 (LLM mock)
# ════════════════════════════════════════════════════════
class T7_FullPipeline(unittest.TestCase):

    @patch('llm._call_claude', return_value=(8, 'Directly relevant to IVI validation'))
    def test_pipeline_end_to_end(self, mock_llm):
        """실제 RSS + mock LLM + 파일 출력 전체 흐름"""
        companies = ['Hyundai', 'Continental', 'Tesla']
        entries = main.fetch_all(companies)
        self.assertGreater(len(entries), 0, 'RSS 수집 결과 없음')

        candidates = [e for e in entries if main.keyword_hits(e)]
        print(f'\n    후보 기사: {len(candidates)}건')

        high, mid = [], []
        for entry in candidates[:10]:
            a = main.normalize(entry)
            score, reason = llm.score(a['title'], a['snippet'])
            a['score'] = score
            a['reason'] = reason
            (high if score >= 7 else mid if score >= 4 else []).append(a)

        self.assertGreater(mock_llm.call_count, 0, 'LLM이 한 번도 호출 안 됨')

        notify(high[:5], mid[:5])
        path = Path(config.OUTPUT_DIR) / f'digest_{_ndt.now():%Y-%m-%d}.md'
        self.assertTrue(path.exists())

        content = path.read_text(encoding='utf-8')
        self.assertIn(_ndt.now().strftime('%Y-%m-%d'), content)

        print(f'    LLM 호출: {mock_llm.call_count}회')
        print(f'    핵심 {len(high)}건 / 관련 {len(mid)}건')
        print(f'    출력: {path}')

    @patch('llm._call_claude', return_value=(8, 'mock reason'))
    def test_pipeline_from_different_cwd(self, _):
        """다른 디렉토리에서 실행해도 동작해야 함 (Task Scheduler 시뮬레이션)"""
        original = os.getcwd()
        try:
            os.chdir(tempfile.gettempdir())
            companies = main.load_companies()
            self.assertGreater(len(companies), 700)
            print(f'\n    타 디렉토리 실행 OK: {os.getcwd()}')
        finally:
            os.chdir(original)


# ════════════════════════════════════════════════════════
# 실행
# ════════════════════════════════════════════════════════
if __name__ == '__main__':
    print('=' * 60)
    print('뉴스 다이제스트 검증 테스트')
    print(f'Python {sys.version.split()[0]} | {HERE}')
    print('=' * 60)

    loader = unittest.TestLoader()
    loader.sortTestMethodsUsing = None  # 정의 순서 유지
    suite = unittest.TestSuite()
    for cls in [T1_LoadCompanies, T2_KeywordFilter, T3_LLMParsing,
                T4_Normalize, T5_OutputFile, T6_RSSFetch, T7_FullPipeline]:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print('\n' + '=' * 60)
    if result.wasSuccessful():
        print('ALL TESTS PASSED')
    else:
        print(f'FAILED: {len(result.failures)} failures / {len(result.errors)} errors')
    print('=' * 60)
    sys.exit(0 if result.wasSuccessful() else 1)
