"""
LLM 추상화 레이어 — Claude API(테스트) 또는 LM Studio(로컬) 선택
config.py의 LLM_MODE로 전환

반환값: (score: int 0-10, reason: str)
  score 7+  → 핵심 관련
  score 4-6 → 관련 기사
  score 0-3 → 제외
"""

from config import LLM_MODE, LLM_MODEL, LM_STUDIO_URL, ANTHROPIC_API_KEY, CAREER_SUMMARY

# 소형 로컬 LLM도 잘 따르는 단순 포맷 (JSON 불사용)
_PROMPT = """\
You are helping an automotive software engineer find relevant news.

Engineer profile: {career}

Rate this article's relevance to their career (0=irrelevant, 10=directly relevant).

Title: {title}
Snippet: {snippet}

Reply in exactly this format — nothing else:
SCORE: [number 0-10]
REASON: [one sentence in English]"""


def score(title: str, snippet: str) -> tuple[int, str]:
    """기사 제목+스니펫을 LLM으로 평가. (점수, 이유) 반환."""
    prompt = _PROMPT.format(
        career=CAREER_SUMMARY,
        title=title,
        snippet=snippet[:400],
    )
    try:
        if LLM_MODE == 'claude':
            return _call_claude(prompt)
        else:
            return _call_local(prompt)
    except Exception as e:
        print(f'    LLM 오류: {e}')
        return 0, ''


def _call_claude(prompt: str) -> tuple[int, str]:
    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    msg = client.messages.create(
        model=LLM_MODEL,
        max_tokens=120,
        messages=[{'role': 'user', 'content': prompt}],
    )
    return _parse(msg.content[0].text)


def _call_local(prompt: str) -> tuple[int, str]:
    # LM Studio는 OpenAI 호환 API 제공 (api_key 불필요)
    from openai import OpenAI
    client = OpenAI(base_url=LM_STUDIO_URL, api_key='local')
    resp = client.chat.completions.create(
        model=LLM_MODEL,
        messages=[{'role': 'user', 'content': prompt}],
        max_tokens=120,
        temperature=0.1,  # 일관된 출력을 위해 낮게 설정
    )
    return _parse(resp.choices[0].message.content)


def _parse(text: str) -> tuple[int, str]:
    """'SCORE: N\nREASON: ...' 형태 파싱. 실패 시 (0, '') 반환."""
    score, reason = 0, ''
    for line in text.strip().splitlines():
        line = line.strip()
        if line.upper().startswith('SCORE:'):
            try:
                score = int(''.join(c for c in line.split(':', 1)[1] if c.isdigit()))
                score = max(0, min(10, score))
            except ValueError:
                pass
        elif line.upper().startswith('REASON:'):
            reason = line.split(':', 1)[1].strip()
    return score, reason
