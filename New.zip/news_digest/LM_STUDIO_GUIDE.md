# 다른 노트북 완전 셋업 가이드

> 이 가이드는 **새 노트북**에 전체 시스템을 처음부터 설치하는 방법을 설명합니다.
> 설치 후 매일 자동으로 두 가지 이메일을 받게 됩니다:
> - **07:00** — 🚗 뉴스레터 (기업 동향 + 경력 관련 기사)
> - **07:30** — 💼 채용공고 알림 (신규 공고만)

---

## 목차

1. [사전 확인](#1-사전-확인)
2. [Python 설치](#2-python-설치)
3. [코드 복사](#3-코드-복사)
4. [LM Studio 설치](#4-lm-studio-설치)
5. [LM Studio 모델 설치](#5-lm-studio-모델-설치)
6. [LM Studio 서버 설정](#6-lm-studio-서버-설정)
7. [패키지 설치](#7-패키지-설치)
8. [Gmail 앱 비밀번호 발급](#8-gmail-앱-비밀번호-발급)
9. [설정 파일 작성](#9-설정-파일-작성)
10. [첫 실행 및 테스트](#10-첫-실행-및-테스트)
11. [자동 실행 등록](#11-자동-실행-등록)
12. [LM Studio 자동 시작 설정](#12-lm-studio-자동-시작-설정)
13. [최종 확인](#13-최종-확인)
14. [문제 해결](#14-문제-해결)

---

## 1. 사전 확인

시작 전 아래 항목을 확인하세요.

| 항목 | 최소 사양 | 권장 |
|------|----------|------|
| OS | Windows 10 64bit | Windows 11 |
| RAM | 8GB | 16GB |
| VRAM (GPU) | 4GB | 8GB+ |
| 저장 공간 | 10GB 여유 | 20GB+ |
| 인터넷 | 필요 (뉴스 수집용) | — |

> **GPU가 없어도 됩니다.** CPU로도 LM Studio가 동작하지만 속도가 느립니다.
> CPU 전용이면 Phi-4 Mini (3.8B) 모델을 권장합니다.

---

## 2. Python 설치

### Python이 이미 설치되어 있는지 확인

`Win + R` → `cmd` → 아래 명령어 입력:

```
python --version
```

`Python 3.10` 이상이 나오면 → **3단계로 이동**
오류가 나오면 → 아래 절차 진행

### Python 설치

1. [python.org/downloads](https://www.python.org/downloads/) 접속
2. **Download Python 3.12.x** 클릭 (최신 버전)
3. 설치 파일 실행
4. ⚠️ **반드시** `Add Python to PATH` 체크박스 선택 후 Install Now

설치 완료 후 cmd 재시작 → `python --version` 으로 확인

---

## 3. 코드 복사

### 방법 A — USB 드라이브

개발 노트북에서:
```
C:\PP\ 폴더 전체를 USB에 복사
```

새 노트북에서:
```
USB에서 C:\PP\ 로 붙여넣기
```

### 방법 B — Git (선택)

```
git clone <저장소 주소> C:\PP
```

### 복사 후 확인

`C:\PP\` 폴더 안에 아래 두 폴더가 있어야 합니다:
```
C:\PP\
├── news_digest\
│   ├── main.py
│   ├── llm.py
│   ├── config.py        ← 이 파일을 수정할 예정
│   ├── company_list.md
│   └── ...
└── job_monitor\
    ├── main.py
    ├── config.py        ← 이 파일을 수정할 예정
    ├── detect_ats.py
    └── ...
```

---

## 4. LM Studio 설치

### 다운로드

1. [lmstudio.ai](https://lmstudio.ai) 접속
2. **Download for Windows** 클릭
3. 다운로드된 `.exe` 파일 실행
4. 기본 설치 경로 그대로 두고 설치 완료

> 설치 후 LM Studio가 자동으로 실행됩니다.

---

## 5. LM Studio 모델 설치

뉴스 관련도 스코어링은 단순 분류 작업이므로 소형 모델로 충분합니다.

### 모델 선택 기준

| 모델명 | 크기 | VRAM | CPU 가능 | 추천 대상 |
|--------|------|------|---------|----------|
| **Phi-4 Mini Instruct** | 3.8B | 4GB | ✅ 가능 | 저사양 노트북 |
| **Llama 3.2 3B Instruct** | 3B | 3GB | ✅ 가능 | 초경량 |
| **Mistral 7B Instruct** | 7B | 8GB | ⚠️ 느림 | 8GB VRAM 이상 |
| **Qwen2.5 7B Instruct** | 7B | 8GB | ⚠️ 느림 | 다국어 필요 시 |

> **권장: Phi-4 Mini Instruct** — 빠르고, 영어 이해력 우수, 낮은 VRAM 요구

### 모델 다운로드

1. LM Studio 실행
2. 왼쪽 사이드바에서 🔍 **(돋보기 아이콘)** 클릭
3. 검색창에 모델명 입력 (예: `phi-4-mini-instruct`)
4. 검색 결과에서 모델 클릭
5. 오른쪽에 나타나는 **Download** 버튼 클릭
6. 다운로드 완료까지 대기 (네트워크 속도에 따라 5~30분)

> 다운로드 진행률은 하단 상태바에서 확인 가능

---

## 6. LM Studio 서버 설정

### 서버 시작

1. LM Studio 왼쪽 사이드바에서 **↔ (화살표 아이콘)** 클릭
2. 상단 드롭다운에서 다운로드한 모델 선택
3. **Start Server** 버튼 클릭
4. 화면에 아래 메시지가 뜨면 성공:
   ```
   Server running at http://localhost:1234
   ```

### 모델명 확인 (config.py에 입력할 값)

서버가 실행 중인 상태에서:

1. 브라우저 열기 → 주소창에 입력:
   ```
   http://localhost:1234/v1/models
   ```
2. 아래와 같은 JSON이 나타납니다:
   ```json
   {
     "data": [
       { "id": "phi-4-mini-instruct", ... }
     ]
   }
   ```
3. `"id"` 값 (`phi-4-mini-instruct`)을 메모해 둡니다 → config.py에 사용

---

## 7. 패키지 설치

`Win + R` → `cmd` 실행 후 아래 명령어 입력:

```
pip install feedparser openai requests
```

> - `feedparser` — 뉴스 RSS 수집
> - `openai` — LM Studio 연결 (LM Studio가 OpenAI 호환 API 제공)
> - `requests` — ATS API 수집 (채용공고)
>
> **`anthropic` 패키지는 이 노트북에서 불필요합니다.**

설치 확인:
```
python -c "import feedparser, openai, requests; print('OK')"
```

`OK`가 출력되면 성공

---

## 8. Gmail 앱 비밀번호 발급

일반 Gmail 비밀번호로는 SMTP 전송이 안 됩니다. **앱 비밀번호**가 필요합니다.

### 발급 절차

1. [myaccount.google.com](https://myaccount.google.com) 접속 (이메일 받을 Gmail 계정)
2. 왼쪽 메뉴 → **보안**
3. **2단계 인증** 확인 → 켜져 있어야 합니다
   - 꺼져 있으면: 2단계 인증 설정 후 진행
4. 검색창에 `앱 비밀번호` 검색 → 클릭
   - 또는 직접 접속: [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
5. 앱 선택 → **메일** 선택
6. **생성** 클릭
7. 16자리 비밀번호 발급 (예: `abcd efgh ijkl mnop`)
8. 이 비밀번호를 안전한 곳에 메모 (창 닫으면 다시 볼 수 없음)

---

## 9. 설정 파일 작성

### 9-1. news_digest/config.py

`C:\PP\news_digest\config.py` 파일을 메모장으로 열고 수정:

```python
# ════════════════════════════════════════════════════════
#  다른 노트북 (실서버) 설정
#  LLM_MODE='local' + NOTIFY_METHODS=['email']
# ════════════════════════════════════════════════════════

# ── LLM 설정 ─────────────────────────────────────────────
LLM_MODE = 'local'                    # ← 'claude' → 'local' 변경

# Claude API (사용 안 함, 그대로 둬도 됨)
ANTHROPIC_API_KEY = ''
LLM_MODEL = 'phi-4-mini-instruct'    # ← 6단계에서 메모한 모델명

# LM Studio 서버 주소 (기본값 유지)
LM_STUDIO_URL = 'http://localhost:1234/v1'

# ── 알림 채널 ─────────────────────────────────────────────
# 'file'|'email'|'telegram'|'slack'|'discord'|'desktop' — 여러 개 가능
NOTIFY_METHODS = ['email']            # ← ['file'] → ['email'] 변경
OUTPUT_DIR  = 'output'

# ── 이메일 설정 ───────────────────────────────────────────
SENDER    = 'your_gmail@gmail.com'   # ← 발신 Gmail 주소 입력
PASSWORD  = 'abcd efgh ijkl mnop'   # ← 8단계에서 발급한 앱 비밀번호
RECIPIENT = 'your_gmail@gmail.com'   # ← 수신 이메일 (같은 주소 가능)

# ── 파일 경로 ─────────────────────────────────────────────
COMPANY_FILE = 'company_list.md'

# ── RSS 설정 ──────────────────────────────────────────────
BATCH_SIZE = 20
LANG       = 'en'
COUNTRY    = 'US'

# ── 경력 키워드 ───────────────────────────────────────────
KEYWORDS = [
    'UDS', 'DoIP', 'CAN-FD', 'OBD', 'diagnostic',
    'IVI', 'infotainment', 'HMI', 'in-vehicle', 'cockpit',
    'SDV', 'OTA', 'FOTA', 'AUTOSAR', 'ASPICE', 'software-defined',
    'EV', 'electric vehicle', 'HEV', 'BMS', 'battery',
    'ADAS', 'autonomous', 'validation', 'verification', 'functional safety',
    'ISO 26262', 'cybersecurity', 'cyber security', 'ISO 21434',
    'ECU', 'embedded', 'firmware', 'bootloader',
    'Hyundai', 'Kia', 'JLR', 'Jaguar', 'Land Rover',
    'Mobileye', 'Continental', 'Bosch',
]

# ── LLM 경력 요약 ─────────────────────────────────────────
CAREER_SUMMARY = (
    'IVI validation engineer, 5+ years. '
    'Specializes in UDS/DoIP diagnostics, CAN, automotive cybersecurity, OTA, SDV. '
    'Currently at Hyundai R&D (EV/HEV IVI). '
    'Target: Technical PM or Validation Lead at international automotive companies. '
    'Key platforms: Hyundai, JLR, Continental, Mobileye.'
)
```

### 9-2. job_monitor/config.py

`C:\PP\job_monitor\config.py` 파일을 메모장으로 열고 수정:

```python
from pathlib import Path

_HERE = Path(__file__).resolve().parent

# 기업 리스트
COMPANY_FILE = _HERE.parent / 'news_digest' / 'company_list.md'

# 파일 경로
ATS_MAP_FILE = _HERE / 'ats_map.json'
DB_FILE      = _HERE / 'jobs.db'
OUTPUT_DIR   = _HERE / 'output'

# ── 알림 채널 ─────────────────────────────────────────────
# 'file'|'email'|'telegram'|'slack'|'discord'|'desktop'
NOTIFY_METHODS = ['email']            # ← ['file'] → ['email'] 변경

# ── 이메일 설정 ───────────────────────────────────────────
SENDER    = 'your_gmail@gmail.com'   # ← news_digest와 동일하게
PASSWORD  = 'abcd efgh ijkl mnop'   # ← 동일한 앱 비밀번호
RECIPIENT = 'your_gmail@gmail.com'

# ── Indeed 설정 ───────────────────────────────────────────
INDEED_DAYS        = 1
INDEED_BATCH_SIZE  = 10
INDEED_DELAY       = 1.5
INDEED_MAX_RESULTS = 50

# ── 직무 키워드 ───────────────────────────────────────────
JOB_KEYWORDS = [
    'validation', 'verification', 'test engineer', 'testing',
    'quality assurance', 'QA engineer',
    'IVI', 'infotainment', 'HMI', 'embedded', 'firmware',
    'ADAS', 'autonomous', 'cybersecurity', 'diagnostic',
    'UDS', 'DoIP', 'OTA', 'FOTA', 'ECU', 'AUTOSAR', 'CAN',
    'SDV', 'software-defined',
    'technical PM', 'project manager', 'program manager',
    'validation lead', 'test lead',
]
```

---

## 10. 첫 실행 및 테스트

### 10-1. LM Studio 서버 확인

LM Studio가 실행 중이고 서버가 켜져 있는지 확인합니다.
브라우저에서 `http://localhost:1234/v1/models` 접속 → JSON 응답이 보여야 합니다.

### 10-2. 뉴스레터 테스트 실행

cmd에서:
```
cd C:\PP\news_digest
python main.py
```

정상 실행 시 출력 예시:
```
[2026-08-05 07:00] 시작 (LLM=local, 출력=email)
기업 986개 / 20개씩 배치
  배치 1/50... 18건
  배치 2/50... 12건
  ...
수집 856건
키워드 통과 124건 → LLM 스코어링
  [1/124] Hyundai unveils new IVI platform...
  [2/124] Continental releases DoIP tool...
  ...
결과 — 핵심 18건 / 관련 31건
이메일 전송 완료
```

처음 실행 시 이메일이 오면 성공입니다. 5~10분 소요됩니다.

### 10-3. 채용공고 ATS 감지 (최초 1회, 10~20분 소요)

```
cd C:\PP\job_monitor
python detect_ats.py
```

완료 후 `ats_map.json` 파일이 생성됩니다.

### 10-4. 채용공고 테스트 실행

```
cd C:\PP\job_monitor
python main.py
```

처음 실행하면 현재까지의 모든 공고가 "신규"로 처리됩니다 (DB가 비어있으므로).
두 번째 실행부터 진짜 신규 공고만 알림이 옵니다.

---

## 11. 자동 실행 등록

### 11-1. 뉴스레터 (매일 07:00)

```
cd C:\PP\news_digest
schedule_setup.bat
```

### 11-2. 채용공고 (매일 07:30)

```
cd C:\PP\job_monitor
schedule_setup.bat
```

### 등록 확인

작업 스케줄러에서 확인:
- `Win + R` → `taskschd.msc` → 작업 스케줄러 라이브러리
- `AutomotiveNewsDigest` — 매일 07:00
- `AutomotiveJobMonitor` — 매일 07:30

---

## 12. LM Studio 자동 시작 설정

Task Scheduler가 실행될 때 LM Studio 서버가 켜져 있어야 합니다.
노트북 시작 시 자동으로 LM Studio가 열리도록 설정합니다.

### 방법 A — 시작프로그램에 추가 (권장)

1. `Win + R` → `shell:startup` 입력 → Enter
2. 시작프로그램 폴더가 열림
3. LM Studio 바탕화면 아이콘을 이 폴더에 **바로가기** 생성
   (아이콘 우클릭 → 보내기 → 바탕 화면에 바로 가기 만들기 → 만들어진 바로 가기를 시작프로그램 폴더로 이동)

### 방법 B — Task Scheduler로 서버 자동 시작

LM Studio를 열지 않고 서버만 백그라운드에서 시작하려면:

1. LM Studio 설치 경로 확인 (보통 `C:\Users\[사용자명]\AppData\Local\LM-Studio\`)
2. 아래 bat 파일을 `C:\PP\start_lm_studio.bat`로 저장:

```batch
@echo off
start "" "C:\Users\%USERNAME%\AppData\Local\Programs\LM-Studio\LM Studio.exe"
```

3. Task Scheduler에서 시스템 시작 시 이 파일을 실행하도록 등록

### 서버 자동 실행 확인

LM Studio 설정에서 자동 서버 시작 옵션 확인:
- LM Studio → Settings (톱니바퀴) → `Start server on app launch` 체크

---

## 13. 최종 확인

셋업이 완료되면 아래 체크리스트를 확인하세요:

- [ ] Python 설치 완료
- [ ] `C:\PP\news_digest\`, `C:\PP\job_monitor\` 폴더 복사 완료
- [ ] LM Studio 설치 및 모델 다운로드 완료
- [ ] LM Studio 서버 실행 중 (`localhost:1234`)
- [ ] `feedparser`, `openai`, `requests` 패키지 설치 완료
- [ ] Gmail 앱 비밀번호 발급 완료
- [ ] `news_digest/config.py` 수정 완료 (LLM_MODE, 이메일)
- [ ] `job_monitor/config.py` 수정 완료 (이메일)
- [ ] `python main.py` 테스트 이메일 수신 확인
- [ ] `python detect_ats.py` 실행 완료 (ats_map.json 생성)
- [ ] Task Scheduler 두 개 등록 완료
- [ ] LM Studio 시작프로그램 등록 완료

---

## 14. 문제 해결

### LM Studio 서버에 연결 안 됨

```
LLM 오류: Connection refused
```

→ LM Studio에서 서버가 실행 중인지 확인 (↔ 탭 → Start Server)
→ `http://localhost:1234/v1/models` 브라우저에서 접속 확인

---

### 모델명 오류

```
LLM 오류: model not found
```

→ `http://localhost:1234/v1/models` 접속 → `"id"` 값 확인
→ config.py의 `LLM_MODEL` 값과 정확히 일치하는지 확인 (대소문자 포함)

---

### 이메일 전송 실패

```
SMTPAuthenticationError
```

→ Gmail 앱 비밀번호가 맞는지 확인 (16자리, 공백 포함 그대로 입력)
→ 2단계 인증이 켜져 있는지 확인
→ `SENDER`에 올바른 Gmail 주소 입력했는지 확인

---

### LLM 스코어링이 너무 느림

→ LM Studio에서 더 작은 모델로 교체 (Llama 3.2 3B)
→ LM Studio → Settings → GPU Offload 레이어 수 늘리기 (GPU 있는 경우)

---

### 채용공고가 안 옴

1. `detect_ats.py` 실행 완료 여부 확인 (`ats_map.json` 파일 존재)
2. `job_monitor/main.py` 직접 실행해서 오류 메시지 확인
3. 처음 실행 시에는 모든 공고가 신규로 처리됨 — 다음 날부터 진짜 신규만 옴

---

### 뉴스가 너무 적거나 관련 없는 기사만 옴

`news_digest/config.py`의 `KEYWORDS` 목록을 조정하세요:
- 관련 없는 기사 많음 → 키워드를 더 구체적으로 변경
- 기사가 너무 적음 → 키워드 추가 (예: `'OBD-II'`, `'V2X'`, `'ethernet'`)

---

*마지막 업데이트: 2026-08-05*
