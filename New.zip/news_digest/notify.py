"""
다채널 알림 디스패처
config.NOTIFY_METHODS 에 원하는 채널을 나열하면 모두 동시 전송됩니다.

지원 채널:
  'file'     — output/ 폴더에 .md 파일 저장
  'email'    — Gmail SMTP
  'telegram' — Telegram 봇 메시지
  'slack'    — Slack Incoming Webhook
  'discord'  — Discord Webhook
  'desktop'  — Windows 바탕화면 알림 (추가 패키지 없음)

예시 (config.py):
  NOTIFY_METHODS = ['email']                  # 이메일만
  NOTIFY_METHODS = ['telegram']               # 텔레그램만
  NOTIFY_METHODS = ['email', 'telegram']      # 둘 다
"""
import smtplib
import ssl
import subprocess
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import requests

import config as _cfg


# ── 공통 텍스트 포맷 (Telegram · Slack · Discord) ────────────

def _text(high: list, low: list, date: str) -> str:
    total = len(high) + len(low)
    lines = [
        f'🚗 Automotive News — {date}',
        f'총 {total}건  (핵심 {len(high)} / 관련 {len(low)})',
        '',
    ]
    if high:
        lines.append('⭐ 핵심 관련')
        for a in high[:10]:
            lines.append(f"• [Score {a['score']}] {a['title'][:70]}")
            lines.append(f"  {a['reason']}")
            lines.append(f"  {a['src']} — {a['link']}")
    if low:
        lines += ['', '📰 관련 기사']
        for a in low[:10]:
            lines.append(f"• {a['title'][:80]}")
            lines.append(f"  {a['src']}")
    return '\n'.join(lines)


# ── file ─────────────────────────────────────────────────────

def _send_file(high: list, low: list, date: str):
    od = Path(_cfg.OUTPUT_DIR)
    od.mkdir(parents=True, exist_ok=True)
    path = od / f'digest_{date}.md'

    def section(heading, articles):
        if not articles:
            return ''
        lines = [f'\n## {heading}\n']
        for a in articles:
            lines += [
                f"### [{a['title']}]({a['link']})",
                f"> **Score {a['score']}** | {a['reason']}",
                f"> {a['src']} · {a['pub']}\n",
            ]
        return '\n'.join(lines)

    total = len(high) + len(low)
    content = (
        f"# 🚗 Automotive News Digest — {date}\n\n"
        f"**총 {total}건** (핵심 {len(high)} / 관련 {len(low)})\n"
        + section('⭐ 핵심 관련 (Score 7+)', high)
        + section('📰 관련 기사 (Score 4–6)', low)
        + '\n---\n*Google News RSS + LLM 스코어링*\n'
    )
    path.write_text(content, encoding='utf-8')
    print(f'  [file] {path}')


# ── email ────────────────────────────────────────────────────

def _html_rows(articles):
    rows = []
    for a in articles:
        rows.append(
            f'<tr><td style="padding:8px 0;border-bottom:1px solid #f4f4f4">'
            f'<a href="{a["link"]}" style="color:#111;font-weight:500;text-decoration:none">'
            f'{a["title"]}</a><br>'
            f'<span style="color:#2c7bb6;font-size:12px">'
            f'Score {a["score"]} — {a["reason"]}</span><br>'
            f'<span style="color:#999;font-size:12px">{a["src"]} · {a["pub"]}</span>'
            f'</td></tr>'
        )
    return ''.join(rows)


def _send_email(high: list, low: list, date: str):
    total = len(high) + len(low)
    h_block = (f'<h3 style="color:#2c7bb6">⭐ 핵심 관련 ({len(high)}건)</h3>'
               f'<table width="100%">{_html_rows(high)}</table>') if high else ''
    l_block = (f'<h3 style="color:#555;margin-top:20px">📰 관련 기사 ({len(low)}건)</h3>'
               f'<table width="100%">{_html_rows(low)}</table>') if low else ''

    html = (
        f'<html><body style="font-family:Arial,sans-serif;max-width:680px;margin:0 auto;padding:20px">'
        f'<div style="background:#2c7bb6;color:#fff;padding:14px 20px;border-radius:6px 6px 0 0">'
        f'<strong>🚗 Automotive News Digest</strong>'
        f'<span style="opacity:.75;margin-left:12px">{date} · {total}건</span></div>'
        f'<div style="border:1px solid #ddd;border-top:none;padding:20px;border-radius:0 0 6px 6px">'
        f'{h_block}{l_block}'
        f'<p style="color:#ccc;font-size:11px;text-align:center;margin-top:24px">'
        f'Google News RSS + LLM 스코어링</p></div></body></html>'
    )
    msg = MIMEMultipart('alternative')
    msg['Subject'] = f'🚗 Automotive Digest {date} — {total}건'
    msg['From']    = _cfg.SENDER
    msg['To']      = _cfg.RECIPIENT
    msg.attach(MIMEText(html, 'html', 'utf-8'))

    ctx = ssl.create_default_context()
    with smtplib.SMTP('smtp.gmail.com', 587) as s:
        s.starttls(context=ctx)
        s.login(_cfg.SENDER, _cfg.PASSWORD)
        s.sendmail(_cfg.SENDER, _cfg.RECIPIENT, msg.as_bytes())
    print(f'  [email] → {_cfg.RECIPIENT}')


# ── telegram ─────────────────────────────────────────────────

def _send_telegram(high: list, low: list, date: str):
    body = _text(high, low, date)
    api  = f'https://api.telegram.org/bot{_cfg.TELEGRAM_TOKEN}/sendMessage'
    # 4096자 제한 → 초과 시 분할 전송
    for chunk in [body[i:i + 4000] for i in range(0, max(len(body), 1), 4000)]:
        requests.post(
            api,
            json={'chat_id': _cfg.TELEGRAM_CHAT_ID, 'text': chunk, 'parse_mode': 'Markdown'},
            timeout=10,
        ).raise_for_status()
    print(f'  [telegram] → chat_id {_cfg.TELEGRAM_CHAT_ID}')


# ── slack ────────────────────────────────────────────────────

def _send_slack(high: list, low: list, date: str):
    requests.post(
        _cfg.SLACK_WEBHOOK,
        json={'text': _text(high, low, date)},
        timeout=10,
    ).raise_for_status()
    print('  [slack] 전송 완료')


# ── discord ──────────────────────────────────────────────────

def _send_discord(high: list, low: list, date: str):
    body = _text(high, low, date)
    # Discord 2000자 제한
    for chunk in [body[i:i + 1900] for i in range(0, max(len(body), 1), 1900)]:
        requests.post(
            _cfg.DISCORD_WEBHOOK,
            json={'content': chunk},
            timeout=10,
        ).raise_for_status()
    print('  [discord] 전송 완료')


# ── desktop (Windows, 추가 패키지 불필요) ─────────────────────

def _send_desktop(high: list, low: list, date: str):
    total = len(high) + len(low)
    title = f'Automotive Digest {date}'
    msg   = f'신규 {total}건 (핵심 {len(high)} / 관련 {len(low)})'
    ps = (
        'Add-Type -AssemblyName System.Windows.Forms;'
        '$n=[System.Windows.Forms.NotifyIcon]::new();'
        '$n.Icon=[System.Drawing.SystemIcons]::Information;'
        '$n.Visible=$true;'
        f'$n.ShowBalloonTip(8000,"{title}","{msg}",'
        '[System.Windows.Forms.ToolTipIcon]::Info);'
        'Start-Sleep 9;$n.Dispose()'
    )
    subprocess.Popen(
        ['powershell', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', ps]
    )
    print('  [desktop] 알림 전송')


# ── 디스패처 ─────────────────────────────────────────────────

_SENDERS = {
    'file':     _send_file,
    'email':    _send_email,
    'telegram': _send_telegram,
    'slack':    _send_slack,
    'discord':  _send_discord,
    'desktop':  _send_desktop,
}


def notify(high: list, low: list):
    """NOTIFY_METHODS에 등록된 모든 채널로 전송."""
    date    = datetime.now().strftime('%Y-%m-%d')
    methods = _cfg.NOTIFY_METHODS
    print(f'알림 전송 → {methods}')
    for method in methods:
        sender = _SENDERS.get(method)
        if not sender:
            print(f'  [{method}] 알 수 없는 채널, 스킵')
            continue
        try:
            sender(high, low, date)
        except Exception as e:
            print(f'  [{method}] 실패: {e}')
