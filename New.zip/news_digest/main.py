"""
Daily Automotive News Digest
  Stage 1 — Google News RSS 수집 (배치, 중복 제거)
  Stage 2 — 키워드 프리필터 (LLM 호출 최소화)
  Stage 3 — LLM 관련도 스코어링 (Claude API 또는 LM Studio)
  Stage 4 — 파일 출력(테스트) 또는 이메일 전송(실서버)

Usage : python main.py
"""

import feedparser
import os
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

# Task Scheduler 등 다른 디렉토리에서 실행되어도 경로가 깨지지 않도록
_HERE = Path(__file__).resolve().parent

import config as _cfg
import llm
from config import BATCH_SIZE, COMPANY_FILE, COUNTRY, KEYWORDS, LANG, LLM_MODE
from notify import notify


# ── 기업 리스트 로드 ─────────────────────────────────────

def load_companies() -> list[str]:
    # _HERE 기준 절대 경로로 열어야 Task Scheduler 등 다른 cwd에서도 동작
    path = _HERE / COMPANY_FILE
    with open(path, encoding='utf-8') as f:
        return [line[2:].strip() for line in f if line.startswith('- ')]


# ── RSS 수집 ─────────────────────────────────────────────

def _fetch_batch(companies: list[str]) -> list:
    q = quote(' OR '.join(f'"{c}"' for c in companies))
    url = f'https://news.google.com/rss/search?q={q}&hl={LANG}&gl={COUNTRY}&ceid={COUNTRY}:{LANG}'
    try:
        return feedparser.parse(url).entries
    except Exception as e:
        print(f'  RSS 오류: {e}')
        return []


def fetch_all(companies: list[str]) -> list[dict]:
    seen, entries = set(), []
    batches = [companies[i:i + BATCH_SIZE] for i in range(0, len(companies), BATCH_SIZE)]
    for i, batch in enumerate(batches, 1):
        print(f'  배치 {i}/{len(batches)}...', end=' ', flush=True)
        new = []
        for e in _fetch_batch(batch):
            url = e.get('link', '')
            if url and url not in seen:
                seen.add(url)
                new.append(e)
        entries.extend(new)
        print(f'{len(new)}건')
        time.sleep(1.5)
    return entries


# ── 키워드 프리필터 ──────────────────────────────────────

def keyword_hits(entry: dict) -> list[str]:
    text = (entry.get('title', '') + ' ' + entry.get('summary', '')).lower()
    return [kw for kw in KEYWORDS if kw.lower() in text]


# ── 기사 정규화 ──────────────────────────────────────────

def normalize(entry: dict) -> dict:
    src = entry.get('source', {})
    return {
        'title':   entry.get('title', ''),
        'link':    entry.get('link', '#'),
        'snippet': entry.get('summary', '')[:400],
        'src':     src.get('title', '') if isinstance(src, dict) else str(src),
        'pub':     entry.get('published', '')[:16],
    }


# ── 메인 ─────────────────────────────────────────────────

def main():
    date_str = datetime.now().strftime('%Y-%m-%d')
    print(f'[{datetime.now():%Y-%m-%d %H:%M}] 시작 (LLM={LLM_MODE}, 알림={_cfg.NOTIFY_METHODS})')

    companies = load_companies()
    print(f'기업 {len(companies)}개 / {BATCH_SIZE}개씩 배치')

    # Stage 1 — RSS 수집
    raw = fetch_all(companies)
    print(f'수집 {len(raw)}건')

    # Stage 2 — 키워드 프리필터
    candidates = [e for e in raw if keyword_hits(e)]
    print(f'키워드 통과 {len(candidates)}건 → LLM 스코어링')

    # Stage 3 — LLM 스코어링
    high, mid = [], []
    for i, entry in enumerate(candidates, 1):
        a = normalize(entry)
        print(f'  [{i}/{len(candidates)}] {a["title"][:60]}')
        score, reason = llm.score(a['title'], a['snippet'])
        a['score'] = score
        a['reason'] = reason
        if score >= 7:
            high.append(a)
        elif score >= 4:
            mid.append(a)

    high = sorted(high, key=lambda x: -x['score'])[:30]
    mid  = mid[:20]
    print(f'결과 — 핵심 {len(high)}건 / 관련 {len(mid)}건')

    # Stage 4 — 출력
    notify(high, mid)


if __name__ == '__main__':
    main()
