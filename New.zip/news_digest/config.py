# ════════════════════════════════════════════════════════
#  이 노트북 (개발/검증)  →  LLM_MODE='claude', NOTIFY_METHODS=['file']
#  다른 노트북 (실서버)   →  LLM_MODE='local',  NOTIFY_METHODS=['email']
# ════════════════════════════════════════════════════════

# ── LLM 설정 ─────────────────────────────────────────────
LLM_MODE = 'claude'           # 'claude' | 'local'

# Claude API (LLM_MODE='claude' 일 때)
ANTHROPIC_API_KEY = 'sk-ant-여기에입력'
LLM_MODEL = 'claude-haiku-4-5'   # 빠르고 저렴 — 스코어링 전용

# LM Studio (LLM_MODE='local' 일 때)
LM_STUDIO_URL = 'http://localhost:1234/v1'
# LLM_MODEL = 'mistral-7b-instruct'  # LM Studio에 로드된 모델명으로 교체

# ── 알림 채널 ─────────────────────────────────────────────
# 여러 개 동시 활성화 가능, 순서대로 전송
# 선택지: 'file' | 'email' | 'telegram' | 'slack' | 'discord' | 'desktop'
NOTIFY_METHODS = ['file']     # ← 여기만 바꾸면 됨

OUTPUT_DIR = 'output'         # 'file' 채널 저장 폴더

# ── 이메일 ('email' 사용 시) ──────────────────────────────
SENDER    = 'your_gmail@gmail.com'
PASSWORD  = 'xxxx xxxx xxxx xxxx'   # Gmail 앱 비밀번호
RECIPIENT = 'your_email@example.com'

# ── Telegram ('telegram' 사용 시) ─────────────────────────
# 1. https://t.me/BotFather → /newbot → 토큰 발급
# 2. 봇에게 메시지 보내기 → https://api.telegram.org/bot{TOKEN}/getUpdates → chat_id 확인
TELEGRAM_TOKEN   = ''
TELEGRAM_CHAT_ID = ''

# ── Slack ('slack' 사용 시) ───────────────────────────────
# Slack 워크스페이스 → 앱 → Incoming Webhooks → Add → URL 복사
SLACK_WEBHOOK = ''

# ── Discord ('discord' 사용 시) ───────────────────────────
# Discord 서버 → 채널 편집 → 연동 → 웹후크 → URL 복사
DISCORD_WEBHOOK = ''

# ── Desktop ('desktop' 사용 시) ───────────────────────────
# Windows 10/11 바탕화면 알림 — 추가 설정 불필요

# ── 파일 경로 ─────────────────────────────────────────────
COMPANY_FILE = 'company_list.md'

# ── RSS 수집 설정 ─────────────────────────────────────────
BATCH_SIZE = 20    # 배치당 기업 수
LANG       = 'en'
COUNTRY    = 'US'

# ── 키워드 프리필터 ───────────────────────────────────────
# LLM 호출 전 1차 필터 — 히트 없으면 LLM 스킵 (비용 절감)
KEYWORDS = [
    'UDS', 'DoIP', 'CAN-FD', 'OBD', 'diagnostic',
    'IVI', 'infotainment', 'HMI', 'in-vehicle', 'cockpit',
    'SDV', 'OTA', 'FOTA', 'AUTOSAR', 'ASPICE', 'software-defined',
    'EV', 'electric vehicle', 'HEV', 'BMS', 'battery',
    'ADAS', 'autonomous', 'validation', 'verification', 'functional safety',
    'ISO 26262', 'cybersecurity', 'cyber security', 'ISO 21434',
    'ECU', 'embedded', 'firmware', 'bootloader',
    'Hyundai', 'Kia', 'JLR', 'Jaguar', 'Land Rover',
    'Mobileye', 'Continental', 'Bosch',
]

# ── LLM에 전달할 경력 요약 ────────────────────────────────
# 간결할수록 소형 로컬 LLM 성능 ↑
CAREER_SUMMARY = (
    'IVI validation engineer, 5+ years. '
    'Specializes in UDS/DoIP diagnostics, CAN, automotive cybersecurity, OTA, SDV. '
    'Currently at Hyundai R&D (EV/HEV IVI). '
    'Target: Technical PM or Validation Lead at international automotive companies. '
    'Key platforms: Hyundai, JLR, Continental, Mobileye.'
)
