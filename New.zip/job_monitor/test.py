#!/usr/bin/env python3
"""
채용공고 모니터 검증 테스트
- ATS: Greenhouse 신 URL 실제 호출 포함
- LinkedIn: mock + 실제 API 호출
- SQLite 추적: 실제 임시 DB
- 통합 파이프라인: mock 사용

Usage: python test.py
"""
import hashlib
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

HERE = Path(__file__).resolve().parent
os.chdir(HERE)
sys.path.insert(0, str(HERE))

# config 오버라이드
import config as _cfg
_tmp = Path(tempfile.mkdtemp(prefix='job_test_'))
_cfg.DB_FILE      = _tmp / 'jobs.db'
_cfg.OUTPUT_DIR   = _tmp / 'output'
_cfg.NOTIFY_METHODS = ['file']
_cfg.INDEED_DELAY       = 0
_cfg.INDEED_BATCH_SIZE  = 3
_cfg.INDEED_MAX_RESULTS = 10
_cfg.INDEED_DAYS        = 1

import db
import models
from detect_ats import make_slugs, _ok_greenhouse
from fetch_ats import fetch_greenhouse, fetch_lever, fetch_all_ats
from fetch_linkedin import _match_company, _parse_page, fetch_all_linkedin
from main import load_companies, score_jobs, split
from notify import notify
from datetime import datetime as _dt


# ═══════════════════════════════════════════════════════
# 1. 슬러그 생성
# ═══════════════════════════════════════════════════════
class T1_Slugs(unittest.TestCase):

    def test_simple(self):
        self.assertIn('waymo', make_slugs('Waymo'))

    def test_strips_suffix(self):
        slugs = make_slugs('Aurora Innovation')
        self.assertIn('aurora-innovation', slugs)
        self.assertIn('aurora', slugs)

    def test_special_chars_removed(self):
        for s in make_slugs("D'Ieteren"):
            self.assertRegex(s, r'^[a-z0-9-]+$')

    def test_long_company(self):
        slugs = make_slugs('Hyundai Motor Group')
        self.assertIn('hyundai', slugs)
        self.assertIn('hyundai-motor', slugs)

    def test_empty(self):
        self.assertIsInstance(make_slugs('AG'), list)


# ═══════════════════════════════════════════════════════
# 2. ATS 파싱 (mock)
# ═══════════════════════════════════════════════════════
class T2_ATSParsing(unittest.TestCase):

    def _gh_resp(self):
        return {
            'jobs': [{
                'id': 12345,
                'title': 'Senior Validation Engineer',
                'absolute_url': 'https://careers.withwaymo.com/jobs?gh_jid=12345',
                'updated_at': '2026-08-05T00:00:00Z',
                'location': {'name': 'Mountain View, CA'},  # 신 API 구조
            }]
        }

    def _lv_resp(self):
        return [{
            'id': 'abc-def',
            'text': 'IVI Test Engineer',
            'hostedUrl': 'https://jobs.lever.co/company/abc-def',
            'createdAt': 1754380800000,
            'categories': {'location': 'Seoul'},
        }]

    @patch('fetch_ats.requests.get')
    def test_greenhouse_new_url(self, mock_get):
        """신 Greenhouse URL(boards-api.greenhouse.io) 사용 확인"""
        mock_get.return_value = MagicMock(
            status_code=200,
            json=lambda: self._gh_resp(),
            raise_for_status=lambda: None,
        )
        jobs = fetch_greenhouse('waymo', 'Waymo')
        # 신 URL이 호출됐는지 확인
        called_url = mock_get.call_args[0][0]
        self.assertIn('boards-api.greenhouse.io', called_url)
        self.assertNotIn('boards.greenhouse.io', called_url)
        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0].location, 'Mountain View, CA')
        print(f'\n    GH 신 URL OK: {called_url}')

    @patch('fetch_ats.requests.get')
    def test_greenhouse_parse(self, mock_get):
        mock_get.return_value = MagicMock(
            status_code=200,
            json=lambda: self._gh_resp(),
            raise_for_status=lambda: None,
        )
        jobs = fetch_greenhouse('waymo', 'Waymo')
        self.assertEqual(jobs[0].id, 'gh_12345')
        self.assertEqual(jobs[0].title, 'Senior Validation Engineer')
        self.assertEqual(jobs[0].source, 'greenhouse')

    @patch('fetch_ats.requests.get')
    def test_lever_parse(self, mock_get):
        mock_get.return_value = MagicMock(
            status_code=200,
            json=lambda: self._lv_resp(),
            raise_for_status=lambda: None,
        )
        jobs = fetch_lever('company', 'TestCo')
        self.assertEqual(jobs[0].id, 'lv_abc-def')
        self.assertEqual(jobs[0].title, 'IVI Test Engineer')

    @patch('fetch_ats.requests.get')
    def test_network_error_returns_empty(self, mock_get):
        mock_get.side_effect = Exception('Network error')
        self.assertEqual(fetch_greenhouse('bad', 'Bad'), [])

    @patch('fetch_ats.requests.get')
    def test_fetch_all_ats(self, mock_get):
        mock_get.return_value = MagicMock(
            status_code=200,
            json=lambda: self._gh_resp(),
            raise_for_status=lambda: None,
        )
        jobs = fetch_all_ats({'Waymo': {'ats': 'greenhouse', 'slug': 'waymo'}})
        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0].company, 'Waymo')


# ═══════════════════════════════════════════════════════
# 3. LinkedIn 파싱 (mock)
# ═══════════════════════════════════════════════════════
class T3_LinkedInParsing(unittest.TestCase):

    def _sample_html(self):
        return """
        <ul>
          <li>
            <div>
              <h3>Validation Engineer</h3>
              <h4>Hyundai AutoEver</h4>
              <a href="https://www.linkedin.com/jobs/view/123456789">Apply</a>
            </div>
          </li>
          <li>
            <div>
              <h3>Software Engineer</h3>
              <h4>Google</h4>
              <a href="https://www.linkedin.com/jobs/view/987654321">Apply</a>
            </div>
          </li>
        </ul>
        """

    def test_match_company_found(self):
        result = _match_company('Hyundai AutoEver', {'Hyundai AutoEver', 'Continental'})
        self.assertEqual(result, 'Hyundai AutoEver')

    def test_match_company_not_found(self):
        result = _match_company('Google LLC', {'Hyundai AutoEver', 'Continental'})
        self.assertIsNone(result)

    def test_match_partial_word(self):
        result = _match_company('Continental Automotive GmbH', {'Continental'})
        self.assertEqual(result, 'Continental')

    def test_parse_page_filters_non_matching(self):
        companies = {'Hyundai AutoEver', 'Continental'}
        jobs = _parse_page(self._sample_html(), companies)
        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0].company, 'Hyundai AutoEver')
        self.assertEqual(jobs[0].title, 'Validation Engineer')
        self.assertEqual(jobs[0].source, 'linkedin')
        print(f'\n    LinkedIn 파싱 OK: {jobs[0].title} at {jobs[0].company}')

    def test_job_id_consistent(self):
        companies = {'Hyundai AutoEver'}
        jobs1 = _parse_page(self._sample_html(), companies)
        jobs2 = _parse_page(self._sample_html(), companies)
        self.assertEqual(jobs1[0].id, jobs2[0].id)  # 동일 URL → 동일 ID

    def test_parse_empty_html(self):
        jobs = _parse_page('<html></html>', {'Hyundai'})
        self.assertEqual(jobs, [])

    @patch('fetch_linkedin.requests.get')
    def test_fetch_all_linkedin_mock(self, mock_get):
        mock_get.return_value = MagicMock(
            status_code=200,
            text=self._sample_html(),
        )
        jobs = fetch_all_linkedin(['Hyundai AutoEver', 'Continental'])
        self.assertIsInstance(jobs, list)
        print(f'\n    fetch_all_linkedin mock OK: {len(jobs)}건')


# ═══════════════════════════════════════════════════════
# 4. SQLite 추적
# ═══════════════════════════════════════════════════════
class T4_DB(unittest.TestCase):

    def setUp(self):
        db.reset()

    def _job(self, id_: str, title: str = 'Engineer') -> models.Job:
        return models.Job(id=id_, title=title, company='TestCo',
                          url=f'https://example.com/{id_}',
                          location='Seoul', source='greenhouse', posted='2026-08-05')

    def test_first_time_is_new(self):
        new = db.get_new([self._job('j1'), self._job('j2')])
        self.assertEqual(len(new), 2)

    def test_second_time_not_new(self):
        db.get_new([self._job('j1')])
        new = db.get_new([self._job('j1')])
        self.assertEqual(len(new), 0)
        print('\n    SQLite 중복 방지 OK')

    def test_only_new_returned(self):
        db.get_new([self._job('j1')])
        new = db.get_new([self._job('j1'), self._job('j2')])
        self.assertEqual(len(new), 1)
        self.assertEqual(new[0].id, 'j2')

    def test_total_seen(self):
        db.get_new([self._job(f'j{i}') for i in range(5)])
        self.assertEqual(db.total_seen(), 5)

    def test_empty_input(self):
        self.assertEqual(db.get_new([]), [])


# ═══════════════════════════════════════════════════════
# 5. 키워드 스코어링
# ═══════════════════════════════════════════════════════
class T5_Scoring(unittest.TestCase):

    def _job(self, title: str) -> models.Job:
        return models.Job(id='x', title=title, company='Co',
                          url='https://example.com', location='',
                          source='greenhouse', posted='2026-08-05')

    def test_high_relevance(self):
        jobs = score_jobs([self._job('Senior IVI Validation Engineer')])
        self.assertGreaterEqual(len(jobs[0].kw_hits), 2)
        high, _ = split(jobs)
        self.assertEqual(len(high), 1)

    def test_general_relevance(self):
        jobs = score_jobs([self._job('Embedded Software Engineer')])
        _, gen = split(jobs)
        self.assertEqual(len(gen), 1)

    def test_no_relevance_excluded(self):
        jobs = score_jobs([self._job('Marketing Manager APAC')])
        high, gen = split(jobs)
        self.assertEqual(len(high) + len(gen), 0)

    def test_no_false_positive_ecu_in_cybersecurity(self):
        """'ECU'가 'cybersecurity' 안에서 오탐되면 안 됨 (\b 단어경계 검증)"""
        jobs = score_jobs([self._job('Automotive Cybersecurity Lead')])
        self.assertEqual(len(jobs[0].kw_hits), 1)  # cybersecurity만 1개
        _, gen = split(jobs)
        self.assertEqual(len(gen), 1)
        print('\n    오탐 방지 OK: ECU not in cybersecurity')


# ═══════════════════════════════════════════════════════
# 6. 파일 출력
# ═══════════════════════════════════════════════════════
class T6_Output(unittest.TestCase):

    def _job(self, title, company, kw=None) -> models.Job:
        j = models.Job(id='x', title=title, company=company,
                       url='https://example.com', location='Seoul',
                       source='greenhouse', posted='2026-08-05')
        j.kw_hits = kw or []
        return j

    def _output_path(self) -> Path:
        return _cfg.OUTPUT_DIR / f'jobs_{_dt.now():%Y-%m-%d}.md'

    def test_creates_file(self):
        notify(
            [self._job('IVI Validation Lead', 'Hyundai', ['IVI', 'validation'])],
            [self._job('Embedded Developer', 'Continental', ['embedded'])])
        self.assertTrue(self._output_path().exists())

    def test_content(self):
        notify([self._job('DoIP Test Engineer', 'JLR', ['DoIP', 'validation'])], [])
        content = self._output_path().read_text(encoding='utf-8')
        self.assertIn('DoIP Test Engineer', content)
        self.assertIn('JLR', content)
        print(f'\n    출력 파일 OK: {self._output_path()}')

    def test_empty_no_crash(self):
        notify([], [])
        self.assertTrue(self._output_path().exists())


# ═══════════════════════════════════════════════════════
# 7. 실제 네트워크 통합 테스트
# ═══════════════════════════════════════════════════════
class T7_RealNetwork(unittest.TestCase):

    def test_greenhouse_real_waymo(self):
        """Greenhouse 신 URL로 실제 공고 수집"""
        jobs = fetch_greenhouse('waymo', 'Waymo')
        self.assertIsInstance(jobs, list)
        if jobs:
            self.assertTrue(all(j.source == 'greenhouse' for j in jobs))
            self.assertTrue(all(j.url.startswith('https://') for j in jobs))
            print(f'\n    Waymo GH 실제: {len(jobs)}건')
            print(f'    샘플: {jobs[0].title} | {jobs[0].location}')
        else:
            print('\n    Waymo GH: 0건 (슬러그 변경 가능성)')

    def test_greenhouse_real_zoox(self):
        """zoox도 Greenhouse 사용 여부 확인"""
        jobs = fetch_greenhouse('zoox', 'Zoox')
        self.assertIsInstance(jobs, list)
        print(f'\n    Zoox GH: {len(jobs)}건')

    def test_lever_real_zoox(self):
        """zoox는 Lever 사용 확인됨"""
        import requests
        r = requests.get('https://api.lever.co/v0/postings/zoox?mode=json', timeout=10)
        self.assertEqual(r.status_code, 200)
        jobs_data = r.json()
        self.assertIsInstance(jobs_data, list)
        print(f'\n    Zoox Lever: {len(jobs_data)}건')
        if jobs_data:
            print(f'    샘플: {jobs_data[0].get("text")} | {jobs_data[0].get("categories", {}).get("location")}')

    def test_linkedin_real_search(self):
        """LinkedIn guest API 실제 키워드 검색"""
        import requests
        from bs4 import BeautifulSoup
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Language': 'en-US,en;q=0.9',
        }
        r = requests.get(
            'https://www.linkedin.com/jobs-guest/jobs/api/seeMoreJobPostings/search',
            params={'keywords': 'validation engineer automotive', 'location': '', 'start': 0},
            headers=headers, timeout=12,
        )
        self.assertEqual(r.status_code, 200)
        soup = BeautifulSoup(r.text, 'html.parser')
        cards = soup.find_all('li')
        self.assertGreater(len(cards), 0)
        print(f'\n    LinkedIn 실제: {len(cards)}개 카드')
        if cards:
            title = cards[0].find('h3')
            company = cards[0].find('h4')
            if title:
                print(f'    샘플: {title.get_text(strip=True)} at {company.get_text(strip=True) if company else "?"}')

    def test_detect_greenhouse_slug(self):
        """detect_ats의 신 URL로 슬러그 감지 테스트"""
        result = _ok_greenhouse('waymo')
        # Waymo가 GH 사용하면 True, 변경됐으면 False — 둘 다 허용
        self.assertIsInstance(result, bool)
        print(f'\n    Greenhouse 감지 (waymo): {result}')

    def test_full_pipeline_mocked(self):
        """전체 파이프라인 — ATS + LinkedIn mock + SQLite + 파일 출력"""
        db.reset()
        fake_jobs = [
            models.Job('gh_111', 'IVI Validation Engineer', 'Waymo',
                       'https://waymo.com/j/111', 'Mountain View', 'greenhouse', '2026-08-05'),
            models.Job('li_222', 'Automotive Cybersecurity Lead', 'Continental',
                       'https://linkedin.com/jobs/222', 'Frankfurt', 'linkedin', '2026-08-05'),
            models.Job('lv_333', 'Marketing Manager', 'Tesla',
                       'https://tesla.com/j/333', 'Austin', 'lever', '2026-08-05'),
        ]
        new    = db.get_new(fake_jobs)
        self.assertEqual(len(new), 3)

        scored = score_jobs(new)
        high, gen = split(scored)

        # IVI Validation → high (IVI + validation)
        self.assertTrue(any(j.title == 'IVI Validation Engineer' for j in high))
        # Marketing Manager → 제외
        all_kept = high + gen
        self.assertFalse(any(j.title == 'Marketing Manager' for j in all_kept))

        notify(high, gen)
        content = (_cfg.OUTPUT_DIR / f'jobs_{_dt.now():%Y-%m-%d}.md').read_text(encoding='utf-8')
        self.assertIn('IVI Validation Engineer', content)
        self.assertNotIn('Marketing Manager', content)

        # 2회차 → 중복 없음
        self.assertEqual(len(db.get_new(fake_jobs)), 0)
        out = _cfg.OUTPUT_DIR / f'jobs_{_dt.now():%Y-%m-%d}.md'
        print(f'\n    전체 파이프라인 OK: 핵심 {len(high)} / 일반 {len(gen)}')
        print(f'    출력: {out}')


# ═══════════════════════════════════════════════════════
# 실행
# ═══════════════════════════════════════════════════════
if __name__ == '__main__':
    print('=' * 60)
    print('채용공고 모니터 검증 테스트')
    print(f'Python {sys.version.split()[0]} | {HERE}')
    print('=' * 60)

    loader = unittest.TestLoader()
    loader.sortTestMethodsUsing = None
    suite = unittest.TestSuite()
    for cls in [T1_Slugs, T2_ATSParsing, T3_LinkedInParsing,
                T4_DB, T5_Scoring, T6_Output, T7_RealNetwork]:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print('\n' + '=' * 60)
    print('ALL TESTS PASSED' if result.wasSuccessful()
          else f'FAILED: {len(result.failures)} failures / {len(result.errors)} errors')
    print('=' * 60)
    sys.exit(0 if result.wasSuccessful() else 1)
