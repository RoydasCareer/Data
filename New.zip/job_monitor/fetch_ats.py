"""
Greenhouse · Lever · Ashby 공개 JSON API 수집
인증 불필요, 구조화된 데이터, 가장 신뢰성 높음
"""
import hashlib
import requests
from datetime import datetime, timezone
from models import Job

_TIMEOUT = 10


def _url_id(url: str) -> str:
    return hashlib.md5(url.encode()).hexdigest()[:12]


# ── Greenhouse ────────────────────────────────────────────────────────

def fetch_greenhouse(slug: str, company: str) -> list[Job]:
    # 구 URL(boards.greenhouse.io) 은 404 → 신 URL 사용
    try:
        r = requests.get(
            f'https://boards-api.greenhouse.io/v1/boards/{slug}/jobs',
            timeout=_TIMEOUT, headers={'User-Agent': 'JobMonitor/1.0'})
        r.raise_for_status()
        jobs = []
        for j in r.json().get('jobs', []):
            loc = j.get('location', {})
            location = loc.get('name', '') if isinstance(loc, dict) else ''
            jobs.append(Job(
                id=f'gh_{j["id"]}',
                title=j.get('title', ''),
                company=company,
                url=j.get('absolute_url', ''),
                location=location,
                source='greenhouse',
                posted=j.get('updated_at', '')[:10],
            ))
        return jobs
    except Exception as e:
        print(f'  [GH] {slug}: {e}')
        return []


# ── Lever ─────────────────────────────────────────────────────────────

def fetch_lever(slug: str, company: str) -> list[Job]:
    try:
        r = requests.get(
            f'https://api.lever.co/v0/postings/{slug}?mode=json',
            timeout=_TIMEOUT, headers={'User-Agent': 'JobMonitor/1.0'})
        r.raise_for_status()
        jobs = []
        for j in r.json():
            ts = j.get('createdAt', 0)
            posted = datetime.fromtimestamp(ts / 1000, tz=timezone.utc).strftime('%Y-%m-%d') if ts else ''
            jobs.append(Job(
                id=f'lv_{j["id"]}',
                title=j.get('text', ''),
                company=company,
                url=j.get('hostedUrl', ''),
                location=j.get('categories', {}).get('location', ''),
                source='lever',
                posted=posted,
            ))
        return jobs
    except Exception as e:
        print(f'  [LV] {slug}: {e}')
        return []


# ── Ashby ─────────────────────────────────────────────────────────────

def fetch_ashby(slug: str, company: str) -> list[Job]:
    try:
        r = requests.get(
            f'https://jobs.ashbyhq.com/{slug}/json',
            timeout=_TIMEOUT, headers={'User-Agent': 'JobMonitor/1.0'})
        r.raise_for_status()
        jobs = []
        for j in r.json().get('jobs', []):
            jobs.append(Job(
                id=f'ab_{j["id"]}',
                title=j.get('title', ''),
                company=company,
                url=f'https://jobs.ashbyhq.com/{slug}/{j["id"]}',
                location=j.get('location', ''),
                source='ashby',
                posted=j.get('publishedDate', '')[:10],
            ))
        return jobs
    except Exception as e:
        print(f'  [AB] {slug}: {e}')
        return []


# ── 디스패처 ──────────────────────────────────────────────────────────

_FETCHERS = {
    'greenhouse': fetch_greenhouse,
    'lever':      fetch_lever,
    'ashby':      fetch_ashby,
}


def fetch_all_ats(ats_map: dict) -> list[Job]:
    """ats_map = {company: {ats: 'greenhouse', slug: '...'}}"""
    all_jobs: list[Job] = []
    for company, info in ats_map.items():
        fetcher = _FETCHERS.get(info['ats'])
        if not fetcher:
            continue
        jobs = fetcher(info['slug'], company)
        print(f'  [{info["ats"].upper()[:2]}] {company}: {len(jobs)}건')
        all_jobs.extend(jobs)
    return all_jobs
