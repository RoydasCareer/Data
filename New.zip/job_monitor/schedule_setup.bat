@echo off
REM ─────────────────────────────────────────────────────
REM  job_monitor — Windows Task Scheduler 등록
REM  news_digest (07:00) 이후 07:30에 실행
REM ─────────────────────────────────────────────────────

set SCRIPT_DIR=%~dp0
set PYTHON=python
set TASK_NAME=AutomotiveJobMonitor

echo [1/2] 기존 태스크 삭제 (없으면 무시)...
schtasks /delete /tn "%TASK_NAME%" /f 2>nul

echo [2/2] 태스크 등록 (매일 07:30)...
schtasks /create ^
  /tn "%TASK_NAME%" ^
  /tr "%PYTHON% \"%SCRIPT_DIR%main.py\"" ^
  /sc DAILY ^
  /st 07:30 ^
  /sd %date% ^
  /f

echo.
echo 완료. 확인:
schtasks /query /tn "%TASK_NAME%"
pause
