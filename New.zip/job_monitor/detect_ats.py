"""
일회성 실행: 780개 기업에서 Greenhouse/Lever/Ashby 사용 여부 자동 감지
결과를 ats_map.json으로 저장 → fetch_ats.py가 매일 사용

실행: python detect_ats.py
소요: 약 10~20분 (요청 간 딜레이 포함)
"""
import json
import re
import time
import requests
from pathlib import Path

HERE = Path(__file__).resolve().parent
COMPANY_FILE = HERE.parent / 'news_digest' / 'company_list.md'
OUT = HERE / 'ats_map.json'
_TIMEOUT = 6
_DELAY = 0.4  # 초


def load_companies() -> list[str]:
    with open(COMPANY_FILE, encoding='utf-8') as f:
        return [l[2:].strip() for l in f if l.startswith('- ')]


def make_slugs(name: str) -> list[str]:
    """회사명 → ATS 슬러그 후보 목록 (시도 순서대로)"""
    n = name.lower()
    # 일반적인 법인 접미사 제거
    for sfx in (' inc', ' llc', ' ltd', ' gmbh', ' ag', ' plc', ' corp',
                ' group', ' technologies', ' automotive', ' systems',
                ' solutions', ' robotics', ' electric', ' motors'):
        n = n.replace(sfx, '')
    n = re.sub(r'[^a-z0-9\s]', ' ', n).strip()
    words = n.split()
    if not words:
        return []
    candidates = []
    candidates.append('-'.join(words))          # "hyundai-motor"
    if len(words) == 1:
        candidates.append(words[0])
    elif len(words) == 2:
        candidates.append(words[0])             # first word only
        candidates.append(''.join(words))       # no separator
    else:
        candidates.append(words[0])
        candidates.append(words[0] + '-' + words[1])
        candidates.append(''.join(words))
    return list(dict.fromkeys(candidates))  # 순서 유지 중복 제거


def _ok_greenhouse(slug: str) -> bool:
    # 구 URL(boards.greenhouse.io/jobs.json) 은 404 → 신 URL 사용
    try:
        r = requests.get(
            f'https://boards-api.greenhouse.io/v1/boards/{slug}/jobs',
            timeout=_TIMEOUT, headers={'User-Agent': 'ATSDetect/1.0'})
        data = r.json()
        return r.status_code == 200 and isinstance(data.get('jobs'), list)
    except Exception:
        return False


def _ok_lever(slug: str) -> bool:
    try:
        r = requests.get(
            f'https://api.lever.co/v0/postings/{slug}?mode=json',
            timeout=_TIMEOUT, headers={'User-Agent': 'ATSDetect/1.0'})
        return r.status_code == 200 and isinstance(r.json(), list)
    except Exception:
        return False


def _ok_ashby(slug: str) -> bool:
    try:
        r = requests.get(
            f'https://jobs.ashbyhq.com/{slug}/json',
            timeout=_TIMEOUT, headers={'User-Agent': 'ATSDetect/1.0'})
        return r.status_code == 200 and 'jobs' in r.json()
    except Exception:
        return False


ATS_CHECKS = [
    ('greenhouse', _ok_greenhouse),
    ('lever',      _ok_lever),
    ('ashby',      _ok_ashby),
]


def detect(companies: list[str] | None = None, resume: bool = True) -> dict:
    """
    companies: 특정 기업만 검사 (None = 전체)
    resume:    기존 ats_map.json 있으면 이어서 진행
    """
    if companies is None:
        companies = load_companies()

    # 기존 결과 로드 (이어하기)
    ats_map: dict = {}
    if resume and OUT.exists():
        with open(OUT, encoding='utf-8') as f:
            ats_map = json.load(f)
        print(f'기존 매핑 {len(ats_map)}개 로드 (이어서 진행)')

    total = len(companies)
    found = 0

    for i, company in enumerate(companies, 1):
        if company in ats_map:
            found += 1
            continue  # 이미 감지된 기업 스킵

        slugs = make_slugs(company)
        matched = False

        for slug in slugs:
            for ats_name, checker in ATS_CHECKS:
                if checker(slug):
                    ats_map[company] = {'ats': ats_name, 'slug': slug}
                    print(f'[{i}/{total}] {company} → {ats_name}:{slug}')
                    found += 1
                    matched = True
                    break
                time.sleep(_DELAY)
            if matched:
                break

        if not matched and i % 50 == 0:
            print(f'[{i}/{total}] 진행 중 ({found}개 발견)...')

        # 중간 저장 (50개마다)
        if i % 50 == 0:
            with open(OUT, 'w', encoding='utf-8') as f:
                json.dump(ats_map, f, indent=2, ensure_ascii=False)

    # 최종 저장
    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump(ats_map, f, indent=2, ensure_ascii=False)

    print(f'\n완료: {found}/{total}개 ATS 감지 → {OUT}')
    return ats_map


if __name__ == '__main__':
    detect()
