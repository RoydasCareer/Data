"""
다채널 알림 디스패처 (채용공고용)
config.NOTIFY_METHODS 에 원하는 채널을 나열하면 모두 동시 전송됩니다.

지원 채널: 'file', 'email', 'telegram', 'slack', 'discord', 'desktop'
"""
import smtplib
import ssl
import subprocess
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import requests

import config as _cfg
from models import Job


# ── 공통 텍스트 포맷 ──────────────────────────────────────────

def _text(high: list[Job], gen: list[Job], date: str) -> str:
    total = len(high) + len(gen)
    lines = [
        f'💼 채용공고 알림 — {date}',
        f'신규 {total}건  (핵심 {len(high)} / 일반 {len(gen)})',
        '',
    ]
    if high:
        lines.append('⭐ 핵심 관련')
        for j in high[:10]:
            kw = ' · '.join(j.kw_hits[:3])
            lines.append(f'• {j.title} — {j.company}')
            lines.append(f'  {j.location or "위치 미상"}  |  {kw}')
            lines.append(f'  {j.url}')
    if gen:
        lines += ['', '📋 기타 신규']
        for j in gen[:10]:
            lines.append(f'• {j.title} — {j.company}')
            lines.append(f'  {j.location or "위치 미상"}')
    return '\n'.join(lines)


# ── file ─────────────────────────────────────────────────────

def _send_file(high: list[Job], gen: list[Job], date: str):
    _cfg.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    path = _cfg.OUTPUT_DIR / f'jobs_{date}.md'

    def section(heading, jobs):
        if not jobs:
            return ''
        lines = [f'\n## {heading}\n']
        for j in jobs:
            kw = ' · '.join(f'`{k}`' for k in j.kw_hits)
            lines += [
                f'### [{j.title}]({j.url})',
                f'**{j.company}** | {j.location or "위치 미상"}',
                f'키워드: {kw}' if kw else '',
                f'출처: {j.source.capitalize()} · {j.posted}\n',
            ]
        return '\n'.join(l for l in lines if l != '')

    total = len(high) + len(gen)
    content = (
        f'# 채용공고 알림 — {date}\n\n'
        f'**신규 {total}건** (핵심 {len(high)} / 일반 {len(gen)})\n'
        + section('⭐ 핵심 관련 (직무 키워드 매칭)', high)
        + section('📋 기타 신규 공고', gen)
        + '\n---\n*Greenhouse · Lever · LinkedIn*\n'
    )
    path.write_text(content, encoding='utf-8')
    print(f'  [file] {path}')


# ── email ────────────────────────────────────────────────────

def _html_rows(jobs: list[Job]) -> str:
    rows = []
    for j in jobs:
        kw = ' '.join(
            f'<code style="background:#eef;padding:1px 4px;border-radius:3px;font-size:11px">{k}</code>'
            for k in j.kw_hits
        )
        rows.append(
            f'<tr><td style="padding:8px 0;border-bottom:1px solid #f4f4f4">'
            f'<a href="{j.url}" style="color:#111;font-weight:500;text-decoration:none">'
            f'{j.title}</a><br>'
            f'<b>{j.company}</b> | {j.location or "위치 미상"} | '
            f'<span style="color:#888;font-size:12px">{j.source} · {j.posted}</span><br>'
            f'<span style="font-size:12px">{kw}</span>'
            f'</td></tr>'
        )
    return ''.join(rows)


def _send_email(high: list[Job], gen: list[Job], date: str):
    total = len(high) + len(gen)
    h_block = (f'<h3 style="color:#2c7bb6">⭐ 핵심 관련 ({len(high)}건)</h3>'
               f'<table width="100%">{_html_rows(high)}</table>') if high else ''
    g_block = (f'<h3 style="color:#555;margin-top:20px">📋 기타 신규 ({len(gen)}건)</h3>'
               f'<table width="100%">{_html_rows(gen)}</table>') if gen else ''

    html = (
        f'<html><body style="font-family:Arial,sans-serif;max-width:700px;margin:0 auto;padding:20px">'
        f'<div style="background:#2c7bb6;color:#fff;padding:14px 20px;border-radius:6px 6px 0 0">'
        f'<strong>💼 채용공고 알림</strong>'
        f'<span style="opacity:.75;margin-left:12px">{date} · 신규 {total}건</span></div>'
        f'<div style="border:1px solid #ddd;border-top:none;padding:20px;border-radius:0 0 6px 6px">'
        f'{h_block}{g_block}'
        f'<p style="color:#ccc;font-size:11px;text-align:center;margin-top:24px">'
        f'Greenhouse · Lever · LinkedIn</p></div></body></html>'
    )
    msg = MIMEMultipart('alternative')
    msg['Subject'] = f'💼 채용공고 알림 {date} — 신규 {total}건'
    msg['From']    = _cfg.SENDER
    msg['To']      = _cfg.RECIPIENT
    msg.attach(MIMEText(html, 'html', 'utf-8'))

    ctx = ssl.create_default_context()
    with smtplib.SMTP('smtp.gmail.com', 587) as s:
        s.starttls(context=ctx)
        s.login(_cfg.SENDER, _cfg.PASSWORD)
        s.sendmail(_cfg.SENDER, _cfg.RECIPIENT, msg.as_bytes())
    print(f'  [email] → {_cfg.RECIPIENT}')


# ── telegram ─────────────────────────────────────────────────

def _send_telegram(high: list[Job], gen: list[Job], date: str):
    body = _text(high, gen, date)
    api  = f'https://api.telegram.org/bot{_cfg.TELEGRAM_TOKEN}/sendMessage'
    for chunk in [body[i:i + 4000] for i in range(0, max(len(body), 1), 4000)]:
        requests.post(
            api,
            json={'chat_id': _cfg.TELEGRAM_CHAT_ID, 'text': chunk},
            timeout=10,
        ).raise_for_status()
    print(f'  [telegram] → chat_id {_cfg.TELEGRAM_CHAT_ID}')


# ── slack ────────────────────────────────────────────────────

def _send_slack(high: list[Job], gen: list[Job], date: str):
    requests.post(
        _cfg.SLACK_WEBHOOK,
        json={'text': _text(high, gen, date)},
        timeout=10,
    ).raise_for_status()
    print('  [slack] 전송 완료')


# ── discord ──────────────────────────────────────────────────

def _send_discord(high: list[Job], gen: list[Job], date: str):
    body = _text(high, gen, date)
    for chunk in [body[i:i + 1900] for i in range(0, max(len(body), 1), 1900)]:
        requests.post(
            _cfg.DISCORD_WEBHOOK,
            json={'content': chunk},
            timeout=10,
        ).raise_for_status()
    print('  [discord] 전송 완료')


# ── desktop ──────────────────────────────────────────────────

def _send_desktop(high: list[Job], gen: list[Job], date: str):
    total = len(high) + len(gen)
    title = f'채용공고 알림 {date}'
    msg   = f'신규 {total}건 (핵심 {len(high)} / 일반 {len(gen)})'
    ps = (
        'Add-Type -AssemblyName System.Windows.Forms;'
        '$n=[System.Windows.Forms.NotifyIcon]::new();'
        '$n.Icon=[System.Drawing.SystemIcons]::Information;'
        '$n.Visible=$true;'
        f'$n.ShowBalloonTip(8000,"{title}","{msg}",'
        '[System.Windows.Forms.ToolTipIcon]::Info);'
        'Start-Sleep 9;$n.Dispose()'
    )
    subprocess.Popen(
        ['powershell', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', ps]
    )
    print('  [desktop] 알림 전송')


# ── 디스패처 ─────────────────────────────────────────────────

_SENDERS = {
    'file':     _send_file,
    'email':    _send_email,
    'telegram': _send_telegram,
    'slack':    _send_slack,
    'discord':  _send_discord,
    'desktop':  _send_desktop,
}


def notify(high: list[Job], gen: list[Job]):
    """NOTIFY_METHODS에 등록된 모든 채널로 전송."""
    date    = datetime.now().strftime('%Y-%m-%d')
    methods = _cfg.NOTIFY_METHODS
    print(f'알림 전송 → {methods}')
    for method in methods:
        sender = _SENDERS.get(method)
        if not sender:
            print(f'  [{method}] 알 수 없는 채널, 스킵')
            continue
        try:
            sender(high, gen, date)
        except Exception as e:
            print(f'  [{method}] 실패: {e}')
