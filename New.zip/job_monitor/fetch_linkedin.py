"""
LinkedIn Jobs guest API — 인증 불필요
키워드 기반 광역 검색 → 기업 목록 필터링

Indeed RSS가 막혔으므로 LinkedIn guest API로 교체.
8개 쿼리 × 2페이지 = 최대 160건, 약 30초 소요.
"""
import hashlib
import requests
import time
from bs4 import BeautifulSoup
from models import Job
import config as _cfg

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/120.0.0.0 Safari/537.36'
    ),
    'Accept-Language': 'en-US,en;q=0.9',
}
_BASE   = 'https://www.linkedin.com/jobs-guest/jobs/api/seeMoreJobPostings/search'
_PAGES  = 2   # 쿼리당 페이지 수 (10건/페이지)

# 경력 영역별 검색 쿼리 — 기업명 불필요, 직무 키워드로 광역 수집 후 필터링
SEARCH_QUERIES = [
    'IVI infotainment validation automotive',
    'automotive cybersecurity engineer',
    'UDS DoIP diagnostic automotive',
    'SDV OTA embedded automotive software',
    'ADAS validation testing automotive',
    'automotive software test engineer',
    'EV electric vehicle software engineer automotive',
    'automotive technical project manager validation',
]


def _jid(url: str) -> str:
    return 'li_' + hashlib.md5(url.encode()).hexdigest()[:10]


def _match_company(company_raw: str, company_set: set[str]) -> str | None:
    """LinkedIn 결과의 회사명이 우리 기업 목록에 속하는지 확인."""
    raw_lower = company_raw.lower()
    for company in company_set:
        # 4자 이상 단어가 회사명에 포함되면 매칭
        words = [w for w in company.lower().split() if len(w) > 3]
        if words and any(w in raw_lower for w in words):
            return company
    return None


def _parse_page(html: str, company_set: set[str]) -> list[Job]:
    soup = BeautifulSoup(html, 'html.parser')
    jobs = []
    for li in soup.find_all('li'):
        try:
            title_el   = li.find('h3')
            company_el = li.find('h4')
            link_el    = li.find('a', href=True)
            if not (title_el and company_el and link_el):
                continue

            title       = title_el.get_text(strip=True)
            company_raw = company_el.get_text(strip=True)
            url         = link_el['href'].split('?')[0]

            matched = _match_company(company_raw, company_set)
            if not matched:
                continue

            jobs.append(Job(
                id=_jid(url),
                title=title,
                company=matched,
                url=url,
                location='',
                source='linkedin',
                posted='',
            ))
        except Exception:
            continue
    return jobs


def fetch_all_linkedin(companies: list[str]) -> list[Job]:
    """SEARCH_QUERIES로 LinkedIn 검색 → 기업 목록 기준 필터링."""
    company_set = set(companies)
    all_jobs: list[Job] = []
    seen_ids:  set[str] = set()
    days_secs = _cfg.INDEED_DAYS * 86400

    for i, query in enumerate(SEARCH_QUERIES, 1):
        label = query[:45] + ('...' if len(query) > 45 else '')
        print(f'  [LinkedIn] {i}/{len(SEARCH_QUERIES)}: {label}', end=' ', flush=True)
        found = 0

        for page in range(_PAGES):
            try:
                r = requests.get(
                    _BASE,
                    params={
                        'keywords': query,
                        'location': '',
                        'f_TPR': f'r{days_secs}',
                        'start': page * 10,
                    },
                    headers=_HEADERS,
                    timeout=12,
                )
                if r.status_code != 200:
                    break

                jobs = _parse_page(r.text, company_set)
                new  = [j for j in jobs if j.id not in seen_ids]
                seen_ids.update(j.id for j in new)
                all_jobs.extend(new)
                found += len(new)

                if len(BeautifulSoup(r.text, 'html.parser').find_all('li')) < 10:
                    break  # 마지막 페이지
            except Exception as e:
                print(f'[err: {e}]', end=' ')
                break
            time.sleep(0.5)

        print(f'{found}건')
        if i < len(SEARCH_QUERIES):
            time.sleep(_cfg.INDEED_DELAY)

    return all_jobs
