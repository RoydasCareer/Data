from dataclasses import dataclass, field

@dataclass
class Job:
    id: str           # ATS job ID or hash(url)
    title: str
    company: str
    url: str
    location: str
    source: str       # 'greenhouse' | 'lever' | 'ashby' | 'indeed'
    posted: str       # YYYY-MM-DD or raw string
    snippet: str = ''
    kw_hits: list = field(default_factory=list)  # matched keywords
