from pathlib import Path

_HERE = Path(__file__).resolve().parent

# 기업 리스트 (news_digest 공유)
COMPANY_FILE = _HERE.parent / 'news_digest' / 'company_list.md'

# 파일 경로
ATS_MAP_FILE = _HERE / 'ats_map.json'
DB_FILE      = _HERE / 'jobs.db'
OUTPUT_DIR   = _HERE / 'output'

# ── 알림 채널 ─────────────────────────────────────────────
# 선택지: 'file' | 'email' | 'telegram' | 'slack' | 'discord' | 'desktop'
NOTIFY_METHODS = ['file']     # ← 여기만 바꾸면 됨

# ── 이메일 ('email' 사용 시) ──────────────────────────────
SENDER    = 'your_gmail@gmail.com'
PASSWORD  = 'xxxx xxxx xxxx xxxx'
RECIPIENT = 'your_email@example.com'

# ── Telegram ('telegram' 사용 시) ─────────────────────────
TELEGRAM_TOKEN   = ''
TELEGRAM_CHAT_ID = ''

# ── Slack ('slack' 사용 시) ───────────────────────────────
SLACK_WEBHOOK = ''

# ── Discord ('discord' 사용 시) ───────────────────────────
DISCORD_WEBHOOK = ''

# Indeed 설정
INDEED_DAYS        = 1    # 최근 N일치만
INDEED_BATCH_SIZE  = 10   # 한 번 쿼리에 묶을 기업 수
INDEED_DELAY       = 1.5  # 요청 간격 (초)
INDEED_MAX_RESULTS = 50   # 배치당 최대 결과

# 직무 관련 키워드 (타이틀 매칭용)
# 2개 이상 매칭 → 핵심 / 1개 → 일반 / 0개 → 제외
JOB_KEYWORDS = [
    # 직무명
    'validation', 'verification', 'test engineer', 'testing',
    'quality assurance', 'QA engineer',
    # 도메인
    'IVI', 'infotainment', 'HMI', 'embedded', 'firmware',
    'ADAS', 'autonomous', 'cybersecurity', 'diagnostic',
    'UDS', 'DoIP', 'OTA', 'FOTA', 'ECU', 'AUTOSAR', 'CAN',
    'SDV', 'software-defined',
    # 시니어/리드 직책
    'technical PM', 'project manager', 'program manager',
    'validation lead', 'test lead',
]
