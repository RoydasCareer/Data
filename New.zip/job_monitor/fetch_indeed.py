"""
Indeed RSS 배치 수집
10개 기업씩 묶어서 한 번에 쿼리 → 78회 요청으로 780개 기업 커버
"""
import hashlib
import re
import time
import feedparser
from urllib.parse import quote
from models import Job
import config as _cfg

_RSS = 'https://www.indeed.com/rss'


def _jid(url: str) -> str:
    m = re.search(r'jk=([a-z0-9]+)', url)
    if m:
        return f'id_{m.group(1)}'
    return 'id_' + hashlib.md5(url.encode()).hexdigest()[:10]


def _build_query(companies: list[str]) -> str:
    parts = ' OR '.join(f'"{c}"' for c in companies)
    return f'({parts})'


def _match_company(result_title: str, candidates: list[str]) -> str | None:
    """
    Indeed 타이틀 형식: "Job Title - Company Name - Location"
    두 번째 세그먼트에서 우리 기업명 매칭
    """
    parts = result_title.split(' - ')
    company_field = parts[1].strip().lower() if len(parts) >= 2 else ''
    for c in candidates:
        # 3자 이상 단어가 회사 필드에 포함되면 매칭
        words = [w for w in c.lower().split() if len(w) > 3]
        if words and any(w in company_field for w in words):
            return c
    return None


def _parse_entries(entries, companies: list[str]) -> list[Job]:
    jobs = []
    for entry in entries:
        title_raw = entry.get('title', '')
        link = entry.get('link', '')
        published = entry.get('published', '')[:16]
        parts = title_raw.split(' - ')

        matched = _match_company(title_raw, companies)
        if not matched:
            continue

        job_title = parts[0].strip() if parts else title_raw
        location = parts[2].strip() if len(parts) >= 3 else ''
        jobs.append(Job(
            id=_jid(link),
            title=job_title,
            company=matched,
            url=link,
            location=location,
            source='indeed',
            posted=published,
            snippet=entry.get('summary', '')[:200],
        ))
    return jobs


def fetch_batch(companies: list[str]) -> list[Job]:
    q = _build_query(companies)
    url = (f'{_RSS}?q={quote(q)}'
           f'&fromage={_cfg.INDEED_DAYS}'
           f'&filter=0&sort=date&limit={_cfg.INDEED_MAX_RESULTS}')
    try:
        feed = feedparser.parse(url)
        return _parse_entries(feed.entries, companies)
    except Exception as e:
        print(f'  [Indeed] 배치 오류: {e}')
        return []


def fetch_all_indeed(companies: list[str]) -> list[Job]:
    """전체 기업을 INDEED_BATCH_SIZE씩 묶어 쿼리"""
    bs = _cfg.INDEED_BATCH_SIZE
    batches = [companies[i:i + bs] for i in range(0, len(companies), bs)]
    all_jobs: list[Job] = []
    total = len(batches)

    for i, batch in enumerate(batches, 1):
        print(f'  [Indeed] 배치 {i}/{total} ({len(batch)}개)...', end=' ', flush=True)
        jobs = fetch_batch(batch)
        all_jobs.extend(jobs)
        print(f'{len(jobs)}건')
        if i < total:
            time.sleep(_cfg.INDEED_DELAY)

    return all_jobs
