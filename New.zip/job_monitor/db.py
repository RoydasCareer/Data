"""SQLite 기반 신규 공고 추적 — 이미 본 job_id는 다시 알리지 않음"""
import sqlite3
from pathlib import Path
from models import Job
import config as _cfg


def _conn() -> sqlite3.Connection:
    _cfg.DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(_cfg.DB_FILE)
    conn.execute('''
        CREATE TABLE IF NOT EXISTS seen_jobs (
            id       TEXT PRIMARY KEY,
            title    TEXT,
            company  TEXT,
            url      TEXT,
            source   TEXT,
            first_seen TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    return conn


def get_new(jobs: list[Job]) -> list[Job]:
    """jobs 중 DB에 없는 신규 항목만 반환하고 DB에 저장."""
    if not jobs:
        return []
    conn = _conn()
    ids = [j.id for j in jobs]
    placeholders = ','.join('?' * len(ids))
    seen = {row[0] for row in conn.execute(
        f'SELECT id FROM seen_jobs WHERE id IN ({placeholders})', ids)}
    new = [j for j in jobs if j.id not in seen]
    if new:
        conn.executemany(
            'INSERT OR IGNORE INTO seen_jobs (id, title, company, url, source) VALUES (?,?,?,?,?)',
            [(j.id, j.title, j.company, j.url, j.source) for j in new])
        conn.commit()
    conn.close()
    return new


def total_seen() -> int:
    conn = _conn()
    n = conn.execute('SELECT COUNT(*) FROM seen_jobs').fetchone()[0]
    conn.close()
    return n


def reset():
    """테스트용: DB 초기화"""
    conn = _conn()
    conn.execute('DELETE FROM seen_jobs')
    conn.commit()
    conn.close()
