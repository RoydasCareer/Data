"""
채용공고 모니터 — 일 1회 실행
  Tier 1: ATS 공개 API (Greenhouse·Lever·Ashby)  → ats_map.json 기반
  Tier 2: Indeed RSS 배치 수집                    → 나머지 전체 기업
  Tier 3: SQLite diff                             → 신규 공고만 추출

Usage:
  # ATS 감지 (첫 실행 시 한 번만)
  python detect_ats.py

  # 일일 모니터링
  python main.py
"""
import json
import re
from pathlib import Path
from datetime import datetime

import config as _cfg
import db
from fetch_ats import fetch_all_ats
from fetch_linkedin import fetch_all_linkedin
from models import Job
from notify import notify


def load_companies() -> list[str]:
    with open(_cfg.COMPANY_FILE, encoding='utf-8') as f:
        return [l[2:].strip() for l in f if l.startswith('- ')]


def load_ats_map() -> dict:
    if not _cfg.ATS_MAP_FILE.exists():
        print('[경고] ats_map.json 없음 — detect_ats.py 먼저 실행하세요')
        return {}
    with open(_cfg.ATS_MAP_FILE, encoding='utf-8') as f:
        return json.load(f)


def _kw_match(kw: str, text: str) -> bool:
    # 단어 경계(\b) 매칭으로 'ECU' in 'cybersecurity', 'OTA' in 'automotive' 오탐 방지
    return bool(re.search(r'\b' + re.escape(kw) + r'\b', text, re.IGNORECASE))


def score_jobs(jobs: list[Job]) -> list[Job]:
    """JOB_KEYWORDS 기준으로 kw_hits 계산 (전체 단어 매칭)."""
    for j in jobs:
        text = j.title + ' ' + j.snippet
        j.kw_hits = [kw for kw in _cfg.JOB_KEYWORDS if _kw_match(kw, text)]
    return jobs


def split(jobs: list[Job]) -> tuple[list[Job], list[Job]]:
    """kw_hits 2개↑ → 핵심 / 1개↑ → 일반 / 0개 → 제외."""
    high = sorted([j for j in jobs if len(j.kw_hits) >= 2], key=lambda x: -len(x.kw_hits))
    gen  = [j for j in jobs if len(j.kw_hits) == 1]
    return high[:50], gen[:50]


def main():
    print(f'[{datetime.now():%Y-%m-%d %H:%M}] 채용공고 모니터 시작')
    companies = load_companies()
    ats_map   = load_ats_map()
    ats_companies = set(ats_map.keys())

    # Tier 1 — ATS API
    print(f'\n[Tier 1] ATS API ({len(ats_map)}개 기업)')
    ats_jobs = fetch_all_ats(ats_map)
    print(f'  소계: {len(ats_jobs)}건')

    # Tier 2 — LinkedIn 키워드 검색 (ATS 커버 기업 포함 전체 대상)
    remaining = [c for c in companies if c not in ats_companies]
    print(f'\n[Tier 2] LinkedIn 검색 ({len(remaining)}개 기업 필터 대상)')
    indeed_jobs = fetch_all_linkedin(remaining)
    print(f'  소계: {len(indeed_jobs)}건')

    # 합산 → 신규 감지
    all_jobs = ats_jobs + indeed_jobs
    new_jobs = db.get_new(all_jobs)
    print(f'\n신규 공고: {len(new_jobs)}건 (전체 누적: {db.total_seen()}건)')

    if not new_jobs:
        print('오늘 신규 공고 없음.')
        return

    # 스코어링 & 분류
    scored = score_jobs(new_jobs)
    high, gen = split(scored)
    print(f'핵심 {len(high)}건 / 일반 {len(gen)}건')

    # 출력
    notify(high, gen)


if __name__ == '__main__':
    main()
