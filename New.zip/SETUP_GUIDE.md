# 자동 뉴스레터 & 채용공고 시스템 — 완전 가이드

> 이 문서 하나로 설치부터 운영까지 모두 해결할 수 있습니다.
> 오류가 발생하면 **14. 오류 해결** 섹션을 먼저 확인하세요.

---

## 시스템 개요

매일 자동으로 두 가지 이메일을 받습니다:

| 시각 | 내용 | 소스 |
|------|------|------|
| 07:00 | 🚗 뉴스레터 — 기업 동향 + 경력 관련 기사 | Google News RSS → LM Studio 스코어링 |
| 07:30 | 💼 채용공고 — 신규 공고만 (중복 없음) | Greenhouse · Lever · LinkedIn |

**관련 폴더:**
```
C:\PP\
├── news_digest\     ← 뉴스레터 (LLM 스코어링 포함)
├── job_monitor\     ← 채용공고 모니터
└── SETUP_GUIDE.md   ← 이 문서
```

---

## 목차

1. [사전 준비](#1-사전-준비)
2. [Python 설치](#2-python-설치)
3. [코드 복사](#3-코드-복사)
4. [패키지 설치](#4-패키지-설치)
5. [LM Studio 설치](#5-lm-studio-설치)
6. [LM Studio 모델 설치](#6-lm-studio-모델-설치)
7. [LM Studio 서버 설정](#7-lm-studio-서버-설정)
8. [Gmail 앱 비밀번호 발급](#8-gmail-앱-비밀번호-발급)
9. [알림 채널 설정](#9-알림-채널-설정)
10. [설정 파일 작성](#10-설정-파일-작성)
11. [첫 실행 (ATS 감지)](#11-첫-실행-ats-감지)
12. [동작 테스트](#12-동작-테스트)
13. [자동 실행 등록](#13-자동-실행-등록)
14. [LM Studio 자동 시작](#14-lm-studio-자동-시작)
15. [오류 해결](#15-오류-해결)
16. [운영 중 FAQ](#16-운영-중-faq)

---

## 1. 사전 준비

### 최소 사양

| 항목 | 최소 | 권장 |
|------|------|------|
| OS | Windows 10 64bit | Windows 11 |
| RAM | 8GB | 16GB |
| GPU VRAM | 없어도 됨 (CPU 사용) | 4GB+ (속도 향상) |
| 저장 공간 | 10GB 여유 | 20GB+ |
| 인터넷 | 필수 | — |

> GPU 없어도 됩니다. CPU로 LM Studio 실행 시 스코어링이 느릴 뿐 작동합니다.

---

## 2. Python 설치

### 설치 확인

`Win + R` → `cmd` 입력 → 확인 → 아래 실행:

```
python --version
```

`Python 3.10` 이상 출력되면 → **3단계로 이동**  
오류 또는 3.10 미만이면 → 아래 진행

### 설치

1. [python.org/downloads](https://www.python.org/downloads/) → 최신 버전 다운로드
2. 설치 파일 실행
3. ⚠️ **반드시** 첫 화면에서 `Add Python to PATH` 체크 후 Install Now

설치 후 cmd를 **새로 열고** `python --version` 재확인

---

## 3. 코드 복사

### USB 드라이브 방법

개발 노트북: `C:\PP\` 폴더 전체 USB에 복사  
새 노트북: USB에서 `C:\PP\`로 붙여넣기

### 확인

```
C:\PP\
├── news_digest\
│   ├── main.py
│   ├── llm.py
│   ├── config.py        ← 수정 필요
│   ├── company_list.md
│   └── ...
└── job_monitor\
    ├── main.py
    ├── config.py        ← 수정 필요
    ├── detect_ats.py
    └── ...
```

---

## 4. 패키지 설치

`Win + R` → `cmd` → 아래 실행:

```
pip install feedparser openai requests beautifulsoup4
```

### 설치 확인

```
python -c "import feedparser, openai, requests, bs4; print('OK')"
```

`OK` 출력되면 성공. 오류 시 → [오류 해결 #1](#오류-1-pip-install-실패)

---

## 5. LM Studio 설치

1. [lmstudio.ai](https://lmstudio.ai) → **Download for Windows** 클릭
2. 다운로드된 `.exe` 실행 → 기본 경로로 설치
3. 설치 완료 후 LM Studio 자동 실행됨

---

## 6. LM Studio 모델 설치

### 모델 선택

| 모델 | 크기 | VRAM | 추천 |
|------|------|------|------|
| **Phi-4 Mini Instruct** | 3.8B | 4GB | ⭐ 저사양 노트북 |
| Llama 3.2 3B Instruct | 3B | 3GB | 초경량 |
| Mistral 7B Instruct | 7B | 8GB | 8GB VRAM 이상 |

### 다운로드

1. LM Studio → 왼쪽 🔍 아이콘 클릭
2. 검색창에 `phi-4-mini-instruct` 입력
3. **Download** 클릭 → 완료까지 대기 (5~30분)

---

## 7. LM Studio 서버 설정

1. 왼쪽 **↔ 아이콘** 클릭
2. 상단 드롭다운에서 다운로드한 모델 선택
3. **Start Server** 클릭
4. 아래 메시지 확인:
   ```
   Server running at http://localhost:1234
   ```

### 모델명 확인 (config.py에 입력할 값)

브라우저에서 `http://localhost:1234/v1/models` 접속:

```json
{ "data": [{ "id": "phi-4-mini-instruct" }] }
```

`"id"` 값을 메모 → config.py의 `LLM_MODEL`에 입력

---

## 8. Gmail 앱 비밀번호 발급

일반 비밀번호는 사용 불가 — **앱 비밀번호** 필요

1. Gmail 계정으로 [myaccount.google.com](https://myaccount.google.com) 접속
2. **보안** → **2단계 인증** 확인 (켜져 있어야 함)
   - 꺼져 있으면: 2단계 인증 설정 먼저
3. 검색창에 `앱 비밀번호` 검색 → 클릭
   - 직접 접속: [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
4. **앱 선택 → 메일 → 생성**
5. **16자리 비밀번호** 발급 — 창 닫으면 다시 볼 수 없으므로 바로 복사

---

## 9. 알림 채널 설정

알림은 `NOTIFY_METHODS` 한 줄로 언제든지 바꿀 수 있습니다. 여러 개를 동시에 켤 수도 있어요.

```python
# config.py 공통 설정 (news_digest, job_monitor 모두 동일)

NOTIFY_METHODS = ['email']              # 이메일만
NOTIFY_METHODS = ['telegram']          # 텔레그램만
NOTIFY_METHODS = ['discord']           # 디스코드만
NOTIFY_METHODS = ['email', 'telegram'] # 이메일 + 텔레그램 동시
NOTIFY_METHODS = ['file']              # 파일로 저장 (테스트용)
```

### 채널별 설정 방법

---

#### Email (Gmail)

> 8단계에서 발급한 앱 비밀번호 사용

```python
NOTIFY_METHODS = ['email']
SENDER    = 'your@gmail.com'
PASSWORD  = 'abcd efgh ijkl mnop'   # 16자리 앱 비밀번호
RECIPIENT = 'your@gmail.com'
```

---

#### Telegram ⭐ 추천

스마트폰으로 즉시 수신, 설정 5분 이내

**1단계: 봇 생성**
1. 텔레그램 앱 → 검색 → `@BotFather`
2. `/newbot` 입력
3. 봇 이름 입력 (예: `MyNewsBot`)
4. 봇 username 입력 (예: `mynews_alert_bot`)
5. **HTTP API 토큰** 발급됨 (예: `1234567890:ABCDEFabcdef...`) → 복사

**2단계: Chat ID 확인**
1. 발급된 봇을 검색해서 `/start` 전송
2. 브라우저에서 접속:
   ```
   https://api.telegram.org/bot[토큰]/getUpdates
   ```
3. JSON에서 `"id"` 값 확인 (예: `987654321`)

**config.py 설정:**
```python
NOTIFY_METHODS   = ['telegram']
TELEGRAM_TOKEN   = '1234567890:ABCDEFabcdef...'
TELEGRAM_CHAT_ID = '987654321'
```

---

#### Slack

**1단계: 웹훅 생성**
1. [api.slack.com/apps](https://api.slack.com/apps) → **Create New App** → From scratch
2. 앱 이름 입력 → 워크스페이스 선택 → Create
3. **Incoming Webhooks** → 활성화 → **Add New Webhook to Workspace**
4. 채널 선택 → Allow
5. **Webhook URL** 복사 (예: `https://hooks.slack.com/services/T.../B.../...`)

**config.py 설정:**
```python
NOTIFY_METHODS = ['slack']
SLACK_WEBHOOK  = 'https://hooks.slack.com/services/T.../B.../..'
```

---

#### Discord

**1단계: 웹훅 생성**
1. Discord 서버 → 알림 받을 채널 우클릭 → **채널 편집**
2. **연동** 탭 → **웹후크** → **새 웹후크** → 이름 입력
3. **웹후크 URL 복사** (예: `https://discord.com/api/webhooks/123.../abc...`)

**config.py 설정:**
```python
NOTIFY_METHODS  = ['discord']
DISCORD_WEBHOOK = 'https://discord.com/api/webhooks/123.../abc...'
```

---

#### Desktop (Windows 알림)

추가 설정 불필요. Windows 10/11 바탕화면 우측 하단에 토스트 알림이 표시됩니다.

```python
NOTIFY_METHODS = ['desktop']
```

> ⚠️ 노트북이 절전 상태이면 알림이 뜨지 않습니다. 보조 채널로 사용 권장.

---

#### 여러 채널 동시 사용

```python
# 이메일 + 텔레그램 동시 (권장 조합)
NOTIFY_METHODS   = ['email', 'telegram']
SENDER           = 'your@gmail.com'
PASSWORD         = 'abcd efgh ijkl mnop'
RECIPIENT        = 'your@gmail.com'
TELEGRAM_TOKEN   = '1234567890:ABCDEFabcdef...'
TELEGRAM_CHAT_ID = '987654321'
```

---

## 10. 설정 파일 작성

### 9-1. news_digest/config.py

`C:\PP\news_digest\config.py` 를 메모장으로 열고 아래와 같이 수정:

```python
# ════════════════════════════════════════════════
#  news_digest/config.py  (새 노트북용)
# ════════════════════════════════════════════════

# ── LLM ───────────────────────────────────────────
LLM_MODE  = 'local'                   # LM Studio 사용
LLM_MODEL = 'phi-4-mini-instruct'    # ← 7단계에서 확인한 모델명으로

ANTHROPIC_API_KEY = ''                # 사용 안 함
LM_STUDIO_URL = 'http://localhost:1234/v1'

# ── 알림 채널 ────────────────────────────────────────────────
# 'file'|'email'|'telegram'|'slack'|'discord'|'desktop' — 여러 개 가능
NOTIFY_METHODS = ['email']            # ← ['file'] → ['email'] 변경
OUTPUT_DIR  = 'output'

# ── 이메일 ────────────────────────────────────────
SENDER    = 'your@gmail.com'          # ← 실제 Gmail 주소
PASSWORD  = 'abcd efgh ijkl mnop'    # ← 8단계 앱 비밀번호 (공백 포함 그대로)
RECIPIENT = 'your@gmail.com'          # ← 수신 이메일

# ── 파일 ──────────────────────────────────────────
COMPANY_FILE = 'company_list.md'

# ── RSS ───────────────────────────────────────────
BATCH_SIZE = 20
LANG       = 'en'
COUNTRY    = 'US'

# ── 키워드 ────────────────────────────────────────
KEYWORDS = [
    'UDS', 'DoIP', 'CAN-FD', 'OBD', 'diagnostic',
    'IVI', 'infotainment', 'HMI', 'in-vehicle', 'cockpit',
    'SDV', 'OTA', 'FOTA', 'AUTOSAR', 'ASPICE', 'software-defined',
    'EV', 'electric vehicle', 'HEV', 'BMS', 'battery',
    'ADAS', 'autonomous', 'validation', 'verification', 'functional safety',
    'ISO 26262', 'cybersecurity', 'cyber security', 'ISO 21434',
    'ECU', 'embedded', 'firmware', 'bootloader',
    'Hyundai', 'Kia', 'JLR', 'Jaguar', 'Land Rover',
    'Mobileye', 'Continental', 'Bosch',
]

CAREER_SUMMARY = (
    'IVI validation engineer, 5+ years. '
    'Specializes in UDS/DoIP diagnostics, CAN, automotive cybersecurity, OTA, SDV. '
    'Currently at Hyundai R&D (EV/HEV IVI). '
    'Target: Technical PM or Validation Lead at international automotive companies.'
)
```

### 9-2. job_monitor/config.py

`C:\PP\job_monitor\config.py` 를 메모장으로 열고 수정:

```python
# ════════════════════════════════════════════════
#  job_monitor/config.py  (새 노트북용)
# ════════════════════════════════════════════════
from pathlib import Path

_HERE = Path(__file__).resolve().parent

COMPANY_FILE = _HERE.parent / 'news_digest' / 'company_list.md'
ATS_MAP_FILE = _HERE / 'ats_map.json'
DB_FILE      = _HERE / 'jobs.db'
OUTPUT_DIR   = _HERE / 'output'

# ── 알림 채널 ────────────────────────────────────────────────
# 'file'|'email'|'telegram'|'slack'|'discord'|'desktop'
NOTIFY_METHODS = ['email']

# ── 이메일 ────────────────────────────────────────
SENDER    = 'your@gmail.com'          # ← news_digest와 동일하게
PASSWORD  = 'abcd efgh ijkl mnop'    # ← 동일한 앱 비밀번호
RECIPIENT = 'your@gmail.com'

# ── Indeed/LinkedIn ────────────────────────────────
INDEED_DAYS        = 1
INDEED_BATCH_SIZE  = 10
INDEED_DELAY       = 1.5
INDEED_MAX_RESULTS = 50

# ── 직무 키워드 ────────────────────────────────────
JOB_KEYWORDS = [
    'validation', 'verification', 'test engineer', 'testing',
    'quality assurance', 'QA engineer',
    'IVI', 'infotainment', 'HMI', 'embedded', 'firmware',
    'ADAS', 'autonomous', 'cybersecurity', 'diagnostic',
    'UDS', 'DoIP', 'OTA', 'FOTA', 'ECU', 'AUTOSAR', 'CAN',
    'SDV', 'software-defined',
    'technical PM', 'project manager', 'program manager',
    'validation lead', 'test lead',
]
```

---

## 11. 첫 실행 (ATS 감지)

채용공고 모니터가 어떤 기업이 Greenhouse/Lever를 사용하는지 감지합니다.  
**최초 1회만** 실행하면 됩니다. 약 10~20분 소요.

```
cd C:\PP\job_monitor
python detect_ats.py
```

완료 후 `ats_map.json` 파일이 생성됩니다.  
중간에 인터넷이 끊겨도 재실행하면 이어서 진행합니다.

---

## 12. 동작 테스트

### 뉴스레터 테스트

LM Studio 서버가 켜진 상태에서:

```
cd C:\PP\news_digest
python main.py
```

**정상 출력 예시:**
```
[2026-08-05 07:00] 시작 (LLM=local, 출력=email)
기업 986개 / 20개씩 배치
  배치 1/50... 18건
  ...
키워드 통과 124건 → LLM 스코어링
  [1/124] Hyundai unveils new IVI platform...
결과 — 핵심 18건 / 관련 31건
이메일 전송 완료
```

Gmail에서 이메일 수신 확인 → 성공

### 채용공고 테스트

```
cd C:\PP\job_monitor
python main.py
```

> ⚠️ **첫 실행 시**: DB가 비어있어 모든 공고가 "신규"로 처리됩니다.
> 두 번째 실행부터 진짜 신규 공고만 알림이 옵니다.

---

## 13. 자동 실행 등록

### 뉴스레터 (매일 07:00)

```
cd C:\PP\news_digest
schedule_setup.bat
```

### 채용공고 (매일 07:30)

```
cd C:\PP\job_monitor
schedule_setup.bat
```

### 등록 확인

`Win + R` → `taskschd.msc` → 작업 스케줄러 라이브러리:
- `AutomotiveNewsDigest` — 매일 07:00 ✅
- `AutomotiveJobMonitor` — 매일 07:30 ✅

---

## 14. LM Studio 자동 시작

Task Scheduler 실행 시 LM Studio 서버가 켜져 있어야 합니다.

### 방법: 시작프로그램 등록

1. `Win + R` → `shell:startup` → Enter
2. 시작프로그램 폴더 열림
3. LM Studio 바탕화면 아이콘 우클릭 → **바로 가기 만들기**
4. 만들어진 바로 가기를 시작프로그램 폴더로 이동

### LM Studio 서버 자동 켜짐 설정

LM Studio → Settings (톱니바퀴) → `Start server on app launch` 체크

---

## 15. 오류 해결

### 오류 1: pip install 실패

```
'pip'은(는) 내부 또는 외부 명령...으로 인식되지 않습니다
```

**원인:** Python이 PATH에 없음  
**해결:** Python 재설치 → 설치 시 `Add Python to PATH` 체크 확인

---

### 오류 2: LM Studio 연결 실패

```
LLM 오류: Connection refused
또는
LLM 오류: HTTPConnectionPool(...) Max retries exceeded
```

**원인:** LM Studio 서버가 꺼져 있음  
**해결:**
1. LM Studio 실행
2. 왼쪽 ↔ 탭 → 모델 선택 → **Start Server**
3. `http://localhost:1234/v1/models` 브라우저에서 확인

---

### 오류 3: LLM 모델명 오류

```
LLM 오류: model not found
또는 스코어가 항상 0
```

**원인:** config.py의 `LLM_MODEL` 값이 LM Studio 모델명과 다름  
**해결:**
1. `http://localhost:1234/v1/models` 접속
2. JSON에서 `"id"` 값 확인
3. `news_digest/config.py`의 `LLM_MODEL = '확인한값'` 으로 수정

---

### 오류 4: 이메일 전송 실패 (인증 오류)

```
SMTPAuthenticationError: (535, b'5.7.8 Username and Password not accepted')
```

**원인:** 일반 비밀번호 입력 또는 앱 비밀번호 오류  
**해결:**
1. [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)에서 앱 비밀번호 재발급
2. config.py의 `PASSWORD` 에 16자리 그대로 입력 (공백 포함)
3. `SENDER`가 올바른 Gmail 주소인지 확인

---

### 오류 5: 이메일 전송 실패 (연결 오류)

```
SMTPConnectError 또는 TimeoutError
```

**원인:** 방화벽 또는 네트워크 차단  
**해결:** 네트워크 설정에서 SMTP (포트 587) 허용 확인

---

### 오류 6: company_list.md 파일 없음

```
FileNotFoundError: company_list.md
```

**원인:** 코드 복사 시 파일 누락 또는 경로 오류  
**해결:**
- `C:\PP\news_digest\company_list.md` 파일 존재 확인
- `C:\PP\job_monitor\config.py`의 `COMPANY_FILE` 경로 확인

---

### 오류 7: detect_ats.py 중간에 멈춤

**원인:** 네트워크 타임아웃 또는 연결 불안정  
**해결:** 그냥 재실행 — 이미 감지된 기업은 스킵하고 이어서 진행

---

### 오류 8: 채용공고가 아예 안 옴

**원인 A:** `detect_ats.py` 미실행  
**해결:** `python detect_ats.py` 먼저 실행 → `ats_map.json` 생성 확인

**원인 B:** 첫 실행 후 다음 날부터 정상 (첫 실행은 모두 신규 처리)  
**해결:** 정상 동작, 다음 날 재실행

**원인 C:** LinkedIn 매칭 기업 없음  
**해결:** `ats_map.json`에 기업이 있으면 ATS 경로로 공고 수신됨. LinkedIn은 보조 소스.

---

### 오류 9: Task Scheduler가 실행되지 않음

**원인 A:** Python 경로 문제  
**확인:** 작업 스케줄러에서 태스크 우클릭 → **실행** → 로그 확인  
**해결:**

```
schedule_setup.bat을 열고 set PYTHON=python 부분을
python의 전체 경로로 변경:
set PYTHON=C:\Users\[사용자명]\AppData\Local\Programs\Python\Python312\python.exe
```

**원인 B:** LM Studio 서버 꺼짐 (뉴스레터)  
**해결:** [13. LM Studio 자동 시작](#13-lm-studio-자동-시작) 참고

---

### 오류 10: 뉴스 기사가 너무 적음

**원인:** KEYWORDS 키워드가 너무 좁음  
**해결:** `news_digest/config.py`의 `KEYWORDS` 에 키워드 추가:

```python
KEYWORDS = [
    ...기존 키워드...,
    'V2X', 'ethernet', 'OBD-II', 'SOTIF', 'UNECE',
    'software update', 'over-the-air', 'connected vehicle',
]
```

---

### 오류 11: 뉴스 기사가 관련 없는 것만 옴

**원인:** 키워드가 너무 일반적  
**해결:** LLM 스코어링 임계값 조정 — `news_digest/main.py`에서:

```python
# 기본값 (핵심: 2개↑, 일반: 1개)
(high if len(kw) >= 2 else mid if len(kw) >= 4 else []).append(a)
# 더 엄격하게 (핵심: 3개↑, 일반: 2개)
(high if len(kw) >= 3 else mid if len(kw) >= 2 else []).append(a)
```

---

### 오류 12: LM Studio 속도가 너무 느림

**증상:** 기사 스코어링에 수십 분 소요  
**해결 A:** LM Studio → Settings → GPU Offload 레이어 수 최대로 증가  
**해결 B:** 더 작은 모델로 교체 (Llama 3.2 3B)  
**해결 C:** 키워드 프리필터를 강화해 LLM 호출 수 줄이기:
```python
# news_digest/config.py - KEYWORDS를 더 구체적으로 수정
```

---

### 오류 13: ats_map.json이 비어 있음

```json
{}
```

**원인:** detect_ats.py가 모든 기업에서 ATS를 찾지 못함  
**해결:** 정상일 수 있음. 기업들이 Greenhouse/Lever를 사용하지 않거나 슬러그가 다를 수 있음. LinkedIn 경로로 공고 수신 가능.

---

### 오류 14: 모듈을 찾을 수 없음

```
ModuleNotFoundError: No module named 'feedparser'
```

**해결:**
```
pip install feedparser openai requests beautifulsoup4
```

---

### 오류 15: 윈도우 인코딩 오류 (한글 깨짐)

```
UnicodeEncodeError: 'cp949' codec can't encode character
```

**해결:** cmd 대신 PowerShell 사용, 또는 cmd에서:
```
chcp 65001
python main.py
```

---

## 16. 운영 중 FAQ

### Q. 이메일이 매일 안 오면?

1. 작업 스케줄러에서 마지막 실행 시각 확인
2. LM Studio 서버 켜져 있는지 확인
3. cmd에서 직접 `python main.py` 실행해서 오류 확인

---

### Q. 채용공고가 처음에 너무 많이 옴

**정상입니다.** 첫 실행에서 DB가 비어 있으므로 기존 공고 전부가 "신규"로 처리됩니다. 두 번째 실행부터 진짜 신규 공고만 옵니다.

---

### Q. 특정 기업 공고가 계속 안 옴

**이유:** 해당 기업이 Greenhouse/Lever를 사용하지 않고, LinkedIn 검색에서도 매칭 안 됨  
**해결:** 해당 기업 채용 페이지를 직접 방문하거나, LinkedIn에서 회사 팔로우 후 알림 설정

---

### Q. 회사 목록을 수정하고 싶음

`C:\PP\news_digest\company_list.md` 직접 편집 (형식: `- 회사명`)  
변경 후 자동으로 반영 (재시작 불필요)

---

### Q. 키워드를 추가하고 싶음

뉴스: `news_digest/config.py` → `KEYWORDS` 목록에 추가  
채용공고: `job_monitor/config.py` → `JOB_KEYWORDS` 목록에 추가

---

### Q. 수신 이메일 주소를 바꾸고 싶음

두 config.py의 `RECIPIENT` 값 수정

---

### Q. LM Studio 없이 Claude API로 뉴스 스코어링 하고 싶음

`news_digest/config.py`:
```python
LLM_MODE = 'claude'
LLM_MODEL = 'claude-haiku-4-5'
ANTHROPIC_API_KEY = 'sk-ant-...'  # Anthropic 콘솔에서 발급
```

`pip install anthropic` 추가 설치 필요

---

*최종 업데이트: 2026-08-05*  
*오류가 발생하면 오류 메시지를 그대로 복사해서 문의하세요.*
